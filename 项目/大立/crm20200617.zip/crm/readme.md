# crm

运行环境：
	MyEclipse直接导出crm为 crm.war包，发布至tomcat/wepapps目录即可.
	apache-tomcat-8.0.14  + JDK8  本地测试都使用32位软件测试通过.

发布的swagger接口访问地址：
	http://localhost:8080/crm/swagger-ui.html 
	
登录接口地址：
	http://localhost:8080/crm/admin/login?loginName=admin&pwd=123456

druid控制台进入界面
http://localhost:8080/crm/druid/login.html  账号：admin  admin
	
项目目录结构如下(com.esa2000):
1. business 业务模块
    - bean 非数据库实体类 BEAN
    - constants 常量
    - entity 数据库对应 BEAN
    - enums 枚举值
    - mapper 数据库接口定义
    - service 数据库操作
    - utils 工具类
    - web 控制类
2. configs 配置模块
    - exception 异常配置
    - interceptor 
    - shiro
    - timer 定时器
3. 

4.  MyEclipse spring boot配置热部署  https://blog.csdn.net/qq_34178998/article/details/79158076，
	配了这个容易出现问题，有时间再研究吧,
	很多框架包，跟spring boot的热部署都有冲突，不只shiro一个，原因就是springboot的热部署的加载器，不一样了
	
	下面的这个人解决了热部署问题：
	https://ask.csdn.net/questions/652023
	找到完美的解决方法了
	不让用 devtools 会浪费很多的时间
	
	解决方法
	我找到一种解决方案, 老规矩先说方案
	在 /resource/META-INF 目录下(没有就创建) 添加文件 spring-devtools.propertis
	加入代码
	
	restart.include.mapper=/mapper-[\\w-\\.]+jar
	restart.include.pagehelper=/pagehelper-[\\w-\\.]+jar
	# 因为我项目中引用了 org.crazycake:shiro-redis ,所以要引用下面这个配置
	restart.include.shiro=/shiro-[\\w-\\.]+jar
	加入后就见证了奇迹
	
	代码解释
	上面三行代码都是, 添加 jar 包到 restart 类加载器中 = 后面是具体的 jar 包名称, 或正则表达式
	
	原因
	DevTools 默认会对 IDE 中引入的所有项目使用 restart 类加载器, 对引入的 jar 包使用 base 类加载器, 因此要保证热部署时使用的类加载器一致就好了

5. 

6.