package tree;

import lombok.*;

/**
 * 数据
 */
@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TreeStructureDTO {
 
    /**
     * 节点id
     */
    private Integer id;
 
    /**
     * 节点名称
     */
    private String name;
 
    /**
     * 父节点
     */
    private Integer parentId;
 
    /**
     * 层级
     *
     */
    private Integer level;
 
    /**
     * 根目录
     */
    private Integer rootId;
 

}
