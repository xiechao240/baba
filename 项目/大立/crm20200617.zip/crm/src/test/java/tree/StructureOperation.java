package tree;

import com.alibaba.fastjson.JSON;
 
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
 
/**
 * 处理树
 */
public class StructureOperation {
 
    public static void main(String[] args){
        // 获取参数
        List<TreeStructureDTO> structureDTOS = packData();
        System.out.println("树结构param:" + JSON.toJSONString(structureDTOS));
        // 开始组装树
        // 现先获取根节点
        TreeStructureDTO rootTreeStructure = structureDTOS.stream()
                .filter(structureDTO -> structureDTO.getParentId() == null)
//        		.filter(structureDTO -> structureDTO.getParentId()==0 )
                .collect(Collectors.toList()).get(0);
        
        
        Tree rootTree = Tree.builder()
                .id(rootTreeStructure.getId())
                .name(rootTreeStructure.getName())
                .parentId(null)
                .build();
 
        Tree tree = StructureUtils.packageTree(structureDTOS, rootTree);
        System.out.println("树结构result:" + JSON.toJSONString(tree));
    }
 
    /**
     * 组装数据(模拟从数据库中获取)
     */
    public static List<TreeStructureDTO> packData(){
        List<TreeStructureDTO> result = new ArrayList<TreeStructureDTO>();
        result.add(TreeStructureDTO.builder().id(1).parentId(null).name("根节点").rootId(null).level(0).build());
        result.add(TreeStructureDTO.builder().id(2).parentId(1).name("1级节点A").rootId(1).level(1).build());
        result.add(TreeStructureDTO.builder().id(3).parentId(1).name("1级节点B").rootId(1).level(1).build());
 
        result.add(TreeStructureDTO.builder().id(4).parentId(2).name("2级节点A").rootId(1).level(2).build());
        result.add(TreeStructureDTO.builder().id(5).parentId(2).name("2级节点B").rootId(1).level(2).build());
        result.add(TreeStructureDTO.builder().id(6).parentId(3).name("2级节点C").rootId(1).level(2).build());
 
        result.add(TreeStructureDTO.builder().id(7).parentId(5).name("3级节点A").rootId(1).level(3).build());
        result.add(TreeStructureDTO.builder().id(8).parentId(6).name("3级节点B").rootId(1).level(3).build());
        result.add(TreeStructureDTO.builder().id(9).parentId(6).name("3级节点C").rootId(1).level(3).build());
        result.add(TreeStructureDTO.builder().id(10).parentId(null).name("根节点2").rootId(null).level(0).build());
 
        return result;
    }
}
