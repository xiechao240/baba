package tree;

import lombok.*;

import java.util.List;
 
@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Tree {
 
    private Integer id;
 
    private String name;
 
    private Integer parentId;
 
    private List<Tree> children;

}
