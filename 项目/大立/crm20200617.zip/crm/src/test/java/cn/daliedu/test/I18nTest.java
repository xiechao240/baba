package cn.daliedu.test;
//package com.esa2000.test;
//
//import java.time.LocalDateTime;
//
//import javax.annotation.Resource;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//
//import com.esa2000.config.param.SmsParamConfig;
//import com.esa2000.entity.ActivitySignIn;
//import com.esa2000.entity.vo.SmsCodeVO;
//import com.esa2000.exception.BusinessException;
//import com.esa2000.service.ActivitySignInService;
//import com.esa2000.shiro.redis.RedisUtil;
//import com.esa2000.util.JsonHelper;
//import com.esa2000.util.Log4jUtil;
//import com.esa2000.util.MessageUtil;
//import com.esa2000.util.Result;
//
//import io.swagger.annotations.ApiImplicitParam;
//import io.swagger.annotations.ApiImplicitParams;
//import io.swagger.annotations.ApiOperation;
//
///**
// * @author xiechao
// * @time 2019年3月13日 下午4:17:14
// * @version 1.0.0 
// * @description  此类不要去运行，为保留i18n国际化的写法，目前项目没有用到国际化了
// */
//public class I18nTest {
//	@Resource
//    private RedisUtil redisUtil;
//	
//	@Autowired
//	ActivitySignInService activitySignInService;
//	
//	@ApiOperation(value ="非会员签到")
//	@ApiImplicitParams({
//		@ApiImplicitParam(paramType = "query",dataType = "String",name ="cmsActivityId",value= "活动ID",required=true),
//		@ApiImplicitParam(paramType = "query",dataType = "String",name ="name",value= "姓名",required=true),
//		@ApiImplicitParam(paramType = "query",dataType = "String",name ="companyName",value= "公司名称",required=true),
//		@ApiImplicitParam(paramType = "query",dataType = "String",name ="departmentName",value= "部门",required=true),
//		@ApiImplicitParam(paramType = "query",dataType = "String",name ="mobile",value= "手机号码",required=true),
//		@ApiImplicitParam(paramType = "query",dataType = "String",name ="validateCode",value= "短信验证码",required=true),})
//	@PostMapping("/activitySignInByNoVip")
//	public Result activitySignInByNoVip(@RequestParam String cmsActivityId, @RequestParam String name, @RequestParam String companyName,
//			@RequestParam String departmentName, @RequestParam String mobile,@RequestParam String validateCode){
//		try {
//			//判断验证码是否正确
//			//1.获得验证码数据，校验验证码
//	        Object obj = redisUtil.get(mobile);
//	        //判断验证码是否已过期
//	        if(obj == null){
//	            throw  new BusinessException(MessageUtil.getMessage("sign.sms.code.noSend"));
//	        }
//	        String  jsonStr = (String)obj;
//	        Log4jUtil.info("个人银行卡绑定时，校验redis中获取存储的手机验证码：" + jsonStr);
//	        
//	        SmsCodeVO smsCodeVO = JsonHelper.getJsonToBean(jsonStr,SmsCodeVO.class);
//	        if(smsCodeVO == null){
//	            throw  new BusinessException(MessageUtil.getMessage("sign.sms.code.expire"));
//	        }
//	        if(System.currentTimeMillis()>smsCodeVO.getExpireTime()){
//	            throw  new BusinessException(MessageUtil.getMessage("sign.sms.code.expire"));
//	        }
//
//	        if(!smsCodeVO.getSmsCode().equals(validateCode)){
//	            int failCounts = smsCodeVO.getFailCounts()+1;
//	            if(SmsParamConfig.RE_CHECK_ERROR >0 && failCounts == SmsParamConfig.RE_CHECK_ERROR){
//	                redisUtil.del(mobile);
//	                throw  new BusinessException(MessageUtil.getMessage("sign.sms.code.error.counts.pass"));
//	            }
//	            smsCodeVO.setFailCounts(failCounts);
//	            //失败次数加1并重新设置超时时(过期时间-当前时间)
//	            redisUtil.set(mobile,JsonHelper.toJson(smsCodeVO),(smsCodeVO.getExpireTime()-System.currentTimeMillis())/1000);
//	            throw  new BusinessException(MessageUtil.getMessage("sign.sms.code.error"));
//	        }
//
//	        //3.验证通过,清除短信验证码缓存
//	        redisUtil.del(mobile);
//			
//			 //根据签到表中的mobile判断，该手机号码是否已经签到过
//			boolean flag = activitySignInService.getIsSignInByMobile(cmsActivityId, mobile);
//			if(!flag){
//				ActivitySignIn entity = new ActivitySignIn();
//				entity.setCmsActivityId(cmsActivityId);
//				entity.setName(name);
//				entity.setCompanyName(companyName);
//				entity.setDepartmentName(departmentName);
//				entity.setMobile(mobile);
//				entity.setCreateTime(LocalDateTime.now());
//				
//				activitySignInService.save(entity);
//				
//				return Result.success("签到成功");
//			}
//			
//			return Result.error("该活动，您已经签到过了");
//		} catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("获取活动列表失败，失败的原因："+e.getMessage());
//		}
//	}
//}
