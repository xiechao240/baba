package cn.daliedu.test;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Vector;

/**
 * @author xiechao
 * @time 2019年10月26日 上午10:21:52
 * @version 1.0.0
 * @description
 */
public class StackQueue {
	public static void main(String[] args) {
		stack();
//		queue();
	}

	// 堆栈
	public static void stack() {
		Vector<String> stack = new Vector<String>();
		stack.add("aaa");
		stack.add("bbb");
//		stack.add("ccc");
//		stack.add("ddd");
//		stack.add("fff");
		System.out.println("---------------------------");
		System.out.println("size" + stack.size());

		String aa;
		try {
			while ((aa = stack.lastElement()) != null) {
				System.out.println("a---" + aa);
				stack.removeElement(aa);
				// break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("size" + stack.size());
	}
	
	
	//  队列
	public static void queue() {
		Queue<String> queue = new LinkedList<>();
		queue.offer("Hello");
		queue.offer("world");
		queue.offer("I m find");
		System.out.println("--------------------------");
		System.out.println(queue.size());
		String aa;
		while ((aa = queue.poll()) != null) {
			System.out.println("queue---" + aa);
		}
		System.out.println(queue.size());
		System.out.println("--------------------------");
	}

}
