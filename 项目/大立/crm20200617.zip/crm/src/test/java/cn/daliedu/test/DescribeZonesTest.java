package cn.daliedu.test;

/**
 * @author xiechao
 * @time 2019年4月23日 上午11:14:46
 * @version 1.0.0 
 * @description 
 */
public class DescribeZonesTest {
	public static void main(String [] args) {
	}   
}
