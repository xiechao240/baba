package cn.daliedu.test;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.core.Ordered;

import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.UserOrgAreaEntity;
import cn.daliedu.enums.UserTypeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.util.ArithUtil;
import cn.daliedu.util.DateUtil;
import cn.daliedu.util.JsonUtil;
import cn.daliedu.util.StringUtil;

/**
 * @author xiechao
 * @time 2019年1月25日 上午10:52:35
 * @version 1.0.0 
 * @description 
 */
public class Test {
	
	private String name;
	

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}
	




	public static void main(String[] args) {
		try {
//			Test test = new Test();
//			test.setName("xiechao");
//			
//			System.out.println(test.getClass());
//			System.out.println(test.getClass().getName());
//			System.out.println(test.getClass().getField("name"));
			
			
//			String s = null;
//			if(s == null){
//				System.out.println("s为空。。。。");
//			}
//			
//			if(null == s){
//				
//			}
			
//			System.out.println(VipTypeEnum.isInclude("1"));;
			
//			String cookie = "SHIRO_SESSION_ID=428e373c-1eb7-49d9-92ec-8f30a86d30fd";
//			System.out.println(cookie.substring(cookie.indexOf("=")+1, cookie.length()));
//			
//			String Token = "Token=18697d1f-d4e0-4341-bb02-0ec91417cd39; SHRIOSESSIONID=286a6e2d-c94b-4d01-9716-200ad077d58b";
//			String[] arr = Token.split("; ");
//			System.out.println(arr[0]);
//			System.out.println(arr[1]);
//			
//			System.out.println(arr[0].substring(arr[0].indexOf("=")+1, arr[0].length()));
			
//			System.out.println(LocalDateTime.now().toString());
//			System.out.println(LocalDate.now().toString());
//			System.out.println(DateUtil.getDay());
//			
//			System.out.println(DateUtil.getDateMonth());
			
//			System.out.println(DateUtil.getYear());
//			System.out.println(DateUtil.getMonth());
//			System.out.println(DateUtil.getDay());
			
//			System.out.println(Calendar.getInstance().get(Calendar.YEAR));
//			System.out.println(Calendar.getInstance().get(Calendar.MONTH));
//			System.out.println(Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
//			
//			
//			
//			System.out.println("我".length());
			
//			System.out.println(Integer.parseInt("我"));
//			System.out.println(Integer.parseInt("123"));
			
//			StringUtil.validatePercentage("-10", "xxx");
			
//			System.out.println(ProjectStateEnum.isInclude("1"));
//			System.out.println(ProjectStateEnum.isInclude("10"));
			
//			String activityTime = "2019-05-01";
//			
//			DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
////			LocalDateTime avtiveDateTime = LocalDateTime.parse(activityTime, df);
////			System.out.println(avtiveDateTime);
//			
//			LocalDate avtiveDateTime2 = LocalDate.parse(activityTime, df);
//			System.out.println(avtiveDateTime2);
			
			
//			System.out.println(StringUtil.validateMobile("18390986952"));
			
//			String cookie = "JSESSIONID=E16CE4E58E7612832A8C49B7B19454CE; SHIRO_SESSION_ID=548460f4-7c1b-4dc0-8b6c-9969e00c2ecf";
//			String cookie = "SHIRO_SESSION_ID=548460f4-7c1b-4dc0-8b6c-9969e00c2ecf;JSESSIONID=E16CE4E58E7612832A8C49B7B19454CE";
//			String sessionId = "";
//			if(cookie.indexOf("SHIRO_SESSION_ID")!=-1){
//        		sessionId = cookie.substring(cookie.indexOf("SHIRO_SESSION_ID")+17, cookie.indexOf("SHIRO_SESSION_ID")+53);
//        	}
//			System.out.println(sessionId);
			
			
//			String orgIds = "2";
//			String arr[] = orgIds.split(",");
//			System.out.println("数组长度：" + arr.length);
//			System.out.println(arr[0]);
			
			
//			if(orgIds!=null && !orgIds.trim().equals("")){
//				String arr[] = orgIds.split(",");
//					for(String str: arr){
//						System.out.println("字符串：" + str);
//					}
//			}else{
//				System.out.println("机构ID为空");
//			}
			
//			Map<String, String> map = new HashMap<String, String>();
//			map.put("1", "1");
//			
//			System.out.println(map.get("2"));
			
			
			
//			String orgIds = "[1,2,3]";
//			String orgIds = "[]";
//			if(orgIds!=null && !orgIds.trim().equals("")){
//				orgIds = orgIds.replace("[", "");
//				System.out.println(orgIds);
//				
//				orgIds = orgIds.replace("]", "");
//				System.out.println(orgIds);;
//				if(orgIds.equals("")){
//					System.out.println("为空");
//				}
//			}
			
//			List<String> list = JsonHelper.getJsonToList(orgIds, String.class);
//			for(String str : list){
//				System.out.println(str);
//			}
//			System.out.println("aaaa");
//			
//			if(list.contains("2")){
//				System.out.println("包含2");
//			}
//			if(list.size()>0){
//				System.out.println("大于 0");
//			}else{
//				System.out.println("集合为空");
//			}
			
			
//			OrgEntity orgEntity = new OrgEntity();
//			orgEntity.setOrgType("1");
//			if(orgEntity.getOrgType().equals("2") || orgEntity.getOrgType().equals("3")){
//				throw new BusinessException("您当前所在的组织机构有问题，您无权限操作，请联系管理员");
//			}
			
//			System.out.println(DateUtil.getDate("yyyyMMddHHmmss"));
			
//			String orgName = "湖南分校-->营销部-->";
//			System.out.println(orgName.substring(orgName.length()-3, orgName.length()));
//			if(orgName.substring(orgName.length()-3, orgName.length()).equals("-->")){
//				System.out.println(orgName.substring(0, orgName.length()-3));
//			}
			
//			String[] str = new String[]{"1","2","3"};
//			System.out.println(str.toString());
			
//			String str = "2019-10-28 15:58:36.0";
//			Date date = DateUtil.parseDate(str);
//			System.out.println(date);
			
//			Date date = DateUtil.strToDate(str);
//			System.out.println(DateUtil.getDate(DateUtil.DATE_FORMATE_2));
//			System.out.println(DateUtil.formatDate(date, DateUtil.DATE_FORMATE_2));;
			
			
//			Integer num1 = 10;
//			Integer num2 = 10;
//			if(num1==num2){
//				System.out.println("==相等");
//			}
//			if(num1.equals(num2)){
//				System.out.println("equals相等");
//			}
			
//			System.out.println(LocalDateTime.now());
//			System.out.println(LocalDateTime.now().toLocalDate());
//			System.out.println(LocalDateTime.now().toLocalTime());
			
//			double d1 = 3L;
//			double d2 = 4L;
//			System.out.println(ArithUtil.div(d1, d2));
//			
//			long l1 = 3L;
//			long l2 = 4L;
//			System.out.println(ArithUtil.div(l1, l2));
			
//			String customerTagIds = "[]";
//			List<Integer> customerTagIdList = JsonUtil.getJsonToList(customerTagIds, Integer.class);
//			if(customerTagIdList!=null && customerTagIdList.size()>0){
//				for(Integer num : customerTagIdList){
//					System.out.println(num);
//				}
//			}else{
//				System.out.println("为空");
//			}
//			
//			System.out.println(LocalDate.now().toString());
			
			
//			String str = "手机（必填）";
//			System.out.println(str.indexOf("手机"));
//			System.out.println(str.indexOf("电话"));
//			if(str.indexOf("手机")!=-1){
//				System.out.println("aaa");
//			}else{
//				System.out.println("bbb");
//			}
			
//			String orgIds = "1";
//			int[] ints = StringUtil.stringToInt(orgIds.split(","));
//			for(int i : ints){
//				System.out.println(i);
//			}
//			
//			System.out.println(Ordered.HIGHEST_PRECEDENCE);
			
			
			
//			String[] atp = {"Rafael Nadal", "Novak Djokovic",  
//				       "Stanislas Wawrinka",  
//				       "David Ferrer","Roger Federer",  
//				       "Andy Murray","Tomas Berdych",  
//				       "Juan Martin Del Potro"};  
//			List<String> players =  Arrays.asList(atp);  
				  
			// 以前的循环方式  
//			for (String player : players) {  
//				    System.out.print(player + "; ");  
//			}  
				  
			// 使用 lambda 表达式以及函数操作(functional operation)  
//			players.forEach((player) -> System.out.print(player + "; "));  
				   
			// 在 Java 8 中使用双冒号操作符(double colon operator)  
//			players.forEach(System.out::println);
			
			
			
			List<Integer> userBranchOrgIdList = new ArrayList<Integer>();
			List<Integer> receiveUserBranchOrgIdList = new ArrayList<Integer>();
			userBranchOrgIdList.add(1);
			userBranchOrgIdList.add(2);
			userBranchOrgIdList.add(3);
			
			receiveUserBranchOrgIdList.add(1);
			receiveUserBranchOrgIdList.add(2);
//			receiveUserBranchOrgIdList.add(3);
//			receiveUserBranchOrgIdList.add(4);
			
//			if(receiveUserBranchOrgIdList.containsAll(userBranchOrgIdList)){
//				System.out.println("全部包含");
//			}else{
//				System.out.println("没有全部包含");
//			}
			
			
			List<String> userTypes = new ArrayList<String>();
			userTypes.add(UserTypeEnum.TYPE_1.getValue());
			userTypes.add(UserTypeEnum.TYPE_2.getValue());
			userTypes.add(UserTypeEnum.TYPE_3.getValue());
			userTypes.add(UserTypeEnum.TYPE_4.getValue());
			userTypes.add(UserTypeEnum.TYPE_5.getValue());
			userTypes.add(UserTypeEnum.TYPE_6.getValue());
			userTypes.add(UserTypeEnum.TYPE_7.getValue());
			
			String userType = "2";
			if(userType.equals("2")){
				userTypes.remove(UserTypeEnum.TYPE_1.getValue());
				userTypes.forEach(str ->{
					System.out.println(str);
				});
			}
			
			
				
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
