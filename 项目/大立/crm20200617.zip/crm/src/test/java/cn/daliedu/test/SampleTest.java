//package cn.daliedu.test;
//
//import java.math.BigInteger;
//import java.time.LocalDateTime;
//import java.util.List;
//import java.util.Map;
//import java.util.UUID;
//
//import javax.annotation.Resource;
//
//import org.junit.Assert;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringRunner;
//
//import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
//
//import cn.daliedu.mapper.DictMapper;
//import cn.daliedu.mapper.MenuMapper;
//import cn.daliedu.mapper.UserMapper;
//
//
//import cn.daliedu.entity.DictEntity;
//import cn.daliedu.entity.MenuEntity;
//import cn.daliedu.entity.UserEntity;
//
//@RunWith(SpringRunner.class)
//@SpringBootTest
//public class SampleTest {
//
//	@Resource
//	private UserMapper userMapper;
//
//	@Resource
//	private ActivityMapper activityMapper;
//	
//	
//	@Resource
//	DictMapper dictMapper;
//	
//	@Resource
//	MenuMapper menuMapper;
//
//	@Test
//	public void testSelect() {
//		Integer roleId = 1;
////		List roleMenus = roleMenuMapper.selectList(new QueryWrapper<RoleMenu>().select("menu_id").eq("role_id", roleId));
////		//打印结果,很明显，无法返回单列集合，只能返回RoleMenu 的集合，说明这个框架还不是特别好，这种需求还是要自定义sql来完成
////		//[RoleMenu{roleId=null, menuId=1011}, RoleMenu{roleId=null, menuId=10110}, RoleMenu{roleId=null, menuId=101101}, RoleMenu{roleId=null, menuId=101102}]
////		System.out.println(roleMenus);
////		
////		
////		List<Map<String, Object>> roleMenu = roleMenuMapper.selectMaps(new QueryWrapper<RoleMenu>().select("menu_id").eq("role_id", roleId));
////		//打印结果，可以适用很多场景，但还是无法直接将这个map传入下面的方法去使用
////		//[{menu_id=1011}, {menu_id=10110}, {menu_id=101101}, {menu_id=101102}]
////		System.out.println(roleMenu);
//		
//		
////		List roleMenussss = roleMenuMapper.selectObjs(new QueryWrapper<RoleMenu>().select("menu_id").eq("role_id", roleId));
////		//打印结果，selectObjs方法还是打印下面的结果
////		//[RoleMenu{roleId=null, menuId=1011}, RoleMenu{roleId=null, menuId=10110}, RoleMenu{roleId=null, menuId=101101}, RoleMenu{roleId=null, menuId=101102}]
////		System.out.println(roleMenussss);
//		
//		
////		List<Menu> menuList = menuMapper.selectList(new QueryWrapper<Menu>().in("menu_id", roleMenussss));
////		System.out.println("菜单集合：" + menuList);
//		
//		List<MenuEntity> menuList = menuMapper.getMenuListByRoleId(roleId);
//		System.out.println("菜单集合：" + menuList);
//		
//		// System.out.println(("----- selectAll method test ------"));
//		// List<User> userList = userMapper.selectList(null);
//		// System.out.println(userList.get(1).getEmail());
//		// System.out.println("数据集合大小：" + userList.size());
//		//
//		// userList.forEach(System.out::println);
//
//		// int num = userMapper.deleteById(1);
//		// System.out.println("删除id后返回结果：" + num);
//
//		// User user = new User();
//		// user.setId(2l);
//		// boolean flag = user.deleteById();
//		// System.out.println("删除id后返回结果：" + flag);
//
//		// User user = new User();
//		// user.setAge(18);
//		// user.setEmail("xiechao240@163.com");
//		// user.setName("xiechao");
//		// userMapper.insert(user);
//
//		try {
//			//新增操作
////			Activity entity = new Activity();
////			entity.setContent("2019新年快乐");
////			entity.setTitle("新年快乐9");
////			entity.setCreateTime(LocalDateTime.now());
////			activityMapper.insert(entity);
//			
//			
//			
////			for(int i=1;i<100;i++){
////				Activity entity = new Activity();
////				entity.setContent("2019新年快乐");
////				entity.setTitle("新年快乐" + i);
////				entity.setCreateTime(LocalDateTime.now());
////				activityMapper.insert(entity);
////			}
//			
//			
//			//删除操作
////			int num = activityMapper.deleteById("469b1787389bf83a97c3aaa416778b23");
////			System.out.println("删除结果：" + num);
//			
//			
//			//查询操作           因为配置了逻辑删除，默认会在后面增加deleted=0
//			//查询title为新年快乐1的活动数据，
////			String title = "新年快乐1";
////			//List<Activity> activityList = activityMapper.selectList(new QueryWrapper<Activity>().eq("deleted", "0"));
////			List<Activity> activityList = activityMapper.selectList(new QueryWrapper<Activity>().eq("title", title));
////			System.out.println("数据集合大小：" + activityList.size());
////			activityList.forEach(System.out::println);
//			
//			
//			//分页操作
////			List<Dict> dictList = dictMapper.selectList(new QueryWrapper<Dict>().eq("type", "vip_type"));
////			dictList.forEach(System.out::println);
//			
//			
//			DictEntity dict = dictMapper.selectOne(new QueryWrapper<DictEntity>().eq("type", "vip_type"));
//			System.out.println(dict);
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		
//
//	}
//}
