package cn.daliedu.test;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

public class TestVector {
	public static void main(String[] args) {
		// new TestVector().test01();
		LinkedList<String> list = new LinkedList<String>();
		// 压栈，先进后出
		list.push("西游记");
		list.push("三国演义");
		list.push("石头记");
		list.push("水浒传");
		System.out.println(list);
		System.out.println(list.size());
		
		for(int i=0;i<4;i++){
			System.out.println(list.pop());
		}
		
		// 弹栈
//		String str1 = list.pop();
//		System.out.println(str1);
//		String str2 = list.pop();
//		System.out.println(str2);
//		String str3 = list.pop();
//		System.out.println(str3);
//		String str4 = list.pop();
//		System.out.println(str4);
		
		
		
//		System.out.println("最后一个：" + list.pop());
		
//		System.out.println(list.size());// 0
//		System.out.println(list); // []

	}

	public void test01() {
		Vector<String> hs = new Vector<String>();
		hs.add("aa");
		hs.add("bb");
		hs.add("aa");
		hs.add("cc");
		hs.add("aa");
		hs.add("dd");
		printSet(hs);
		// printSet2(hs);
	}

	public void printSet(List hs) {
		Iterator iterator = hs.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}

	public void printSet2(Vector<String> hs) {
		Enumeration<String> elements = hs.elements();
		while (elements.hasMoreElements()) {
			System.out.println(elements.nextElement());
		}
	}

}
