package cn.daliedu.test;
//package com.esa2000.test;
//
//
//import java.util.List;
//
//import javax.annotation.Resource;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringRunner;
//import org.springframework.util.CollectionUtils;
//
//import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
//import com.baomidou.mybatisplus.core.metadata.IPage;
//import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
//import cn.daliedu.config.param.SysParamConfig;
//import cn.daliedu.mapper.ActivityMapper;
//
//import cn.daliedu.entity.Activity;
//
///**
// * @author miemie
// * @since 2018-08-10
// */
//@RunWith(SpringRunner.class)
//@SpringBootTest
//public class PaginationTest {
//
//    @Resource
//    private ActivityMapper activityMapper;
//
//    @Test
//    public void tests() {
//    	String name = "";
//        System.out.println("----- baseMapper 自带分页 ------");
//        long pageSize = SysParamConfig.PAGE_SIZE;
//        System.out.println("分页大小：" + pageSize);
//        Page<Activity> page = new Page<>(1, pageSize);
//        
//        //动态拼接的写法
//        QueryWrapper<Activity>  wrapper = new QueryWrapper<Activity>();
//        wrapper.orderByDesc("create_time");
//            
//        if(name!=null && !name.equals("")){
//            wrapper.eq("name", "Jack");
//        }
//        IPage<Activity> activityIPage = activityMapper.selectPage(page, wrapper);
//        
//        
//        //棉花糖式写法
////        IPage<Activity> activityIPage = activityMapper.selectPage(page, new QueryWrapper<Activity>()
////        		//.orderByAsc("create_time")
////        		.orderByDesc("create_time")
//////        		if(str!=null){  这种动态拼加，怎么不支持呢？
//////        			.orderByDesc("create_time");
//////        		}
////        		);
////               // .eq("age", 20).eq("name", "Jack"));
//        
//        
//        System.out.println("总条数 ------> " + activityIPage.getTotal());
//        System.out.println("当前页数 ------> " + activityIPage.getCurrent());
//        System.out.println("当前每页显示数 ------> " + activityIPage.getSize());
//        print(activityIPage.getRecords());
//        System.out.println("----- baseMapper 自带分页 ------");
//
////        System.out.println("json 正反序列化 begin");
////        String json = JSON.toJSONString(page);
////        Page<Activity> page1 = JSON.parseObject(json, TypeBuilder.newInstance(Page.class).addTypeParam(Activity.class).build());
////        print(page1.getRecords());
////        System.out.println("json 正反序列化 end");
////
////        System.out.println("----- 自定义 XML 分页 ------");
////        MyPage<User> myPage = new MyPage<User>(1, 5).setSelectInt(20).setSelectStr("Jack");
////        ParamSome paramSome = new ParamSome(20, "Jack");
////        MyPage<User> userMyPage = mapper.mySelectPage(myPage, paramSome);
////        Assert.assertSame(myPage, userMyPage);
////        System.out.println("总条数 ------> " + userMyPage.getTotal());
////        System.out.println("当前页数 ------> " + userMyPage.getCurrent());
////        System.out.println("当前每页显示数 ------> " + userMyPage.getSize());
////        print(userMyPage.getRecords());
////        System.out.println("----- 自定义 XML 分页 ------");
//    }
//
//    private <T> void print(List<T> list) {
//        if (!CollectionUtils.isEmpty(list)) {
//            list.forEach(System.out::println);
//        }
//    }
//}
