package cn.daliedu.test;

import java.util.Random;

import com.aliyuncs.CommonRequest;
import com.aliyuncs.CommonResponse;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.exceptions.ServerException;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import cn.daliedu.entity.SmsTemplateEntity;
import cn.daliedu.util.StringUtil;

/**
 * @Title AliDayunSms
 * @Description 阿里大鱼短信接口开发
 * @author calvin
 * @date: 2018/8/9 下午1:28 
 */
public class AliyunSmsTest {
	// 阿里云
	private static final String product = "Dysmsapi";// 短信API产品名称（短信产品名固定，无需修改）
	private static final String domain = "dysmsapi.aliyuncs.com";// 短信API产品域名（接口地址固定，无需修改）
	private static final String accessKeyId = "hnblga1pqamuj7yi0n1b2qdu";// 你的accessKeyId
	private static final String accessKeySecret = "vICsq+LZWGNtZ9MO6SruJdCAryw=";// 你的accessKeySecret
	
	public static void sendSms(String mobile, String templateCode, String... param){
//		System.out.println(param[0]);
//		System.out.println(param[1]);
		
		String str = "尊敬的用户，您在大立教育的的登录账号为${name}，密码为${password}，请不要把密码泄露给其他人。";
		System.out.println(StringUtil.countStr(str, "$"));
		
		JsonArray array=new JsonArray();
		JsonObject lan1=new JsonObject();

		lan1.addProperty("id", 1);

		lan1.addProperty("name", "Java");

		lan1.addProperty("ide", "Eclipse");

		//将 lan1 添加到 array
		array.add(lan1);
		
		System.out.println(array);
		System.out.println(lan1);
		System.out.println(lan1.toString());
	}

    public static void main(String[] args) {
        sendSms("18390986952", "", "1");
    }

	/**
     * 生成随机的6位数，短信验证码
     * @return
     */
    private static String getMsgCode() {
        int n = 6;
        StringBuilder code = new StringBuilder();
        Random ran = new Random();
        for (int i = 0; i < n; i++) {
            code.append(Integer.valueOf(ran.nextInt(10)).toString());
        }
        return code.toString();
    }
    
    public static void sendSms() throws Exception{
    	
    	//设置超时时间-可自行调整
        System.setProperty("sun.net.client.defaultConnectTimeout", "10000");
        System.setProperty("sun.net.client.defaultReadTimeout", "10000");
        //初始化ascClient需要的几个参数
        final String product = "Dysmsapi";//短信API产品名称（短信产品名固定，无需修改）
        final String domain = "dysmsapi.aliyuncs.com";//短信API产品域名（接口地址固定，无需修改）
        //替换成你的AK
        final String accessKeyId = "hnblga1pqamuj7yi0n1b2qdu";//你的accessKeyId
        final String accessKeySecret = "vICsq+LZWGNtZ9MO6SruJdCAryw=";//你的accessKeySecret
        //初始化ascClient,暂时不支持多region（请勿修改）
        IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou", accessKeyId, accessKeySecret);
        DefaultProfile.addEndpoint("cn-hangzhou", "cn-hangzhou", product, domain);
        IAcsClient acsClient = new DefaultAcsClient(profile);
        //组装请求对象
        SendSmsRequest request = new SendSmsRequest();
        //使用post提交
        request.setMethod(MethodType.POST);
        //必填:待发送手机号。支持以逗号分隔的形式进行批量调用，批量上限为1000个手机号码,批量调用相对于单条调用及时性稍有延迟,验证码类型的短信推荐使用单条调用的方式；发送国际/港澳台消息时，接收号码格式为00+国际区号+号码，如“0085200000000”
        request.setPhoneNumbers("18390986952");
        //必填:短信签名-可在短信控制台中找到
        request.setSignName("大立教育");
        //必填:短信模板-可在短信控制台中找到，发送国际/港澳台消息时，请使用国际/港澳台短信模版
        request.setTemplateCode("SMS_175582380");
        //可选:模板中的变量替换JSON串,如模板内容为"亲爱的${name},您的验证码为${code}"时,此处的值为
        //友情提示:如果JSON中需要带换行符,请参照标准的JSON协议对换行符的要求,比如短信内容中包含\r\n的情况在JSON中需要表示成\\r\\n,否则会导致JSON在服务端解析失败
        //request.setTemplateParam("{\"code\":\"988756\"}");
        String msgCode = getMsgCode();
        request.setTemplateParam("{\"code\":\"" + msgCode + "\"}");
        //请求失败这里会抛ClientException异常
        SendSmsResponse sendSmsResponse = acsClient.getAcsResponse(request);
        if (sendSmsResponse.getCode() != null && sendSmsResponse.getCode().equals("OK")) {
            //请求成功
            System.out.println("=====success====");
        } else {
            System.out.println("=====fail=======");
        }
    }
}
