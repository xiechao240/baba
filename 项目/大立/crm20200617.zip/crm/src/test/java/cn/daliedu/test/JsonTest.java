package cn.daliedu.test;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;

import cn.daliedu.entity.CustomerSelfDefineItemConfigEntity;

/**
 * @author xiechao
 * @time 2019年9月29日 上午9:58:49
 * @version 1.0.0 
 * @description 
 */
public class JsonTest {
	
	/**
     * List<T> 转 json 保存到数据库
     */
    public static <T> String listToJson(List<T> ts) {
        String jsons = JSON.toJSONString(ts);
        return jsons;
    }

    /**
     * json 转 List<T>
     */
    public static <T> List<T> jsonToList(String jsonString, Class<T> clazz) {
        @SuppressWarnings("unchecked")
        List<T> ts = (List<T>) JSONArray.parseArray(jsonString, clazz);
        return ts;
    }

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		CustomerSelfDefineItemEntity entity = new CustomerSelfDefineItemEntity();
//		entity.setCustomerId("1");
//		entity.setTag("danban");
//		entity.setRemark("单班");
//		entity.setDefineItemName("零基础");
//		entity.setDefineItemValue(1);
//		
//		
//		CustomerSelfDefineItemEntity entity2 = new CustomerSelfDefineItemEntity();
//		entity2.setCustomerId("1");
//		entity2.setTag("danban");
//		entity2.setRemark("单班");
//		entity2.setDefineItemName("精讲班");
//		entity2.setDefineItemValue(2);
//		
//		
//		CustomerSelfDefineItemEntity bean = new CustomerSelfDefineItemEntity();
//		bean.setCustomerId("1");
//		bean.setTag("taoban");
//		bean.setRemark("套班");
//		bean.setDefineItemName("精品套餐A");
//		bean.setDefineItemValue(1);
//		
//		
//		CustomerSelfDefineItemEntity bean2 = new CustomerSelfDefineItemEntity();
//		bean2.setCustomerId("1");
//		bean2.setTag("taoban");
//		bean2.setRemark("套班");
//		bean2.setDefineItemName("精品套餐B");
//		bean2.setDefineItemValue(1);
//		
//		
//		List<CustomerSelfDefineItemEntity> list = new ArrayList<CustomerSelfDefineItemEntity>();
//		list.add(entity);
//		list.add(entity2);
//		list.add(bean);
//		list.add(bean2);
//		
//		System.out.println("list转json...............");
//		String jsonString = JsonTest.listToJson(list);
//		System.out.println(jsonString);;
//		
//		System.out.println();
//		System.out.println("json转List...........");
//		
//		List<CustomerSelfDefineItemEntity> arrList = JsonTest.jsonToList(jsonString, CustomerSelfDefineItemEntity.class);
//		for(CustomerSelfDefineItemEntity pojo : arrList){
//			System.out.println(pojo.getTag()+pojo.getRemark()+pojo.getDefineItemName());
//		}
	}

}
