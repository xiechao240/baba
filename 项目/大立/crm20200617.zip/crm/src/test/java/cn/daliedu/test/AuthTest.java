//package cn.daliedu.test;
//
//import java.util.Map;
//
//import org.springframework.boot.SpringApplication;
//
//import com.alibaba.fastjson.JSONObject;
//import cn.daliedu.config.param.GlobalParamConfig;
//import cn.daliedu.util.Base64Util;
//import cn.daliedu.util.HttpClientUtil;
//
///**
// * @author xiechao
// * @time 2019年3月11日 下午4:04:01
// * @version 1.0.0 
// * @description 
// */
//public class AuthTest {
//	public static String testCompanyinfo() throws Exception{
//		JSONObject json = new JSONObject();
//		
//		json.put("projectNo", GlobalParamConfig.BAKN_AUTH_PROJECT_NO);
//		json.put("account", GlobalParamConfig.BANK_AUTH_ACCOUNT);
//		json.put("password", GlobalParamConfig.BANK_AUTH_PASSWORD);
//		
//		json.put("companyName", "北京安证通信息科技股份有限公司");
//		
//		String result = HttpClientUtil.postJson(GlobalParamConfig.COMPANY_INFO_URL, Base64Util.encodeToString(json.toString().getBytes("utf-8")));
//		System.out.println("返回 结果：" + Base64Util.base64Decode(result));
//		
//		if(result!=null && !result.equals("")){
//			Map map = (Map) JSONObject.parse(Base64Util.base64Decode(result));
//			
//			String code = map.get("code").toString();
//			String data = map.get("data").toString();
//			
//			Map map2 = (Map) JSONObject.parse(data);
//			String farenName = map2.get("farenName").toString().trim();//接口返回法人姓名
//			String no = map2.get("no").toString().trim(); //接口返回证件号
//			
//			
//		}
//		return Base64Util.base64Decode(result);
//	}
//	
//	public static void main(String[] args) throws Exception {
//		
//		
//		System.out.println(testCompanyinfo());
//		
//		
//	}
//
//}
