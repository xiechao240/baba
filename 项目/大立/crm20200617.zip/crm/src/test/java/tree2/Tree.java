package tree2;

import lombok.*;

import java.util.List;
 
@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Tree {
 
	 private Long id;
	 
	    private String name;
	 
	    private Long parentId;
	 
	    private List<Tree> children;

}
