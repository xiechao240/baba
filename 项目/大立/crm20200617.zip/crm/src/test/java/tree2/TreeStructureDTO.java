package tree2;

import lombok.*;

/**
 * 数据
 */
@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TreeStructureDTO {
 
	/**
     * 节点id
     */
    private Long id;
 
    /**
     * 节点名称
     */
    private String name;
 
    /**
     * 父节点
     */
    private Long parentId;
 
    /**
     * 层级
     *
     */
    private Integer level;
 
    /**
     * 根目录
     */
    private Long rootId;

 

}
