package tree2;

 
import java.util.ArrayList;
import java.util.List;
 
public class StructureUtils {
 
	public static Tree packageTree(List<TreeStructureDTO> structureDTOS, Tree rootTree){
        if (structureDTOS != null && structureDTOS.size() > 0) {
            structureDTOS.forEach(structureDTO -> judgeObj(structureDTO, rootTree));
            if (rootTree.getChildren() != null && rootTree.getChildren().size() > 0) {
                rootTree.getChildren().forEach(r -> packageTree(structureDTOS, r));
            }
        }
        return rootTree;
    }
 
    public static void judgeObj(TreeStructureDTO structureDTO, Tree rootTree){
        List<Tree> children = rootTree.getChildren();
        if (children == null) {
            children = new ArrayList<>();
        }
        if (structureDTO.getParentId() != null && rootTree.getId().equals(structureDTO.getParentId())) {
            children.add(Tree.builder().id(structureDTO.getId()).name(structureDTO.getName()).parentId(structureDTO.getParentId()).build());
            rootTree.setChildren(children);
        }
    }
}
