package tree2;

import com.alibaba.fastjson.JSON;
 
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
 
/**
 * 处理树
 */
public class StructureOperation {
 
	public static void main(String[] args){
        // 获取参数
        List<TreeStructureDTO> structureDTOS = packData();
        System.out.println("树结构param:" + JSON.toJSONString(structureDTOS));
        // 开始组装树
        // 现先获取根节点
        TreeStructureDTO rootTreeStructure = structureDTOS.stream()
                .filter(structureDTO -> structureDTO.getParentId() == null)
                .collect(Collectors.toList()).get(0);
        
        //根据父节点找子孙节点
//        TreeStructureDTO rootTreeStructure = new TreeStructureDTO();
//        rootTreeStructure.setId(2L);
//        rootTreeStructure.setName("2级节点A");
        
        
        Tree rootTree = Tree.builder()
                .id(rootTreeStructure.getId())
                .name(rootTreeStructure.getName())
                .parentId(null)
                .build();
 
        Tree tree = StructureUtils.packageTree(structureDTOS, rootTree);
        System.out.println("树结构result:" + JSON.toJSONString(tree));
    }
 
    /**
     * 组装数据(模拟从数据库中获取)
     */
    public static List<TreeStructureDTO> packData(){
        List<TreeStructureDTO> result = new ArrayList<TreeStructureDTO>();
        result.add(TreeStructureDTO.builder().id(1L).parentId(null).name("根节点").rootId(null).level(0).build());
        result.add(TreeStructureDTO.builder().id(2L).parentId(1L).name("1级节点A").rootId(1L).level(1).build());
        result.add(TreeStructureDTO.builder().id(3L).parentId(1L).name("1级节点B").rootId(1L).level(1).build());
 
        result.add(TreeStructureDTO.builder().id(4L).parentId(2L).name("2级节点A").rootId(1L).level(2).build());
        result.add(TreeStructureDTO.builder().id(5L).parentId(2L).name("2级节点B").rootId(1L).level(2).build());
        result.add(TreeStructureDTO.builder().id(6L).parentId(3L).name("2级节点C").rootId(1L).level(2).build());
 
        result.add(TreeStructureDTO.builder().id(7L).parentId(5L).name("3级节点A").rootId(1L).level(3).build());
        result.add(TreeStructureDTO.builder().id(8L).parentId(6L).name("3级节点B").rootId(1L).level(3).build());
        result.add(TreeStructureDTO.builder().id(9L).parentId(6L).name("3级节点C").rootId(1L).level(3).build());
 
        return result;
    }

}
