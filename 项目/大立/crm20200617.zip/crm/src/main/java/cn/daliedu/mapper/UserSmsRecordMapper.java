package cn.daliedu.mapper;

import cn.daliedu.entity.UserSmsRecordEntity;

import java.util.Map;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 用户短信发送记录表 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-12-26
 */
public interface UserSmsRecordMapper extends BaseMapper<UserSmsRecordEntity> {
	
	/**
	 * 获取用户今天发送的短信数量
	 * @param userId
	 * @return
	 */
	public Integer getUserSmsCount(Map<Object, Object> map);
}
