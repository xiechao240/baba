package cn.daliedu.service;

import java.util.LinkedHashMap;
import java.util.List;

import com.baomidou.mybatisplus.extension.service.IService;

import cn.daliedu.entity.DictManyDetailEntity;
import cn.daliedu.entity.DictManyEntity;

/**
 * <p>
 * 存储2个维度的，一对多的数据字典 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-11-07
 */
public interface DictManyService extends IService<DictManyEntity> {
	
	
	
	/**
	 * 获取数据库中所有的数据字典类别
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<String, String>> getDictTypeList() throws Exception;
	
	/**
	 * 根据字典类别获取所有的数据字典
	 * @param tag 标签标识符
	 * @return
	 * @throws Exception
	 */
	public List<DictManyEntity> getDictValueByTag(String tag) throws Exception;
	
	/**
	 * 根据字典类别ID获取字典标签
	 * @param tag 标签标识符
	 * @return
	 * @throws Exception
	 */
	public DictManyEntity getDictValueByTagId(String tagId) throws Exception;
	
	
	/**
	 * 根据字典类别获取所有的数据字典
	 * @param tag 标签标识符
	 * @return
	 * @throws Exception
	 */
	public List<DictManyDetailEntity> getDictDetailByTagId(String tagId) throws Exception;
	
}
