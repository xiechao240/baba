package cn.daliedu.shiro.redis;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Sets;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisNode;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import redis.clients.jedis.JedisPoolConfig;

import java.text.SimpleDateFormat;
import java.util.Set;

/**
 * @Auther: Administrator
 * @Date: 2018/7/31 09:29
 * @Description:
 */
@Configuration
@EnableCaching
// maxInactiveIntervalInSeconds 默认是 1800 秒过期, 这里测试修改为 60 秒
// @EnableRedisHttpSession(maxInactiveIntervalInSeconds = 1800)
// @PropertySource("classpath:configs/redis/redis.properties")
public class RedisConfig extends CachingConfigurerSupport {
	@Value("${spring.redis.host}")
	private String host;

	@Value("${spring.redis.port}")
	private Integer port;

	@Value("${spring.redis.database}")
	private Integer database;

	@Value("${spring.redis.timeout}")
	private Integer timeout;

	@Value("${spring.redis.password}")
	private String password;

	@Value("${spring.redis.max-idle}")
	private Integer maxIdle;

	@Value("${spring.redis.min-idle}")
	private Integer minIdle;

	@Value("${spring.redis.max-total}")
	private Integer maxTotal;

	@Value("${spring.redis.max-wait-millis}")
	private Integer maxWaitMillis;

	@Value("${spring.redis.min-evictable-idle-time-millis}")
	private Integer minEvictableIdleTimeMillis;

	@Value("${spring.redis.num-tests-per-eviction-run}")
	private Integer numTestsPerEvictionRun;

	@Value("${spring.redis.time-between-eviction-runs-millis}")
	private long timeBetweenEvictionRunsMillis;

	@Value("${spring.redis.test-on-borrow}")
	private boolean testOnBorrow;

	@Value("${spring.redis.test-on-return}")
	private boolean testOnReturn;

	@Value("${spring.redis.test-while-idle}")
	private boolean testWhileIdle;

	@Value("${spring.redis.cluster.nodes}")
	private String clusterNodes;

	@Value("${spring.redis.cluster.max-redirects}")
	private Integer maxRedirects;

	@Value("${spring.redis.sentinel.host1}")
	private String senHost1;

	@Value("${spring.redis.sentinel.port1}")
	private Integer senPort1;

	@Value("${spring.redis.sentinel.host2}")
	private String senHost2;

	@Value("${spring.redis.sentinel.port2}")
	private Integer senPort2;

	/**
	 * JedisPoolConfig 连接池
	 */
	@Bean
	public JedisPoolConfig jedisPoolConfig() {
		JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
		// 最大空闲数
		jedisPoolConfig.setMaxIdle(maxIdle);
		// 最小空闲数
		jedisPoolConfig.setMinIdle(minIdle);
		// 连接池的最大数据库连接数
		jedisPoolConfig.setMaxTotal(maxTotal);
		// 最大建立连接等待时间
		jedisPoolConfig.setMaxWaitMillis(maxWaitMillis);
		// 逐出连接的最小空闲时间, 默认 1800000 毫秒( 30分钟)
		jedisPoolConfig.setMinEvictableIdleTimeMillis(minEvictableIdleTimeMillis);
		// 每次逐出检查时, 逐出的最大数目, 如果为负数就是 : 1/abs(n), 默认 3
		jedisPoolConfig.setNumTestsPerEvictionRun(numTestsPerEvictionRun);
		// 逐出扫描的时间间隔(毫秒), 如果为负数, 则不运行逐出线程, 默认 -1
		jedisPoolConfig.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRunsMillis);
		// 是否在从池中取出连接前进行检验, 如果检验失败, 则从池中去除连接并尝试取出另一个
		jedisPoolConfig.setTestOnBorrow(testOnBorrow);
		jedisPoolConfig.setTestOnReturn(testOnReturn);
		// 在空闲时检查有效性, 默认 false
		jedisPoolConfig.setTestWhileIdle(testWhileIdle);
		return jedisPoolConfig;
	}

	/**
	 * 配置工厂
	 */
	@Bean
	public JedisConnectionFactory jedisConnectionFactory(JedisPoolConfig jedisPoolConfig) {
		// 单机版配置
		JedisConnectionFactory JedisConnectionFactory = new JedisConnectionFactory(jedisPoolConfig);
		// 连接池
		JedisConnectionFactory.setPoolConfig(jedisPoolConfig);
		// IP 地址
		JedisConnectionFactory.setHostName(host);
		// 配置数据库
		JedisConnectionFactory.setDatabase(database);
		// 端口号
		JedisConnectionFactory.setPort(port);
		// 客户端超时时间单位是毫秒
		JedisConnectionFactory.setTimeout(timeout);
		// 如果 Redis 设置有密码
		JedisConnectionFactory.setPassword(password);
		return JedisConnectionFactory;

		// 集群的配置
		// return new JedisConnectionFactory(redisClusterConfiguration(),
		// jedisPoolConfig);

		// 配置哨兵
		// return new JedisConnectionFactory(sentinelConfiguration(),
		// jedisPoolConfig);
	}

	/**
	 * Redis 集群的配置
	 */
	private RedisClusterConfiguration redisClusterConfiguration() {
		RedisClusterConfiguration redisClusterConfiguration = new RedisClusterConfiguration();

		String[] serverArray = clusterNodes.split(",");

		Set<RedisNode> nodes = Sets.newHashSet();

		for (String ipPort : serverArray) {
			String[] ipAndPort = ipPort.split(":");
			nodes.add(new RedisNode(ipAndPort[0].trim(), Integer.valueOf(ipAndPort[1])));
		}

		redisClusterConfiguration.setClusterNodes(nodes);
		redisClusterConfiguration.setMaxRedirects(maxRedirects);

		return redisClusterConfiguration;
	}

	/**
	 * 配置 redis 的哨兵
	 */
	private RedisSentinelConfiguration sentinelConfiguration() {
		RedisSentinelConfiguration redisSentinelConfiguration = new RedisSentinelConfiguration();
		// 配置 master 的名称
		RedisNode redisNode = new RedisNode(host, port);
		redisNode.setName("myMaster");
		redisSentinelConfiguration.master(redisNode);
		// 配置 redis 的哨兵
		RedisNode senRedisNode;
		Set<RedisNode> redisNodeSet = Sets.newHashSet();
		senRedisNode = new RedisNode(senHost1, senPort1);
		redisNodeSet.add(senRedisNode);
		senRedisNode = new RedisNode(senHost2, senPort2);
		redisNodeSet.add(senRedisNode);

		redisSentinelConfiguration.setSentinels(redisNodeSet);
		return redisSentinelConfiguration;
	}

	/**
	 * 实例化 RedisTemplate 对象
	 */
	@Bean
	public RedisTemplate<String, Object> functionDomainRedisTemplate(RedisConnectionFactory redisConnectionFactory) {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
		initDomainRedisTemplate(redisTemplate, redisConnectionFactory);
		return redisTemplate;
	}

	/**
	 * 设置数据存入 redis 的序列化方式, 并开启事务
	 */
	private void initDomainRedisTemplate(RedisTemplate<String, Object> redisTemplate, RedisConnectionFactory factory) {
		// 如果不配置 Serializer, 那么存储的时候缺省使用 String, 如果用 User 类型存储, 那么会提示错误User
		// can't cast to String！
		RedisSerializer redisSerializer = new StringRedisSerializer();
		redisTemplate.setKeySerializer(redisSerializer);
		redisTemplate.setHashKeySerializer(redisSerializer);

		// 解决日期序列化问题
		ObjectMapper om = new ObjectMapper();
		om.setDateFormat(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"));
		redisSerializer = new GenericJackson2JsonRedisSerializer(om);
		// redisTemplate.setDefaultSerializer(redisSerializer);
		redisTemplate.setValueSerializer(redisSerializer);
		redisTemplate.setHashValueSerializer(redisSerializer);

		// 开启事务
		redisTemplate.setEnableTransactionSupport(true);

		redisTemplate.setConnectionFactory(factory);
	}

	/**
	 * 注入封装 RedisTemplate
	 */
	@Bean(name = "redisUtil")
	public RedisUtil redisUtil(RedisTemplate<String, Object> redisTemplate) {
		RedisUtil redisUtil = new RedisUtil();
		redisUtil.setRedisTemplate(redisTemplate);
		return redisUtil;
	}
}
