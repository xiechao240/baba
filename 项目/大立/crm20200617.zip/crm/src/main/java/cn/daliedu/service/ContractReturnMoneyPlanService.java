package cn.daliedu.service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;

import cn.daliedu.entity.ContractReturnMoneyPlanEntity;

/**
 * <p>
 * 合同回款计划表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-31
 */
public interface ContractReturnMoneyPlanService extends IService<ContractReturnMoneyPlanEntity> {
	
	/**
	 * 定时任务调度，更新回款计划状态为逾期未完成
	 * @return
	 */
	public Integer updateReturnMoneyStateByScheduleTask();
	
	
	/**
	 * 获取合同回款计划，回款记录列表
	 * @param map
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getContractReturnMoneyPlanList(Map<Object, Object> map);
	
	/**
	 * 获取合同回款计划，回款记录列表总数
	 * @param map
	 * @return
	 */
	public Long getContractReturnMoneyPlanListCount(Map<Object, Object> map);
	
	
	/**
	 * 获取客户合同回款计划，回款记录列表
	 * @param map
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getContractReturnMoneyPlanByCustomerIdList(Map<Object, Object> map);
	
	/**
	 * 获取客户合同回款计划，回款记录列表总数
	 * @param map
	 * @return
	 */
	public Long getContractReturnMoneyPlanByCustomerIdListCount(Map<Object, Object> map);
	
	/**
	 * 获取当前合同回款期次的最大值，能前端点击 （期次+）号使用
	 * @param contractId
	 * @return
	 */
	public Integer getReturnMoneyNumMax(String contractId);
	
	/**
	 * 根据合同ID及回款期次，找到对应的回款计划
	 * @param contractId
	 * @param returnMoneyNum
	 * @return
	 */
	public ContractReturnMoneyPlanEntity getReturnMoneyPlan(String contractId, Integer returnMoneyNum);
}
