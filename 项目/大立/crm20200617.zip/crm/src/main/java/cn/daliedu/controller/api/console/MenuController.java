package cn.daliedu.controller.api.console;

import java.util.List;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.MenuEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.json.GlobalJson;
import cn.daliedu.entity.json.MenuJson;
import cn.daliedu.entity.json.UserJson;
import cn.daliedu.service.MenuService;
import cn.daliedu.service.OrgService;
import cn.daliedu.service.RoleService;
import cn.daliedu.service.UserRoleService;
import cn.daliedu.service.UserService;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * 菜单操作相关接口控制器
 * @author xiechao
 * @time 2019年5月13日 上午10:33:58
 * @version 1.0.0 
 * @description
 */
@Api(description = "菜单操作相关接口")
@RestController
@RequestMapping(value = "${rest.path}/console/menu") 
public class MenuController {
	
	@Autowired
	UserService userService;
	
	@Autowired
	RoleService roleService;
	
	@Autowired
	OrgService deptService;
	
	@Autowired
	MenuService menuService;
	

	
	@Autowired
	UserRoleService userRoleService;
	
	
	/** 
	 * 新增菜单
	 **/
	@ApiOperation(value = "新增菜单", notes = "新增菜单")
	@ApiJsonObject(name = "save", value = { 
			@ApiJsonProperty(name = MenuJson.type),
			@ApiJsonProperty(name = MenuJson.name),
			@ApiJsonProperty(name = MenuJson.parentId),
			@ApiJsonProperty(name = MenuJson.permission),
			@ApiJsonProperty(name = MenuJson.url),
			@ApiJsonProperty(name = MenuJson.orderNum),
			@ApiJsonProperty(name = MenuJson.icon)})
	@ApiImplicitParam(name = "params", required = true, dataType = "save")
	@PostMapping("/save")
	public Result save(@RequestBody String params)  {
		try {
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String type = jsonObject.get("type").toString();
			String name = jsonObject.get("name").toString();
			String parentId = jsonObject.get("parentId").toString();
			String permission = jsonObject.get("permission").toString();
			String url = jsonObject.get("url").toString();
			String orderNum = jsonObject.get("orderNum").toString();
			String icon = jsonObject.get("icon").toString();
			
			StringUtil.validateIsNull(type, "请输入菜单类型");
			StringUtil.validateIsNull(name, "请输入名称");
			StringUtil.validateIsNull(parentId, "请输入上级菜单ID");
			StringUtil.validateIsNull(orderNum, "请输入菜单排序号");
			
			MenuEntity menu = new MenuEntity();
			menu.setType(type);
			menu.setName(name);
			menu.setParentId(Integer.parseInt(parentId));
			menu.setPermission(permission);
			menu.setUrl(url);
			menu.setOrderNum(Integer.parseInt(orderNum));
			menu.setIcon(icon);
			
			boolean flag = menuService.save(menu);
			if(flag){
				return Result.success("新增成功！");
			}
			return Result.success("新增成功！");
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("新增失败，请稍后再试！");
		}
	}
	
	/**
	 *  删除菜单（支持批量删除）
	 * @return 
	 **/
	@ApiOperation(value = "删除菜单（支持批量删除）", notes = "删除菜单（支持批量删除）")
	@RequestMapping(value = "/delete",method = RequestMethod.DELETE,produces = "application/json;charset=UTF-8")
	public Result deleteBatch(String[] ids) {
		for (int i = 0; i < ids.length; i++) {
			menuService.removeById(ids[i]);
		}
		return Result.success("删除成功！");
	}

//	@ApiOperation(value = "获取所有菜单导航，不包含按钮", notes = "获取所有菜单，不包含按钮")
//	@GetMapping(value="/findNavTree")
//	public Result findNavTree(@RequestParam String userName) {
//		return HttpResult.ok(sysMenuService.findTree(userName, 1));
//	}
	

	
	
	@ApiOperation(value = "获取所有菜单，包含按钮，以树形结构返回结果集", notes = "获取所有菜单，包含按钮，以树形结构返回结果集")
	@GetMapping(value="/findMenuTree")
	public Result findNavTree(){
		try{
			List<MenuEntity> menuList = menuService.findMenuTree("0");
			
			return Result.success(menuList);
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取当前用户菜单失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "获取指定的菜单节点下的子孙菜单", notes = "获取所有菜单，包含按钮，以树形结构返回结果集")
	@GetMapping(value="/getTreeMenuListByParentId/{parentId}")
	public Result getTreeMenuListByParentId(@PathVariable(value="parentId", required=true)Integer parentId){
		try{
			List<MenuEntity> menuList = menuService.getTreeMenuListByParentId(parentId);
			
			return Result.success(menuList);
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取当前用户菜单失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
	
	
}
