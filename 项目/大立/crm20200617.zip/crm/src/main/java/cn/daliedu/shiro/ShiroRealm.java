package cn.daliedu.shiro;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.DisabledAccountException;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;

import cn.daliedu.entity.MenuEntity;
import cn.daliedu.entity.RoleEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.enums.UserTypeEnum;
import cn.daliedu.mapper.MenuMapper;
import cn.daliedu.mapper.RoleMapper;
import cn.daliedu.mapper.UserMapper;
import cn.daliedu.service.MenuService;
import cn.daliedu.service.RoleService;
import cn.daliedu.service.UserRoleService;
import cn.daliedu.service.UserService;
import cn.daliedu.util.Log4jUtil;


public class ShiroRealm extends AuthorizingRealm {

//	@Autowired
//	private UserService userService; 千万别在这里面注入userService层，一个都不行，会导致事务失效
	
	@Resource
	UserMapper userMapper;
	
	@Resource
	RoleMapper roleMapper;
	
	@Resource
	MenuMapper menuMapper;
	
	//直接导入下面的服务层，会引起事务无效
//	@Autowired
//	private UserRoleService userRoleService;
//	@Autowired
//	private RoleService roleService;
//	@Autowired
//	private MenuService menuService;

	/**
	 * 认证信息.(身份验证) : Authentication 是用来验证用户身份
	 *
	 */
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authcToken)
			throws AuthenticationException {
		Log4jUtil.info("---------------- 执行 Shiro 凭证认证 ----------------------");
		
		MyUsernamePasswordToken token = (MyUsernamePasswordToken) authcToken;
//		UsernamePasswordToken token = (UsernamePasswordToken) authcToken;
		Log4jUtil.info("用户名：" + token.getUsername());
//		Log4jUtil.info("用户类别：" + token.getUserType());
		
		//目前下面的代码，每次访问都会执行一遍，在shiroConfig里面去掉缓存，每次都会执行下面的，否则缓存期内不会执行下面的
		if(null != token && token.getUsername()!=null && !token.getUsername().equals("")){
			// 从数据库获取对应用户名密码的用户
			// 通过username从数据库中查找 User对象.
			// 实际项目中，这里可以根据实际情况做缓存，如果不做，Shiro自己也是有时间间隔机制，2分钟内不会重复执行该方法
			UserEntity user = userMapper.selectOne(new QueryWrapper<UserEntity>().eq("login_name", token.getUsername()).last("limit 1"));
//			UserEntity user = userService.findUserByLoginName(token.getUsername());
			if (user != null) {
//				// 用户为删除状态
//				if (user.getDeleted().equals("1")) {
//					throw new DisabledAccountException();
//				}
				//用户为禁用状态或离职状态
				if(user.getState().equals("0") || user.getState().equals("2")){
					throw new DisabledAccountException();
				}
				
				
				
				
				Log4jUtil.info("---------------- Shiro 凭证认证开始 ----------------------");
				SimpleAuthenticationInfo authenticationInfo = new SimpleAuthenticationInfo(
						//这里面直接把 LoginUserInfo这个大对象，放到shiro里面去，感觉没什么作用，后面取菜单，取角色，还得实时去表里面查，防止用户重新授权过，如果不改为实时去查的话，就需要用户重新登录一次才可用
						//还是使用这种缓存方式好一些，不然整个工程代码，有用户权限相关的修改都要做刷新
						user, //注意这个地方放入的对象，后面是通过SecurityUtils.getSubject().getPrincipal()获取的
						user.getPassword(), // 密码
						getName() // realm name
				);
				return authenticationInfo;
			}
		}
		
		// //普通比对的写法，后续完善一定要改为加盐的比对，同样的密码存在数据库里面要保持不一致
		// SimpleAuthenticationInfo authenticationInfo = new
		// SimpleAuthenticationInfo(user, user.getPassword(), getName());
		//
		// //下面为加盐的写法
		// SimpleAuthenticationInfo authenticationInfo = new
		// SimpleAuthenticationInfo(user, //
		// 这里传入的是user对象，比对的是用户名，直接传入用户名也没错，但是在授权部分就需要自己重新从数据库里取权限
		// user.getPassword(), // 密码
		// //
		// ByteSource.Util.bytes(user.getCredentialsSalt()),//salt=username+salt
		// ByteSource.Util.bytes(user.getName()), // salt=username+salt
		// getName() // realm name
		// );
		throw new UnknownAccountException();
	}

	/**
	 * 授权,  权限认证(为当前登录的 Subject 授予角色和权限)
	 * <p>
	 * 该方法的调用时机为需授权资源被访问时, 并且每次访问需授权资源都会执行该方法中的逻辑, 这表明本例中并未启用
	 * AuthorizationCache, 如果连续访问同一个 URL(比如刷新), 该方法不会被重复调用, Shiro 有一个时间间隔(也就是
	 * cache 时间, 在 ehcache-shiro.xml 中配置), 超过这个时间间隔再刷新页面, 该方法会被执行
	 * <p>
	 * doGetAuthorizationInfo() 是权限控制, 当访问到页面的时候, 使用了相应的注解或者 shiro
	 * 标签才会执行此方法否则不会执行, 所以如果只是简单的身份认证没有权限的控制的话, 那么这个方法可以不进行实现, 直接返回 null 即可
	 */
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		Log4jUtil.info("---------------- 执行 Shiro 权限获取 ---------------------");

		Object principal = principals.getPrimaryPrincipal();
		SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
		
		//CRM复杂权限体系，用户授权流程(不使用LoginUserInfo里面的缓存起来的，采用即时加载的方式，
		//感觉即时加载也没用，因为即使下面的代码采用去库表中查菜单及角色的方式，也还是缓存在shiro里面的,所以用户还得重新登录，shiro才会更新)
		//还有一种方案，就是全部采用刷新shiro的方案，但工作量会比较大
		if (principal instanceof UserEntity) {
			UserEntity user = (UserEntity) principal;
			if (user != null) {
				//1.获取用户的角色
				//用户授权的角色
				Set<String> roles = new HashSet<String>();
				Map<Object, Object> map = new HashMap<Object, Object>();
//				map.put("startRow", null);
//				map.put("pageSize", null);
				map.put("userId", user.getId());
				
				Set<String> permissionsSet = new HashSet<String>();
				//超级管理员，加载所有菜单的权限
				if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue())){
					List<MenuEntity> listMenu = menuMapper.selectList(new QueryWrapper<MenuEntity>());
					for(MenuEntity menuEntity : listMenu) {
						if(StringUtils.isNotBlank(menuEntity.getPermission())){
							permissionsSet.add(menuEntity.getPermission());
						}
					}
				}else{
					for(RoleEntity role: roleMapper.getUserRoleList(map)) {
						roles.add(role.getName());
					}
					//2.获取角色对应的菜单
					
					List<MenuEntity> listMenu = menuMapper.getMenuListByUserId(user.getId());
					for(MenuEntity menuEntity : listMenu) {
						if(StringUtils.isNotBlank(menuEntity.getPermission())){
							permissionsSet.add(menuEntity.getPermission());
						}
					}
				}
				
				
		        info.setStringPermissions(permissionsSet);
		        info.setRoles(roles);
		        return info;
			}
		}
		

			
		Log4jUtil.info("---------------- 获取到以下权限 ----------------");
		Log4jUtil.info(info.getStringPermissions().toString());
		Log4jUtil.info("---------------- Shiro 权限获取成功 ----------------------");

		return info;
	}

	
	
	 /**
     * 重写方法,清除当前用户的的 授权缓存
     * @param principals
     */
    @Override
    public void clearCachedAuthorizationInfo(PrincipalCollection principals) {
        super.clearCachedAuthorizationInfo(principals);
    }

    /**
     * 重写方法，清除当前用户的 认证缓存
     * @param principals
     */
    @Override
    public void clearCachedAuthenticationInfo(PrincipalCollection principals) {
        super.clearCachedAuthenticationInfo(principals);
    }

    @Override
    public void clearCache(PrincipalCollection principals) {
        super.clearCache(principals);
    }

    /**
     * 自定义方法：清除所有 授权缓存
     */
    public void clearAllCachedAuthorizationInfo() {
        getAuthorizationCache().clear();
    }

    /**
     * 自定义方法：清除所有 认证缓存
     */
    public void clearAllCachedAuthenticationInfo() {
        getAuthenticationCache().clear();
    }

    /**
     * 自定义方法：清除所有的  认证缓存  和 授权缓存
     */
    public void clearAllCache() {
        clearAllCachedAuthenticationInfo();
        clearAllCachedAuthorizationInfo();
    }

 // 下面这个方法不注掉，一放开，存储至redis中的key是：SPRINGBOOT_CACHE:cn.daliedu.shiro.ShiroRealm.authorizationCache:User{id=2,
 	// name=plat, password=e10adc3949ba59abbe56e057f20f883e, userType=null,
 	// status=1, dataScope=1, auditStatus=1, loginTime=null, createBy=null,
 	// createTime=null, updateBy=null, updateTime=null, deleted=0, remark=null}
 	// 如果注掉的话，缓存的key是：
 	// SPRINGBOOT_CACHE:cn.daliedu.shiro.ShiroRealm.authorizationCache:1
 	// SPRINGBOOT_CACHE:cn.daliedu.shiro.ShiroRealm.authorizationCache:2
 	// 合同项目缓存的key为：com.yqt.contract.configs.shiro.MyShiroRealm_0 所有用户登入都被覆盖了
 	// @Override
 	// protected Object getAuthorizationCacheKey(PrincipalCollection principals)
 	// {
 	// return principals.toString();
 	// }

}
