package cn.daliedu.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 用户客户表，存储用户关联的客户数据
 * </p>
 *
 * @author xiechao
 * @since 2019-09-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_user_customer")
public class UserCustomerEntity extends Model<UserCustomerEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;

    /**
     * 用户ID
     */
    private String userId;

    /**
     * 客户ID
     */
    private String customerId;

    /**
     * 我的客户类型，1：我的客户，2：共享给我的客户，3：共享给同事的客户
     */
    private String myCustomerType;

    /**
     * 客户分组类型ID，1：一般客户，2：意向客户，3：已成交客户，4：无意向客户，5：拉黑客户，6：其他
     * 目前已经注掉此字段，客户分组属于客户，不直接属于用户，不用每个人都给这个客户分不同的组
     */
//    private String customerGroupTypeId;

    /**
     * 我的客户创建时间
     */
    private LocalDateTime createTime;



    /**
     * 共享人ID，即发起共享的用户ID（如果不是共享的客户，那么此列的值为空）
     */
    private String shareId;

    

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "UserCustomerEntity{" +
        "id=" + id +
        ", userId=" + userId +
        ", customerId=" + customerId +
        ", myCustomerType=" + myCustomerType +
//        ", customerGroupTypeId=" + customerGroupTypeId +
//        ", createTime=" + createTime +
        ", shareId=" + shareId +
        "}";
    }
}
