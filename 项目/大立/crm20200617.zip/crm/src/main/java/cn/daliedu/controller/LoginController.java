package cn.daliedu.controller;

import java.time.LocalDateTime;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.DisabledAccountException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.cache.Cache;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.enums.ResultCodeEnum;
import cn.daliedu.service.OrgService;
import cn.daliedu.service.UserService;
import cn.daliedu.shiro.MyUsernamePasswordToken;
import cn.daliedu.shiro.ShiroRealm;
import cn.daliedu.shiro.redis.MyRedisSessionDAO;
import cn.daliedu.util.Result;
import cn.daliedu.util.SpringUtil;

@RestController
@RequestMapping("/admin")
public class LoginController {
	
	@Autowired
	OrgService orgService;
	
	@Autowired
	private UserService userService;
	


	/**
	 * 签友汇，会员版登录
	 * @param loginName
	 * @param pwd
	 * @param response
	 * @return
	 */
	@RequestMapping("/login")
	public Result login(String loginName, String pwd, HttpServletResponse response) {
		try {
			if(loginName!=null && !loginName.trim().equals("")){
				loginName = loginName.replaceAll(" ", "");
			}
			pwd = pwd.trim();
			
			
			UserEntity user = userService.findUserByLoginName(loginName);
			if(user==null){
				return Result.error("用户不存在，请检查账号");
			}
			
//			MyUsernamePasswordToken token = new MyUsernamePasswordToken(loginName, pwd, SysUserTypeEnum.SYSTEM_TYPE.getValue());
			MyUsernamePasswordToken token = new MyUsernamePasswordToken(loginName, pwd);
//			UsernamePasswordToken token = new UsernamePasswordToken(loginName, pwd,userType);
//			token.setUserType(userType);
			// token.setRememberMe(true);//设置记住我

			// 登录不在该处处理，交由shiro处理
			Subject subject = SecurityUtils.getSubject();
//			Session session = subject.getSession();
			
//			System.out.println("打印session相关属性");
//			System.out.println("是否认证：" + subject.isAuthenticated());
//			System.out.println(session.getStartTimestamp());
//			System.out.println(session.getLastAccessTime());
//			System.out.println(session.getTimeout());
			
			subject.login(token);

			if (subject.isAuthenticated()) {
				//修改用户的登录时间
				user.setLoginTime(LocalDateTime.now());
				userService.saveOrUpdate(user);
				
				List<OrgEntity> branchOrgIds = orgService.getBranchOrgByUser(user);
				user.setBranchOrgIds(branchOrgIds);
//				
//				JSONObject json = new JSONObject();
//				json.put("token", subject.getSession().getId());
//
//				Object object = subject.getPrincipal();
//		        if(object instanceof UserEntity){
//		        	UserEntity user = (UserEntity)object;
////		        	Log4jUtil.info("获取user用户信息：" + user.toString());
//		        }
		        
		        String sessionId = (String)subject.getSession().getId();
	            response.addCookie(new Cookie("SHIRO_SESSION_ID", sessionId));
	            
	            //直接将SHIRO_SESSION_ID返回至data里面，给前端使用，前端从data里面去拿更方便，后面再发起每个接口调用的时候，都把这个带上就可以保持登录状态
	            user.setToken(sessionId);
	            return Result.success(user);
	            
//	            UUID uuid = (UUID)subject.getSession().getId();
//	            System.out.println("设置的uuid:" + uuid.toString());
//	            response.addCookie(new Cookie("SHIRO_SESSION_ID", uuid.toString()));
//		        SysLog sysLog = new SysLog();
//		        sysLog.setVipId(vip.getId());
//		        sysLog.setOperaTypeId(SysLogTypeEnum.LOG_TYPE_1.getValue());
//		        sysLog.setOperaTypeName(SysLogTypeEnum.LOG_TYPE_1.getDesc());
//		        sysLog.setOperaResult("成功");
//		        sysLog.setOperaBy(vip.getLoginName());
//		        sysLog.setCreateTime(LocalDateTime.now());
//		        sysLog.setDeleted("0");
//		        boolean flag = sysLogService.saveOrUpdate(sysLog);
//		        if (flag) {
//		        	return new Result(ResultCodeEnum.SUCCESS, json);
//				}
//				return Result.error("登陆失败，更新系统操作日志数据失败");
	            
			} else {
				return Result.error(ResultCodeEnum.USER_LOGIN_ERROR);
			}
		} catch (IncorrectCredentialsException | UnknownAccountException e) {
			e.printStackTrace();
			return Result.error(ResultCodeEnum.USER_NOT_EXIST_USER_OR_ERROR_PWD);
		} catch (LockedAccountException e) {
			e.printStackTrace();
			return Result.error(ResultCodeEnum.USER_FROZEN);
		} catch (DisabledAccountException e) {
			e.printStackTrace();
			return Result.error(ResultCodeEnum.USER_FROZEN);
		} catch (AuthenticationException e) {
			e.printStackTrace();
			return Result.error(ResultCodeEnum.USER_VERIFY_ERROR);
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error(ResultCodeEnum.NET_WORK_500_SYSTEM_ERR);
		}
	}
	
	
	
	
	/**
	 * 退出登录
	 * 
	 * @return
	 */
	@RequestMapping("/logout")
	public Result logout() {
		try{
			Subject subject = SecurityUtils.getSubject();
			Object object = subject.getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				UserEntity user = userService.getById(bean.getId());
				
				//删除用户登录缓存,我这边集成的shiro+springboot需要执行下面这一段删除缓存的操作，否则用户修改密码后，再登录，还是使用缓存中的密码，新密码无法登录
				//敬业项目也是shiro+springboot,退出登录就SecurityUtils.getSubject().logout();一行代码搞定了，不需要清理缓存也没有修改密码，新密码无法登录的问题，有时间再研究
				SecurityUtils.getSubject().logout();
				ShiroRealm realm = (ShiroRealm)SpringUtil.getBean("myShiroRealm");
				Cache<Object, AuthenticationInfo> authenticationcache = realm.getAuthenticationCache();
				if(authenticationcache!=null){
					authenticationcache.remove(user.getLoginName());
					
					
					//同时删除redis中的session缓存
					String sessionId = subject.getSession().getId().toString();
					
					MyRedisSessionDAO  redisSessionDAO= (MyRedisSessionDAO)SpringUtil.getBean("redisSessionDAO");
	            	Session session = redisSessionDAO.doReadSession(sessionId);
	            	if(session!=null){
	            		redisSessionDAO.delete(session);
	            	}
					
				}
				
				
//				SysLog sysLog = new SysLog();
//				sysLog.setVipId(vip.getId());
//				sysLog.setOperaTypeId(SysLogTypeEnum.LOG_TYPE_2.getValue());
//				sysLog.setOperaTypeName(SysLogTypeEnum.LOG_TYPE_2.getDesc());
//				sysLog.setOperaResult("成功");
//				sysLog.setOperaBy(vip.getLoginName());
//				sysLog.setCreateTime(LocalDateTime.now());
//				sysLog.setDeleted("0");
//				boolean flag = sysLogService.saveOrUpdate(sysLog);
//				if (!flag) {
//					return Result.error("退出失败,更新系统操作日志数据失败");
//				}
			}
			return Result.success(ResultCodeEnum.SUCCESS);
		}catch(Exception e){
			return Result.success("成功");
		}
	}
}
