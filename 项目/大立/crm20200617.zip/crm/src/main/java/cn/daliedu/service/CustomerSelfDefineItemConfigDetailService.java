package cn.daliedu.service;

import cn.daliedu.entity.CustomerSelfDefineItemConfigDetailEntity;
import cn.daliedu.entity.CustomerTagGroupDetailEntity;

import java.util.List;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 客户自定义类别配置明细表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2020-05-20
 */
public interface CustomerSelfDefineItemConfigDetailService extends IService<CustomerSelfDefineItemConfigDetailEntity> {
	/**
	 * 根据客户自定义分组类型ID，加载客户自定义分组下的明细
	 * @param itemId
	 * @return
	 */
	public List<CustomerSelfDefineItemConfigDetailEntity> getCustomerSelfDefineItemConfigDetailByItemId(String itemId);
	
	/**
	 * 保存客户自定义分组明细
	 * @param itemId 客户自定义分组类型ID
	 * @param itemDetailName 客户标签名称
	 * @return
	 * @throws Exception
	 */
	public boolean saveCustomerSelfDefineItemConfigDetail(String itemId, String itemDetailName) throws Exception;
	
	/**
	 * 判断数据库中是否已经存在客户自定义分组，简单防止同名的标签加入
	 * @param itemId 客户自定义分组类型ID
	 * @param itemDetailName 客户自定义明细名称
	 * @return
	 * @throws Exception
	 */
	public boolean existsCustomerSelfDefineItemConfigDetail(String itemId, String itemDetailName);
	
}
