package cn.daliedu.entity.json;

import cn.daliedu.config.swagger.model.ApiSingleParam;

/**
 * <p>
 * swagger注释属性：公告表
 * </p>
 *
 * @author xiechao
 * @since 2019-05-06
 */
public class NoticeJson{
	
	
	@ApiSingleParam(value = "id", example = "6629b90b02f8071dd03c7d68b2f278c6")
    public static final String id = "id";
	
	@ApiSingleParam(value = "公告ID集合", example = "[1,2,3]")
	public static final String ids = "ids";
	
	@ApiSingleParam(value = "公告名称", example = "如何有效管理客户关系")
    public static final String title = "title";
	
	@ApiSingleParam(value = "公告内容", example = "管理客户三要素：一，二，三")
    public static final String content = "content";
	
	
}
