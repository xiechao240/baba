package cn.daliedu.service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;

import cn.daliedu.entity.UserEntity;

/**
 * <p>
 * 用户管理 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
public interface UserService extends IService<UserEntity> {
	
	/**
	 * 将一个用户交接给别一个用户
	 * @param userId  交接人
	 * @param receiveUserId  交接的接收人
	 * @return
	 */
	public boolean receiveToNewUser(String userId, String receiveUserId)  throws Exception;
	
	/**
	 * 根据传入的用户类型，获取同级别的交接人员列表
	 * @param map
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> findUserListByUserType(Map<Object, Object> map);
	
	/**
	 * 根据传入的用户类型，获取同级别的交接人员列表数量
	 * @param map
	 * @return
	 */
	public Long findUserListByUserTypeCount(Map<Object, Object> map);
	
	/**
	 * 加载代理商列表
	 * @param map
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> findAgentUserListByUserId(Map<Object, Object> map);
	
	/**
	 * 加载代理商列表数量
	 * @param map
	 * @return
	 */
	public Long findAgentUserListByUserIdCount(Map<Object, Object> map);
	
	
	/**
	 * 【客户标签变化统计】按分校统计一段时间范围内的，所有分校用户的客户标签 
	 * @param map 查询组合参数集合
	 * @return
	 */
	public Integer getCustomerTagUpdateByCustomerTagAllCount(Map<Object, Object> map);
	
	/**
	 * 【客户标签变化统计】获取客户标签变化的用户的标签数
	 * @param map 查询组合参数集合
	 * @return
	 */
	public Integer getCustomerTagUpdateByCustomerTag(Map<Object, Object> map);
	
	/**
	 * 【客户标签变化统计】获取客户标签变化的用户（没有打标签的用户，将不出现在结果集中）
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerTagUpdateByUser(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【电话联系统计】获取分校的电话联系的客户数
	 * @param map
	 * @return
	 */
	public Integer getCallContactCustomerCount(Map<Object, Object> map);
	
	/**
	 * 【电话联系统计】获取分校的电话联系统计报表
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getCallContactDetailCount(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【工作效率统计】获取新增客户数量排名列表总数
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public Long getAddCustomerCountTopListCount(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【工作效率统计】获取新增客户数量排名列表
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getAddCustomerCountTopList(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【电话排名】获取电话联系统计列表
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getCallRankingByContactList(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【电话排名】获取电话联系统计列表总数
	 * @param map 查询组合参数集合
	 */
	public Long getCallRankingByContactListCount(Map<Object, Object> map);
	
	/**
	 * 校验手机号码是否存在
	 * @param mobile
	 * @return
	 */
	public boolean validateMobileExist(String mobile);
	
	/**
	 * 根据手机号码加载用户
	 * @param mobile
	 * @return
	 */
	public UserEntity getUserByMobile(String mobile) throws Exception;
	
	
	/**
	 * 根据客户ID，获取所有共享给我的客户用户列表
	 * @param customerId
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getShareRelationUsers(String customerId);
	
	/**
	 * 获取收款人用户列表（返回整个公司的所有在职员工,包含普通管理员，普通用户，超级管理员和代理商用户及其他类型的用户除外）
	 * @param map
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getReceiptUserList(Map<Object, Object> map);
	
	/**
	 * 获取收款人用户列表总数（返回整个公司的所有在职员工,包含普通管理员，普通用户，超级管理员和代理商用户及其他类型的用户除外）
	 * @param map
	 * @return
	 */
	public Long getReceiptUserListCount(Map<Object, Object> map);
	
	/**
	 * 根据用户名称查找用户
	 * @param name
	 * @return
	 */
	public UserEntity findUserByUserName(String name);
	
	/**
	 * 根据登录账号查找用户
	 * @param loginName
	 * @return
	 */
	public UserEntity findUserByLoginName(String loginName);
	
	/**
	 * 根据登录名或用户名查询用户集合,带分页
	 * @param loginNameOrUserName
	 * @return
	 */
	public IPage<UserEntity> findUserListByLoginNameOrUserName(Integer pageNum, Integer pageSize, String loginNameOrUserName, String state);
	
	/**
	 * 创建用户，同时保存用户的角色，用户所属组织
	 * @param params  前端传入的json参数
	 * @throws Exception
	 */
	public boolean saveUser(String params) throws Exception;

	/**
	 * 修改用户，同时修改用户的角色，用户所属组织
	 * @param params  前端传入的json参数
	 * @throws Exception
	 */
	public boolean updateUserInfo(String params) throws Exception;
	
	
	/**
	 * 根据权限过滤，查询代理商节点下面的用户集合
	 * @param map
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> findUserListByAgent(Map<Object, Object> map);
	
	/**
	 * 根据权限过滤，查询代理商节点下面的用户数量
	 * @param map
	 * @return
	 */
	public Long findUserListByAgentCount(Map<Object, Object> map);
	
	
	/**
	 * 查询机构及子机构下面的员工(带综合查询)
	 * @param orgId  机构ID(必传参数)
	 * @param name  用户名称（非必传）
	 * @param loginName 用户登录账号（非必传）
	 * @param pageNum  分页页码
	 * @param pageSize  每页显示记录数
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> findUserListByOrgId(Map<Object, Object> map);
	
	/**
	 * 查询机构下面的员工（不包含子孙机构下面的员工）
	 * @param orgId  机构ID(必传参数)
	 * @return
	 */
	public List<UserEntity> getUserListByOrgId(String orgId);
	
	
	/**
	 * 查询机构下面的员工(包含分校下子孙机构下面的员工)
	 * @param orgId  机构ID(必传参数)
	 * @return
	 */
	public List<UserEntity> getUserListByBranchOrgId(Map<Object, Object> map);
	
	public Long getUserListByBranchOrgIdCount(Map<Object, Object> map);
	
	
	
	/**
	 * 根据查询条件，查询机构下面的用户总数
	 * @param map 查询组合参数集合
	 * @return
	 */
	public Long findUserListByOrgIdCount(Map<Object, Object> map);
	
	/**
	 * 查询机构下面的员工（包含子孙机构下面的员工）
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> findUserListByOrgIdAndChildren(Map<Object, Object> map);
	
	/**
	 * 根据查询条件，查询机构下面的用户总数
	 * @param map 查询组合参数集合
	 * @return
	 */
	public Long findUserListByOrgIdAndChildrenCount(Map<Object, Object> map);
	
	
	
	/**
	 * 查询已禁用的员工或已离职的员工列表
	 * @param map
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> findUserListByUserState(Map<Object, Object> map);
	
	/**
	 * 查询已禁用的员工或已离职的员工列表总数
	 * @param map
	 * @return
	 */
	public Long findUserListByUserStateCount(Map<Object, Object> map);
	
	/**
	 * 根据员工id批量禁用，启用员工状态，0：禁用状态，1：可用状态，2：离职状态
	 * @param userIdList 用户ID集合
	 * @param state 批量更新的状态
	 * @throws Exception
	 */
	public boolean updateUserStateBatch(List<String> userIdList, String state) throws Exception;

	/**
	 * 批量编辑员工所属组织
	 * @param userIds 用户ID集合
	 * @param orgId 组织ID
	 */
	public boolean updateUserOrgBatch(List<String> userIds, String orgId) throws Exception;
	
	/**
	 * 获取客户的跟进人列表
	 * @param map
	 * @return
	 */
	public List<UserEntity> getFollowUserList(Map<Object, Object> map);
	
	/**
	 * 获取客户的跟进人列表总数
	 * @param map
	 * @return
	 */
	public Long getFollowUserListCount(Map<Object, Object> map);
	
	/*
	 * 根据用户ID获取用户名称与机构名称
	 */
	public LinkedHashMap<Object, Object> getUserNameAndOrgNameByUserId(String userId);
	
	/**
	 * 获取系统中正常状态下的所有用户
	 * @return
	 */
	public List<UserEntity> getAllUser();
}
