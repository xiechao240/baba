package cn.daliedu.exception;

/**
 * 自定义业务层异常
 * 
 * @author xiechao
 * @time 2019年2月18日 上午10:13:15
 * @version 1.0.0
 * @description
 */
public class CrmException extends Exception {
	private static final long serialVersionUID = 1L;

	public CrmException(String message) {
		super(message);
	}

	public CrmException(String message, Throwable cause) {
		super(message, cause);
	}

	public CrmException(Throwable cause) {
		super(cause);
	}
}
