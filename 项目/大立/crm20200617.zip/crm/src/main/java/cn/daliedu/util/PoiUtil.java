package cn.daliedu.util;

import java.text.DecimalFormat;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

import com.alibaba.druid.util.StringUtils;

import cn.daliedu.exception.BusinessException;


/**
 * poi框架工具类(poi可以支持xls以及xlsx格式的文件)
 * @author xiechao
 * @time 2019年10月22日 下午3:15:28
 * @version 1.0.0 
 * @description
 */
public class PoiUtil {
	
	/**
	 * 校验上传的excel文件头，是否为我们指定的模板
	 * @param customerSheet
	 * @throws Exception
	 */
	public static void validateCell(Sheet customerSheet) throws Exception{
		Row header = customerSheet.getRow(10);
		
		String name = header.getCell(0).getStringCellValue().trim();//姓名
		if(!name.equals("客户姓名")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【姓名】列，请检查文件");
		}
		
		String sex = header.getCell(1).getStringCellValue().trim();//性别
		if(!sex.equals("性别")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【性别】列，请检查文件");
		}
		
		String customerSourceType = header.getCell(2).getStringCellValue().trim();//来源
		if(!customerSourceType.equals("来源")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【来源】列，请检查文件");
		}
		
		String mobile = header.getCell(3).getStringCellValue().trim();//手机	
		if(mobile.indexOf("手机")==-1){
			throw new BusinessException("上传的客户数据模板有问题，缺少【手机】列，请检查文件");
		}
		
		String qq = header.getCell(4).getStringCellValue().trim();//QQ
		if(!qq.equals("QQ")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【QQ】列，请检查文件");
		}
		
		String weixinId = header.getCell(5).getStringCellValue().trim();//微信
		if(!weixinId.equals("微信")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【微信】列，请检查文件");
		}
		
		String phone = header.getCell(6).getStringCellValue().trim();//座机
		if(!phone.equals("座机")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【座机】列，请检查文件");
		}
		
		String email = header.getCell(7).getStringCellValue().trim();//邮箱	
		if(!email.equals("邮箱")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【邮箱】列，请检查文件");
		}
		
		String guojia = header.getCell(8).getStringCellValue().trim();//地区：国家	
		if(!guojia.equals("地区：国家")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【地区：国家】列，请检查文件");
		}
		
		String provinceName = header.getCell(9).getStringCellValue().trim();//地区：省/州	
		if(!provinceName.equals("地区：省/州")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【地区：省/州】列，请检查文件");
		}
		
		String cityName = header.getCell(10).getStringCellValue().trim();//地区：城市	
		if(!cityName.equals("地区：城市")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【地区：城市】列，请检查文件");
		}
		
		String areaName = header.getCell(11).getStringCellValue().trim();//地区：区/县
		if(!areaName.equals("地区：区/县")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【地区：区/县】列，请检查文件");
		}
		
		String companyName = header.getCell(12).getStringCellValue().trim();//公司
		if(!companyName.equals("公司")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【公司】列，请检查文件");
		}
		
		String address = header.getCell(13).getStringCellValue().trim();//地址
		if(!address.equals("地址")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【地址】列，请检查文件");
		}
		
		String remark = header.getCell(14).getStringCellValue().trim();//备注	
		if(!remark.equals("备注")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【备注】列，请检查文件");
		}
		
		String jobAge = header.getCell(15).getStringCellValue().trim();//工作年限(需要判断是否为数字，如果不为数字，就不入库)
		if(!jobAge.equals("工作年限")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【工作年限】列，请检查文件");
		}
		
		String education =  header.getCell(16).getStringCellValue().trim();//学历	
		if(!education.equals("学历")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【学历】列，请检查文件");
		}
		
		String customerActivityPage = header.getCell(17).getStringCellValue().trim();//填写表单页面
		if(!customerActivityPage.equals("填写表单页面")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【填写表单页面】列，请检查文件");
		}
		
		String professional = header.getCell(18).getStringCellValue().trim();//专业	
		if(!professional.equals("专业")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【专业】列，请检查文件");
		}
		
		String customerActivityTypePage = header.getCell(19).getStringCellValue().trim();//分类
		if(!customerActivityTypePage.equals("分类")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【分类】列，请检查文件");
		}
		
		String danban = header.getCell(20).getStringCellValue().trim();//单班	
		if(!danban.equals("单班")){
			throw new BusinessException("上传的客户数据模板有问题，缺少列，请检查文件");
		}
		
		String taoban = header.getCell(21).getStringCellValue().trim();//套班	
		if(!taoban.equals("套班")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【套班】列，请检查文件");
		}
		
		String neixun = header.getCell(22).getStringCellValue().trim();//内训	
		if(!neixun.equals("内训")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【内训】列，请检查文件");
		}
		
		String yijiankemu = header.getCell(23).getStringCellValue().trim();//一建科目	
		if(!yijiankemu.equals("一建科目")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【一建科目】列，请检查文件");
		}
		
		String erjiankemu = header.getCell(24).getStringCellValue().trim();//二建科目	
		if(!erjiankemu.equals("二建科目")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【二建科目】列，请检查文件");
		}
		
		String zaojiakemu = header.getCell(25).getStringCellValue().trim();//造价科目	
		if(!zaojiakemu.equals("造价科目")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【造价科目】列，请检查文件");
		}
		
		String jianlikemu = header.getCell(26).getStringCellValue().trim();//监理科目	
		if(!jianlikemu.equals("监理科目")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【监理科目】列，请检查文件");
		}
		
		String xiaofangkumu = header.getCell(27).getStringCellValue().trim();//消防科目	
		if(!xiaofangkumu.equals("消防科目")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【消防科目】列，请检查文件");
		}
		
		String zixungongchengshi = header.getCell(28).getStringCellValue().trim();//咨询工程师
		if(!zixungongchengshi.equals("咨询工程师")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【咨询工程师】列，请检查文件");
		}
		
		String yibaotonghang = header.getCell(29).getStringCellValue().trim();//已报同行	
		if(!yibaotonghang.equals("已报同行")){
			throw new BusinessException("上传的客户数据模板有问题，缺少列，请检查文件");
		}
		
		String remark2 = header.getCell(30).getStringCellValue().trim();//备注2	
		if(!remark2.equals("备注2")){
			throw new BusinessException("上传的客户数据模板有问题，缺少【备注2】列，请检查文件");
		}
		
//		String yijiankemu2 = header.getCell(31).getStringCellValue().trim();//一建科目2	
//		if(!yijiankemu2.equals("一建科目2")){
//			throw new BusinessException("上传的客户数据模板有问题，缺少【一建科目2】列，请检查文件");
//		}
//		
//		String banxingmingcheng2 = header.getCell(32).getStringCellValue().trim();//班型名称2	
//		if(!banxingmingcheng2.equals("班型名称2")){
//			throw new BusinessException("上传的客户数据模板有问题，缺少【班型名称2】列，请检查文件");
//		}
		
//		String youhuiquan = header.getCell(33).getStringCellValue().trim();//优惠券	
//		if(!youhuiquan.equals("优惠券")){
//			throw new BusinessException("上传的客户数据模板有问题，缺少【优惠券】列，请检查文件");
//		}
	}
	
//	public void getCellValue(Cell cell) {
//		// CellType cellType = ;
//
//		// switch(cell.getCellType()) {
//		switch (cell.getCellType()) {
//		case STRING:
//			// data.get(i).add(cell.getRichStringCellValue().getString());
//			break;
//		case NUMERIC:
//			if (DateUtil.isCellDateFormatted(cell)) {
//				// data.get(i).add(cell.getDateCellValue));
//			} else {
//				// data.get(i).add(cell.getNumericCellValue());
//			}
//			break;
//		case BOOLEAN:
//			// data.get(i).add(cell.getBooleanCellValue());
//			break;
//		case FORMULA:
//			// data.get(i).add(cell.getCellFormula());
//			break;
//		case BLANK:
//			// data.get(i).add("")
//			break;
//		}
//	}
	
	
	//获取单元格各类型值，返回字符串类型
	public static String getCellValue(Cell cell) {
		// 判断是否为null或空串
		if (cell == null || cell.toString().trim().equals("")) {
			return "";
		}
		String cellValue = "";
		CellType cellType = cell.getCellType();
		if (cellType.getCode() == CellType.FORMULA.getCode()) { // 表达式类型
			// cellType=evaluator.evaluate(cell).getCellType();
			return "";// 表达式类型直接返回""空串处理
		}

		switch (cellType) {
		case STRING: // 字符串类型
			cellValue = cell.getStringCellValue().trim();
			cellValue = StringUtils.isEmpty(cellValue) ? "" : cellValue;
			break;
		// case BOOLEAN: //布尔类型
		//// cellValue = String.valueOf(cell.getBooleanCellValue());
		// cellValue = "";
		// break;
		case NUMERIC: // 数值类型
			if (HSSFDateUtil.isCellDateFormatted(cell)) { // 判断日期类型
				// cellValue =
				// DateUtil.formatDateByFormat(cell.getDateCellValue(),
				// "yyyy-MM-dd");
				cellValue = "";
			} else { // 否
				cellValue = new DecimalFormat("#.######").format(cell.getNumericCellValue());
			}
			break;
		default: // 其它类型，取空串吧
			cellValue = "";
			break;
		}
		return cellValue;
	}
	
	

}
