package cn.daliedu.entity.json;

import cn.daliedu.config.swagger.model.ApiSingleParam;

/**
 * @author xiechao
 * @time 2019年4月23日 下午2:29:04
 * @version 1.0.0 
 * @description 
 */
public class GlobalJson {

	/**
	 * 页码
	 */
	@ApiSingleParam(value = "页码", example = "1")
    public static final String pageNum = "pageNum";

	/**
	 * 每页记录数
	 */
    @ApiSingleParam(value = "每页记录数", example = "10")
    public static final String pageSize = "pageSize";
    
    

    
}
