package cn.daliedu.entity.json;

import cn.daliedu.config.swagger.model.ApiSingleParam;

/**
 * <p>
 * swagger注释属性：角色表
 * </p>
 *
 * @author xiechao
 * @since 2019-05-06
 */
public class RoleJson{

    /**
     * 角色状态，1：可用，0：不可用
     */
	@ApiSingleParam(value = "角色状态，1：可用，0：不可用", example = "1")
    public static final String available = "available";
	
	/**
     * 角色ID
     */
	@ApiSingleParam(value = "ID", example = "1")
    public static final String id = "id";
	
	/**
     * 角色ID
     */
	@ApiSingleParam(value = "角色ID", example = "1")
    public static final String roleId = "roleId";
	
	@ApiSingleParam(value = "角色ID集合", example = "[1,2,3]")
    public static final String roleIds = "roleIds";
	
	/**
     * 角色名称
     */
	@ApiSingleParam(value = "角色名称（可传可不传）", example = "")
    public static final String roleName = "roleName";
	
	/**
     * 角色描述
     */
	@ApiSingleParam(value = "描述", example = "描述")
    public static final String remark = "remark";
	
	/**
     * 机构ID
     */
	@ApiSingleParam(value = "机构ID", example = "1")
	public static final  String orgId = "orgId";
	
	
	
	


}
