package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 客户动态上传的文件或图片
 * </p>
 *
 * @author xiechao
 * @since 2019-10-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_customer_dynamic_file")
public class CustomerDynamicFileEntity extends Model<CustomerDynamicFileEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;

    /**
     * 客户动态ID
     */
    private String customerDynamicId;
    
    /**
     * 文件名
     */
    private String fileName;

    /**
     * 图片路径（目前只有动态类别为：添加跟进记录的有上传图片的功能）
     */
    private String filePath;


    @Override
    protected Serializable pkVal() {
        return null;
    }

}
