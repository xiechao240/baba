package cn.daliedu.entity;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 合同回款计划期次表
 * </p>
 *
 * @author xiechao
 * @since 2019-11-01
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_contract_return_money_plan")
public class ContractReturnMoneyPlanEntity extends Model<ContractReturnMoneyPlanEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;
    
    /**
     * 用户ID（方便统计每个人在此表创建的合同回款计划等，统计金额在回款记录里面统计）
     */
    private String userId;

    /**
     * 客户ID
     */
    private String customerId;

    /**
     * 合同ID
     */
    private String contractId;


    /**
     * 期次
     */
    private Integer returnMoneyNum;

    /**
     * 计划回款日期
     */
    private LocalDate planReturnMoneyDate;

    /**
     * 计划回款金额
     */
    private BigDecimal planReturnMoney;
    
    /**
     * 已回款金额
     */
    private BigDecimal alreadyReturnMoney;
    
    /**
     * 未回款金额
     */
    private BigDecimal noReturnMoney;
    
    /**
     * 回款状态（0：未完成，1：完成，2：逾期未完成）
     */
    private String returnMoneyState;

    /**
     * 创建日期
     */
    private LocalDateTime createDate;
    
    /**
     * 更新日期
     */
    private LocalDateTime updateDate;
    
    /**
     * 备注
     */
    private String remark;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
