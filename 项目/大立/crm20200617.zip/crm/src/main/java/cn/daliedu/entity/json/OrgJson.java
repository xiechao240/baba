package cn.daliedu.entity.json;

import cn.daliedu.config.swagger.model.ApiSingleParam;

/**
 * <p>
 * swagger注释属性：菜单表
 * </p>
 *
 * @author xiechao
 * @since 2019-05-06
 */
public class OrgJson{
	
	@ApiSingleParam(value = "机构ID，必传参数", example = "1")
    public static final String orgId = "orgId";
	
	@ApiSingleParam(value = "分校ID", example = "1")
	public static final String branchOrgId = "branchOrgId";
	
	@ApiSingleParam(value = "部门ID", example = "1")
	public static final String departmentId = "departmentId";

	@ApiSingleParam(value = "名称", example = "")
	public static final String orgName = "orgName";
	
	@ApiSingleParam(value = "账号", example = "1")
    public static final String loginName = "loginName";
	
	@ApiSingleParam(value = "上级parentId", example = "1")
    public static final String parentId = "parentId";
	
	
	@ApiSingleParam(value = "排序编号", example = "0")
    public static final String orderNum = "orderNum";
	
	
	@ApiSingleParam(value = "机构类型，0：顶级机构， 1：省份或直辖市，2：分校，3：部门， 4：代理商", example = "1")
    public static final String orgType = "orgType";
	
	

}
