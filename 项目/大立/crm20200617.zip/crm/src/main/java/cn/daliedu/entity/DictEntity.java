package cn.daliedu.entity;

import java.time.LocalDateTime;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 数据字典表，存储系统中静态的或少量变动的格式化数据
 * </p>
 *
 * @author xiechao
 * @since 2019-09-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("sys_dict")
public class DictEntity extends Model<DictEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private Integer id;

    /**
     * 数据类型，存储数据如，user-type，customer_type等
     */
    private String tag;

    /**
     * 数据名称
     */
    private String name;

    /**
     * 数据标签值，标签上显示的内容对应的值
     */
    private String value;

    /**
     * 描述
     */
    private String remark;

    /**
     * 字典级别,0表示系统级别;1表示用户创建
     */
    private String level;

    /**
     * 是否可用,1:可用true, 0：不可用false
     */
    private String available;

    /**
     * 是否默认选中，1：选中，0：不选中
     */
    private String defaultSelected;

    /**
     * 是否可编辑（为以后做后台编辑数据字典预留，不可编辑的数据字典，则可以使用枚举类编写代码），0：不可编辑，1：可编辑
     */
    private String isEdit;

    /**
     * 排序号
     */
    private Integer orderNum;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;



    @Override
    public String toString() {
        return "DictEntity{" +
        "id=" + id +
        ", tag=" + tag +
        ", name=" + name +
        ", value=" + value +
        ", remark=" + remark +
        ", level=" + level +
        ", available=" + available +
        ", defaultSelected=" + defaultSelected +
        ", isEdit=" + isEdit +
        ", orderNum=" + orderNum +
        ", createBy=" + createBy +
        ", createTime=" + createTime +
        ", updateBy=" + updateBy +
        ", updateTime=" + updateTime +
        "}";
    }
}
