package cn.daliedu.enums;

/**
 * 用户枚举类
 * @author xiechao
 * @time 2019年1月9日 下午5:51:51
 * @version 1.0.0
 * @description 
 */
public enum UserTypeEnum {
	/**
	 *  1：超级管理员
	 */
	TYPE_1("1", "超级管理员"), 
	/**
	 * 2：区域管理员
	 */
	TYPE_2("2", "区域管理员"),
	/**
	 * 3：分校管理员
	 */
	TYPE_3("3", "分校管理员"),
	/**
	 * 4：部门管理员
	 */
	TYPE_4("4", "部门管理员"),
	/**
	 * 5：销售人员
	 */
	TYPE_5("5", "销售人员"),
	/**
	 * 6：普通用户
	 */
	TYPE_6("6", "普通用户"),
	/**
	 * 7：代理商用户
	 */
	TYPE_7("7", "代理商用户");
	

	private String value;
	private String desc;

	UserTypeEnum(final String value, final String desc) {
		this.value = value;
		this.desc = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}