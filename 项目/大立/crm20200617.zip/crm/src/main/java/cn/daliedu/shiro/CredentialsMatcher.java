package cn.daliedu.shiro;


import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authc.credential.SimpleCredentialsMatcher;

import cn.daliedu.util.Log4jUtil;
import cn.daliedu.util.MD5Util;

//SimpleCredentialsMatcher不进行加密，仅仅匹配密码对应的字节数组
public class CredentialsMatcher extends SimpleCredentialsMatcher {
 
	@Override
	public boolean doCredentialsMatch(AuthenticationToken token, AuthenticationInfo info) {
		UsernamePasswordToken utoken = (UsernamePasswordToken) token;
		// 获得用户输入的密码:(可以采用加盐(salt)的方式去检验)
		String inPassword = new String(utoken.getPassword());
		// 获得数据库中的密码
		String dbPassword = (String) info.getCredentials();
		
		Log4jUtil.info("密码比对：" + inPassword);
		Log4jUtil.info("密码比对：" + dbPassword);
		
		boolean flag = this.equals(MD5Util.encrypt(inPassword), dbPassword);
		Log4jUtil.info("密码比对结果：" + flag);
		// 进行密码的比对
		return flag;
	}

}
