package cn.daliedu.service;

import cn.daliedu.entity.ParameterEntity;
import cn.daliedu.entity.SmsTemplateEntity;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 系统参数表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-12-31
 */
public interface ParameterService extends IService<ParameterEntity> {
	
	/**
	 * 获取系统参数集合
	 * @param map 
	 * @return
	 */
	public IPage<ParameterEntity> getSysParameterList(Map<Object, Object> map);
	
	/**
	 * 根据参数的key获取参数对象
	 * @param paramKey
	 * @return
	 */
	public ParameterEntity getParameterByKey(String paramKey);
	
}
