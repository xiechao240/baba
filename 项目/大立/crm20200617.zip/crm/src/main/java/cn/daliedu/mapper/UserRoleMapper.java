package cn.daliedu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import cn.daliedu.entity.UserRoleEntity;

/**
 * <p>
 * 用户角色 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
public interface UserRoleMapper extends BaseMapper<UserRoleEntity> {
	
	
	
	
}
