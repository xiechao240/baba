package cn.daliedu.mapper;

import cn.daliedu.entity.UserCustomerEntity;

import java.util.Map;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 用户客户表，存储用户关联的客户数据 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-09-26
 */
public interface UserCustomerMapper extends BaseMapper<UserCustomerEntity> {
	
	/**
	 * 移除共享给我的客户
	 * @param map
	 * @return
	 */
	public Integer removeShareToMyCustomer(Map<Object, Object> map);
	
	/**
	 * 批量移动客户分组
	 * @param map
	 * @return
	 */
	public Integer moveCustomerGroupByCustomerId(Map<Object, Object> map);
	
}
