package cn.daliedu.controller.api.console;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.ParameterEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.json.GlobalJson;
import cn.daliedu.entity.json.NoticeJson;
import cn.daliedu.entity.json.ParameterJson;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.NoticeService;
import cn.daliedu.service.ParameterService;
import cn.daliedu.util.LocalDateTimeUtil;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 系统参数表 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2020-02-12
 */
@Api(description = "系统参数模块")
@RestController
@RequestMapping("${rest.path}/sysParameter")
public class ParameterController {
	@Autowired
	ParameterService parameterService;
	
	@ApiOperation(value = "获取系统参数集合接口")
	@ApiJsonObject(name = "getSysParameterList", value = { 
			@ApiJsonProperty(name = ParameterJson.paramName),
			@ApiJsonProperty(name = ParameterJson.paramKey),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getSysParameterList")
	@PostMapping("/getSysParameterList")
	public Result getSysParameterList(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
			String paramName = String.valueOf(jsonObject.get("paramName"));
			String paramKey = String.valueOf(jsonObject.get("paramKey"));
			
			StringUtil.validateIsNull(pageNum, "请输入页码");
			StringUtil.validateIsNull(pageSize, "请输入每页记录数");
			
            
            Map<Object, Object> paramMap = new HashMap<Object, Object>();
            paramMap.put("pageNum", pageNum);
            paramMap.put("pageSize", Integer.parseInt(pageSize));
            paramMap.put("paramName", paramName);
            paramMap.put("paramKey", paramKey);
			
            IPage<ParameterEntity> page = parameterService.getSysParameterList(paramMap);
			
			return Result.success(page);
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取系统公告失败，失败原因：" + e.getMessage());
		}
	}

	@ApiOperation(value = "新增系统参数接口")
	@ApiJsonObject(name = "saveSysParameter", value = { 
			@ApiJsonProperty(name = ParameterJson.paramName),
			@ApiJsonProperty(name = ParameterJson.paramKey),
			@ApiJsonProperty(name = ParameterJson.paramValue),
			@ApiJsonProperty(name = ParameterJson.paramDesc)})
	@ApiImplicitParam(name = "params", required = true, dataType = "saveSysParameter")
	@PostMapping("/saveSysParameter")
	public Result saveSysParameter(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String paramName = String.valueOf(jsonObject.get("paramName"));
			String paramKey = String.valueOf(jsonObject.get("paramKey"));
			String paramValue = String.valueOf(jsonObject.get("paramValue"));
			String paramDesc = String.valueOf(jsonObject.get("paramDesc"));
			
			StringUtil.validateIsNull(paramName, "请输入参数名称");
			StringUtil.validateIsNull(paramKey, "请输入参数key");
			StringUtil.validateIsNull(paramValue, "请输入参数值");
			
			paramName = paramName.trim();
			paramKey = paramKey.trim();
			paramValue = paramValue.trim();
			
			Object object = SecurityUtils.getSubject().getPrincipal();
			UserEntity user = (UserEntity) object;
			
			ParameterEntity entity = new ParameterEntity();
			entity.setParamName(paramName);
			entity.setParamKey(paramKey);
			entity.setParamValue(paramValue);
			entity.setParamDesc(paramDesc);
			entity.setCreaterById(user.getId());
			entity.setCreateDateTime(LocalDateTime.now());
			entity.setCreaterByName(user.getUserName());
			entity.setUpdaterById(user.getId());
			entity.setUpdateDateTime(LocalDateTime.now());
			entity.setUpdaterByName(user.getUserName());
			
			boolean flag = parameterService.save(entity);
			if(flag){
				return Result.success("新增成功！");
			}
			return Result.error("新增失败");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("新增系统参数失败，失败原因：" + e.getMessage());
		}
	}

	@ApiOperation(value = "修改系统参数接口")
	@ApiJsonObject(name = "updateSysParameter", value = { 
			@ApiJsonProperty(name = NoticeJson.id),
			@ApiJsonProperty(name = ParameterJson.paramName),
			@ApiJsonProperty(name = ParameterJson.paramKey),
			@ApiJsonProperty(name = ParameterJson.paramValue),
			@ApiJsonProperty(name = ParameterJson.paramDesc)})
	@ApiImplicitParam(name = "params", required = true, dataType = "updateSysParameter")
	@PostMapping("/updateSysParameter")
	public Result updateSysParameter(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String id = String.valueOf(jsonObject.get("id"));
			String paramName = String.valueOf(jsonObject.get("paramName"));
			String paramKey = String.valueOf(jsonObject.get("paramKey"));
			String paramValue = String.valueOf(jsonObject.get("paramValue"));
			String paramDesc = String.valueOf(jsonObject.get("paramDesc"));
			
			StringUtil.validateIsNull(id, "请输入参数ID");
			StringUtil.validateIsNull(paramName, "请输入参数名称");
			StringUtil.validateIsNull(paramKey, "请输入参数key");
			StringUtil.validateIsNull(paramValue, "请输入参数值");
			
			id = id.trim();
			paramName = paramName.trim();
			paramKey = paramKey.trim();
			paramValue = paramValue.trim();
			
			Object object = SecurityUtils.getSubject().getPrincipal();
			UserEntity user = (UserEntity) object;
			
			ParameterEntity entity = new ParameterEntity();
			entity.setId(id);
			entity.setParamName(paramName);
			entity.setParamKey(paramKey);
			entity.setParamValue(paramValue);
			entity.setParamDesc(paramDesc);
			entity.setUpdaterById(user.getId());
			entity.setUpdateDateTime(LocalDateTime.now());
			entity.setUpdaterByName(user.getUserName());
			
			boolean flag = parameterService.updateById(entity);
			if(flag){
				return Result.success("修改成功！");
			}
			return Result.error("修改失败");
			
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("修改系统参数失败，失败原因：" + e.getMessage());
		}
	}


}
