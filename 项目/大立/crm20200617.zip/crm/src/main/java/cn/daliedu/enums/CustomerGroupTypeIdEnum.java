package cn.daliedu.enums;

/**
 * 客户分组类型枚举类
 * @author xiechao
 * @time 2019年9月27日 下午2:44:36
 * @version 1.0.0 
 * @description
 */
public enum  CustomerGroupTypeIdEnum {
	/**
	 * 客户分组类型：一般客户
	 */
	TYPE_1("1", "一般客户"), 
	/**
	 * 客户分组类型：意向客户
	 */
	TYPE_2("2", "意向客户"),
	/**
	 * 客户分组类型：已成交客户
	 */
	TYPE_3("3", "已成交客户"),
	/**
	 * 客户分组类型：无意向客户
	 */
	TYPE_4("4", "无意向客户"),
	/**
	 * 客户分组类型：拉黑客户
	 */
	TYPE_5("5", "拉黑客户"),
	/**
	 * 客户分组类型：其他
	 */
	TYPE_6("6", "其他");

	private String value;
	private String desc;

	CustomerGroupTypeIdEnum(final String value, final String desc) {
		this.value = value;
		this.desc = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
	
	/**
     * 根据枚举值获取枚举描述
     * @param key
     * @return
     */
    public static String getDesc(String value){
    	String returnStr = "";
        for (CustomerGroupTypeIdEnum e: CustomerGroupTypeIdEnum.values()){
            if(e.getValue().equals(value)){
            	returnStr = e.getDesc();
            	break;
            }
        }
		return returnStr;
    }
}