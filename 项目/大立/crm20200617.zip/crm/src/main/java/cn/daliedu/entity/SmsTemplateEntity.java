package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 短信模板表
 * </p>
 *
 * @author xiechao
 * @since 2019-12-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("sys_sms_template")
public class SmsTemplateEntity extends Model<SmsTemplateEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "template_id", type = IdType.UUID)
    private String templateId;
    
    /**
     * 模板名称
     */
    private String templateName;

    /**
     * 模板编号
     */
    private String templateCode;

    /**
     * 模板内容
     */
    private String templateContent;
    
    /**
     * 模板参数1名称
     */
    private String param1;

    /**
     * 模板参数2名称
     */
    private String param2;

    /**
     * 模板参数3名称
     */
    private String param3;



    @Override
    protected Serializable pkVal() {
        return this.templateId;
    }

}
