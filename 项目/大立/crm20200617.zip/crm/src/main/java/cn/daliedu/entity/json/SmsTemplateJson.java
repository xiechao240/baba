package cn.daliedu.entity.json;

import cn.daliedu.config.swagger.model.ApiSingleParam;

/**
 * @author xiechao
 * @time 2019年4月23日 下午2:29:04
 * @version 1.0.0 
 * @description 
 */
public class SmsTemplateJson {
	/**
	 * 短信内容
	 */
	@ApiSingleParam(value = "短信内容", example = "这是一条测试短信")
	public static final String smsContent = "smsContent";

	/**
	 * 模板ID
	 */
	@ApiSingleParam(value = "模板ID", example = "1")
    public static final String templateId = "templateId";

	/**
	 * 模板名称
	 */
    @ApiSingleParam(value = "模板名称", example = "注册码")
    public static final String templateName = "templateName";
    
    /**
	 * 模板编号
	 */
    @ApiSingleParam(value = "模板编号", example = "SMS_179155048")
    public static final String templateCode = "templateCode";
    
    /**
	 * 模板内容
	 */
    @ApiSingleParam(value = "模板内容", example = "尊敬的用户，您的账号${name}在大立教育平台的${course}课程已开通,请合理安排时间学习哦")
    public static final String templateContent = "templateContent";
    
    /**
	 * 模板参数1
	 */
    @ApiSingleParam(value = "模板参数1", example = "param1")
    public static final String param1 = "param1";
    
    /**
	 * 模板参数2
	 */
    @ApiSingleParam(value = "模板参数2", example = "param2")
    public static final String param2 = "param2";
    
    /**
	 * 模板参数3
	 */
    @ApiSingleParam(value = "模板参数3", example = "param3")
    public static final String param3 = "param3";
    
    

    
}
