package cn.daliedu.shiro.redis;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.session.UnknownSessionException;
import org.apache.shiro.session.mgt.SessionKey;
import org.apache.shiro.web.servlet.ShiroHttpServletRequest;
import org.apache.shiro.web.session.mgt.DefaultWebSessionManager;
import org.apache.shiro.web.session.mgt.WebSessionKey;
import org.apache.shiro.web.util.WebUtils;

import cn.daliedu.util.Log4jUtil;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.io.Serializable;

public class SessionManager extends DefaultWebSessionManager {
	private static final String AUTHORIZATION = "Token";

	private static final String REFERENCED_SESSION_ID_SOURCE = "Stateless request";

	public SessionManager() {
	}

	@Override
	protected Serializable getSessionId(ServletRequest request, ServletResponse response) {
//		System.out.println("获取请求头Cookie内容 ：" + WebUtils.toHttp(request).getHeader("Cookie"));
//		System.out.println("获取请求头Cookies内容 ：" + WebUtils.toHttp(request).getHeader("Cookies"));

		String cookies = WebUtils.toHttp(request).getHeader("Cookies");
		
		String cookie = WebUtils.toHttp(request).getHeader("Cookie");
		
		if (cookie != null && !cookie.equals("") && cookie.indexOf("SHIRO_SESSION_ID")!=-1) {//直接加上SHIRO_SESSION_ID的查找，解决前端传了cookie又传了cookies，但只在其中一个中加了SHIRO_SESSION_ID的问题
			//下面为做大立crm时，莫莫直接传 SHIRO_SESSION_ID=dbed1777-27c5-46dd-b407-b95832eed6fd的写法
//			if(cookie.indexOf("SHIRO_SESSION_ID")!=-1){
        		String token = cookie.substring(cookie.indexOf("SHIRO_SESSION_ID")+17, cookie.indexOf("SHIRO_SESSION_ID")+53);
				if (token != null) {
					request.setAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID_SOURCE, REFERENCED_SESSION_ID_SOURCE);
					request.setAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID, token);
					request.setAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID_IS_VALID, Boolean.TRUE);
				
//					System.out.println("返回token:" + token);
					return token;
				}
//			}
			//下面为之前做渠道版本时的做法，有多个值，所以需要去拆分  分号
//			if (cookie.indexOf("; ") != -1) {
//				String[] str = cookie.split("; ");
//				String token = str[0].substring(str[0].indexOf("=") + 1, str[0].length());
//
//				if (token != null) {
//					request.setAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID_SOURCE, REFERENCED_SESSION_ID_SOURCE);
//					request.setAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID, token);
//					request.setAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID_IS_VALID, Boolean.TRUE);
//					
////					System.out.println("返回token:" + token);
//					return token;
//				}
//			}
			return super.getSessionId(request, response);
		} 
		
		if (cookies != null && !cookies.equals("") && cookies.indexOf("SHIRO_SESSION_ID")!=-1) {//直接加上SHIRO_SESSION_ID的查找，解决前端传了cookie又传了cookies，但只在其中一个中加了SHIRO_SESSION_ID的问题
			//下面为做大立crm时，莫莫直接传 SHIRO_SESSION_ID=dbed1777-27c5-46dd-b407-b95832eed6fd的写法
//			if(cookies.indexOf("SHIRO_SESSION_ID")!=-1){
        		String token = cookies.substring(cookies.indexOf("SHIRO_SESSION_ID")+17, cookies.indexOf("SHIRO_SESSION_ID")+53);
				if (token != null) {
					request.setAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID_SOURCE, REFERENCED_SESSION_ID_SOURCE);
					request.setAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID, token);
					request.setAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID_IS_VALID, Boolean.TRUE);
				
//					System.out.println("返回token:" + token);
					return token;
				}
//			}
			
			//下面为之前做渠道版本时的做法，有多个值，所以需要去拆分  分号
//			if (cookies.indexOf("; ") != -1) {
//				String[] str = cookies.split("; ");
//				String token = str[0].substring(str[0].indexOf("=") + 1, str[0].length());
//
//				if (token != null) {
//					request.setAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID_SOURCE, REFERENCED_SESSION_ID_SOURCE);
//					request.setAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID, token);
//					request.setAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID_IS_VALID, Boolean.TRUE);
//					
////					System.out.println("返回token:" + token);
//					return token;
//				}
//			}
			return super.getSessionId(request, response);
		}
		
		// 若header获取不到token则尝试从cookie中获取
//		System.out.println("获取cook sessionID....");
		// // 否则按默认规则从cookie取sessionId
		return super.getSessionId(request, response);
		

		// //获取请求头，或者请求参数中的Token
//		String id = StringUtils.isEmpty(WebUtils.toHttp(request).getHeader(AUTHORIZATION))
//                ? request.getParameter(AUTHORIZATION) : WebUtils.toHttp(request).getHeader(AUTHORIZATION);
//                Log4jUtil.info("获取的token: " + id);
//                Log4jUtil.info("获取请求头中的token: " + WebUtils.toHttp(request).getHeader(AUTHORIZATION));
//        // 如果请求头中有 Token 则其值为sessionId
//        if (StringUtils.isNotEmpty(id)) {
//            request.setAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID_SOURCE, REFERENCED_SESSION_ID_SOURCE);
//            request.setAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID, id);
//            request.setAttribute(ShiroHttpServletRequest.REFERENCED_SESSION_ID_IS_VALID, Boolean.TRUE);
// 
//            return id;
//        } else {
//        	Log4jUtil.info("获取cook sessionID....");
//            // 否则按默认规则从cookie取sessionId
//            return super.getSessionId(request, response);
//        }
	}

	/**
	 * 获取session 优化单次请求需要多次访问redis的问题
	 *
	 * @param sessionKey
	 * @return
	 * @throws UnknownSessionException
	 */
	@Override
	protected Session retrieveSession(SessionKey sessionKey) throws UnknownSessionException {
		Serializable sessionId = getSessionId(sessionKey);

		ServletRequest request = null;
		if (sessionKey instanceof WebSessionKey) {
			request = ((WebSessionKey) sessionKey).getServletRequest();
		}

		if (request != null && null != sessionId) {
			Object sessionObj = request.getAttribute(sessionId.toString());
			if (sessionObj != null) {
				return (Session) sessionObj;
			}
		}

		Session session = super.retrieveSession(sessionKey);
		if (request != null && null != sessionId) {
			request.setAttribute(sessionId.toString(), session);
		}
		return session;
	}
}
