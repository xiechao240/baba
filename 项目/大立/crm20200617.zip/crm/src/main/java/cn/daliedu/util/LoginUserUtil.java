//package cn.daliedu.util;
//
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import org.apache.shiro.SecurityUtils;
//
//import cn.daliedu.constants.DictDefinition;
//import cn.daliedu.entity.MenuEntity;
//import cn.daliedu.entity.RoleEntity;
//import cn.daliedu.entity.web.LoginUserInfo;
//
//
//
//public class LoginUserUtil {
//
//	private static Map<Integer, List<Integer>> loginUserAccessibleOrgIdsMap = new HashMap<Integer, List<Integer>>();
//	private static Map<Integer, List<Integer>> loginUserAccessibleAppIdsMap = new HashMap<Integer, List<Integer>>();
//	
//	public static LoginUserInfo getLoginUserInfo() {
//		return (LoginUserInfo) SecurityUtils.getSubject().getPrincipal();
//	}
//	
//	/**
//	 * 获取当前登录用户的id
//	 * @return
//	 */
//	public static Integer getLoginUserId() {
//		if (getLoginUserInfo()==null) {
//			return null;
//		}		
//		return getLoginUserInfo().getUser().getId();
//	}
//	
//	/**
//	 * 获取当前登录用户的数据权限域
//	 * @return
//	 */
//	public static Integer getLoginUserDataScope() {
//		if (getLoginUserInfo()==null) {
//			return null;
//		}		
//		return getLoginUserInfo().getUserDataScope();
//	}
//	
//	/**
//	 * 获取当前登录用户的可访问的组织机构集合
//	 * @return
//	 */
//	public static List<Integer> getLoginUserAccessibleOrgIds() {
//		LoginUserInfo userInfo = getLoginUserInfo();
//		if (userInfo==null) {
//			return null;
//		}		
//		List<Integer> orgIds = loginUserAccessibleOrgIdsMap.get(userInfo.getUser().getId());
//		if (orgIds==null) {
//			orgIds = userInfo.getOrgIds();
//			if (orgIds!=null) {
//				loginUserAccessibleOrgIdsMap.put(userInfo.getUser().getId(), orgIds);
//			}
//		}
//		return orgIds;
//	}
//	
//	/**
//	 * 获取当前登录用户的appIds集合
//	 * @return
//	 */
//	public static List<Integer> getLoginUserAccessibleAppIds() {
//		
//		LoginUserInfo userInfo = getLoginUserInfo();
//		if (userInfo==null) {
//			return null;
//		}		
//		List<Integer> appIds = loginUserAccessibleAppIdsMap.get(userInfo.getUser().getId());
//		if (appIds==null) {
//			appIds = userInfo.getAppIds();
//			if (appIds!=null) {
//				loginUserAccessibleAppIdsMap.put(userInfo.getUser().getId(), appIds);
//			}
//		}
//		return appIds;
//	}
//	
//	/**
//	 * 重置当前登录用户可访问的组织机构集合
//	 * @return
//	 */
//	public static void resetUserAccessibleOrgIds(int userId, List<Integer> orgIds) {
//		if (orgIds!=null) {
//			loginUserAccessibleOrgIdsMap.put(userId, orgIds);
//		} else {
//			loginUserAccessibleOrgIdsMap.remove(userId);
//		}
//	}
//	
//	/**
//	 * 重置当前登录用户可访问的appids集合
//	 * @return
//	 */
//	public static void resetUserAccessibleAppIds(int userId, List<Integer> appIds) {
//		if (appIds!=null) {
//			loginUserAccessibleAppIdsMap.put(userId, appIds);
//		} else {
//			loginUserAccessibleAppIdsMap.remove(userId);
//		}
//	}
//	
//	/**
//	 * 获取当前登录的用户类型
//	 * @return
//	 */
//	public static String getLoginUserType() {
//		if (getLoginUserInfo()==null) {
//			return null;
//		}		
//		return getLoginUserInfo().getUser().getUserType();
//	}
//	
//	/**
//	 * 获取当前登录用户的ID，并转为String类型
//	 * @return
//	 */
//	public static String getLoginUserIdAsString() {
//		if (getLoginUserInfo()==null) {
//			return null;
//		}
//		return String.valueOf(getLoginUserInfo().getUser().getId());
//	}
//	
//	/**
//	 * 获取登录用户的名称
//	 * @return
//	 */
//	public static String getLoginUserName() {
//		if (getLoginUserInfo()==null) {
//			return null;
//		}
//		return getLoginUserInfo().getUser().getName();
//	}
//	
//	/**
//	 * 获取登录的账号
//	 * @return
//	 */
//	public static String getLoginUserAccount() {
//		if (getLoginUserInfo()==null) {
//			return null;
//		}
//		return getLoginUserInfo().getUser().getAccount();
//	}
//	
//	/**
//	 * 判断用户是否为开发管理员用户
//	 * @return
//	 */
//	public static boolean isDeveloper() {
//		if (getLoginUserInfo()==null) {
//			return false;
//		}
//		String userType = getLoginUserInfo().getUser().getUserType();
//		if (DictDefinition.USER_TYPE_DEVELOPER.equals(userType)) {
//			return true;
//		}
//		return false;
//	}
//	
//	/**
//	 * 判断用户是否为项目管理员用户
//	 * @return
//	 */
//	public static boolean isProjectAdmin() {
//		if (getLoginUserInfo()==null) {
//			return false;
//		}
//		String userType = getLoginUserInfo().getUser().getUserType();
//		if (DictDefinition.USER_TYPE_PROJECT_MANAGER.equals(userType)) {
//			return true;
//		}
//		return false;
//	}
//	
//	/**
//	 * 判断用户是否为系统管理员用户
//	 * @return
//	 */
//	public static boolean isSysAdmin() {
//		if (getLoginUserInfo()==null) {
//			return false;
//		}
//		String userType = getLoginUserInfo().getUser().getUserType();
//		if (DictDefinition.USER_TYPE_SYS_MANAGER.equals(userType)) {
//			return true;
//		}
//		return false;
//	}
//	
//	/**
//	 * 判断用户是否为机构管理员用户
//	 * @return
//	 */
//	public static boolean isOrgAdmin() {
//		if (getLoginUserInfo()==null) {
//			return false;
//		}
//		String userType = getLoginUserInfo().getUser().getUserType();
//		if (DictDefinition.USER_TYPE_ORG_MANAGER.equals(userType)) {
//			return true;
//		}
//		return false;
//	}
//	
//	/**
//	 * 判断用户是否为普通用户
//	 * @return
//	 */
//	public static boolean isOrgUser() {
//		if (getLoginUserInfo()==null) {
//			return false;
//		}
//		String userType = getLoginUserInfo().getUser().getUserType();
//		if (DictDefinition.USER_TYPE_ORG_USER.equals(userType)) {
//			return true;
//		}
//		return false;
//	}
//	
//	/**
//	 * 获取用户所在机构id
//	 * @return
//	 */
//	public static Integer getLoginUserOrgId() {
//		if (getLoginUserInfo()==null) {
//			return null;
//		}
//		return getLoginUserInfo().getUser().getOrgId();
//	}
//	
//	/**
//	 * 获取用户所在公司id
//	 * @return
//	 */
//	public static Integer getLoginUserCompanyId() {
//		if (getLoginUserInfo()==null) {
//			return null;
//		}
//		return getLoginUserInfo().getOrgId();
//	}
//	
//	/**
//	 * 获取用户所在顶级机构id
//	 * @return
//	 */
//	public static Integer getLoginUserTopOrgId() {
//		if (getLoginUserInfo()==null) {
//			return null;
//		}
//		return getLoginUserInfo().getTopOrgId();
//	}
//	
//	/**
//	 * 获取当前用户的直属机构id(非部门)
//	 * @return
//	 */
//	public static Integer getLoginUserDataScopeOrgId() {
//		if (getLoginUserInfo()==null) {
//			return null;
//		}
//		return getLoginUserInfo().getOrgId();
//	}
//	
//	/**
//	 * 获取登录用户的菜单集合
//	 * @return
//	 */
//	public static List<MenuEntity> getMenuList() {
//		if (getLoginUserInfo()==null) {
//			return null;
//		}
//		return getLoginUserInfo().getMenuList();
//	}
//	
//	/**
//	 * 获取登录用户的角色集合
//	 * @return
//	 */
//	public static List<RoleEntity> getRoleList() {
//		if (getLoginUserInfo()==null) {
//			return null;
//		}
//		return getLoginUserInfo().getRoleList();
//	}
//}
