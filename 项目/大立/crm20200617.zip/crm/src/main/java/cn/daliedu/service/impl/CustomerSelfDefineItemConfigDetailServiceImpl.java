package cn.daliedu.service.impl;

import cn.daliedu.entity.CustomerSelfDefineItemConfigDetailEntity;
import cn.daliedu.entity.CustomerTagGroupDetailEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.mapper.CustomerSelfDefineItemConfigDetailMapper;
import cn.daliedu.service.CustomerSelfDefineItemConfigDetailService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import java.time.LocalDateTime;
import java.util.List;

import javax.annotation.Resource;

import org.apache.shiro.SecurityUtils;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 客户自定义类别配置明细表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2020-05-20
 */
@Service
public class CustomerSelfDefineItemConfigDetailServiceImpl extends ServiceImpl<CustomerSelfDefineItemConfigDetailMapper, CustomerSelfDefineItemConfigDetailEntity> implements CustomerSelfDefineItemConfigDetailService {
	
	@Resource
	CustomerSelfDefineItemConfigDetailMapper customerSelfDefineItemConfigDetailMapper;
	
	@Override
	public List<CustomerSelfDefineItemConfigDetailEntity> getCustomerSelfDefineItemConfigDetailByItemId(String itemId) {
		return customerSelfDefineItemConfigDetailMapper.selectList(new QueryWrapper<CustomerSelfDefineItemConfigDetailEntity>().eq("item_id", itemId).orderByAsc("order_num"));
	}

	@Override
	public boolean saveCustomerSelfDefineItemConfigDetail(String itemId, String itemDetailName) throws Exception {
		Integer orderNum = customerSelfDefineItemConfigDetailMapper.getMaxCustomerSelfDefineItemDetailValueByItemId(itemId);
		
		CustomerSelfDefineItemConfigDetailEntity entity = new CustomerSelfDefineItemConfigDetailEntity();
		entity.setItemId(itemId);
		entity.setItemDetailName(itemDetailName);
		entity.setOrderNum(orderNum==null ? 0 : orderNum+1);
		
		
		int num = customerSelfDefineItemConfigDetailMapper.insert(entity);
		if(num>0){
			return true;
		}
		return false;
	}

	@Override
	public boolean existsCustomerSelfDefineItemConfigDetail(String itemId, String itemDetailName) {
		List<CustomerSelfDefineItemConfigDetailEntity> list = customerSelfDefineItemConfigDetailMapper.selectList(new QueryWrapper<CustomerSelfDefineItemConfigDetailEntity>()
				.eq("item_id", itemId)
				.eq("item_detail_name", itemDetailName));
		if(list!=null && list.size()>0){
			return true;
		}
		return false;
	}
	
}
