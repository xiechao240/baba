package cn.daliedu.entity.web;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * 展现树形节点的model类
 * @author xiechao
 * @date 2019年7月22日 上午11:36:47
 * @Descripton
 */
@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class OrgTreeNode implements Serializable{

	private static final long serialVersionUID = 3947907013587170250L;
	
	private String id;
	private String parentId;
	private String name;

	private Integer orderNum;


	//子区域
	private List<OrgTreeNode> children;


	
	
}
