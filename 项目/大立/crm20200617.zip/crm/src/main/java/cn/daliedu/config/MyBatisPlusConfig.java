package cn.daliedu.config;

import java.util.Properties;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.baomidou.mybatisplus.core.injector.ISqlInjector;
import com.baomidou.mybatisplus.extension.injector.LogicSqlInjector;
import com.baomidou.mybatisplus.extension.plugins.PaginationInterceptor;
import com.baomidou.mybatisplus.extension.plugins.PerformanceInterceptor;

/**
 * 
 * @author xiechao
 * @time 2019年1月8日 下午5:07:06
 * @version 1.0.0 
 * @description MyBatisPlus注册控制类
 */
@EnableTransactionManagement
@Configuration
public class MyBatisPlusConfig {

	/**
	 * 注册分页插件
	 */
	@Bean
	public PaginationInterceptor paginationInterceptor() {
		return new PaginationInterceptor();
	}
	
	/**
	 * 注册逻辑删除组件
	 * @return
	 */
    @Bean
    public ISqlInjector sqlInjector() {
        return new LogicSqlInjector();
    }
    
    /**
     * 注册性能分析插件，并格式化sql语句，打印sql执行时间
     */
    @Bean
    public PerformanceInterceptor performanceInterceptor() {
        PerformanceInterceptor performanceInterceptor = new PerformanceInterceptor();
        //格式化sql语句
        Properties properties = new Properties();
        properties.setProperty("format", "false"); //参数：format SQL SQL是否格式化，默认false
//        properties.setProperty("maxTime", "100");  //参数：maxTime SQL 执行最大时长，超过自动停止运行，有助于发现问题
        performanceInterceptor.setProperties(properties);
        return performanceInterceptor;
    }
    
    //SqlExplainInterceptor  sql执行计划，这个在mybatils plus3.x版本的官网上还没有这个，估计还在开发中，
    //不过有要求说mysql数据库需要5.6.3以上的版本才支持

}
