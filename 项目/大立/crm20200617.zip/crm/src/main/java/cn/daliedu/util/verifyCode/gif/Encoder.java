package cn.daliedu.util.verifyCode.gif;

import java.io.IOException;
import java.io.OutputStream;

class Encoder
{
    private static final int EOF = -1;

    private int imgW, imgH;

    private byte[] pixAry;

    private int initCodeSize;

    private int remaining;

    private int curPixel;

    private static final int BITS = 12;

    private static final int H_SIZE = 5003;

    private int n_bits;

    private int maxBits = BITS;

    private int maxCode;

    private int maxMaxCode = 1 << BITS;

    private int[] hTab = new int[H_SIZE];

    private int[] codeTab = new int[H_SIZE];

    private int hSize = H_SIZE;

    private int free_ent = 0;

    private boolean clear_flg = false;

    private int g_init_bits;

    private int clearCode;

    private int eofCode;

    private int cur_count = 0;

    private int cur_bits = 0;

    private int masks[] = {0x0000, 0x0001, 0x0003, 0x0007, 0x000F, 0x001F, 0x003F, 0x007F, 0x00FF, 0x01FF, 0x03FF,
        0x07FF, 0x0FFF, 0x1FFF, 0x3FFF, 0x7FFF, 0xFFFF};

    private int a_count;

    private byte[] count = new byte[256];

    Encoder(int width, int height, byte[] pixels, int color_depth)
    {
        imgW = width;
        imgH = height;
        pixAry = pixels;
        initCodeSize = Math.max(2, color_depth);
    }

    private void char_out(byte c, OutputStream outs)
        throws IOException
    {
        count[a_count++] = c;
        if (a_count >= 254)
            flush_char(outs);
    }

    private void cl_block(OutputStream outs)
        throws IOException
    {
        cl_hash(hSize);
        free_ent = clearCode + 2;
        clear_flg = true;

        output(clearCode, outs);
    }

    private void cl_hash(int hSize)
    {
        for (int i = 0; i < hSize; ++i)
            hTab[i] = -1;
    }

    private void compress(int init_bits, OutputStream outs)
        throws IOException
    {
        int fCode;
        int i /* = 0 */;
        int c;
        int ent;
        int disP;
        int hSize_reg;
        int hShift;

        g_init_bits = init_bits;

        clear_flg = false;
        n_bits = g_init_bits;
        maxCode = MAXCODE(n_bits);

        clearCode = 1 << (init_bits - 1);
        eofCode = clearCode + 1;
        free_ent = clearCode + 2;

        a_count = 0;

        ent = nextPixel();

        hShift = 0;
        for (fCode = hSize; fCode < 65536; fCode *= 2)
            ++hShift;
        hShift = 8 - hShift;

        hSize_reg = hSize;
        cl_hash(hSize_reg);

        output(clearCode, outs);

        outer_loop:
        while ((c = nextPixel()) != EOF)
        {
            fCode = (c << maxBits) + ent;
            i = (c << hShift) ^ ent;

            if (hTab[i] == fCode)
            {
                ent = codeTab[i];
                continue;
            }
            else if (hTab[i] >= 0)
            {
                disP = hSize_reg - i;
                if (i == 0)
                    disP = 1;
                do
                {
                    if ((i -= disP) < 0)
                        i += hSize_reg;

                    if (hTab[i] == fCode)
                    {
                        ent = codeTab[i];
                        continue outer_loop;
                    }
                } while (hTab[i] >= 0);
            }
            output(ent, outs);
            ent = c;
            if (free_ent < maxMaxCode)
            {
                codeTab[i] = free_ent++;
                hTab[i] = fCode;
            }
            else
                cl_block(outs);
        }

        output(ent, outs);
        output(eofCode, outs);
    }

    void encode(OutputStream os)
        throws IOException
    {
        os.write(initCodeSize);

        remaining = imgW * imgH;
        curPixel = 0;

        compress(initCodeSize + 1, os);

        os.write(0);
    }

    private void flush_char(OutputStream outs)
        throws IOException
    {
        if (a_count > 0)
        {
            outs.write(a_count);
            outs.write(count, 0, a_count);
            a_count = 0;
        }
    }

    private int MAXCODE(int n_bits)
    {
        return (1 << n_bits) - 1;
    }

    private int nextPixel()
    {
        if (remaining == 0)
            return EOF;

        --remaining;

        byte pix = pixAry[curPixel++];

        return pix & 0xff;
    }

    private void output(int code, OutputStream outs)
        throws IOException
    {
        cur_count &= masks[cur_bits];

        if (cur_bits > 0)
            cur_count |= (code << cur_bits);
        else
            cur_count = code;

        cur_bits += n_bits;

        while (cur_bits >= 8)
        {
            char_out((byte)(cur_count & 0xff), outs);
            cur_count >>= 8;
            cur_bits -= 8;
        }

        if (free_ent > maxCode || clear_flg)
        {
            if (clear_flg)
            {
                maxCode = MAXCODE(n_bits = g_init_bits);
                clear_flg = false;
            }
            else
            {
                ++n_bits;
                if (n_bits == maxBits)
                    maxCode = maxMaxCode;
                else
                    maxCode = MAXCODE(n_bits);
            }
        }

        if (code == eofCode)
        {
            while (cur_bits > 0)
            {
                char_out((byte)(cur_count & 0xff), outs);
                cur_count >>= 8;
                cur_bits -= 8;
            }

            flush_char(outs);
        }
    }
}
