package cn.daliedu.mapper;

import cn.daliedu.entity.CustomerSelfDefineItemEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 客户自定义类别表，其实就是用户给客户进行自定义分类，例如：单班，套班，内训，一建科目等 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2020-06-03
 */
public interface CustomerSelfDefineItemMapper extends BaseMapper<CustomerSelfDefineItemEntity> {

}
