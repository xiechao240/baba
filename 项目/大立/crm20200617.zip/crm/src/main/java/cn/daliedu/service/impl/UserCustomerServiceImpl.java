package cn.daliedu.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.entity.UserCustomerEntity;
import cn.daliedu.mapper.UserCustomerMapper;
import cn.daliedu.service.UserCustomerService;

/**
 * <p>
 * 用户客户表，存储用户关联的客户数据 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-26
 */
@Service
public class UserCustomerServiceImpl extends ServiceImpl<UserCustomerMapper, UserCustomerEntity> implements UserCustomerService {
	
	@Resource
	UserCustomerMapper userCustomerMapper;
	
	
	@Override
	public boolean updateCustomerUserId(String userId, String receiveUserId) throws Exception {
		UserCustomerEntity entity = new UserCustomerEntity();
		entity.setUserId(receiveUserId);
		int num = userCustomerMapper.update(entity, new UpdateWrapper<UserCustomerEntity>().eq("user_id", userId));
		if(num>0){
			return true;
		}
		return false;
	}



	@Override
	public boolean deleteUserCustomerByUserId(String userId) {
		int num = userCustomerMapper.delete(new QueryWrapper<UserCustomerEntity>().eq("user_id", userId));
		if(num>0){
			return true;
		}
		return false;
	}
	
	
	
//	@Override
//	public boolean moveCustomerGroupByCustomerId(String userId, String customerIds, String customerGroupTypeId) {
//		
//		Map<Object, Object> map = new HashMap<Object, Object>();
//		map.put("userId", userId);
//		map.put("customerIds", customerIds);
//		map.put("customerGroupTypeId", customerGroupTypeId);
//		
//		
//		int num = userCustomerMapper.moveCustomerGroupByCustomerId(map);
//		if(num > 0){
//			return true;
//		}
//		return false;
//	}

}
