package cn.daliedu.entity.json;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**组装给前端传递客户流转原因，客户流转操作配置，传递参数时的一个重合对象(暂未启用此类)
 * @author xiechao
 * @time 2019年10月15日 上午11:07:54
 * @version 1.0.0 
 * @description 
 */
@ApiModel(value="客户流转原因操作配置",description="客户流转原因操作配置")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class CustomerFlowOperationAndCause {
	
//	@ApiModelProperty(value="客户流转原因配置")
//	public CustomerFlowCauseConfigEntity[] customerFlowCauseConfigEntity;
	
	@ApiModelProperty(value="客户流转原因操作配置")
	public CustomerFlowOperationConfigJson[] customerFlowOperationConfigJson;
	
}
