package cn.daliedu.service;

import cn.daliedu.entity.UserCustomerEntity;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户客户表，存储用户关联的客户数据 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-26
 */
public interface UserCustomerService extends IService<UserCustomerEntity> {
	
	/**
	 * 更新客户的持有人
	 * @param userId
	 * @param receiveUserId
	 * @return
	 * @throws Exception
	 */
	public boolean updateCustomerUserId(String userId, String receiveUserId) throws Exception;
	
	/**
	 * 移动客户分组功能(此方法暂时不使用，客户分组是属于客户，不是属于用户)
	 * @param userId 用户ID
	 * @param customerId 客户ID
	 * @param customerGroupTypeId 客户分组ID
	 * @return
	 */
//	public boolean moveCustomerGroupByCustomerId(String userId, String customerIds, String customerGroupTypeId);
	
	/**
	 * 根据用户ID，删除用户关联的所有客户数据
	 * @param userId
	 * @return
	 */
	public boolean deleteUserCustomerByUserId(String userId);

}
