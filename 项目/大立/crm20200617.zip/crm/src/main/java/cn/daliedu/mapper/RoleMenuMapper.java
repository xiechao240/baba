package cn.daliedu.mapper;

import cn.daliedu.entity.RoleMenuEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 角色菜单 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
public interface RoleMenuMapper extends BaseMapper<RoleMenuEntity> {

}
