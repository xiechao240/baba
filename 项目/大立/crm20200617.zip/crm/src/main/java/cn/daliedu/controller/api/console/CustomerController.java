package cn.daliedu.controller.api.console;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.UnauthorizedException;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.CustomerEntity;
import cn.daliedu.entity.CustomerSelfDefineItemConfigEntity;
import cn.daliedu.entity.DictEntity;
import cn.daliedu.entity.DictManyDetailEntity;
import cn.daliedu.entity.DictManyEntity;
import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.json.CustomerJson;
import cn.daliedu.entity.json.CustomerModel;
import cn.daliedu.entity.json.CustomerTagJson;
import cn.daliedu.entity.json.GlobalJson;
import cn.daliedu.entity.json.OrgJson;
import cn.daliedu.entity.json.UserJson;
import cn.daliedu.enums.CustomerStageEnum;
import cn.daliedu.enums.ResultCodeEnum;
import cn.daliedu.enums.SexEnum;
import cn.daliedu.enums.UserTypeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.CustomerSelfDefineItemConfigService;
import cn.daliedu.service.CustomerService;
import cn.daliedu.service.CustomerTagService;
import cn.daliedu.service.DictManyDetailService;
import cn.daliedu.service.DictManyService;
import cn.daliedu.service.DictService;
import cn.daliedu.service.MenuService;
import cn.daliedu.service.OrgService;
import cn.daliedu.service.RoleService;
import cn.daliedu.service.UserCustomerService;
import cn.daliedu.service.UserOrgAreaService;
import cn.daliedu.service.UserRoleService;
import cn.daliedu.service.UserService;
import cn.daliedu.util.FileUtil;
import cn.daliedu.util.JsonUtil;
import cn.daliedu.util.LocalDateTimeUtil;
import cn.daliedu.util.PageUtil;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;


/**
 * 客户相关接口控制器
 * @author xiechao
 * @time 2019年5月13日 上午10:33:58
 * @version 1.0.0 
 * @description
 */
@Api(description = "客户相关接口")
@RestController
@RequestMapping(value = "${rest.path}/console/customer") 
public class CustomerController {
	
	@Autowired
	UserService userService;
	
	@Autowired
	RoleService roleService;
	
	@Autowired
	OrgService orgService;
	
	@Autowired
	MenuService menuService;
	
	@Autowired
	UserRoleService userRoleService;
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	CustomerTagService customerTagService;
	
	@Autowired
	UserCustomerService userCustomerService;
	
	@Autowired
	UserOrgAreaService userOrgAreaService;
	
	@Autowired
	DictManyService dictManyService;
	
	@Autowired
	DictService dictService;
	
	@Autowired
	DictManyDetailService dictManyDetailService;
	
	@Autowired
	CustomerSelfDefineItemConfigService customerSelfDefineItemConfigService;
	
	
	@ApiOperation(value = "共享给同事的客户--》取消共享")
	@ApiJsonObject(name = "cancelShareToUserCustomer", value = { 
			@ApiJsonProperty(name = CustomerJson.customerIds)})
	@ApiImplicitParam(name = "params", required = true, dataType = "cancelShareToUserCustomer")
//	@RequiresPermissions("sys:customer:getCustomerByCustomerId")
	@PostMapping("/cancelShareToUserCustomer")
	public Result cancelShareToUserCustomer(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String customerIds = String.valueOf(jsonObject.get("customerIds"));
				
				StringUtil.validateIsNull(customerIds, "请输入客户ID");
				
				List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
				boolean flag = customerService.updateCancelShareToUserCustomer(customerIdList);
				if(flag){
					return Result.success("操作成功");
				}
				return Result.error("操作失败，请联系管理员");
			}
			return Result.error("无法操作取消共享客户，请联系系统管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("取消共享客户失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "共享给我的客户--》移除客户")
	@ApiJsonObject(name = "removeShareToMyCustomer", value = { 
			@ApiJsonProperty(name = CustomerJson.customerIds)})
	@ApiImplicitParam(name = "params", required = true, dataType = "removeShareToMyCustomer")
//	@RequiresPermissions("sys:customer:getCustomerByCustomerId")
	@PostMapping("/removeShareToMyCustomer")
	public Result removeShareToMyCustomer(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String customerIds = String.valueOf(jsonObject.get("customerIds"));
				
				StringUtil.validateIsNull(customerIds, "请输入客户ID");
				
				List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
				boolean flag = customerService.removeShareToMyCustomer(customerIdList);
				if(flag){
					return Result.success("操作成功");
				}
	            return Result.error("操作失败，请联系管理员");
			}
			return Result.error("无法操作移除客户，请联系系统管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("移除客户失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "【资源库】领取客户（将资源库的客户领给自己）")
	@ApiJsonObject(name = "getCustomerByCustomerId", value = { 
			@ApiJsonProperty(name = CustomerJson.customerIds),
			@ApiJsonProperty(name = CustomerJson.customerGroupTypeId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerByCustomerId")
	@RequiresPermissions("sys:customer:getCustomerByRepository")
	@PostMapping("/getCustomerByRepository")
	public Result getCustomerByRepository(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String customerIds = String.valueOf(jsonObject.get("customerIds"));
				String customerGroupTypeId = String.valueOf(jsonObject.get("customerGroupTypeId"));
				
				StringUtil.validateIsNull(customerIds, "请输入客户ID");
				StringUtil.validateIsNull(customerGroupTypeId, "请选择客户分组类型");
				
				List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
				boolean flag = customerService.updateGetCustomerByRepository(customerGroupTypeId, customerIdList);
				if(flag){
					return Result.success("领取客户成功");
				}
	            return Result.error("领取客户失败");
			}
			return Result.error("无法进行领取客户，请联系系统管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("领取客户失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "【分校回收站】领取客户（将分校回收站的客户领给自己）")
	@ApiJsonObject(name = "getCustomerByBusinessGroupSea", value = { 
			@ApiJsonProperty(name = CustomerJson.customerIds),
			@ApiJsonProperty(name = CustomerJson.customerGroupTypeId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerByBusinessGroupSea")
	@RequiresPermissions("sys:customer:getCustomerByBusinessGroupSea")
	@PostMapping("/getCustomerByBusinessGroupSea")
	public Result getCustomerByBusinessGroupSea(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String customerIds = String.valueOf(jsonObject.get("customerIds"));
				String customerGroupTypeId = String.valueOf(jsonObject.get("customerGroupTypeId"));
				
				StringUtil.validateIsNull(customerIds, "请输入客户ID");
				StringUtil.validateIsNull(customerGroupTypeId, "请选择客户分组类型");
				
				List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
				boolean flag = customerService.updateGetCustomerByBusinessGroupSea(customerGroupTypeId, customerIdList);
				if(flag){
					return Result.success("领取客户成功");
				}
	            return Result.error("领取客户失败");
			}
			return Result.error("无法进行领取客户，请联系系统管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("领取客户失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "【公司回收站】领取客户（将公司回收站的客户领给自己）,因为考虑到区域管理员领取，及以前从一个分校领取到别的分校的情况，所以需要传branchOrgId")
	@ApiJsonObject(name = "getCustomerByCompanySea", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.customerIds),
			@ApiJsonProperty(name = CustomerJson.customerGroupTypeId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerByCompanySea")
	@RequiresPermissions("sys:customer:getCustomerByCompanySea")
	@PostMapping("/getCustomerByCompanySea")
	public Result getCustomerByCompanySea(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String customerIds = String.valueOf(jsonObject.get("customerIds"));
				String customerGroupTypeId = String.valueOf(jsonObject.get("customerGroupTypeId"));
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
				
				StringUtil.validateIsNull(branchOrgId, "请选择领取的分校");
				StringUtil.validateIsNull(customerIds, "请输入客户ID");
				StringUtil.validateIsNull(customerGroupTypeId, "请选择客户分组类型");
				
				List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
				boolean flag = customerService.updateGetCustomerByCompanySea(branchOrgId, customerGroupTypeId, customerIdList);
				if(flag){
					return Result.success("领取客户成功");
				}
	            return Result.error("领取客户失败");
			}
			return Result.error("无法进行领取客户，请联系系统管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("领取客户失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【资源库】分配客户（将资源库的客户分配给同事）")
	@ApiJsonObject(name = "allocationCustomerByCustomerIdRepository", value = { 
			@ApiJsonProperty(name = CustomerJson.customerIds),
			@ApiJsonProperty(name = UserJson.userId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "allocationCustomerByCustomerIdRepository")
	@RequiresPermissions("sys:customer:allocationCustomerByCustomerIdRepository")
	@PostMapping("/allocationCustomerByCustomerIdRepository")
	public Result allocationCustomerByCustomerIdRepository(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String customerIds = String.valueOf(jsonObject.get("customerIds"));
				String userId = String.valueOf(jsonObject.get("userId"));
				
				StringUtil.validateIsNull(customerIds, "请输入客户ID");
				StringUtil.validateIsNull(userId, "请输入用户ID");
				
				List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
				boolean flag = customerService.updateAllocationCustomerByCustomerIdRepository(userId, customerIdList);
				if(flag){
					return Result.success("分配客户成功");
				}
	            return Result.error("分配客户失败");
			}
			return Result.error("无法进行分配客户，请联系系统管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("分配客户失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "【分校回收站】分配客户（将分校回收站的客户分配给同事）")
	@ApiJsonObject(name = "allocationCustomerByCustomerIdBusinessGroupSea", value = { 
			@ApiJsonProperty(name = CustomerJson.customerIds),
			@ApiJsonProperty(name = UserJson.userId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "allocationCustomerByCustomerIdBusinessGroupSea")
	@RequiresPermissions("sys:customer:allocationCustomerByCustomerIdBusinessGroupSea")
	@PostMapping("/allocationCustomerByCustomerIdBusinessGroupSea")
	public Result allocationCustomerByCustomerIdBusinessGroupSea(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String customerIds = String.valueOf(jsonObject.get("customerIds"));
				String userId = String.valueOf(jsonObject.get("userId"));
				
				StringUtil.validateIsNull(customerIds, "请输入客户ID");
				StringUtil.validateIsNull(userId, "请输入用户ID");
				
				List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
				boolean flag = customerService.updateAllocationCustomerByCustomerIdBusinessGroupSea(userId, customerIdList);
				if(flag){
					return Result.success("分配客户成功");
				}
	            return Result.error("分配客户失败");
			}
			return Result.error("无法进行分配客户，请联系系统管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("分配客户失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【公司回收站】分配客户（将公司回收站的客户分配给同事,需要先选择分校，再选择人）")
	@ApiJsonObject(name = "allocationCustomerByCustomerIdCompanySea", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.customerIds),
			@ApiJsonProperty(name = UserJson.userId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "allocationCustomerByCustomerIdCompanySea")
	@RequiresPermissions("sys:customer:allocationCustomerByCustomerIdCompanySea")
	@PostMapping("/allocationCustomerByCustomerIdCompanySea")
	public Result allocationCustomerByCustomerIdCompanySea(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String customerIds = String.valueOf(jsonObject.get("customerIds"));
				String userId = String.valueOf(jsonObject.get("userId"));
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
				
				StringUtil.validateIsNull(branchOrgId, "请选择分校");
				StringUtil.validateIsNull(customerIds, "请输入客户ID");
				StringUtil.validateIsNull(userId, "请输入用户ID");
				
				List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
				boolean flag = customerService.updateAllocationCustomerByCustomerIdCompanySea(branchOrgId, userId, customerIdList);
				if(flag){
					return Result.success("分配客户成功");
				}
	            return Result.error("分配客户失败");
			}
			return Result.error("无法进行分配客户，请联系系统管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("分配客户失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "根据客户ID获取客户自定义信息,如果客户ID为空，则为新增客户时获取所有客户自定义信息")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "branchOrgId", dataType ="String", required = true, value = "分校ID"),
		@ApiImplicitParam(name = "customerId", dataType ="String", required = false, value = "客户ID")
	})
	@GetMapping("/getCustomerSelfDefineByCustomerId")
	public Result getCustomerSelfDefineByCustomerId(@RequestParam(required=true) String branchOrgId, @RequestParam String customerId) {
		try{
			List<CustomerSelfDefineItemConfigEntity> list = customerSelfDefineItemConfigService.getCustomerSelfDefineItemByCustomerId(branchOrgId, customerId);
			if(list!=null && list.size()>0){
				return Result.success(list);
			}
            return Result.error("当前客户无自定义信息");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户自定义信失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "根据用户id查询业务组的客户列表(代理商用户查询)")
	@ApiJsonObject(name = "getCustomerListByAgentsSearch", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.customerStage),
			@ApiJsonProperty(name = CustomerJson.customerTagIdList),
			@ApiJsonProperty(name = CustomerJson.updateStartDate),
			@ApiJsonProperty(name = CustomerJson.updateEndDate),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerListByAgentsSearch")
//	@RequiresPermissions("sys:customer:customerListByBusinessGroupSea:view")
	@PostMapping("/getCustomerListByAgentsSearch")
	public Result getCustomerListByAgentsSearch(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String customerStage = String.valueOf(jsonObject.get("customerStage"));//客户阶段
				String customerTagIdList = String.valueOf(jsonObject.get("customerTagIdList"));//客户标签集合
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));//分校ID
				String updateStartDate = String.valueOf(jsonObject.get("updateStartDate"));
				String updateEndDate = String.valueOf(jsonObject.get("updateEndDate"));
				
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				
	            
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	    		
	            paramMap.put("userId", bean.getId());//用来查用户范围内的分校的业务组数据
	            paramMap.put("customerStage", customerStage);
	            paramMap.put("customerTagIdList", customerTagIdList);
	            paramMap.put("updateStartDate", updateStartDate);
	            paramMap.put("updateEndDate", updateEndDate);
	            
	            if(branchOrgId!=null && !branchOrgId.equals("") && !branchOrgId.equals("null")){
	            	paramMap.put("branchOrgId", "'" + branchOrgId +"'");
	            }else{
	            	//加载用户当前能访问的分校范围
	            	paramMap.put("branchOrgId", branchOrgId);
	            	List<OrgEntity> list = orgService.getBranchOrgByUserId(bean.getId());
	            	if(list!=null && list.size()>0){
	            		String orgId = "";
	    				for(OrgEntity entity : list){
	    					orgId = orgId + "'" + entity.getId() + "'" + ",";
	    				}
	    				paramMap.put("branchOrgId", orgId.substring(0, orgId.length()-1));
	            	}
	            }
	            
	            
	            List<LinkedHashMap<Object, Object>> list = customerService.getCustomerListByAgentsSearch(paramMap);
	            if(list!=null && list.size()>0){
	            	//将每个客户的标签添加进去，与创建人加进去
					for(LinkedHashMap<Object, Object> map : list){
						//添加客户标签
						String customerId = map.get("id").toString();
						List<LinkedHashMap<Object, Object>> customerTagList = customerTagService.getCustomerTagListByCustomerId(customerId);
	            		if(customerTagList!=null && customerTagList.size()>0){
	            			map.put("customerTagList", customerTagList);
	            		}else{
	            			map.put("customerTagList", "");
	            		}
	            		
	            		//添加 创建人
	            		String createUserId = map.get("create_user_id").toString();
	            		UserEntity createUser = userService.getById(createUserId);
	            		if(createUser!=null){
	            			map.put("create_user_name", createUser.getUserName());
	            		}
	            		
	            		//添加客户所属分校名称，将每个客户的分校加进去，因为有时候客户是没有分校的，不在sql语句里面进行处理
	            		OrgEntity orgEntity = orgService.getBranchOrgByCustomerId(customerId);
	            		if(orgEntity!=null){
	            			map.put("branch_org_name", orgEntity.getOrgName());
	            		}else{
	            			map.put("branch_org_name", "");
	            		}
	            	}
	            	
					Long total = customerService.getCustomerListByAgentsSearchCount(paramMap);
					
					IPage page  = new Page();
					page.setTotal(total.longValue());
					page.setSize(Long.parseLong(pageSize));
					page.setRecords(list);
					return Result.success(page);
				}
	            return Result.error("当前用户下没有客户");
			}
			return Result.error("无法获取客户列表");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户列表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【我的客户,共享给我的客户，共享给同事的客户】综合查询获取客户列表(带分页)")
	@ApiJsonObject(name = "getCustomerList", value = { 
			@ApiJsonProperty(name = CustomerJson.myCustomerType),
			@ApiJsonProperty(name = CustomerJson.customerGroupTypeId),
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = OrgJson.departmentId),
//			@ApiJsonProperty(name = CustomerJson.customerType),//搜索无此项，直接是通过客户标签中的客户类型来搜索
//			@ApiJsonProperty(name = CustomerJson.customerSourceNameValue),//搜索无此项，直接是通过客户标签中的客户来源来搜索
			@ApiJsonProperty(name = CustomerJson.customerIntentionContent),
			@ApiJsonProperty(name = CustomerJson.createStartDate),
			@ApiJsonProperty(name = CustomerJson.createEndDate),
			@ApiJsonProperty(name = CustomerJson.customerStage),
			@ApiJsonProperty(name = CustomerJson.customerTagIdList),
			@ApiJsonProperty(name = CustomerJson.updateStartDate),
			@ApiJsonProperty(name = CustomerJson.updateEndDate),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerList")
	@PostMapping("/getCustomerList")
	public Result getCustomerList(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));//分校ID
				String departmentId = String.valueOf(jsonObject.get("departmentId"));//部门ID
				String myCustomerType = String.valueOf(jsonObject.get("myCustomerType"));//我的客户类型
				String customerGroupTypeId = String.valueOf(jsonObject.get("customerGroupTypeId"));
				String customerStage = String.valueOf(jsonObject.get("customerStage"));//客户阶段
				String customerTagIdList = String.valueOf(jsonObject.get("customerTagIdList"));//客户标签集合
				String updateStartDate = String.valueOf(jsonObject.get("updateStartDate"));
				String updateEndDate = String.valueOf(jsonObject.get("updateEndDate"));
				String customerIntentionContent = String.valueOf(jsonObject.get("customerIntentionContent"));
				String createStartDate = String.valueOf(jsonObject.get("createStartDate"));
				String createEndDate = String.valueOf(jsonObject.get("createEndDate"));
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				StringUtil.validateIsNull(branchOrgId, "请选择分校");
	            
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	    		
	            paramMap.put("userId", bean.getId());
	            paramMap.put("myCustomerType", myCustomerType);
	            paramMap.put("customerGroupTypeId", customerGroupTypeId);
	            paramMap.put("customerStage", customerStage);
	            paramMap.put("customerTagIdList", customerTagIdList);
	            paramMap.put("updateStartDate", updateStartDate);
	            paramMap.put("updateEndDate", updateEndDate);
	            paramMap.put("branchOrgId", branchOrgId);
	            paramMap.put("departmentId", departmentId);
	            paramMap.put("customerIntentionContent", customerIntentionContent);
	            paramMap.put("createStartDate", createStartDate);
	            paramMap.put("createEndDate", createEndDate);
	            
//	            if(branchOrgId!=null && !branchOrgId.equals("") && !branchOrgId.equals("null")){
//	            	paramMap.put("branchOrgId", "'" + branchOrgId +"'");
//	            }else{
//	            	//加载用户当前能访问的分校范围
//	            	paramMap.put("branchOrgId", branchOrgId);
//	            	List<OrgEntity> list = orgService.getBranchOrgByUserId(bean.getId());
//	            	if(list!=null && list.size()>0){
//	            		String orgId = "";
//	    				for(OrgEntity entity : list){
//	    					orgId = orgId + "'" + entity.getId() + "'" + ",";
//	    				}
//	    				paramMap.put("branchOrgId", orgId.substring(0, orgId.length()-1));
//	            	}
//	            }
	            
	            List<LinkedHashMap<Object, Object>> list = customerService.getCustomerList(paramMap);
	            if(list!=null && list.size()>0){
//	            	//获取客户来源
//	    			List<DictManyEntity> customerSourceList = dictManyService.getDictValueByTag("customer_source_type");
//	    			for(DictManyEntity entity : customerSourceList){
//	    				List<DictManyDetailEntity> customerSourceDetails = dictManyService.getDictDetailByTagId(entity.getTagId().toString());
//	    				entity.setCustomerSourceDetails(customerSourceDetails);
//	    			}
	    			//客户意向内容
	    			List<DictEntity> customerIntentionContentList = dictService.getDictValueByType("customer_intention_content");
	            	//客户来源明细集合
	    			List<DictManyDetailEntity> dictDetailList = dictManyDetailService.getDictDetailList();
	    			
	            	//将每个客户的标签添加进去，与创建人加进去
					for(LinkedHashMap<Object, Object> map : list){
						//添加客户来源类型(因为可能为空，不在sql里面处理)
						String customerSourceType = String.valueOf(map.get("customer_source_type"));
						if(customerSourceType!=null && !customerSourceType.equals("") && !customerSourceType.equals("null")){
							DictManyEntity dictManyEntity = dictManyService.getDictValueByTagId(customerSourceType);
							String customerSourceTypeName = dictManyEntity.getRemark();
							map.put("customer_source_type_name", customerSourceTypeName);
						}else{
							map.put("customer_source_type_name", "");
						}
						
						//添加客户来源明细
						map.put("customer_source_name", "");
						String customerSourceNameValue = String.valueOf(map.get("customer_source_name_value"));
						if(customerSourceNameValue!=null && !customerSourceNameValue.equals("") && !customerSourceNameValue.equals("null")){
							for(DictManyDetailEntity detail : dictDetailList){
								if(customerSourceNameValue.equals(detail.getDetailId().toString())){
									map.put("customer_source_name", detail.getDetailName());
									continue;
								}
							}
						}
						//添加客户意向内容
						map.put("customer_intention_content_name", "");
						customerIntentionContent = String.valueOf(map.get("customer_intention_content"));
						if(customerIntentionContent!=null && !customerIntentionContent.equals("") && !customerIntentionContent.equals("null")){
							for(DictEntity entity : customerIntentionContentList){
								if(customerIntentionContent.equals(entity.getId().toString())){
									map.put("customer_intention_content_name", entity.getRemark());
									continue;
								}
							}
						}
						
						
						//添加客户标签
						String customerId = map.get("id").toString();
						List<LinkedHashMap<Object, Object>> customerTagList = customerTagService.getCustomerTagListByCustomerId(customerId);
	            		if(customerTagList!=null && customerTagList.size()>0){
	            			map.put("customerTagList", customerTagList);
	            		}else{
	            			map.put("customerTagList", "");
	            		}
	            		
	            		//添加 创建人，因为客户的创建人跟当前我的客户不一定是一个，所以需要单独处理创建人,还有一种可能就是这个用户被删除了，那么这个创建人这里应该显示为空，去关联sql的话，也只能left join了
	            		String createUserId = map.get("create_user_id").toString();
	            		UserEntity createUser = userService.getById(createUserId);
	            		if(createUser!=null){
	            			map.put("create_user_name", createUser.getUserName());
	            		}
	            		
	            		//添加客户所属分校名称，将每个客户的分校加进去，因为有时候客户是没有分校的，不在sql语句里面进行处理
	            		OrgEntity orgEntity = orgService.getBranchOrgByCustomerId(customerId);
	            		if(orgEntity!=null){
	            			map.put("branch_org_name", orgEntity.getOrgName());
	            		}else{
	            			map.put("branch_org_name", "");
	            		}
	            	}
	            	
					Long total = customerService.getCustomerListCount(paramMap);
					
					IPage page  = new Page();
					page.setTotal(total.longValue());
					page.setSize(Long.parseLong(pageSize));
					page.setRecords(list);
					return Result.success(page);
				}
	            return Result.error("当前用户下没有客户");
			}
			return Result.error("无法获取客户列表");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户列表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【资源库查询】综合查询获取客户列表(带分页)")
	@ApiJsonObject(name = "getCustomerListByRepository", value = { 
			@ApiJsonProperty(name = CustomerJson.customerStage),
			@ApiJsonProperty(name = CustomerJson.customerSourceType),
			@ApiJsonProperty(name = CustomerJson.customerTagIdList),
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = OrgJson.departmentId),
			@ApiJsonProperty(name = CustomerJson.customerIntentionContent),
			@ApiJsonProperty(name = CustomerJson.updateStartDate),
			@ApiJsonProperty(name = CustomerJson.updateEndDate),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerListByRepository")
	@RequiresPermissions("sys:customer:customerListByRepository:view")
	@PostMapping("/getCustomerListByRepository")
	public Result getCustomerListByRepository(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String customerStage = String.valueOf(jsonObject.get("customerStage"));//客户阶段
				String customerSourceType = String.valueOf(jsonObject.get("customerSourceType"));//客户来源
				String customerTagIdList = String.valueOf(jsonObject.get("customerTagIdList"));//客户标签集合
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));//分校ID
				String departmentId = String.valueOf(jsonObject.get("departmentId"));//部门ID
				String updateStartDate = String.valueOf(jsonObject.get("updateStartDate"));
				String updateEndDate = String.valueOf(jsonObject.get("updateEndDate"));
				String customerIntentionContent = String.valueOf(jsonObject.get("customerIntentionContent"));
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				StringUtil.validateIsNull(branchOrgId, "请输入分校");
				StringUtil.validateIsNull(customerSourceType, "请输入客户来源");
				
				if(bean.getUserType().equals(UserTypeEnum.TYPE_4.getValue())){
					StringUtil.validateIsNull(departmentId, "部门管理员，请选择部门");
				}
				
	            
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	    		
	            paramMap.put("userId", bean.getId());
	            paramMap.put("customerSourceType", customerSourceType);
	            paramMap.put("customerStage", customerStage);
	            paramMap.put("customerTagIdList", customerTagIdList);
	            paramMap.put("updateStartDate", updateStartDate);
	            paramMap.put("updateEndDate", updateEndDate);
	            paramMap.put("customerIntentionContent", customerIntentionContent);
	            
	            paramMap.put("branchOrgId", branchOrgId);
	            paramMap.put("departmentId", departmentId);
	            if(departmentId!=null && !departmentId.equals("") && !departmentId.equals("null")){
	            	paramMap.put("searchType", "department");
	            }else{
	            	paramMap.put("searchType", "branch");
	            }
	            
	            
	            List<LinkedHashMap<Object, Object>> list = customerService.getCustomerListByRepository(paramMap);
	            if(list!=null && list.size()>0){
	            	//将每个客户的标签添加进去，与创建人加进去
					for(LinkedHashMap<Object, Object> map : list){
						//添加客户标签
						String customerId = map.get("id").toString();
						List<LinkedHashMap<Object, Object>> customerTagList = customerTagService.getCustomerTagListByCustomerId(customerId);
	            		if(customerTagList!=null && customerTagList.size()>0){
	            			map.put("customerTagList", customerTagList);
	            		}else{
	            			map.put("customerTagList", "");
	            		}
	            		
	            		//添加 创建人
	            		String createUserId = map.get("create_user_id").toString();
	            		UserEntity createUser = userService.getById(createUserId);
	            		if(createUser!=null){
	            			map.put("create_user_name", createUser.getUserName());
	            		}
	            		
	            		//添加客户所属分校名称，将每个客户的分校加进去，因为有时候客户是没有分校的，不在sql语句里面进行处理
	            		OrgEntity orgEntity = orgService.getBranchOrgByCustomerId(customerId);
	            		if(orgEntity!=null){
	            			map.put("branch_org_name", orgEntity.getOrgName());
	            		}else{
	            			map.put("branch_org_name", "");
	            		}
	            	}
	            	
					Long total = customerService.getCustomerListByRepositoryCount(paramMap);
					
					IPage page  = new Page();
					page.setTotal(total.longValue());
					page.setSize(Long.parseLong(pageSize));
					page.setRecords(list);
					return Result.success(page);
				}
	            return Result.error("当前用户下没有客户");
			}
			return Result.error("无法获取客户列表");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户列表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【分校回收站】综合查询获取客户列表(带分页)")
	@ApiJsonObject(name = "getCustomerListByBusinessGroupSea", value = { 
			@ApiJsonProperty(name = CustomerJson.customerStage),
			@ApiJsonProperty(name = CustomerJson.customerTagIdList),
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.followType),
			@ApiJsonProperty(name = CustomerJson.waiveCauseId), 
			@ApiJsonProperty(name = CustomerJson.updateStartDate),
			@ApiJsonProperty(name = CustomerJson.updateEndDate),
			@ApiJsonProperty(name = CustomerJson.customerIntentionContent),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerListByBusinessGroupSea")
	@RequiresPermissions("sys:customer:customerListByBusinessGroupSea:view")
	@PostMapping("/getCustomerListByBusinessGroupSea")
	public Result getCustomerListByBusinessGroupSea(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String customerStage = String.valueOf(jsonObject.get("customerStage"));//客户阶段
				String customerTagIdList = String.valueOf(jsonObject.get("customerTagIdList"));//客户标签集合
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));//分校ID
				String followType = String.valueOf(jsonObject.get("followType"));
				String waiveCauseId = String.valueOf(jsonObject.get("waiveCauseId"));
				String updateStartDate = String.valueOf(jsonObject.get("updateStartDate"));
				String updateEndDate = String.valueOf(jsonObject.get("updateEndDate"));
				String customerIntentionContent = String.valueOf(jsonObject.get("customerIntentionContent"));
				
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				StringUtil.validateIsNull(followType, "请输入跟进人类别");
				StringUtil.validateIsNull(branchOrgId, "请输入分校");
				
	            
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	    		
	            paramMap.put("userId", bean.getId());//用来查用户范围内的分校的业务组数据
	            paramMap.put("customerStage", customerStage);
	            paramMap.put("customerTagIdList", customerTagIdList);
	            paramMap.put("followType", followType);
	            paramMap.put("waiveCauseId", waiveCauseId);
	            paramMap.put("updateStartDate", updateStartDate);
	            paramMap.put("updateEndDate", updateEndDate);
	            paramMap.put("customerIntentionContent", customerIntentionContent);
	            
	            paramMap.put("branchOrgId", branchOrgId);
	            
//	            if(branchOrgId!=null && !branchOrgId.equals("") && !branchOrgId.equals("null")){
//	            	paramMap.put("branchOrgId", branchOrgId);
//	            }else{
//	            	//加载用户当前能访问的分校范围
//	            	paramMap.put("branchOrgId", branchOrgId);
//	            	List<OrgEntity> list = orgService.getBranchOrgByUserId(bean.getId());
//	            	if(list!=null && list.size()>0){
//	            		String orgId = "";
//	    				for(OrgEntity entity : list){
//	    					orgId = orgId + "'" + entity.getId() + "'" + ",";
//	    				}
//	    				paramMap.put("branchOrgId", orgId.substring(0, orgId.length()-1));
//	            	}
//	            }
	            
	            
	            List<LinkedHashMap<Object, Object>> list = customerService.getCustomerListByBusinessGroupSea(paramMap);
	            if(list!=null && list.size()>0){
	            	//将每个客户的标签添加进去，与创建人加进去
					for(LinkedHashMap<Object, Object> map : list){
						//添加客户标签
						String customerId = map.get("id").toString();
						List<LinkedHashMap<Object, Object>> customerTagList = customerTagService.getCustomerTagListByCustomerId(customerId);
	            		if(customerTagList!=null && customerTagList.size()>0){
	            			map.put("customerTagList", customerTagList);
	            		}else{
	            			map.put("customerTagList", "");
	            		}
	            		
	            		//添加 创建人
	            		String createUserId = map.get("create_user_id").toString();
	            		UserEntity createUser = userService.getById(createUserId);
	            		if(createUser!=null){
	            			map.put("create_user_name", createUser.getUserName());
	            		}
	            		
	            		//添加客户所属分校名称，将每个客户的分校加进去，因为有时候客户是没有分校的，不在sql语句里面进行处理
	            		OrgEntity orgEntity = orgService.getBranchOrgByCustomerId(customerId);
	            		if(orgEntity!=null){
	            			map.put("branch_org_name", orgEntity.getOrgName());
	            		}else{
	            			map.put("branch_org_name", "");
	            		}
	            	}
	            	
					Long total = customerService.getCustomerListByBusinessGroupSeaCount(paramMap);
					
					IPage page  = new Page();
					page.setTotal(total.longValue());
					page.setSize(Long.parseLong(pageSize));
					page.setRecords(list);
					return Result.success(page);
				}
	            return Result.error("当前用户下没有客户");
			}
			return Result.error("无法获取客户列表");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户列表失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "【公司回收站】综合查询获取客户列表(带分页)")
	@ApiJsonObject(name = "getCustomerListByCompanySea", value = { 
			@ApiJsonProperty(name = CustomerJson.customerStage),
			@ApiJsonProperty(name = CustomerJson.customerTagIdList),
			@ApiJsonProperty(name = CustomerJson.waiveCauseId),
			@ApiJsonProperty(name = CustomerJson.followType),
			@ApiJsonProperty(name = CustomerJson.updateStartDate),
			@ApiJsonProperty(name = CustomerJson.updateEndDate),
			@ApiJsonProperty(name = CustomerJson.customerIntentionContent),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerListByCompanySea")
	@PostMapping("/getCustomerListByCompanySea")
	@RequiresPermissions("sys:customer:customerListByCompanySea:view")
	public Result getCustomerListByCompanySea(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String customerStage = String.valueOf(jsonObject.get("customerStage"));//客户阶段
				String customerTagIdList = String.valueOf(jsonObject.get("customerTagIdList"));//客户标签集合
				String waiveCauseId = String.valueOf(jsonObject.get("waiveCauseId"));
				String followType = String.valueOf(jsonObject.get("followType"));
				String updateStartDate = String.valueOf(jsonObject.get("updateStartDate"));
				String updateEndDate = String.valueOf(jsonObject.get("updateEndDate"));
				String customerIntentionContent = String.valueOf(jsonObject.get("customerIntentionContent"));
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				StringUtil.validateIsNull(followType, "请输入跟进人类别");
				
	            
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	    		
	            paramMap.put("userId", bean.getId());
	            paramMap.put("customerStage", customerStage);
	            paramMap.put("customerTagIdList", customerTagIdList);
	            paramMap.put("waiveCauseId", waiveCauseId);
	            paramMap.put("followType", followType);
	            paramMap.put("updateStartDate", updateStartDate);
	            paramMap.put("updateEndDate", updateEndDate);
	            paramMap.put("customerIntentionContent", customerIntentionContent);
	            
	            List<LinkedHashMap<Object, Object>> list = customerService.getCustomerListByCompanySea(paramMap);
	            if(list!=null && list.size()>0){
	            	//将每个客户的标签添加进去，与创建人加进去
	            	for(LinkedHashMap<Object, Object> map : list){
						//添加客户标签
						String customerId = map.get("id").toString();
						List<LinkedHashMap<Object, Object>> customerTagList = customerTagService.getCustomerTagListByCustomerId(customerId);
	            		if(customerTagList!=null && customerTagList.size()>0){
	            			map.put("customerTagList", customerTagList);
	            		}else{
	            			map.put("customerTagList", "");
	            		}
	            		
	            		//添加 创建人
	            		String createUserId = map.get("create_user_id").toString();
	            		UserEntity createUser = userService.getById(createUserId);
	            		if(createUser!=null){
	            			map.put("create_user_name", createUser.getUserName());
	            		}
	            		
	            		//添加客户所属分校名称，将每个客户的分校加进去，因为有时候客户是没有分校的，不在sql语句里面进行处理
	            		OrgEntity orgEntity = orgService.getBranchOrgByCustomerId(customerId);
	            		if(orgEntity!=null){
	            			map.put("branch_org_name", orgEntity.getOrgName());
	            		}else{
	            			map.put("branch_org_name", "");
	            		}
	            	}
	            	
					Long total = customerService.getCustomerListByCompanySeaCount(paramMap);
					
					IPage page  = new Page();
					page.setTotal(total.longValue());
					page.setSize(Long.parseLong(pageSize));
					page.setRecords(list);
					return Result.success(page);
				}
	            return Result.error("暂时无数据");
			}
			return Result.error("无法获取客户列表");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户列表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【我的导入】综合查询获取客户列表(带分页),只需要查询由我创建的即可，不需要管客户当前是否是删除状态什么的")
	@ApiJsonObject(name = "getCustomerListByImport", value = { 
			@ApiJsonProperty(name = CustomerJson.customerStage),
			@ApiJsonProperty(name = CustomerJson.customerTagIdList),
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.updateStartDate),
			@ApiJsonProperty(name = CustomerJson.updateEndDate),
			@ApiJsonProperty(name = CustomerJson.customerIntentionContent),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerListByImport")
//	@RequiresPermissions("sys:customer:customerListByRepository:view")
	@PostMapping("/getCustomerListByImport")
	public Result getCustomerListByImport(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String customerStage = String.valueOf(jsonObject.get("customerStage"));//客户阶段
				String customerTagIdList = String.valueOf(jsonObject.get("customerTagIdList"));//客户标签集合
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));//分校ID
				String updateStartDate = String.valueOf(jsonObject.get("updateStartDate"));
				String updateEndDate = String.valueOf(jsonObject.get("updateEndDate"));
				String customerIntentionContent = String.valueOf(jsonObject.get("customerIntentionContent"));
				
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				StringUtil.validateIsNull(branchOrgId, "请输入分校");
				
	            
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	    		
	            paramMap.put("userId", bean.getId());
	            paramMap.put("customerStage", customerStage);
	            paramMap.put("customerTagIdList", customerTagIdList);
	            paramMap.put("updateStartDate", updateStartDate);
	            paramMap.put("updateEndDate", updateEndDate);
	            paramMap.put("customerIntentionContent", customerIntentionContent);
	            
	            paramMap.put("branchOrgId", branchOrgId);
	            
	            
	            List<LinkedHashMap<Object, Object>> list = customerService.getCustomerListByImport(paramMap);
	            if(list!=null && list.size()>0){
	            	//将每个客户的标签添加进去，与创建人加进去
					for(LinkedHashMap<Object, Object> map : list){
						//添加客户标签
						String customerId = map.get("id").toString();
						List<LinkedHashMap<Object, Object>> customerTagList = customerTagService.getCustomerTagListByCustomerId(customerId);
	            		if(customerTagList!=null && customerTagList.size()>0){
	            			map.put("customerTagList", customerTagList);
	            		}else{
	            			map.put("customerTagList", "");
	            		}
	            		
	            		//添加 创建人
	            		String createUserId = map.get("create_user_id").toString();
	            		UserEntity createUser = userService.getById(createUserId);
	            		if(createUser!=null){
	            			map.put("create_user_name", createUser.getUserName());
	            		}
	            		
	            		//添加客户所属分校名称，将每个客户的分校加进去，因为有时候客户是没有分校的，不在sql语句里面进行处理
	            		OrgEntity orgEntity = orgService.getBranchOrgByCustomerId(customerId);
	            		if(orgEntity!=null){
	            			map.put("branch_org_name", orgEntity.getOrgName());
	            		}else{
	            			map.put("branch_org_name", "");
	            		}
	            	}
	            	
					Long total = customerService.getCustomerListByImportCount(paramMap);
					
					IPage page  = new Page();
					page.setTotal(total.longValue());
					page.setSize(Long.parseLong(pageSize));
					page.setRecords(list);
					return Result.success(page);
				}
	            return Result.error("当前用户下没有客户");
			}
			return Result.error("无法获取客户列表");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户列表失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "【我的推广】综合查询获取客户列表(带分页)，考虑到将来跨分校推广情况，不需要传分校ID进来查询了")
	@ApiJsonObject(name = "getCustomerListByGeneralize", value = { 
			@ApiJsonProperty(name = CustomerJson.customerStage),
			@ApiJsonProperty(name = CustomerJson.customerTagIdList),
//			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.updateStartDate),
			@ApiJsonProperty(name = CustomerJson.updateEndDate),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerListByGeneralize")
//	@RequiresPermissions("sys:customer:customerListByRepository:view")
	@PostMapping("/getCustomerListByGeneralize")
	public Result getCustomerListByGeneralize(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String customerStage = String.valueOf(jsonObject.get("customerStage"));//客户阶段
				String customerTagIdList = String.valueOf(jsonObject.get("customerTagIdList"));//客户标签集合
//				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));//分校ID
				String updateStartDate = String.valueOf(jsonObject.get("updateStartDate"));
				String updateEndDate = String.valueOf(jsonObject.get("updateEndDate"));
				
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
//				StringUtil.validateIsNull(branchOrgId, "请输入分校");
				
	            
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	    		
	            paramMap.put("userId", bean.getId());
	            paramMap.put("customerStage", customerStage);
	            paramMap.put("customerTagIdList", customerTagIdList);
	            paramMap.put("updateStartDate", updateStartDate);
	            paramMap.put("updateEndDate", updateEndDate);
	            
//	            paramMap.put("branchOrgId", branchOrgId);
	            
	            
	            List<LinkedHashMap<Object, Object>> list = customerService.getCustomerListByGeneralize(paramMap);
	            if(list!=null && list.size()>0){
	            	//将每个客户的标签添加进去，与创建人加进去
					for(LinkedHashMap<Object, Object> map : list){
						//添加客户标签
						String customerId = map.get("id").toString();
						List<LinkedHashMap<Object, Object>> customerTagList = customerTagService.getCustomerTagListByCustomerId(customerId);
	            		if(customerTagList!=null && customerTagList.size()>0){
	            			map.put("customerTagList", customerTagList);
	            		}else{
	            			map.put("customerTagList", "");
	            		}
	            		
	            		//添加 创建人
	            		String createUserId = map.get("create_user_id").toString();
	            		UserEntity createUser = userService.getById(createUserId);
	            		if(createUser!=null){
	            			map.put("create_user_name", createUser.getUserName());
	            		}
	            		
	            		//添加客户所属分校名称，将每个客户的分校加进去，因为有时候客户是没有分校的，不在sql语句里面进行处理
	            		OrgEntity orgEntity = orgService.getBranchOrgByCustomerId(customerId);
	            		if(orgEntity!=null){
	            			map.put("branch_org_name", orgEntity.getOrgName());
	            		}else{
	            			map.put("branch_org_name", "");
	            		}
	            	}
	            	
					Long total = customerService.getCustomerListByGeneralizeCount(paramMap);
					
					IPage page  = new Page();
					page.setTotal(total.longValue());
					page.setSize(Long.parseLong(pageSize));
					page.setRecords(list);
					return Result.success(page);
				}
	            return Result.error("当前用户下没有客户");
			}
			return Result.error("无法获取客户列表");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户列表失败，失败原因：" + e.getMessage());
		}
	}
	
	

	
	@ApiOperation(value = "新增客户,如果不传客户分组，则默认我的客户--》其他")
	@PostMapping("/saveCustomer")
//	public Result saveCustomer(@RequestBody @ApiParam(required=true)CustomerModel model) {
	public Result saveCustomer(@RequestBody @ApiParam(required=true)CustomerModel model) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				UserEntity user = userService.getById(bean.getId());
				
				if(model==null){
					return Result.error("请输入客户信息");
				}
				
				boolean flag = customerService.saveCustomer(model, null, user);
				if(flag){
					return Result.success("新增客户成功");
				}
				return Result.error("新增客户失败，请联系管理员");
			}
			return Result.error("非法请求");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("新增客户失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "修改客户")
	@PostMapping("/updateCustomerByCustomerId")
	public Result updateCustomerByCustomerId(@RequestBody @ApiParam(required=true)CustomerModel model) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				UserEntity user = userService.getById(bean.getId());
//				//如果当前用户是超级管理员，则不允许新建用户，不符合业务逻辑，超级管理员创建的客户，不知道挂到哪个分校下，除非变更原型，可以往分校下挂，就注掉下面的代码
//				if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue())){
//					return Result.error("当前为超级管理员，请更换账号来创建用户");
//				}
				
				if(model==null){
					return Result.error("请输入客户信息");
				}
				
				boolean flag = customerService.updateCustomerByCustomerId(model, null, user);
				if(flag){
					return Result.success("修改客户成功");
				}
				return Result.error("修改客户失败，请联系管理员");
			}
			return Result.error("非法请求");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("新增客户失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "根据客户ID获取客户详细信息")
	@ApiJsonObject(name = "getCustomerDetailById", value = { 
			@ApiJsonProperty(name = CustomerJson.id)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerDetailById")
	@RequiresPermissions("sys:customer:customerDetail")
	@PostMapping("/getCustomerDetailById")
	public Result getCustomerDetailById(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String id = String.valueOf(jsonObject.get("id"));
			
			StringUtil.validateIsNull(id, "请输入客户id");
			
			CustomerEntity entity = customerService.getById(id);
			if(entity!=null){
				UserEntity promotionEntity = userService.getById(entity.getPromotionUserId());
				if(promotionEntity!=null){
					entity.setPromotionUserName(promotionEntity.getUserName());
				}else{
					entity.setPromotionUserName("");
				}
				
				return Result.success(entity);
			}
			return Result.error("客户不存在");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("根据客户ID获取客户信息失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "给客户打标签,支持单个客户打标签，多个客户打标签（前端需要组装客户ID），客户详细信息页面的修改客户标签也是此接口（客户ID传一个即可）,无需标签修改接口，保存前先删除原来的标签即可")
//	@RequiresPermissions("sys:role:list")
	@PostMapping("/saveCustomerTagByCustomerId") 
	public Result saveCustomerTagByCustomerId(@RequestBody @ApiParam(required=true)CustomerTagJson model){
		try{
			if(model==null){
				return Result.error("请选择客户标签");
			}
			if(model.getCustomerIds().length==0){
				return Result.error("请选择客户");
			}
			//下面的不做校验，因为需要做支持清空标签的功能
//			if(model.getCustomerTagEntity().length==0){
//				return Result.error("请选择客户标签");
//			}
			
			boolean flag = customerTagService.saveCustomerTagByCustomerId(model);
			if(flag){
				return Result.success("保存客户标签成功");
			}
			//逻辑为：先删除客户已经存在的客户标签，再保存，有事务，移至service层去实现
			return Result.error("保存客户标签失败");
			
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("保存客户标签失败，失败原因：" + e.getMessage());
		}
	}

	
	@ApiOperation(value = "获取客户已经存在的标签接口")
	@ApiJsonObject(name = "getCustomerTagByCustomerId", value = { 
			@ApiJsonProperty(name = CustomerJson.id)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerTagByCustomerId")
//	@RequiresPermissions("sys:role:list")
	@PostMapping("/getCustomerTagByCustomerId")
	public Result getCustomerTagByCustomerId(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String customerId = String.valueOf(jsonObject.get("id"));
			
			
			StringUtil.validateIsNull(customerId, "请输入客户id");
			
			List<LinkedHashMap<Object, Object>> list = customerTagService.getCustomerTagListByCustomerId(customerId);
			if(list!=null && list.size()>0){
				return Result.success(list);
			}
			return Result.error("暂无数据");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户已经存在的标签失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "我的客户【删除客户】，进入公司回收站")
	@ApiJsonObject(name = "deleteCustomerByCustomerId", value = { 
			@ApiJsonProperty(name = CustomerJson.customerIds),
			@ApiJsonProperty(name = CustomerJson.causeId),
			@ApiJsonProperty(name = CustomerJson.cause)})
	@ApiImplicitParam(name = "params", required = true, dataType = "deleteCustomerByCustomerId")
//	@RequiresPermissions("sys:role:list")
	@PostMapping("/deleteCustomerByCustomerId")
	public Result deleteCustomerByCustomerId(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String customerIds = String.valueOf(jsonObject.get("customerIds"));
			String causeId = String.valueOf(jsonObject.get("causeId"));
			String cause = String.valueOf(jsonObject.get("cause"));
			
			StringUtil.validateIsNull(customerIds, "请输入客户id");
			
			//删除客户核心逻辑：1.先删除用户客户表中的数据，切断引用关系  2.更新客户表中的客户数据为进入回收站状态，同时增加删除人，删除时间属性
			boolean flag = customerService.deleteCustomerByCustomerId(customerIds, causeId, cause);
			if(flag){
				return Result.success("删除客户成功");
			}
			return Result.error("删除客户失败，请联系系统管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("删除客户失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "资源库【删除客户】，进入分校回收站")
	@ApiJsonObject(name = "deleteCustomerFromRepositoryByCustomerId", value = { 
			@ApiJsonProperty(name = CustomerJson.customerIds)})
	@ApiImplicitParam(name = "params", required = true, dataType = "deleteCustomerFromRepositoryByCustomerId")
	@RequiresPermissions("sys:customer:deleteCustomerFromRepositoryByCustomerId")
	@PostMapping("/deleteCustomerFromRepositoryByCustomerId")
	public Result deleteCustomerFromRepositoryByCustomerId(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String customerIds = String.valueOf(jsonObject.get("customerIds"));
			
			StringUtil.validateIsNull(customerIds, "请输入客户id");
			
			//资源库删除客户，进入分校回收站
			boolean flag = customerService.deleteCustomerFromRepositoryByCustomerId(customerIds);
			if(flag){
				return Result.success("删除客户成功");
			}
			return Result.error("删除客户失败，请联系系统管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("删除客户失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "分校回收站【删除客户】，进入公司回收站")
	@ApiJsonObject(name = "deleteCustomerBeFromBusinessGroupSeaByCustomerId", value = { 
			@ApiJsonProperty(name = CustomerJson.customerIds),
			@ApiJsonProperty(name = CustomerJson.causeId),
			@ApiJsonProperty(name = CustomerJson.cause)})
	@ApiImplicitParam(name = "params", required = true, dataType = "deleteCustomerBeFromBusinessGroupSeaByCustomerId")
	@RequiresPermissions("sys:customer:deleteCustomerBeFromBusinessGroupSeaByCustomerId")
	@PostMapping("/deleteCustomerBeFromBusinessGroupSeaByCustomerId")
	public Result deleteCustomerBeFromBusinessGroupSeaByCustomerId(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String customerIds = String.valueOf(jsonObject.get("customerIds"));
			String causeId = String.valueOf(jsonObject.get("causeId"));
			String cause = String.valueOf(jsonObject.get("cause"));
			
			StringUtil.validateIsNull(customerIds, "请输入客户id");
			
			//删除客户核心逻辑：业务组公海里面的客户被删除，则直接删除客户，删除分校与客户表的数据
			boolean flag = customerService.deleteCustomerBeFromBusinessGroupSeaByCustomerId(customerIds, causeId, cause);
			if(flag){
				return Result.success("删除客户成功");
			}
			return Result.error("删除客户失败，请联系系统管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("删除客户失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "公司回收站【删除客户】")
	@ApiJsonObject(name = "deleteCustomerBeFromCompanySeaByCustomerId", value = { 
			@ApiJsonProperty(name = CustomerJson.customerIds),
			@ApiJsonProperty(name = CustomerJson.causeId),
			@ApiJsonProperty(name = CustomerJson.cause)})
	@ApiImplicitParam(name = "params", required = true, dataType = "deleteCustomerBeFromCompanySeaByCustomerId")
	@RequiresPermissions("sys:customer:deleteCustomerBeFromCompanySeaByCustomerId")
	@PostMapping("/deleteCustomerBeFromCompanySeaByCustomerId")
	public Result deleteCustomerBeFromCompanySeaByCustomerId(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String customerIds = String.valueOf(jsonObject.get("customerIds"));
			String causeId = String.valueOf(jsonObject.get("causeId"));
			String cause = String.valueOf(jsonObject.get("cause"));
			
			StringUtil.validateIsNull(customerIds, "请输入客户id");
			
			//删除客户核心逻辑：直接删除客户
			boolean flag = customerService.deleteCustomerBeFromCompanySeaByCustomerId(customerIds, causeId, cause);
			if(flag){
				return Result.success("删除客户成功");
			}
			return Result.error("删除客户失败，请联系系统管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("删除客户失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【我的客户】放弃客户至分校回收站(默认放弃至当前用户所在的分校业务组，含普通管理员)")
	@ApiJsonObject(name = "waiveCustomerToBusinessGroupSea", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.customerIds),
			@ApiJsonProperty(name = CustomerJson.causeId),
			@ApiJsonProperty(name = CustomerJson.cause)})
	@ApiImplicitParam(name = "params", required = true, dataType = "waiveCustomerToBusinessGroupSea")
//	@RequiresPermissions("sys:role:list")
	@PostMapping("/waiveCustomerToBusinessGroupSea")
	public Result waiveCustomerToBusinessGroup(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String customerIds = String.valueOf(jsonObject.get("customerIds"));
			String causeId = String.valueOf(jsonObject.get("causeId"));
			String cause = String.valueOf(jsonObject.get("cause"));
			
			StringUtil.validateIsNull(customerIds, "请输入客户id");
			
			//放弃客户至业务组公海核心逻辑：
			//1.获取当前用户所在的机构，并判断机构类型，0：顶级机构， 1：省份或直辖市，2：分校，3：部门， 4：代理商  如果为2或者3即是正常操作，否则不允许操作，不然数据会搞乱， 
			//2.删除用户客户表中的数据，切断引用关系  
			//3.将客户表的公海类别sea_type设置为1
			//4.在 分校与客户关联表（即公海与客户关联表）中增加一条
			boolean flag = customerService.updateWaiveCustomerToBusinessGroupSea(customerIds, causeId, cause);
			if(flag){
				return Result.success("放弃客户至业务组成功");
			}
			return Result.error("放弃客户至业务组失败，请联系系统管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("放弃客户至业务组失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "【我的客户】放弃客户至公司回收站")
	@ApiJsonObject(name = "waiveCustomerToCompanySea", value = { 
			@ApiJsonProperty(name = CustomerJson.customerIds),
			@ApiJsonProperty(name = CustomerJson.causeId),
			@ApiJsonProperty(name = CustomerJson.cause)})
	@ApiImplicitParam(name = "params", required = true, dataType = "waiveCustomerToCompanySea")
//	@RequiresPermissions("sys:role:list")
	@PostMapping("/waiveCustomerToCompanySea")
	public Result waiveCustomerToCompanySea(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String customerIds = String.valueOf(jsonObject.get("customerIds"));
			String causeId = String.valueOf(jsonObject.get("causeId"));
			String cause = String.valueOf(jsonObject.get("cause"));
			
			StringUtil.validateIsNull(customerIds, "请输入客户id");
			
			//放弃客户至公司大公海核心逻辑：1.先删除用户客户表中的数据，切断引用关系  2.将客户表的公海类别sea_type设置为2，统计公司大公海客户，直接统计此表即可
			boolean flag = customerService.updateWaiveCustomerToCompanySea(customerIds, causeId, cause);
			if(flag){
				return Result.success("放弃客户至公海成功");
			}
			return Result.error("放弃客户至公海失败，请联系系统管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("放弃客户至公海失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【我的客户】返回客户至资源库")
	@ApiJsonObject(name = "updateCustomerToRepository", value = { 
			@ApiJsonProperty(name = CustomerJson.customerIds)})
	@ApiImplicitParam(name = "params", required = true, dataType = "updateCustomerToRepository")
//	@RequiresPermissions("sys:role:list")
	@PostMapping("/updateCustomerToRepository")
	public Result updateCustomerToRepository(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String customerIds = String.valueOf(jsonObject.get("customerIds"));
			
			StringUtil.validateIsNull(customerIds, "请输入客户id");
			
			
			boolean flag = customerService.updateCustomerToRepository(customerIds);
			if(flag){
				return Result.success("返回客户至至资源库");
			}
			return Result.error("返回客户至至资源库失败，请联系系统管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("返回客户至至资源库失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "【我的客户】转让客户给同事接口(支持将多个客户同时转让给同事)")
	@ApiJsonObject(name = "transferCustomerToUser", value = { 
			@ApiJsonProperty(name = CustomerJson.customerIds),
			@ApiJsonProperty(name = CustomerJson.causeId),
			@ApiJsonProperty(name = CustomerJson.cause),
			@ApiJsonProperty(name = UserJson.userId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "transferCustomerToUser")
	@RequiresPermissions("sys:customer:transferCustomerToUser")
	@PostMapping("/transferCustomerToUser")
	public Result transferCustomerToUser(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String customerIds = String.valueOf(jsonObject.get("customerIds"));
			String causeId = String.valueOf(jsonObject.get("causeId"));
			String cause = String.valueOf(jsonObject.get("cause"));
			String userId = String.valueOf(jsonObject.get("userId"));
			
			StringUtil.validateIsNull(customerIds, "请输入客户id");
			StringUtil.validateIsNull(userId, "请输入转让的接收人id");
			
			//转让客户给同事核心逻辑：
			//1.先删除用户客户表中的数据，切断现有用户与客户的引用关系
			//2.用户客户表中增加新的用户与客户的引用关系，并且设置客户分组类型为：其他
			boolean flag = customerService.updateTransferCustomerToUser(customerIds, Integer.parseInt(causeId), cause, userId);
			if(flag){
				return Result.success("转让客户给同事成功");
			}
			return Result.error("转让客户给同事失败，请联系系统管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("转让客户给同事失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "共享关系，数据获取")
	@ApiJsonObject(name = "getShareRelation", value = { 
			@ApiJsonProperty(name = CustomerJson.customerId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getShareRelation")
	@PostMapping("/getShareRelation")
	public Result getShareRelation(@RequestBody String params) {
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String customerId = String.valueOf(jsonObject.get("customerId"));
			
			StringUtil.validateIsNull(customerId, "请输入客户id");
			
			List<LinkedHashMap<Object, Object>> list = customerService.getShareRelation(customerId);
			if(list!=null && list.size()>0){
				return Result.success(list);
			}
			
			return Result.error("当前无共享关系数据");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取共享关系数据失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【我的客户】共享客户给同事接口（支持批量共享）")
	@ApiJsonObject(name = "shareCustomerToUser", value = { 
			@ApiJsonProperty(name = CustomerJson.customerIds),
			@ApiJsonProperty(name = UserJson.userIds),
			@ApiJsonProperty(name = CustomerJson.shareType)})
	@ApiImplicitParam(name = "params", required = true, dataType = "shareCustomerToUser")
//	@RequiresPermissions("sys:role:list")
	@PostMapping("/shareCustomerToUser")
	public Result shareCustomerToUser(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			System.out.println("params参数为：" + params);
			
			String customerIds = String.valueOf(jsonObject.get("customerIds"));
			String userIds = String.valueOf(jsonObject.get("userIds"));
			String shareType = String.valueOf(jsonObject.get("shareType"));
			
			
			StringUtil.validateIsNull(customerIds, "请输入客户id");
			StringUtil.validateIsNull(userIds, "请输入共享的接收人id");
			StringUtil.validateIsNull(shareType, "请输入共享类型");
			
			if(shareType.trim().equals("1") || shareType.trim().equals("2")){
				boolean flag = customerService.updateShareCustomerToUser(customerIds, userIds, shareType);
				if(flag){
					return Result.success("共享客户给同事成功");
				}
				return Result.error("共享客户给同事失败");
			}else{
				return Result.error("请输入正确的共享类型");
			}
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("共享客户给同事失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "移动客户分组接口（支持批量移动）")
	@ApiJsonObject(name = "moveCustomerGroupByCustomerId", value = { 
			@ApiJsonProperty(name = CustomerJson.customerIds),
			@ApiJsonProperty(name = CustomerJson.customerGroupTypeId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "moveCustomerGroupByCustomerId")
//	@RequiresPermissions("sys:role:list")
	@PostMapping("/moveCustomerGroupByCustomerId")
	public Result moveCustomerGroupByCustomerId(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String customerIds = String.valueOf(jsonObject.get("customerIds"));
			String customerGroupTypeId = String.valueOf(jsonObject.get("customerGroupTypeId"));
			
			StringUtil.validateIsNull(customerIds, "请输入客户id集合");
			StringUtil.validateIsNull(customerGroupTypeId, "请输入客户分组id");
			
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            boolean flag = customerService.moveCustomerGroupByCustomerId(customerIds, customerGroupTypeId);
	            if(flag){
	            	return Result.success("移动客户分组成功");
	            }
			}
			
			return Result.error("移动客户分组失败，请联系管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("移动客户分组失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
//	@ApiOperation(value = "【回收站】客户列表(带分页)")
//	@ApiJsonObject(name = "getCustomerRecycledList", value = { 
//			@ApiJsonProperty(name = CustomerJson.customerName),
//			@ApiJsonProperty(name = CustomerJson.startDateTime),
//			@ApiJsonProperty(name = CustomerJson.endDateTime),
//			@ApiJsonProperty(name = OrgJson.branchOrgId),
//			@ApiJsonProperty(name = CustomerJson.followUserId),
//			@ApiJsonProperty(name = CustomerJson.deleteUserId),
//			@ApiJsonProperty(name = GlobalJson.pageNum),
//			@ApiJsonProperty(name = GlobalJson.pageSize)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerRecycledList")
//	@PostMapping("/getCustomerRecycledList")
//	public Result getCustomerRecycledList(@RequestBody String params) {
//		try{
//			Object object = SecurityUtils.getSubject().getPrincipal();
//			if (object instanceof UserEntity) {
//				UserEntity bean = (UserEntity) object;
//				UserEntity user = userService.getById(bean.getId());
//	            
//				System.out.println("params参数为：" + params);
//				
//				JSONObject jsonObject = JSON.parseObject(params);
//				String pageNum = String.valueOf(jsonObject.get("pageNum"));
//				String pageSize = String.valueOf(jsonObject.get("pageSize"));
//				String customerName = String.valueOf(jsonObject.get("customerName"));
//				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
//				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));//
//				String followUserId = String.valueOf(jsonObject.get("followUserId"));//跟进人
//				String deleteUserId = String.valueOf(jsonObject.get("deleteUserId"));//删除人
//				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
//				
//				StringUtil.validateIsNull(pageNum, "请输入页码");
//				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
//				StringUtil.validateIsNull(branchOrgId, "请输入分校ID");
//				
//				
//	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
//	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
//	            paramMap.put("pageSize", Integer.parseInt(pageSize));
//	            paramMap.put("userType", user.getUserType());
//	            paramMap.put("customerName", customerName);
//	            paramMap.put("startDateTime", startDateTime);
//	            paramMap.put("endDateTime", endDateTime);
//	            paramMap.put("followUserId", followUserId);
//	            paramMap.put("deleteUserId", deleteUserId);
//	            paramMap.put("branchOrgId", branchOrgId);
//	            
////	            //加载用户当前能访问的分校范围
////            	List<OrgEntity> orgList = orgService.getBranchOrgByUserId(bean.getId());
////            	if(orgList!=null && orgList.size()>0){
////            		String orgId = "";
////    				for(OrgEntity entity : orgList){
////    					orgId = orgId + "'" + entity.getId() + "'" + ",";
////    				}
////    				paramMap.put("branchOrgId", orgId.substring(0, orgId.length()-1));
////            	}
//	            
//	            List<LinkedHashMap<Object, Object>> list = customerService.findCustomerRecycledList(paramMap);
//	            if(list!=null && list.size()>0){
//	            	//添加跟进人名称
//	            	for(LinkedHashMap<Object, Object> map : list){
//	            		String followUserId2 = map.get("follow_user_id").toString();
//	            		UserEntity followUser = userService.getById(followUserId2);
//	            		map.put("follow_user_name", followUser.getUserName());
//	            		
//	            	}
//					Long total = customerService.findCustomerRecycledListCount(paramMap);
//					
//					IPage page  = new Page();
//					page.setTotal(total.longValue());
//					page.setSize(Long.parseLong(pageSize));
//					page.setRecords(list);
//					return Result.success(page);
//				}
//	            return Result.error("暂无数据");
//			}
//			return Result.error("无法获取客户列表");
//		}catch (UnauthorizedException e){
//			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
//		}catch (BusinessException e) {
//			return Result.error(e.getMessage());
//		}catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("无法获取客户列表失败，失败原因：" + e.getMessage());
//		}
//	}
	
	
	
	
	
//	@ApiOperation(value = "【回收站】还原客户给同事接口")
//	@ApiJsonObject(name = "restoreCustomerByCustomerId", value = { 
//			@ApiJsonProperty(name = CustomerJson.customerId),
//			@ApiJsonProperty(name = UserJson.userId)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "restoreCustomerByCustomerId")
//	@PostMapping("/restoreCustomerByCustomerId")
//	public Result restoreCustomerByCustomerId(@RequestBody String params) {
//		try{
//			System.out.println("params参数为：" + params);
//			
//			JSONObject jsonObject = JSON.parseObject(params);
//			String customerId = String.valueOf(jsonObject.get("customerId"));
//			String userId = String.valueOf(jsonObject.get("userId"));
//			
//			StringUtil.validateIsNull(customerId, "请输入客户ID");
//			StringUtil.validateIsNull(userId, "请输入需要还原的同事用户ID");
//			
//			boolean flag = customerService.updateRestoreCustomerByCustomerId(customerId, userId);
//			if(flag){
//				return Result.success("还原给同事成功");
//			}
//			return Result.error("还原给同事失败");
//		}catch (UnauthorizedException e){
//			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
//		}catch (BusinessException e) {
//			return Result.error(e.getMessage());
//		}catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("还原客户给同事失败，失败原因：" + e.getMessage());
//		}
//	}
//	
//	
//	@ApiOperation(value = "【回收站】还原到公司大公海（其实就是将客户表的公海类别sea_type设置为2，统计公司大公海客户，直接统计此表即可）")
//	@ApiJsonObject(name = "restoreCustomerToCompanySea", value = { 
//			@ApiJsonProperty(name = CustomerJson.customerId)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "restoreCustomerToCompanySea")
//	@PostMapping("/restoreCustomerToCompanySea")
//	public Result restoreCustomerToCompanySea(@RequestBody String params) {
//		try{
//			System.out.println("params参数为：" + params);
//			
//			JSONObject jsonObject = JSON.parseObject(params);
//			String customerId = String.valueOf(jsonObject.get("customerId"));
//			
//			StringUtil.validateIsNull(customerId, "请输入客户ID");
//			
//			boolean flag = customerService.updateRestoreCustomerToCompanySea(customerId);
//			if(flag){
//				return Result.success("还原到公司大公海成功");
//			}
//			return Result.error("还原到公司大公海失败");
//		}catch (UnauthorizedException e){
//			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
//		}catch (BusinessException e) {
//			return Result.error(e.getMessage());
//		}catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("还原到公司大公海失败，失败原因：" + e.getMessage());
//		}
//	}
//	
//	
//	@ApiOperation(value = "【回收站】还原到业务组公海（业务组公海，其实就是一个组织机构，所以传branchOrgId即业务组公海ID）")
//	@ApiJsonObject(name = "restoreCustomerToBusinessGroupSea", value = { 
//			@ApiJsonProperty(name = CustomerJson.customerId),
//			@ApiJsonProperty(name = OrgJson.branchOrgId)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "restoreCustomerToBusinessGroupSea")
//	@PostMapping("/restoreCustomerToBusinessGroupSea")
//	public Result restoreCustomerToBusinessGroupSea(@RequestBody String params) {
//		try{
//			System.out.println("params参数为：" + params);
//			
//			JSONObject jsonObject = JSON.parseObject(params);
//			String customerId = String.valueOf(jsonObject.get("customerId"));
//			String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
//			
//			StringUtil.validateIsNull(customerId, "请输入客户ID");
//			StringUtil.validateIsNull(branchOrgId, "请选择需要还原的业务组");
//			
//			//实现逻辑为：
//			//1. 将客户表中的公海类别设置为1，即客户目前属于业务组公海
//			//2. 在分校与客户关联表（即公海与客户关联表）中增加一条数据，记录此客户目前已经挂在此业务组公海下面
//			//注意：当客户在业务组公海中被领走的时候，实现逻辑则是上面两步的逆向工程
//			//1. 将客户表中的公海类别置空
//			//2. 将分校与客户关联表（即公海与客户关联表）中的此客户数据删除
//			
//			
//			boolean flag = customerService.updateRestoreCustomerToBusinessGroupSea(customerId, branchOrgId);
//			if(flag){
//				return Result.success("还原到业务组公海成功");
//			}
//			return Result.error("还原到业务组公海失败");
//		}catch (UnauthorizedException e){
//			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
//		}catch (BusinessException e) {
//			return Result.error(e.getMessage());
//		}catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("还原到业务组公海失败，失败原因：" + e.getMessage());
//		}
//	}
	
	
	@ApiOperation(value = "获取客户阶段")
	@ApiJsonObject(name = "getCustomerStage", value = { 
			@ApiJsonProperty(name = CustomerJson.customerId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerStage")
	@PostMapping("/getCustomerStage")
	public Result getCustomerStage(@RequestBody String params) {
		try{
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String customerId = String.valueOf(jsonObject.get("customerId"));
			
			StringUtil.validateIsNull(customerId, "请输入客户ID");
			
			CustomerEntity entity = customerService.getById(customerId);
			if(entity!=null){
				return Result.success("", entity.getCustomerStage());
			}else{
				return Result.error("获取客户阶段失败，请联系管理员");
			}
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户阶段失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "更新客户阶段接口（往下一个客户阶段更新），目前即使是已经缴费的状态，也还是可以通过回滚接口，更新为其他的状态")
	@ApiJsonObject(name = "updateCustomerStage", value = { 
			@ApiJsonProperty(name = CustomerJson.customerId),
			@ApiJsonProperty(name = CustomerJson.customerStage)})
	@ApiImplicitParam(name = "params", required = true, dataType = "updateCustomerStage")
	@PostMapping("/updateCustomerStage")
	public Result updateCustomerStage(@RequestBody String params) {
		try{
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String customerId = String.valueOf(jsonObject.get("customerId"));
			String customerStage = String.valueOf(jsonObject.get("customerStage"));
			
			StringUtil.validateIsNull(customerId, "请输入客户ID");
			StringUtil.validateIsNull(customerStage, "请选择客户");
			
			//业务需求为：
			//判断用户类型，如果用户类型为1或者2，则可以操作阶段回退，否则不允许操作回退
			customerStage = customerStage.trim();
			
			if(customerService.updateCustomerStage(customerId, customerStage)){
				return Result.success("更新成功");
			}else{
				return Result.error("更新客户阶段失败，请联系管理员");
			}
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("更新客户阶段失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "回滚客户阶段接口（往上一个客户阶段更新）")
	@ApiJsonObject(name = "returnCustomerStage", value = { 
			@ApiJsonProperty(name = CustomerJson.customerId),
			@ApiJsonProperty(name = CustomerJson.customerStage)})
	@ApiImplicitParam(name = "params", required = true, dataType = "returnCustomerStage")
	@RequiresPermissions("sys:customer:returnCustomerStage")
	@PostMapping("/returnCustomerStage")
	public Result returnCustomerStage(@RequestBody String params) {
		try{
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String customerId = String.valueOf(jsonObject.get("customerId"));
			String customerStage = String.valueOf(jsonObject.get("customerStage"));
			
			StringUtil.validateIsNull(customerId, "请输入客户ID");
			StringUtil.validateIsNull(customerStage, "请选择客户");
			
			//业务需求为：
			//判断用户类型，如果用户类型为1或者2，则可以操作阶段回退，否则不允许操作回退
			customerStage = customerStage.trim();
			
			if(customerService.updateCustomerStage(customerId, customerStage)){
				return Result.success("更新成功");
			}else{
				return Result.error("更新客户阶段失败，请联系管理员");
			}
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("更新客户阶段失败，失败原因：" + e.getMessage());
		}
	}
	

	
//	@ApiOperation(value = "【回收站】还原到业务组的公海列表（如果此接口返回为空，则没有还原到业务组公海这一选项，防止有人将用户挂至省份下面）")
//	@GetMapping("/restoreBusinessGroupSeaList")
//	public Result restoreBusinessGroupSeaList() {
//		try{
//			Object object = SecurityUtils.getSubject().getPrincipal();
//			if (object instanceof UserEntity) {
//				UserEntity bean = (UserEntity) object;
//				
//				List<OrgEntity> list = orgService.getBranchOrgByUserId(bean.getId());
//				
//				return Result.success(list);
//			}
//			return Result.error("还原到业务组的公海列表,请求失败");
//		}catch (UnauthorizedException e){
//			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
//		}catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("还原到业务组的公海列表加载失败，失败原因：" + e.getMessage());
//		}
//	}
	
	
	
//	@ApiOperation(value = "导出客户接口  jxl版本")
//	@ApiJsonObject(name = "customerExport", value = { 
//			@ApiJsonProperty(name = CustomerJson.customerIds)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "customerExport")
////	@RequiresPermissions("sys:role:list")
//	@PostMapping("/customerExport")
//	public void customerExport(@RequestBody String params, HttpServletResponse response) {
//		OutputStream os = null;
//		WritableWorkbook wwb = null;
//		try {
//			JSONObject jsonObject = JSON.parseObject(params);
//			String customerIds = String.valueOf(jsonObject.get("customerIds"));
//			
//			if (customerIds == null || customerIds.trim().equals("") || customerIds.equals("null")) {
//				return;
//			}
//			
//			String fileName = "客户数据.xls";
//			
//			response.reset();
//			// 设置文件MIME类型
//			response.setContentType("multipart/form-data");
//			// 设置Content-Disposition,下面的为导出xls格式的
//			response.setContentType("application/vnd.ms-excel");//其他自定义的文件如ofd文件采用：application/x-download
//			response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
//			
//			
//			os = response.getOutputStream();
//			// 1、创建工作簿(WritableWorkbook)对象
//			wwb = Workbook.createWorkbook(os);
//		 
//		    // 2、新建工作表(sheet)对象，并声明其属于第几页
//			WritableSheet customerSheet = wwb.createSheet("客户数据", 0);//客户数据sheet页
//
//			// 3、创建单元格(Label)对象，
//			//设置表头列的宽度
//			customerSheet.setColumnView(0, 20);//客户姓名
//			customerSheet.setColumnView(1, 6);//性别
//			customerSheet.setColumnView(2, 10);//来源
//			customerSheet.setColumnView(3, 15);//微信
//			customerSheet.setColumnView(4, 15);//QQ
//			customerSheet.setColumnView(5, 15);//手机
//			customerSheet.setColumnView(6, 15);//座机（电话）
//			customerSheet.setColumnView(7, 20);//邮箱
//			customerSheet.setColumnView(8, 15);//地区：国家
//			customerSheet.setColumnView(9, 15);//地区：省/州
//			customerSheet.setColumnView(10, 15);//地区：城市	
//			customerSheet.setColumnView(11, 15);//地区：区/县
//			customerSheet.setColumnView(12, 20);//公司
//			customerSheet.setColumnView(13, 20);//地址
//			customerSheet.setColumnView(14, 20);//备注	
//			customerSheet.setColumnView(15, 10);//工作年限
//			customerSheet.setColumnView(16, 15);//学历	
//			customerSheet.setColumnView(17, 20);//填写表单页面
//			customerSheet.setColumnView(18, 20);//专业
//			customerSheet.setColumnView(19, 25);//分类	
//			customerSheet.setColumnView(20, 26);//单班	
//			customerSheet.setColumnView(21, 26);//套班	
//			customerSheet.setColumnView(22, 26);//内训	
//			customerSheet.setColumnView(23, 26);//一建科目	
//			customerSheet.setColumnView(24, 26);//二建科目
//			customerSheet.setColumnView(25, 26);//造价科目
//			customerSheet.setColumnView(26, 26);//监理科目	
//			customerSheet.setColumnView(27, 26);//消防科目	
//			customerSheet.setColumnView(28, 26);//咨询工程师	
//			customerSheet.setColumnView(29, 26);//已报同行	
//			customerSheet.setColumnView(30, 26);//备注2	
//			customerSheet.setColumnView(31, 26);//一建科目2	
//			customerSheet.setColumnView(32, 26);//班型名称2	
//			customerSheet.setColumnView(33, 26);//优惠券
//			customerSheet.setColumnView(34, 20);//创建时间
//			customerSheet.setColumnView(35, 15);//客户阶段
//			customerSheet.setColumnView(36, 26);//标签
//			customerSheet.setColumnView(37, 20);//跟进人
//			customerSheet.setColumnView(38, 20);//部门
//			
//			//设置表头列的高度
//			customerSheet.setRowView(0, 450, false);
//			
//			//设置列的名称
////			customerSheet.addCell(new Label(0, 0, "客户姓名", JxlStyleUtil.getHeaderCellStyle())); //如果需要添加样式，则使用此方式即可
//			customerSheet.addCell(new Label(0, 0, "客户姓名"));//姓名	
//			customerSheet.addCell(new Label(1, 0, "性别"));//性别
//			customerSheet.addCell(new Label(2, 0, "来源"));	//来源	
//			customerSheet.addCell(new Label(3, 0, "微信"));//微信
//			customerSheet.addCell(new Label(4, 0, "QQ"));//QQ
//			customerSheet.addCell(new Label(5, 0, "手机"));//手机	
//			customerSheet.addCell(new Label(6, 0, "座机"));//座机（电话）
//			customerSheet.addCell(new Label(7, 0, "邮箱"));//邮箱	
//			customerSheet.addCell(new Label(8, 0, "地区：国家"));//地区：国家	
//			customerSheet.addCell(new Label(9, 0, "地区：省/州"));//地区：省/州	
//			customerSheet.addCell(new Label(10, 0, "地区：城市"));//地区：城市	
//			customerSheet.addCell(new Label(11, 0, "地区：区/县"));//地区：区/县
//			customerSheet.addCell(new Label(12, 0, "公司"));//公司	
//			customerSheet.addCell(new Label(13, 0, "地址"));//地址	
//			customerSheet.addCell(new Label(14, 0, "备注"));//备注	
//			customerSheet.addCell(new Label(15, 0, "工作年限"));//工作年限	
//			customerSheet.addCell(new Label(16, 0, "学历"));//学历	
//			customerSheet.addCell(new Label(17, 0, "填写表单页面"));//填写表单页面	
//			customerSheet.addCell(new Label(18, 0, "专业"));//专业	
//			customerSheet.addCell(new Label(19, 0, "分类"));//分类	
//			customerSheet.addCell(new Label(20, 0, "单班"));//单班	
//			customerSheet.addCell(new Label(21, 0, "套班"));//套班	
//			customerSheet.addCell(new Label(22, 0, "内训"));//内训	
//			customerSheet.addCell(new Label(23, 0, "一建科目"));//一建科目	
//			customerSheet.addCell(new Label(24, 0, "二建科目"));//二建科目	
//			customerSheet.addCell(new Label(25, 0, "造价科目"));//造价科目	
//			customerSheet.addCell(new Label(26, 0, "监理科目"));//监理科目	
//			customerSheet.addCell(new Label(27, 0, "消防科目"));//消防科目	
//			customerSheet.addCell(new Label(28, 0, "咨询工程师"));//咨询工程师	
//			customerSheet.addCell(new Label(29, 0, "已报同行"));//已报同行	
//			customerSheet.addCell(new Label(30, 0, "备注2"));//备注2	
//			customerSheet.addCell(new Label(31, 0, "一建科目2"));//一建科目2	
//			customerSheet.addCell(new Label(32, 0, "班型名称2"));//班型名称2	
//			customerSheet.addCell(new Label(33, 0, "优惠券"));//优惠券	
//			customerSheet.addCell(new Label(34, 0, "创建时间"));//创建时间	
//			customerSheet.addCell(new Label(35, 0, "客户阶段"));//客户阶段	
//			customerSheet.addCell(new Label(36, 0, "标签"));//标签	
//			customerSheet.addCell(new Label(37, 0, "跟进人"));//跟进人	
//			customerSheet.addCell(new Label(38, 0, "部门"));//部门
//			
//			
//			List<String> customerIdList = JsonHelper.getJsonToList(customerIds, String.class);
//			
//			List<CustomerEntity> list = (List<CustomerEntity>) customerService.listByIds(customerIdList);
//			
//			
//			for(int i=0; i<list.size(); i++){
//				CustomerEntity bean = list.get(i);
//				customerSheet.setRowView(i+1, 350, false);
//				
//				customerSheet.addCell(new Label(0, i+1, bean.getCustomerName()));//姓名
//				customerSheet.addCell(new Label(1, i+1, SexEnum.getDesc(bean.getSex())));//性别
//				customerSheet.addCell(new Label(2, i+1, CustomerSourceTypeEnum.getDesc(bean.getCustomerSourceType())));//来源
//				customerSheet.addCell(new Label(3, i+1, bean.getWeixinId()));//微信
//				customerSheet.addCell(new Label(4, i+1, bean.getQq()));//QQ
//				customerSheet.addCell(new Label(5, i+1, bean.getMobile()));//手机
//				customerSheet.addCell(new Label(6, i+1, bean.getPhone()));//座机
//				customerSheet.addCell(new Label(7, i+1, bean.getEmail()));//邮箱
//				customerSheet.addCell(new Label(8, i+1, "中国"));//地区：国家
//				customerSheet.addCell(new Label(9, i+1, bean.getProvinceName()));//地区：省/州	
//				customerSheet.addCell(new Label(10, i+1, bean.getCityName()));//地区：城市
//				customerSheet.addCell(new Label(11, i+1, bean.getAreaName()));//地区：区/县	
//				customerSheet.addCell(new Label(12, i+1, bean.getCompanyName()));//公司
//				customerSheet.addCell(new Label(13, i+1, bean.getAddress()));//地址
//				customerSheet.addCell(new Label(14, i+1, bean.getRemark()));//备注
//				customerSheet.addCell(new Label(15, i+1, bean.getJobAge()));//工作年限
//				customerSheet.addCell(new Label(16, i+1, bean.getEducation()));//学历
//				customerSheet.addCell(new Label(17, i+1, bean.getCustomerActivityPage()));//填写表单页面	
//				customerSheet.addCell(new Label(18, i+1, bean.getProfessional()));//专业
//				customerSheet.addCell(new Label(19, i+1, bean.getCustomerActivityTypePage()));//分类
//				customerSheet.addCell(new Label(20, i+1, ""));//单班
//				customerSheet.addCell(new Label(21, i+1, ""));//套班
//				customerSheet.addCell(new Label(22, i+1, ""));//内训
//				customerSheet.addCell(new Label(23, i+1, ""));//一建科目
//				customerSheet.addCell(new Label(24, i+1, ""));//二建科目
//				customerSheet.addCell(new Label(25, i+1, ""));//造价科目
//				customerSheet.addCell(new Label(26, i+1, ""));//监理科目
//				customerSheet.addCell(new Label(27, i+1, ""));//消防科目	
//				customerSheet.addCell(new Label(28, i+1, ""));//咨询工程师
//				customerSheet.addCell(new Label(29, i+1, ""));//已报同行
//				customerSheet.addCell(new Label(30, i+1, ""));//备注2	
//				customerSheet.addCell(new Label(31, i+1, ""));//一建科目2
//				customerSheet.addCell(new Label(32, i+1, ""));//班型名称2	
//				customerSheet.addCell(new Label(33, i+1, ""));//优惠券	
//				customerSheet.addCell(new Label(34, i+1, bean.getCreateTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))));//创建时间
//				customerSheet.addCell(new Label(35, i+1, CustomerStageEnum.getDesc(bean.getCustomerStage())));//客户阶段	
//				customerSheet.addCell(new Label(36, i+1, ""));//标签	
//				//获取跟进人及跟进人所在的部门
//				LinkedHashMap<Object, Object> map = userService.getUserNameAndOrgNameByUserId(bean.getFollowUserId());
//				if(map!=null && map.size()>0){
//					customerSheet.addCell(new Label(37, i+1, map.get("userName").toString()));//跟进人
//					customerSheet.addCell(new Label(38, i+1, map.get("name").toString()));//部门
//				}else{
//					customerSheet.addCell(new Label(37, i+1, ""));//跟进人
//					customerSheet.addCell(new Label(38, i+1, ""));//部门
//				}
//			}
//			
//
//			// 4、打开流，开始写文件
//			wwb.write();
//			os.flush();
//			wwb.close();
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			if (os != null){
//				try {
//					os.close();
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
//			}
//		}
//	}
	
	
	
	
	
	
//	@SuppressWarnings("resource")
	@ApiOperation(value = "导出客户接口(不支持按条件导出，用户勾多少条就导出多少条，如果可全部导出，不安全)")
	@ApiJsonObject(name = "customerExport", value = { 
			@ApiJsonProperty(name = CustomerJson.customerIds)})
	@ApiImplicitParam(name = "params", required = true, dataType = "customerExport")
	@RequiresPermissions("sys:customer:export")
	@PostMapping("/customerExport")
	public void customerExport(@RequestBody String params, HttpServletResponse response) {
		OutputStream os = null;
		Workbook workbook = null;
		try {
			JSONObject jsonObject = JSON.parseObject(params);
			String customerIds = String.valueOf(jsonObject.get("customerIds"));
			
			if (customerIds == null || customerIds.trim().equals("") || customerIds.equals("null")) {
				return ;
			}
			
			String fileName = "customer.xls";
			
			response.reset();
			// 设置文件MIME类型
			response.setContentType("multipart/form-data");
			// 设置Content-Disposition,下面的为导出xls格式的
			response.setContentType("application/vnd.ms-excel");//其他自定义的文件如ofd文件采用：application/x-download
			response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
			
			
			os = response.getOutputStream();
			
			List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
			List<CustomerEntity> list = (List<CustomerEntity>) customerService.listByIds(customerIdList);

			// 1、创建工作簿(WritableWorkbook)对象
			workbook = new XSSFWorkbook();
		 
		    // 2、新建工作表(sheet)对象，并声明其属于第几页
			Sheet customerSheet = workbook.createSheet("客户数据"); // 创建Sheet
			
			// 3、创建单元格(Label)对象，
			//设置列的宽度,注意（POI框架设置宽度需要*256，否则会挤到一列里面去）
			customerSheet.setColumnWidth(0, 20*256);//客户姓名
			customerSheet.setColumnWidth(1, 6*256);//性别
			customerSheet.setColumnWidth(2, 10*256);//来源
			customerSheet.setColumnWidth(3, 15*256);//微信
			customerSheet.setColumnWidth(4, 15*256);//QQ
			customerSheet.setColumnWidth(5, 15*256);//手机
			customerSheet.setColumnWidth(6, 15*256);//座机（电话）
			customerSheet.setColumnWidth(7, 20*256);//邮箱
			customerSheet.setColumnWidth(8, 15*256);//地区：国家
			customerSheet.setColumnWidth(9, 15*256);//地区：省/州
			customerSheet.setColumnWidth(10, 15*256);//地区：城市	
			customerSheet.setColumnWidth(11, 15*256);//地区：区/县
			customerSheet.setColumnWidth(12, 20*256);//公司
			customerSheet.setColumnWidth(13, 20*256);//地址
			customerSheet.setColumnWidth(14, 20*256);//备注	
			customerSheet.setColumnWidth(15, 10*256);//工作年限
			customerSheet.setColumnWidth(16, 15*256);//学历	
			customerSheet.setColumnWidth(17, 20*256);//填写表单页面
			customerSheet.setColumnWidth(18, 20*256);//专业
			customerSheet.setColumnWidth(19, 25*256);//分类	
			customerSheet.setColumnWidth(20, 26*256);//单班	
			customerSheet.setColumnWidth(21, 26*256);//套班	
			customerSheet.setColumnWidth(22, 26*256);//内训	
			customerSheet.setColumnWidth(23, 26*256);//一建科目	
			customerSheet.setColumnWidth(24, 26*256);//二建科目
			customerSheet.setColumnWidth(25, 26*256);//造价科目
			customerSheet.setColumnWidth(26, 26*256);//监理科目	
			customerSheet.setColumnWidth(27, 26*256);//消防科目	
			customerSheet.setColumnWidth(28, 26*256);//咨询工程师	
			customerSheet.setColumnWidth(29, 26*256);//已报同行	
			customerSheet.setColumnWidth(30, 26*256);//备注2	
			customerSheet.setColumnWidth(31, 26*256);//一建科目2	
			customerSheet.setColumnWidth(32, 26*256);//班型名称2	
			customerSheet.setColumnWidth(33, 26*256);//优惠券
			customerSheet.setColumnWidth(34, 22*256);//创建时间
			customerSheet.setColumnWidth(35, 15*256);//客户阶段
			customerSheet.setColumnWidth(36, 26*256);//标签
			customerSheet.setColumnWidth(37, 20*256);//跟进人
			customerSheet.setColumnWidth(38, 20*256);//部门
			
			//设置表头列的高度
//			customerSheet.setColumnHidden(0, true);

			Row header = customerSheet.createRow(0);
			// 创建表头行
			header.createCell(0).setCellValue("客户姓名");//姓名	
			header.createCell(1).setCellValue("性别");//性别
			header.createCell(2).setCellValue("来源");	//来源
			header.createCell(3).setCellValue("手机（必填）");//手机	
			header.createCell(4).setCellValue("QQ");//QQ
			header.createCell(5).setCellValue("微信");//微信
			header.createCell(6).setCellValue("座机");//座机（电话）
			header.createCell(7).setCellValue("邮箱");//邮箱	
			header.createCell(8).setCellValue("地区：国家");//地区：国家	
			header.createCell(9).setCellValue("地区：省/州");//地区：省/州	
			header.createCell(10).setCellValue("地区：城市");//地区：城市	
			header.createCell(11).setCellValue("地区：区/县");//地区：区/县
			header.createCell(12).setCellValue("公司");//公司	
			header.createCell(13).setCellValue("地址");//地址	
			header.createCell(14).setCellValue("备注");//备注	
			header.createCell(15).setCellValue("工作年限");//工作年限	
			header.createCell(16).setCellValue("学历");//学历	
			header.createCell(17).setCellValue("填写表单页面");//填写表单页面	
			header.createCell(18).setCellValue("专业");//专业	
			header.createCell(19).setCellValue("分类");//分类	
			header.createCell(20).setCellValue("单班");//单班	
			header.createCell(21).setCellValue("套班");//套班	
			header.createCell(22).setCellValue("内训");//内训	
			header.createCell(23).setCellValue("一建科目");//一建科目	
			header.createCell(24).setCellValue("二建科目");//二建科目	
			header.createCell(25).setCellValue("造价科目");//造价科目	
			header.createCell(26).setCellValue("监理科目");//监理科目	
			header.createCell(27).setCellValue("消防科目");//消防科目	
			header.createCell(28).setCellValue("咨询工程师");//咨询工程师	
			header.createCell(29).setCellValue("已报同行");//已报同行	
			header.createCell(30).setCellValue("备注2");//备注2	
			header.createCell(31).setCellValue("一建科目2");//一建科目2	
			header.createCell(32).setCellValue("班型名称2");//班型名称2	
			header.createCell(33).setCellValue("优惠券");//优惠券	
			header.createCell(34).setCellValue("创建时间");//创建时间	
			header.createCell(35).setCellValue("客户阶段");//客户阶段	
			header.createCell(36).setCellValue("标签");//标签	
			header.createCell(37).setCellValue("跟进人");//跟进人	
			header.createCell(38).setCellValue("部门");//部门

		
			for(int i=0; i<list.size(); i++){
				CustomerEntity bean = list.get(i);
				
				Row row = customerSheet.createRow(i+1);
				
				row.createCell(0).setCellValue(bean.getCustomerName());//姓名
				row.createCell(1).setCellValue(SexEnum.getDesc(bean.getSex()));//性别
//				row.createCell(2).setCellValue(CustomerSourceTypeEnum.getDesc(bean.getCustomerSourceType()));//来源,是指的来源于竞价表单，在线咨询这样的来源，不是代理商与非代理商
//				row.createCell(2).setCellValue(bean.getCustomerSourceName());
				row.createCell(2).setCellValue("");
				row.createCell(3).setCellValue(bean.getMobile());//手机
				row.createCell(4).setCellValue(bean.getQq());//QQ
				row.createCell(5).setCellValue(bean.getWeixinId());//微信
				row.createCell(6).setCellValue(bean.getPhone());//座机
				row.createCell(7).setCellValue(bean.getEmail());//邮箱
				row.createCell(8).setCellValue("中国");//地区：国家
				row.createCell(9).setCellValue(bean.getProvinceName());//地区：省/州	
				row.createCell(10).setCellValue(bean.getCityName());//地区：城市
				row.createCell(11).setCellValue(bean.getAreaName());//地区：区/县	
				row.createCell(12).setCellValue(bean.getCompanyName());//公司
				row.createCell(13).setCellValue(bean.getAddress());//地址
				row.createCell(14).setCellValue(bean.getRemark());//备注
				row.createCell(15).setCellValue(bean.getJobAge());//工作年限
				row.createCell(16).setCellValue(bean.getEducation());//学历
				row.createCell(17).setCellValue(bean.getCustomerActivityPage());//填写表单页面	
				row.createCell(18).setCellValue(bean.getProfessional());//专业
				row.createCell(19).setCellValue(bean.getCustomerActivityTypePage());//分类
				row.createCell(20).setCellValue("");//单班
				row.createCell(21).setCellValue("");//套班
				row.createCell(22).setCellValue("");//内训
				row.createCell(23).setCellValue("");//一建科目
				row.createCell(24).setCellValue("");//二建科目
				row.createCell(25).setCellValue("");//造价科目
				row.createCell(26).setCellValue("");//监理科目
				row.createCell(27).setCellValue("");//消防科目	
				row.createCell(28).setCellValue("");//咨询工程师
				row.createCell(29).setCellValue("");//已报同行
				row.createCell(30).setCellValue("");//备注2	
				row.createCell(31).setCellValue("");//一建科目2
				row.createCell(32).setCellValue("");//班型名称2	
				row.createCell(33).setCellValue("");//优惠券	
				row.createCell(34).setCellValue(LocalDateTimeUtil.getDateTime(bean.getCreateTime(), "yyyy-MM-dd HH:mm:ss"));//创建时间
				row.createCell(35).setCellValue(CustomerStageEnum.getDesc(bean.getCustomerStage()));//客户阶段	
				row.createCell(36).setCellValue("");//标签	
				//获取跟进人及跟进人所在的部门
				LinkedHashMap<Object, Object> map = userService.getUserNameAndOrgNameByUserId(bean.getFollowUserId());
				if(map!=null && map.size()>0){
					row.createCell(37).setCellValue(map.get("userName").toString());//跟进人
					row.createCell(38).setCellValue(map.get("orgName").toString());//部门
				}else{
					row.createCell(37).setCellValue("");//跟进人
					row.createCell(38).setCellValue("");//部门
				}
			}

			// 4、打开流，开始写文件
			workbook.write(os);
			os.flush();
			workbook.close();
		}catch (UnauthorizedException e){
			Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null){
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	
	@ApiOperation(value = "导出客户模板文件")
//	@RequiresPermissions("sys:customer:export")
	@GetMapping("/customerTemplateExport")
	public void customerTemplateExport(HttpServletResponse response) {
		OutputStream os = null;
		try {
			ResourceLoader resourceLoader = new DefaultResourceLoader();
	        Resource resource = resourceLoader.getResource("templates/templateFile/批量导入客户模板.xls");
			
			File file =  resource.getFile();
//			String fileName = file.getName(); //如果要下载中文，可参考：https://www.cnblogs.com/zhaoyan001/p/9012750.html 前端也要更改URI编码
			String fileName = "customerTemplate.xls";
			
			response.reset();
			// 设置文件MIME类型
			response.setContentType("multipart/form-data");
			// 设置Content-Disposition,下面的为导出xls格式的
			response.setContentType("application/vnd.ms-excel");//其他自定义的文件如ofd文件采用：application/x-download
			response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
			
			
			os = response.getOutputStream();
			os.write(FileUtil.getContent(file));
			
			os.flush();
		}catch (UnauthorizedException e){
			Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null){
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	@ApiOperation(value = "导入客户给自己接口(只支持上传.xls与.xlsx格式文件)")
//	@ApiJsonObject(name = "customerImport", value = { 
//			@ApiJsonProperty(name = CustomerJson.customerGroupTypeId),
//			@ApiJsonProperty(name = CustomerJson.seaId),
//			@ApiJsonProperty(name = CustomerJson.importType),
//			@ApiJsonProperty(name = CustomerJson.isSupplementCustomerInfo)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "customerImport")
	@ApiImplicitParams({
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "customerGroupTypeId", value = "客户分组类型ID，1：一般客户，2：意向客户，3：已成交客户，4：无意向客户，5：拉黑客户，6：其他", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "branchOrgId", value = "分校ID", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "departmentId", value = "部门ID", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "isSupplementCustomerInfo", value = "是否补充已有客户资料信息，1：补充，0：不补充", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "userId", value = "如果是导入给同事，此参数就传选择的同事ID过来", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "customerQuality", value = "客户质量(需要调用数据字典接口获取，为动态)，1：优质，2：一般", required = true),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "customerIntentionLevel", value = "客户意向程度（见数据字典sys_dict表customer_intention_level的定义）", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "customerIntentionContent", value = "客户意向内容（见数据字典sys_dict表customer_intention_content的定义）", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "promotionUserId", value = "推广人（用于记录公司内部推广部的人提供的号码，由内部别的部门人员导入系统进行跟进）", required = false)})
//			@ApiImplicitParam(paramType = "query", dataType = "__file", name = "file", value = "需要导入的客户数据的excel文件", required = false)}  此处引入这样，虽然将改为__file，dataType = "__file"但还是不行，因为使用swagger的文件框，上传的请求不是MultipartFile类型了，需要包装一下，可参考https://blog.csdn.net/weixin_30572613/article/details/98979319
	//注意上面的_file可能写错了，可能是网上的误导性的文章有问题，应该是file,public Result saveCustomer(@RequestBody @ApiParam(required=true)CustomerModel model, @RequestParam(required=true, value = "file") MultipartFile file) {这样也没问题
	@RequiresPermissions("sys:customer:customerImportToSelf")
	@PostMapping("/customerImportToSelf")
//	public Result customerImport(@RequestBody String params, HttpServletRequest request) {
	//注意此处无法@RequestBody @RequestParam两个注解同时使用
//	public Result customerImport(@RequestBody String params, @RequestParam(value = "file") MultipartFile file) {
//	public Result customerImport(@RequestParam(value = "file") MultipartFile file) {
	//正确的用法，请看下面，已经在swagger接口列表页中测试文件上传，不用再使用postman来测试文件上传接口了,已经在UserCustomerCallController类中定义了saveCallRecordingFile接口在使用了
//	@PostMapping(value = "/saveCallRecordingFile", consumes = "multipart/*", headers = "content-type=multipart/form-data") 
	//@PostMapping(value = "/saveCallRecordingFile", consumes = "multipart/*", headers = "content-type=multipart/form-data")//注意consumes = "multipart/*"这个我没加，也可以在swagger上上传成功
//	public Result saveCallRecordingFile(
//			@ApiParam(value="用户客户通话唯一ID",required=true)@RequestParam(required=true) String userCustomerCallId, 
//			@ApiParam(value="上传的文件",required=true)@RequestParam(required=true, value = "file") MultipartFile file) {
	public Result customerImportToSelf(@RequestParam(required=false) String customerGroupTypeId, @RequestParam(required=false) String branchOrgId, 
			@RequestParam(required=false) String departmentId, 
		    @RequestParam(required=false) String isSupplementCustomerInfo, 
			@RequestParam(required=false) String userId, 
			@RequestParam(required=true) String customerQuality, 
			@RequestParam(required=false) String customerIntentionLevel, 
			@RequestParam(required=false) String customerIntentionContent, 
			@RequestParam(required=false) String promotionUserId, 
			@RequestParam(required=true, value = "file") MultipartFile file) {
		try{
//			System.out.println("params参数为：" + params);
			
			String importType = "1";
			return customerService.saveCustomerImport(customerGroupTypeId, branchOrgId, departmentId, importType, 
					isSupplementCustomerInfo, userId, customerQuality, customerIntentionLevel,
					customerIntentionContent, promotionUserId, file);
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("导入客户失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "导入客户给资源库接口(只支持上传.xls与.xlsx格式文件)")
	@ApiImplicitParams({
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "customerGroupTypeId", value = "客户分组类型ID，1：一般客户，2：意向客户，3：已成交客户，4：无意向客户，5：拉黑客户，6：其他", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "branchOrgId", value = "分校ID", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "departmentId", value = "部门ID", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "isSupplementCustomerInfo", value = "是否补充已有客户资料信息，1：补充，0：不补充", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "userId", value = "如果是导入给同事，此参数就传选择的同事ID过来", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "customerQuality", value = "客户质量(需要调用数据字典接口获取，为动态)，1：优质，2：一般", required = true),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "customerIntentionLevel", value = "客户意向程度（见数据字典sys_dict表customer_intention_level的定义）", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "customerIntentionContent", value = "客户意向内容（见数据字典sys_dict表customer_intention_content的定义）", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "promotionUserId", value = "推广人（用于记录公司内部推广部的人提供的号码，由内部别的部门人员导入系统进行跟进）", required = false)})
	@RequiresPermissions("sys:customer:customerImportToRepository")
	@PostMapping("/customerImportToRepository")
	public Result customerImportToRepository(@RequestParam(required=false) String customerGroupTypeId, @RequestParam(required=false) String branchOrgId, 
			@RequestParam(required=false) String departmentId, 
			 @RequestParam(required=false) String isSupplementCustomerInfo, 
			@RequestParam(required=false) String userId, 
			@RequestParam(required=true) String customerQuality, 
			@RequestParam(required=false) String customerIntentionLevel, 
			@RequestParam(required=false) String customerIntentionContent, 
			@RequestParam(required=false) String promotionUserId, 
			@RequestParam(required=true, value = "file") MultipartFile file) {
		try{
			String importType = "2";
			return customerService.saveCustomerImport(customerGroupTypeId, branchOrgId, departmentId,importType, 
					isSupplementCustomerInfo, userId, customerQuality, customerIntentionLevel,
					customerIntentionContent, promotionUserId, file);
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("导入客户失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "导入客户给同事接口(只支持上传.xls与.xlsx格式文件)")
	@ApiImplicitParams({
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "customerGroupTypeId", value = "客户分组类型ID，1：一般客户，2：意向客户，3：已成交客户，4：无意向客户，5：拉黑客户，6：其他", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "branchOrgId", value = "分校ID", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "departmentId", value = "部门ID", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "isSupplementCustomerInfo", value = "是否补充已有客户资料信息，1：补充，0：不补充", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "userId", value = "如果是导入给同事，此参数就传选择的同事ID过来", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "customerQuality", value = "客户质量(需要调用数据字典接口获取，为动态)，1：优质，2：一般", required = true),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "customerIntentionLevel", value = "客户意向程度（见数据字典sys_dict表customer_intention_level的定义）", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "customerIntentionContent", value = "客户意向内容（见数据字典sys_dict表customer_intention_content的定义）", required = false),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "promotionUserId", value = "推广人（用于记录公司内部推广部的人提供的号码，由内部别的部门人员导入系统进行跟进）", required = false)})
	@RequiresPermissions("sys:customer:customerImportToColleague")
	@PostMapping("/customerImportToColleague")
	public Result customerImport(@RequestParam(required=false) String customerGroupTypeId, @RequestParam(required=false) String branchOrgId, 
			@RequestParam(required=false) String departmentId, 
			@RequestParam(required=false) String isSupplementCustomerInfo, 
			@RequestParam(required=false) String userId, 
			@RequestParam(required=true) String customerQuality, 
			@RequestParam(required=false) String customerIntentionLevel, 
			@RequestParam(required=false) String customerIntentionContent, 
			@RequestParam(required=false) String promotionUserId, 
			@RequestParam(required=true, value = "file") MultipartFile file) {
		try{
			String importType = "3";
			return customerService.saveCustomerImport(customerGroupTypeId, branchOrgId, departmentId, importType, 
					isSupplementCustomerInfo, userId, customerQuality, customerIntentionLevel,
					customerIntentionContent, promotionUserId, file);
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("导入客户失败，失败原因：" + e.getMessage());
		}
	}
	
}
