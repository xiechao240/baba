package cn.daliedu.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cn.daliedu.entity.UserEntity;
import cn.daliedu.enums.UserTypeEnum;
import cn.daliedu.mapper.ContractMapper;
import cn.daliedu.mapper.CustomerMapper;
import cn.daliedu.mapper.ReportMapper;
import cn.daliedu.service.ReportService;
import cn.daliedu.service.UserService;


@Service
public class ReportServiceImpl implements ReportService{
	
	@Autowired
	UserService userService;
	
	@Resource
	CustomerMapper customerMapper;
	
	@Resource
	ContractMapper contractMapper;
	
	@Resource
	ReportMapper reportMapper;
	
	
	
	@Override
	public BigDecimal getFollowRecoreCount(Map<Object, Object> map) {
		return reportMapper.getFollowRecoreCount(map);
	}

	@Override
	public BigDecimal getCallCount(Map<Object, Object> map) {
		return reportMapper.getCallCount(map);
	}

	@Override
	public BigDecimal getContactCustomerCount(Map<Object, Object> map) {
		return reportMapper.getContactCustomerCount(map);
	}

	@Override
	public HashMap<Object, Object> findContractReturnMoneyCount(String contractId) {
		return reportMapper.findContractReturnMoneyCount(contractId);
	}

	@Override
	public HashMap<Object, Object> findUserIdContractCount(Map<Object, Object> map) {
		return reportMapper.findUserIdContractCount(map);
	}

	@Override
	public HashMap<Object, Object> findUserIdContractReturnMoneyCount(Map<Object, Object> map) {
		return reportMapper.findUserIdContractReturnMoneyCount(map);
	}


	@Override
	public HashMap<Object, Object> findOrgIdContractCount(Map<Object, Object> map) {
		return reportMapper.findOrgIdContractCount(map);
	}


	@Override
	public HashMap<Object, Object> findOrgIdContractReturnMoneyCount(Map<Object, Object> map) {
		return reportMapper.findOrgIdContractReturnMoneyCount(map);
	}


	@Override
	public HashMap<Object, Object> findbranchOrgIdContractCount(Map<Object, Object> map) {
		return reportMapper.findbranchOrgIdContractCount(map);
	}


	@Override
	public HashMap<Object, Object> findbranchOrgIdContractReturnMoneyCount(Map<Object, Object> map) {
		return reportMapper.findbranchOrgIdContractReturnMoneyCount(map);
	}


	@Override
	public List<LinkedHashMap<Object, Object>> getContractList(Map<Object, Object> map) throws Exception {
		return contractMapper.getContractList(map);
	}


	@Override
	public Long getContractListCount(Map<Object, Object> map) {
		return contractMapper.getContractListCount(map);
	}


	@Override
	public List<LinkedHashMap<Object, Object>> getCustomerCreateRecordList(Map<Object, Object> map) throws Exception {
		return customerMapper.getCustomerCreateRecordList(map);
	}
	
	
	@Override
	public Long getCustomerCreateRecordListCount(Map<Object, Object> map) {
		return customerMapper.getCustomerCreateRecordListCount(map);
	}





	@Override
	public List<LinkedHashMap<Object, Object>> getCustomerCountList(String params) throws Exception{
		UserEntity bean = (UserEntity)SecurityUtils.getSubject().getPrincipal();
		UserEntity user = userService.getById(bean.getId());
		
		JSONObject jsonObject = JSON.parseObject(params);
		String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
		String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
		String orgId = String.valueOf(jsonObject.get("orgId"));
		String customerTagIdList = String.valueOf(jsonObject.get("customerTagIdList"));
		
		Map<Object, Object> paramMap = new HashMap<Object, Object>();
        paramMap.put("startDateTime", startDateTime);
        paramMap.put("endDateTime", endDateTime);
        paramMap.put("orgId", orgId);
        paramMap.put("customerTagIdList", customerTagIdList);
		
		//如果是超级管理员，如果不传orgId，则默认统计所有的客户数据
		if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue())){
			
		}
		
		//如果是普通管理员，则统计拥有权限范围的分校的所有客户数据
		if (user.getUserType().equals(UserTypeEnum.TYPE_2.getValue())) {

		}
		//如果是普通用户或代理商用户，则只统计自己的客户数据
		if (user.getUserType().equals(UserTypeEnum.TYPE_3.getValue()) || user.getUserType().equals(UserTypeEnum.TYPE_4.getValue())) {

		}
		
		return null;
	}
	
	
}
