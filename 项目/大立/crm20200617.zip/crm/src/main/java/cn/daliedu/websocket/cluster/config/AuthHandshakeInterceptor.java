//package cn.daliedu.websocket.cluster.config;
//
//
//import org.apache.shiro.SecurityUtils;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.http.server.ServerHttpRequest;
//import org.springframework.http.server.ServerHttpResponse;
//import org.springframework.http.server.ServletServerHttpRequest;
//import org.springframework.stereotype.Component;
//import org.springframework.util.StringUtils;
//import org.springframework.web.socket.WebSocketHandler;
//import org.springframework.web.socket.server.HandshakeInterceptor;
//
//import cn.daliedu.entity.UserEntity;
//
//import javax.servlet.http.HttpSession;
//import java.util.Map;
//
///**
// * 自定义的握手拦截
// *  在握手前判断，判断当前用户是否已经登录。如果未登录，则不允许登录websocket
// * Created by huangrongyou@yixin.im on 2018/7/10.
// */
//@Component
//public class AuthHandshakeInterceptor implements HandshakeInterceptor {
//    private static final Logger log = LoggerFactory.getLogger(AuthHandshakeInterceptor.class);
//
//
//    @Override
//    public boolean beforeHandshake(ServerHttpRequest request, ServerHttpResponse response, WebSocketHandler wsHandler, Map<String, Object> attributes) throws Exception {
//    	Object object = SecurityUtils.getSubject().getPrincipal();
//		if (object instanceof UserEntity) {
////			UserEntity user = (UserEntity) object;
//			return true;
//		}
//    	//未登录返回false;
//    	return false;
//    	
////    	HttpSession httpSession = getSession(request);
////        String user = (String)httpSession.getAttribute("loginName");
////
////        if(StringUtils.isEmpty(user)){
////            log.error("未登录系统，禁止登录websocket!");
////            return false;
////        }
////        log.info("login = " + user);
////
////        return true;
//    }
//
//    @Override
//    public void afterHandshake(ServerHttpRequest request, ServerHttpResponse response, WebSocketHandler wsHandler, Exception exception) {
//    }
//
////    // 参考 HttpSessionHandshakeInterceptor
////    private HttpSession getSession(ServerHttpRequest request) {
////        if (request instanceof ServletServerHttpRequest) {
////            ServletServerHttpRequest serverRequest = (ServletServerHttpRequest) request;
////            return serverRequest.getServletRequest().getSession(false);
////        }
////        return null;
////    }
//}
