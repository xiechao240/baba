package cn.daliedu.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.entity.UserOrgAreaEntity;
import cn.daliedu.mapper.UserOrgAreaMapper;
import cn.daliedu.service.UserOrgAreaService;

/**
 * <p>
 * 用户可查看的业务组公海与部门数据，用户可拥有多个分校的数据查看权限，其实就是存储用户从属于多个分校 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-23
 */
@Service
public class UserOrgAreaServiceImpl extends ServiceImpl<UserOrgAreaMapper, UserOrgAreaEntity> implements UserOrgAreaService {

	@Resource
	UserOrgAreaMapper userOrgAreaMapper;
	
	@Override
	public String getUserOrgAreaIdsByUserId(String userId) {
		return userOrgAreaMapper.getUserOrgAreaIdsByUserId(userId);
	}

}
