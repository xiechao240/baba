package cn.daliedu.util;

import org.apache.commons.lang3.time.DateFormatUtils;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * 日期工具类, 继承org.apache.commons.lang.time.DateUtils类
 *
 * @author ThinkGem
 * @version 2014-4-15
 */
public class DateUtil extends org.apache.commons.lang3.time.DateUtils {
	/**
	 * yyyy-MM-dd
	 */
	public static final String DATE_FORMATE_1 = "yyyy-MM-dd";
	
	/**
	 * yyyy-MM-dd HH:mm:ss
	 */
	public static final String DATE_FORMATE_2 = "yyyy-MM-dd HH:mm:ss";

	/**
	 * yyyy/MM/dd
	 */
	public static final String DATE_FORMATE_3 = "yyyy/MM/dd";

	/**
	 * yyyy/MM/dd HH:mm:ss
	 */
	public static final String DATE_FORMATE_4 = "yyyy/MM/dd HH:mm:ss";

	/**
	 * yyyyMMddHHmmss
	 */
	public static final String DATE_FORMATE_5 = "yyyyMMddHHmmss";

	private static String[] parsePatterns = { "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM",
			"yyyy/MM/dd", "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd HH:mm", "yyyy/MM", "yyyy.MM.dd", "yyyy.MM.dd HH:mm:ss",
			"yyyy.MM.dd HH:mm", "yyyy.MM", "yyyyMMddHHmmss" };
	
	
	/**
	* 字符串转换成日期
	* @param str  字符串日期
	* @return date  日期对象
	*/
	public static Date strToDate(String str) {
	   SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	   Date date = null;
	   try {
	    date = format.parse(str);
	   } catch (ParseException e) {
	    e.printStackTrace();
	   }
	   return date;
	}

	/**
	 * 获取当前时间的字符串格式
	 * @return 返回格式yyyy-MM-dd HH:mm:ss
	 */
	public static String getCurrentDateString() {
		return getCurrentDateString("yyyy-MM-dd HH:mm:ss");
	}
	
	/**
	 * 获取当前时间的字符串格式
	 * @param pattern 日期格式
	 * @return 返回指定格式的时间字符串
	 */
	public static String getCurrentDateString(String pattern) {
		return DateFormatUtils.format(new Date(), pattern);
	}
	
	/**
	 * 获取当前月份的字符串格式日期
	 * @return 如：201908
	 */
	public static String getCurrentDateMonth() {
		return getCurrentDateString("yyyyMM");
	}


	
	/**
	 * 根据传入的date对象，返回yyyy-MM-dd HH:mm:ss格式的时间
	 * @param date
	 * @return
	 */
	public static String getDateString(Date date){
		return getDateString(date, "yyyy-MM-dd HH:mm:ss");
	}
	
	/**
	 * 根据传入的date对象，返回yyyy-MM-dd HH:mm:ss格式的时间
	 * @param date
	 * @return
	 */
	public static String getDateString(Date date, String pattern){
		return DateFormatUtils.format(date, pattern);
	}

//	/**
//	 * 得到日期字符串 默认格式（yyyy-MM-dd） pattern可以为："yyyy-MM-dd" "HH:mm:ss" "E"
//	 */
//	public static String formatDate(Date date, String... pattern) {
//		String formatDate;
//		if (pattern != null && pattern.length > 0) {
//			formatDate = DateFormatUtils.format(date, pattern[0].toString());
//		} else {
//			formatDate = DateFormatUtils.format(date, "yyyy-MM-dd");
//		}
//		return formatDate;
//	}

	/**
	 * 得到日期时间字符串，转换格式（yyyy-MM-dd HH:mm:ss）
	 */
	public static String formatDateTime(Date date) {
		return DateFormatUtils.format(date, "yyyy-MM-dd HH:mm:ss");
	}

	/**
	 * 得到当前时间字符串 格式（HH:mm:ss）
	 */
	public static String getTime() {
		return DateFormatUtils.format(new Date(), "HH:mm:ss");
	}

	/**
	 * 得到当前日期和时间字符串 格式（yyyy-MM-dd HH:mm:ss）
	 */
	public static String getDateTime() {
		return DateFormatUtils.format(new Date(), "yyyy-MM-dd HH:mm:ss");
	}

	public static String getDateTime(String pattern) {
		return DateFormatUtils.format(new Date(), pattern);
	}

	/**
	 * 得到当前年份字符串 格式（yyyy）
	 */
	public static String getYear() {
		return DateFormatUtils.format(new Date(), "yyyy");
	}

	/**
	 * 得到当前月份字符串 格式（MM）
	 */
	public static String getMonth() {
		return DateFormatUtils.format(new Date(), "MM");
	}

	/**
	 * 得到当天字符串 格式（dd）
	 */
	public static String getDay() {
		return DateFormatUtils.format(new Date(), "dd");
	}

	/**
	 * 得到当前星期字符串 格式（E）星期几
	 */
	public static String getWeek() {
		return DateFormatUtils.format(new Date(), "E");
	}

	/**
	 * 日期型字符串转化为日期 格式 { "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm",
	 * "yyyy/MM/dd", "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd HH:mm", "yyyy.MM.dd",
	 * "yyyy.MM.dd HH:mm:ss", "yyyy.MM.dd HH:mm" }
	 */
	public static Date parseDate(String str) {
		if (str == null) {
			return null;
		}

		try {
			return parseDate(str.toString(), parsePatterns);
		} catch (ParseException e) {
			return null;
		}
	}

	/**
	 * 获取过去的天数
	 */
	public static long pastDays(Date date) {
		long t = System.currentTimeMillis() - date.getTime();
		return t / (24 * 60 * 60 * 1000);
	}

	/**
	 * 获取过去的小时
	 */
	public static long pastHour(Date date) {
		long t = System.currentTimeMillis() - date.getTime();
		return t / (60 * 60 * 1000);
	}

	/**
	 * 获取过去的分钟
	 */
	public static long pastMinutes(Date date) {
		long t = System.currentTimeMillis() - date.getTime();
		return t / (60 * 1000);
	}

	/**
	 * 转换为时间（天,时:分:秒.毫秒）
	 */
	public static String formatDateTime(long timeMillis) {
		long day = timeMillis / (24 * 60 * 60 * 1000);
		long hour = (timeMillis / (60 * 60 * 1000) - day * 24);
		long min = ((timeMillis / (60 * 1000)) - day * 24 * 60 - hour * 60);
		long s = (timeMillis / 1000 - day * 24 * 60 * 60 - hour * 60 * 60 - min * 60);
		long sss = (timeMillis - day * 24 * 60 * 60 * 1000 - hour * 60 * 60 * 1000 - min * 60 * 1000 - s * 1000);
		return (day > 0 ? day + "," : "") + hour + ":" + min + ":" + s + "." + sss;
	}

	/**
	 * 获取两个日期之间的天数
	 * @param startDate 开始日期
	 * @param endDate 结束时间
	 * @return
	 */
	public static double getDateDays(Date startDate, Date endDate) {
		long beforeTime = startDate.getTime();
		long afterTime = endDate.getTime();
		return (afterTime - beforeTime) / (1000 * 60 * 60 * 24);
	}
	
	/**
	 * 获取两个日期之间的天数
	 * @param startDate 开始日期
	 * @param endDate 结束时间
	 * @return
	 */
	public static double getDateDays(String startDate, String endDate) {
		long beforeTime = parseDate(startDate).getTime();
		long afterTime = parseDate(endDate).getTime();
		return (afterTime - beforeTime) / (1000 * 60 * 60 * 24);
	}
	
	/**
	 * 获取两个日期之间的秒数
	 * @param startDate 开始日期
	 * @param endDate 结束时间
	 * @return
	 */
	public static Long getDateSecTotal(String startTime, String endTime) {
		long beforeTime = parseDate(startTime).getTime();
		long afterTime = parseDate(endTime).getTime();
		return (afterTime - beforeTime) / (1000);
	}

	public static Timestamp getTimestamp() {
		return new Timestamp(System.currentTimeMillis());
	}

	/**
	 * 获取当前时间之前或之后 N 天的时间
	 *
	 * @param i
	 *            天数, 负数为之前天数, 正数为之后天数
	 */
	public static Timestamp getTimestamp(int i) {
		Date date = new Date();

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_MONTH, i);
		date = calendar.getTime();

		return new Timestamp(date.getTime());
	}
	
	/**
	 * 获取当前时间之前或之后 N 天的时间
	 *
	 * @param num
	 *            天数, 负数为之前天数, 正数为之后天数
	 */
	public static Date getBeforOrAfterDate(int num) {
		Date date = new Date();

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_MONTH, num);
		date = calendar.getTime();

		return date;
	}
	
	/**
	 * 根据开始时间和结束时间返回时间段内的时间集合
	 * 
	 * @param beginDate 开始日期
	 * @param endDate 结束日期
	 * @return List
	 * @throws ParseException 
	 */
	public static List<String> getDatesBetweenTwoDate(String beginDate, String  endDate) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		List<String> lDate = new ArrayList<String>();
		lDate.add(beginDate);// 把开始时间加入集合
		if(beginDate.equals(endDate)){
			return lDate;
		}
		
		Calendar cal = Calendar.getInstance();
		// 使用给定的 Date 设置此 Calendar 的时间
		cal.setTime(sdf.parse(beginDate));
		boolean bContinue = true;
		while (bContinue) {
			// 根据日历的规则，为给定的日历字段添加或减去指定的时间量
			cal.add(Calendar.DAY_OF_MONTH, 1);
			// 测试此日期是否在指定日期之后
			if (sdf.parse(endDate).after(cal.getTime())) {
				lDate.add(sdf.format(cal.getTime()));
			} else {
				break;
			}
		}
		
		lDate.add(endDate);// 把结束时间加入集合
		return lDate;
 
	}
	
	public static void main(String[] args) {
//		System.out.println(getDateDays("2019-11-06", "2019-11-06"));
//		System.out.println(getDateSecTotal("2019-11-26 10:17:43", "2019-11-26 10:18:08").intValue());
//		Date befor7 = getBeforOrAfterDate(-7);
		
		
		
//		System.out.println(DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-7), "yyyy-MM-dd"));
//		System.out.println(DateUtil.getCurrentDateString("yyyy-MM-dd"));
//		System.out.println();
//		
//		System.out.println(DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-30), "yyyy-MM-dd"));
//		System.out.println(DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-8), "yyyy-MM-dd"));
//		System.out.println();
//		
//		System.out.println(DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-60), "yyyy-MM-dd"));
//		System.out.println(DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-31), "yyyy-MM-dd"));
//		System.out.println();
//		
//		System.out.println(DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-61), "yyyy-MM-dd"));
//		System.out.println(DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-5000), "yyyy-MM-dd"));
		
		try {
			List<String> list = getDatesBetweenTwoDate("2019-12-02", "2019-12-02");
			for(String date : list){
				System.out.println(date);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
