package cn.daliedu.service;

import cn.daliedu.entity.CustomerTagGroupDetailEntity;

import java.util.List;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 客户标签分组明细表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-24
 */
public interface CustomerTagGroupDetailService extends IService<CustomerTagGroupDetailEntity> {
	
	/**
	 * 根据客户标签分组类型ID，加载客户标签分组下的明细
	 * @param customerTagTypeId
	 * @return
	 */
	public List<CustomerTagGroupDetailEntity> getCustomerTagGroupDetailByCustomerTagTypeId(String customerTagTypeId);
	
	/**
	 * 保存客户标签明细
	 * @param customerTagTypeId 客户标签分组类型ID
	 * @param customerTagName 客户标签名称
	 * @return
	 * @throws Exception
	 */
	public boolean saveCustomerTagGroupDetail(String customerTagTypeId, String customerTagName) throws Exception;
	
	/**
	 * 判断数据库中是否已经存在客户标签，简单防止同名的标签加入
	 * @param customerTagTypeId 客户标签分组类型ID
	 * @param customerTagName 客户标签名称
	 * @return
	 * @throws Exception
	 */
	public boolean existsCustomerTagName(String customerTagTypeId, String customerTagName);
	
	/**
	 * 判断数据库中是否已经存在客户标签
	 * @param customerTagId 客户标签ID
	 * @param customerTagName 客户标签名称
	 * @return
	 * @throws Exception
	 */
	public boolean existsCustomerTagNameByTagId(String customerTagId, String customerTagName);
	
	
}
