package cn.daliedu.mapper;

import cn.daliedu.entity.SmsTemplateEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 短信模板表 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-12-26
 */
public interface SmsTemplateMapper extends BaseMapper<SmsTemplateEntity> {

}
