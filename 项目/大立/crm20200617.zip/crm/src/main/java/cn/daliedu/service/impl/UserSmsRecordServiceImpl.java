package cn.daliedu.service.impl;

import cn.daliedu.entity.UserSmsRecordEntity;
import cn.daliedu.mapper.UserSmsRecordMapper;
import cn.daliedu.service.UserSmsRecordService;
import cn.daliedu.util.DateUtil;
import cn.daliedu.util.LocalDateUtil;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户短信发送记录表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-12-26
 */
@Service
public class UserSmsRecordServiceImpl extends ServiceImpl<UserSmsRecordMapper, UserSmsRecordEntity> implements UserSmsRecordService {
	
	@Resource
	UserSmsRecordMapper userSmsRecordMapper;

	@Override
	public Integer getUserSmsCount(String userId) {
		Map<Object, Object> map = new HashMap<Object, Object>();
		map.put("userId", userId);
		map.put("dateTime", DateUtil.getCurrentDateString("yyyy-MM-dd"));
		return userSmsRecordMapper.getUserSmsCount(map);
	}
	
}
