package cn.daliedu.service;

import cn.daliedu.entity.DictManyDetailEntity;

import java.util.List;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 数据字典（二维数据字典明细） 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-11-07
 */
public interface DictManyDetailService extends IService<DictManyDetailEntity> {
	
	/**
	 * 获取所有的数据字典明细
	 * @return
	 * @throws Exception
	 */
	public List<DictManyDetailEntity> getDictDetailList() throws Exception;
}
