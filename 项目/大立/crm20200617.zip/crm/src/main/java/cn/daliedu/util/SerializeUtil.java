package cn.daliedu.util;

import com.alibaba.fastjson.util.IOUtils;
import org.apache.shiro.codec.Base64;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * 
 * @author xiechao
 * @time 2019年1月15日 下午2:47:29
 * @version 1.0.0
 * @description 序列化与反序列化(将java bean对象存入redis时先序列化存入，从redis读取的时候需要反序列化拿出来)
 */
public class SerializeUtil {
	public static byte[] serialize(Object object) {
		ObjectOutputStream oos = null;
		ByteArrayOutputStream baos = null;
		try {
			// 序列化
			baos = new ByteArrayOutputStream();
			oos = new ObjectOutputStream(baos);
			oos.writeObject(object);
			byte[] bytes = baos.toByteArray();

			return Base64.encode(bytes);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			IOUtils.close(oos);
			IOUtils.close(baos);
		}
		return null;
	}

	public static Object unSerialize(byte[] str) {
		if (null == str) {
			return null;
		}

		byte[] bytes = Base64.decode(str);

		ByteArrayInputStream bais = null;
		try {
			// 反序列化
			bais = new ByteArrayInputStream(bytes);
			ObjectInputStream ois = new ObjectInputStream(bais);
			return ois.readObject();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			IOUtils.close(bais);
		}
		return null;
	}
}
