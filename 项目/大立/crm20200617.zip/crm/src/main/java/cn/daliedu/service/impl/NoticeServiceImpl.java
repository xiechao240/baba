package cn.daliedu.service.impl;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.shiro.SecurityUtils;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.entity.NoticeEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.mapper.NoticeMapper;
import cn.daliedu.service.NoticeService;

/**
 * <p>
 * 公告表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-28
 */
@Service
public class NoticeServiceImpl extends ServiceImpl<NoticeMapper, NoticeEntity> implements NoticeService {
	
	@Resource
	NoticeMapper noticeMapper;
	
	@Override
	public List<LinkedHashMap<Object, Object>> getNoticeList(Map<Object, Object> map) {
		return noticeMapper.getNoticeList(map);
	}
	
	
	@Override
	public Long getNoticeListCount(Map<Object, Object> map) {
		return noticeMapper.getNoticeListCount(map);
	}
	
	
	

	@Override
	public List<LinkedHashMap<Object, Object>> getNoticeAndNumCount(String id) {
		NoticeEntity entity = this.getById(id);
		entity.setBrowseCount(entity.getBrowseCount()+1);
		noticeMapper.updateById(entity);
		
		return noticeMapper.getNoticeById(id);
	}


	@Override
	public List<LinkedHashMap<Object, Object>> getNoticeById(String id) {
		return noticeMapper.getNoticeById(id);
	}


	@Override
	public boolean saveNotice(String title, String content) {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity user = (UserEntity) object;
			
			NoticeEntity entity = new NoticeEntity();
			entity.setTitle(title);
			entity.setContent(content);
			entity.setIsStop("0");
			entity.setBrowseCount(0);
			entity.setCreateDate(LocalDateTime.now());
			entity.setUpdateDate(LocalDateTime.now());
			entity.setReleaseUserId(user.getId());
			
			int num = noticeMapper.insert(entity);
			if(num>0){
				return true;
			}
		}
		
		return false;
	}

	@Override
	public boolean updateNotice(String id, String title, String content) {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity user = (UserEntity) object;
			
			NoticeEntity entity = new NoticeEntity();
			entity.setId(id);
			entity.setTitle(title);
			entity.setContent(content);
			entity.setReleaseUserId(user.getId());
			entity.setCreateDate(LocalDateTime.now());
			
			int num = noticeMapper.updateById(entity);
			if(num>0){
				return true;
			}
		}
		
		return false;
	}

	@Override
	public boolean deleteNoticeById(String id) {
		int num = noticeMapper.deleteById(id);
		if(num>0){
			return true;
		}
		return false;
	}
	
	


	@Override
	public boolean deleteNoticeByIds(List<String> idList) {
		if(idList!=null && idList.size()>0){
			noticeMapper.deleteBatchIds(idList);
			return true;
		}
		return false;
	}


	@Override
	public boolean optionNoticeTop(String id) {
		NoticeEntity entity = new NoticeEntity();
		entity.setId(id);
		entity.setIsStop("1");
		entity.setUpdateDate(LocalDateTime.now());
//		entity.setCreateDate(LocalDateTime.now());
		
		int num = noticeMapper.updateById(entity);
		if(num>0){
			return true;
		}
		return false;
	}
	
}
