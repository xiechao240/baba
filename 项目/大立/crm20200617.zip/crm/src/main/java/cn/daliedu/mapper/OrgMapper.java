package cn.daliedu.mapper;

import cn.daliedu.entity.OrgEntity;

import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 组织架构表，顶级节点：大立教育 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-09-20
 */
public interface OrgMapper extends BaseMapper<OrgEntity> {
	
	
	/**
	 * 获取顶级节点以及代理商，代理商下的子节
	 * @param map
	 * @return
	 */
	public List<OrgEntity> getAgentOrgList();
	
	/**
	 * 根据分校ID加载分校ID所属的省份，分校，以及分校下的所有子节点的机构集合（写这种混合的方法，不为别的，就是减少查询提高效率）
	 * @param map
	 * @return
	 */
	public List<OrgEntity> getUserProvinceBranchDepartmentOrgList(Map<Object, Object> map);
	
	/**
	 * 获取当前组织节点及组织节点下的子节点机构集合
	 * @param map
	 * @return
	 */
	public List<OrgEntity> getOrgListByBranchId(Map<Object, Object> map);

	/**
	 * 根据用户ID获取用户具有权限的业务组公海集合(即用户拥有的分校)
	 * @param userId
	 * @return
	 */
	public List<OrgEntity> getUserBusinessGroupListByUserId(String userId);
	

	/**
	 * 根据客户id，查询客户所属的分校
	 * @param orgId 用户的机构ID
	 * @return 
	 */
	public OrgEntity getBranchOrgByCustomerId(String customerId) throws Exception;
	
	
}
