package cn.daliedu.controller.api.console;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.CustomerTagGroupEntity;
import cn.daliedu.entity.NoticeEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.json.CustomerTagGroupJson;
import cn.daliedu.entity.json.GlobalJson;
import cn.daliedu.entity.json.NoticeJson;
import cn.daliedu.entity.json.OrgJson;
import cn.daliedu.entity.json.UserJson;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.NoticeService;
import cn.daliedu.service.UserService;
import cn.daliedu.util.JsonUtil;
import cn.daliedu.util.LocalDateTimeUtil;
import cn.daliedu.util.PageUtil;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 公告表 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2019-10-28
 */
@Api(description = "系统公告相关接口")
@RestController
@RequestMapping("${rest.path}/console/notice")
public class NoticeController {
	
	@Autowired
	NoticeService noticeService;
	
	@Autowired
	UserService userService;
	
	@ApiOperation(value = "获取系统公告集合接口")
	@ApiJsonObject(name = "getNoticeList", value = { 
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getNoticeList")
	@PostMapping("/getNoticeList")
	public Result getNoticeList(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
			
			StringUtil.validateIsNull(pageNum, "请输入页码");
			StringUtil.validateIsNull(pageSize, "请输入每页记录数");
			
			//需要自己写方法，置顶的优先排，再根据创建日期倒排
            
            Map<Object, Object> paramMap = new HashMap<Object, Object>();
            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
            paramMap.put("pageSize", Integer.parseInt(pageSize));
			
			List<LinkedHashMap<Object, Object>> tempList = noticeService.getNoticeList(paramMap);
			List<LinkedHashMap<Object, Object>> list = new ArrayList<LinkedHashMap<Object, Object>>();
			if(tempList!=null){
				for(LinkedHashMap<Object, Object> map : tempList){
					String createDate = map.get("create_date").toString();
					
					map.put("create_date", LocalDateTimeUtil.getDateTime(createDate));
					
					list.add(map);
				}
				
				Long total = noticeService.getNoticeListCount(paramMap);
				
				IPage page  = new Page();
				page.setTotal(total.longValue());
				page.setSize(Long.parseLong(pageSize));
				page.setRecords(list);
				return Result.success(page);
			}
			return Result.success(list);
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取系统公告失败，失败原因：" + e.getMessage());
		}
	}

	@ApiOperation(value = "新增系统公告接口")
	@ApiJsonObject(name = "saveNotice", value = { 
			@ApiJsonProperty(name = NoticeJson.title),
			@ApiJsonProperty(name = NoticeJson.content)})
	@ApiImplicitParam(name = "params", required = true, dataType = "saveNotice")
	@PostMapping("/saveNotice")
	public Result saveNotice(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String title = String.valueOf(jsonObject.get("title"));
			String content = String.valueOf(jsonObject.get("content"));
			
			StringUtil.validateIsNull(title, "请输入公告标题");
			StringUtil.validateIsNull(content, "请输入公告内容");
			
			title = title.trim();
			
			
			boolean flag = noticeService.saveNotice(title, content);
			if(flag){
				return Result.success("新增成功！");
			}
			return Result.error("新增失败");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("新增系统公告失败，失败原因：" + e.getMessage());
		}
	}

	@ApiOperation(value = "修改系统公告接口")
	@ApiJsonObject(name = "updateNotice", value = { 
			@ApiJsonProperty(name = NoticeJson.id),
			@ApiJsonProperty(name = NoticeJson.title),
			@ApiJsonProperty(name = NoticeJson.content)})
	@ApiImplicitParam(name = "params", required = true, dataType = "updateNotice")
	@PostMapping("/updateNotice")
	public Result updateNotice(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String id = String.valueOf(jsonObject.get("id"));
			String title = String.valueOf(jsonObject.get("title"));
			String content = String.valueOf(jsonObject.get("content"));
			
			StringUtil.validateIsNull(id, "公告ID不能为空");
			StringUtil.validateIsNull(title, "公告标题不能为空");
			StringUtil.validateIsNull(content, "公告内容不能为空");
			
			id = id.trim();
			title  = title.trim();
			
			boolean flag = noticeService.updateNotice(id, title, content);
			if(flag){
				return Result.success("修改成功！");
			}
			return Result.error("修改失败");
			
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("修改系统公告失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "后台，根据公告ID获取公告接口")
	@ApiJsonObject(name = "getNoticeById", value = { 
			@ApiJsonProperty(name = NoticeJson.id)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getNoticeById")
	@PostMapping("/getNoticeById")
	public Result getNoticeById(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String id = String.valueOf(jsonObject.get("id"));
			
			StringUtil.validateIsNull(id, "公告ID不能为空");
			
			List<LinkedHashMap<Object, Object>> entity = noticeService.getNoticeById(id);
			
			if(entity!=null){
				return Result.success(entity);
			}
			
			return Result.error("获取公告失败");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取系统公告失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "首页，根据公告ID获取公告接口，每点开看一下，则增加一个流量量")
	@ApiJsonObject(name = "getNoticeAndNumCount", value = { 
			@ApiJsonProperty(name = NoticeJson.id)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getNoticeAndNumCount")
	@PostMapping("/getNoticeAndNumCount")
	public Result getNoticeAndNumCount(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String id = String.valueOf(jsonObject.get("id"));
			
			StringUtil.validateIsNull(id, "公告ID不能为空");
			
			List<LinkedHashMap<Object, Object>> entity = noticeService.getNoticeAndNumCount(id);
			
			if(entity!=null){
				return Result.success(entity);
			}
			
			return Result.error("获取公告失败");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取系统公告失败，失败原因：" + e.getMessage());
		}
	}

	@ApiOperation(value = "删除系统公告接口")
	@ApiJsonObject(name = "deleteNoticeById", value = { 
			@ApiJsonProperty(name = NoticeJson.ids) })
	@ApiImplicitParam(name = "params", required = true, dataType = "deleteNoticeById")
	@PostMapping("/deleteNoticeById")
	public Result deleteNoticeById(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String ids = String.valueOf(jsonObject.get("ids"));
			
			StringUtil.validateIsNull(ids, "请输入公告ID");
			
			List<String> idList = JsonUtil.getJsonToList(ids, String.class);
			
			boolean flag = noticeService.deleteNoticeByIds(idList);
			if(flag){
				return Result.success("删除成功！");
			}
			return Result.error("删除失败");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("删除系统公告失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "公告置顶接口")
	@ApiJsonObject(name = "optionNoticeTop", value = { 
			@ApiJsonProperty(name = NoticeJson.id) })
	@ApiImplicitParam(name = "params", required = true, dataType = "optionNoticeTop")
	@PostMapping("/optionNoticeTop")
	public Result optionNoticeTop(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String id = String.valueOf(jsonObject.get("id"));
			
			StringUtil.validateIsNull(id, "请输入公告ID");
			
			id = id.trim();
			
			boolean flag = noticeService.optionNoticeTop(id);
			if(flag){
				return Result.success("操作成功！");
			}
			return Result.error("操作失败");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("公告置顶失败，失败原因：" + e.getMessage());
		}
	}
}
