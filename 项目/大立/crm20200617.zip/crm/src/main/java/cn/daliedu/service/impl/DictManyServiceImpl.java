package cn.daliedu.service.impl;

import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.entity.DictManyDetailEntity;
import cn.daliedu.entity.DictManyEntity;
import cn.daliedu.mapper.DictManyDetailMapper;
import cn.daliedu.mapper.DictManyMapper;
import cn.daliedu.service.DictManyService;

/**
 * <p>
 * 存储2个维度的，一对多的数据字典 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-11-07
 */
@Service
public class DictManyServiceImpl extends ServiceImpl<DictManyMapper, DictManyEntity> implements DictManyService {
	
	@Resource
	DictManyMapper dictManyMapper;
	
	@Resource
	DictManyDetailMapper dictManyDetailMapper;
	
	
	

	


	@Override
	public List<LinkedHashMap<String, String>> getDictTypeList() throws Exception {
		return dictManyMapper.getDictTypeList();
	}

	
	@Override
	public List<DictManyEntity> getDictValueByTag(String tag) throws Exception {
		return dictManyMapper.selectList(new QueryWrapper<DictManyEntity>().eq("tag", tag));
	}


	@Override
	public List<DictManyDetailEntity> getDictDetailByTagId(String tagId) throws Exception {
		return dictManyDetailMapper.selectList(new QueryWrapper<DictManyDetailEntity>().eq("tag_id", tagId));
	}



	@Override
	public DictManyEntity getDictValueByTagId(String tagId) throws Exception {
		return dictManyMapper.selectById(tagId);
	}
	
	
	
	
	
}
