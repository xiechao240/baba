package cn.daliedu.entity.json;

import cn.daliedu.config.swagger.model.ApiSingleParam;

/**
 * <p>
 * swagger注释属性：客户标签分组属性json
 * </p>
 *
 * @author xiechao
 * @since 2019-05-06
 */
public class CustomerTagGroupJson{
	
	
	@ApiSingleParam(value = "客户标签分组类型ID", example = "1")
	public static final String customerTagTypeId = "customerTagTypeId";
	
	@ApiSingleParam(value = "客户标签ID", example = "1")
	public static final String customerTagId = "customerTagId";
	
	
	@ApiSingleParam(value = "客户标签分组类型名称", example = "客户来源")
	public static final String customerTagTypeName = "customerTagTypeName";
	
	@ApiSingleParam(value = "客户标签名称", example = "个人客户")
	public static final String customerTagName = "customerTagName";
	
}
