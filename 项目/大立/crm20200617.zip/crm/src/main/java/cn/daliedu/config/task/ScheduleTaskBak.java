package cn.daliedu.config.task;
//package cn.daliedu.config.taskbak;
//
//import java.math.BigDecimal;
//import java.net.InetAddress;
//import java.time.LocalDate;
//import java.time.LocalDateTime;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.scheduling.annotation.EnableScheduling;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Component;
//
//import cn.daliedu.config.param.SysParamConfig;
//import cn.daliedu.entity.CustomerCountEntity;
//import cn.daliedu.entity.OrgEntity;
//import cn.daliedu.entity.UserEntity;
//import cn.daliedu.service.ContractReturnMoneyPlanService;
//import cn.daliedu.service.CustomerCountService;
//import cn.daliedu.service.CustomerService;
//import cn.daliedu.service.OrgService;
//import cn.daliedu.service.UserService;
//
///**
// * @author xiechao
// * @time 2019年11月18日 上午10:17:58
// * @version 1.0.0 
// * @description 
// */
//@Component
//@Configuration      //1.主要用于标记配置类，兼备Component的效果。
//@EnableScheduling   // 2.开启定时任务
//public class ScheduleTask {
//	@Autowired
//	OrgService orgService;
//	
//	@Autowired
//	UserService userService;
//	
//	@Autowired
//	CustomerService customerService;
//	
//	@Autowired
//	CustomerCountService customerCountService;
//	
//	@Autowired
//	ContractReturnMoneyPlanService contractReturnMoneyPlanService;
//	
//  @Scheduled(cron = "0 0 23 * * ?") //设置为每天23:00执行 
////	@Scheduled(cron = "0/3 * * * * ?") // 每3秒执行一次，开发测试时使用
//	private void configureTasks() {
//		try {
//			String configHostAddress = SysParamConfig.JOB_EXCUSE_ADDRESS;
//			String localHostAddress = InetAddress.getLocalHost().getHostAddress();
//			if (configHostAddress.trim().equals(localHostAddress)) {
//				// 1.统计所有分校下的客户数
//				List<OrgEntity> orgList = orgService.getBranchOrg();
//				for (OrgEntity entity : orgList) {
//					//如果已经执行完，则不再执行，防止重复执行
//					boolean flag = customerCountService.existBranchCustomerCountData(entity.getId().toString(), LocalDate.now().toString());
//					if(!flag){
//						CustomerCountEntity bean = new CustomerCountEntity();
//						bean.setBranchOrgId(entity.getId().toString());
//						bean.setCreateDate(LocalDate.now());
//						bean.setDataType("1");
//						bean.setCustomerCount(customerService.getCustomerCountByBranchOrgId(entity.getId()));
//						
//						customerCountService.save(bean);
//					}
//				}
//				// 2.统计所有分校下的用户的客户数
//				List<UserEntity> userList = userService.getAllUser();
//				for (UserEntity entity : userList) {
//					boolean flag = customerCountService.existUserCustomerCountData(entity.getId(), LocalDate.now().toString());
//					if(!flag){
//						CustomerCountEntity bean = new CustomerCountEntity();
//						bean.setUserId(entity.getId());
//						bean.setCreateDate(LocalDate.now());
//						bean.setDataType("2");
//						bean.setCustomerCount(customerService.getCustomerCountByUserId(entity.getId()));
//						
//						customerCountService.save(bean);
//					}
//				}
//			}
//		} catch (Exception e) {
//			System.out.println("执行定时任务出现异常");
//			e.printStackTrace();
//		}
//	}
//	
//	//添加定时任务
//    @Scheduled(cron = "0 0 1 * * ?") //设置为每天凌晨1点执行   (0/10 * * * * ? 每10秒执行一次)
//    //或直接指定时间间隔，例如：5秒
//    //@Scheduled(fixedRate=5000)
//    private void updateContractReturnMoneyPlanTasks() {
//    	try {
//    		String configHostAddress = SysParamConfig.JOB_EXCUSE_ADDRESS;
//    		String localHostAddress = InetAddress.getLocalHost().getHostAddress();
//        	if(configHostAddress.trim().equals(localHostAddress)){
//        		contractReturnMoneyPlanService.updateReturnMoneyStateByScheduleTask();
//        		
////        		Integer num = contractReturnMoneyPlanService.updateReturnMoneyStateByScheduleTask();
////        		if(num>0){
////        			System.out.println("更新成功");
////        		}
////        		System.out.println("未更新到数据" + num);
////                System.err.println("执行静态定时任务时间: " + LocalDateTime.now());
//        	}
//		} catch (Exception e) {
//			System.out.println("执行定时任务出现异常");
//			e.printStackTrace();
//		}
//    }
//    
//    
//
//}
