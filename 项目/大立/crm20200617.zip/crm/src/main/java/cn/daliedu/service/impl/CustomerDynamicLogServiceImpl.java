package cn.daliedu.service.impl;

import cn.daliedu.config.param.SysParamConfig;
import cn.daliedu.entity.CustomerDynamicFileEntity;
import cn.daliedu.entity.CustomerDynamicLogEntity;
import cn.daliedu.entity.CustomerEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.enums.DynamicTypeEnum;
import cn.daliedu.mapper.CustomerDynamicFileMapper;
import cn.daliedu.mapper.CustomerDynamicLogMapper;
import cn.daliedu.mapper.CustomerMapper;
import cn.daliedu.service.CustomerDynamicLogService;
import cn.daliedu.service.CustomerService;
import cn.daliedu.util.HttpClientUtil;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import java.io.File;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * 客户动态记录表，如新建客户，客户资料变更等操作记录 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-19
 */
@Service
public class CustomerDynamicLogServiceImpl extends ServiceImpl<CustomerDynamicLogMapper, CustomerDynamicLogEntity> implements CustomerDynamicLogService {
	@Autowired
	CustomerService customerService;
	
	@Resource
	CustomerMapper customerMapper;
	
	@Resource
	CustomerDynamicLogMapper customerDynamicLogMapper;
	
	@Resource
	CustomerDynamicFileMapper customerDynamicFileMapper;
	
	
	
	@Override
	public boolean insertFollowLog(String customerId, String dynamicContent) throws Exception {
		CustomerDynamicLogEntity entity = new CustomerDynamicLogEntity();
		entity.setCustomerId(customerId);
		entity.setDynamicType(DynamicTypeEnum.TYPE_10.getValue());
		entity.setDynamicName(DynamicTypeEnum.TYPE_10.getDesc());
		entity.setDynamicContent(dynamicContent);
		entity.setCreateDate(LocalDateTime.now());
		
		Object object = SecurityUtils.getSubject().getPrincipal();
		UserEntity user = null;
		if (object instanceof UserEntity) {
			user = (UserEntity) object;
			entity.setDynamicUserId(user.getId());
		}
		
		CustomerEntity customerEntity = customerService.getById(customerId);
		customerEntity.setUpdateTime(LocalDateTime.now());
		customerEntity.setRecentDynamicContent("添加跟进记录");
		customerEntity.setRecentDynamicDateTime(LocalDateTime.now());
		customerMapper.updateById(customerEntity);
		
		customerDynamicLogMapper.insert(entity);
		return true;
	}


	@Override
	public boolean insertFollowLog(HttpServletRequest request, String customerId, String dynamicContent, MultipartFile[] files) throws Exception {
//		String path = request.getSession().getServletContext().getRealPath("");//路径：E:\project\crm\src\main\webapp\
		
		CustomerDynamicLogEntity entity = new CustomerDynamicLogEntity();
		entity.setCustomerId(customerId);
		entity.setDynamicType(DynamicTypeEnum.TYPE_10.getValue());
		entity.setDynamicName(DynamicTypeEnum.TYPE_10.getDesc());
		entity.setDynamicContent(dynamicContent);
		entity.setCreateDate(LocalDateTime.now());
		
		Object object = SecurityUtils.getSubject().getPrincipal();
		UserEntity user = null;
		if (object instanceof UserEntity) {
			user = (UserEntity) object;
			entity.setDynamicUserId(user.getId());
		}
		
		CustomerEntity customerEntity = customerService.getById(customerId);
		customerEntity.setUpdateTime(LocalDateTime.now());
		customerEntity.setRecentDynamicContent("添加跟进记录");
		customerEntity.setRecentDynamicDateTime(LocalDateTime.now());
		customerMapper.updateById(customerEntity);
		
		customerDynamicLogMapper.insert(entity);
		
		for(MultipartFile file : files){
//			String filePath = "";
//			String imgPath = "";
//			if(SysParamConfig.UPLOAD_TYPE.equals("local")){
//				filePath = path + SysParamConfig.UPLOAD_FILE_PATH + File.separatorChar + customerId;
//				imgPath = filePath +  File.separatorChar + file.getOriginalFilename();
//			}else{
//				filePath = SysParamConfig.UPLOAD_FILE_PATH + File.separatorChar + customerId;
//				imgPath = File.separatorChar + customerId + File.separatorChar + file.getOriginalFilename();
//			}
//			
//			System.out.println("创建的上传路径为：" + filePath);
//			File folder = new File(filePath);
//			if(!folder.exists()){
//				folder.mkdirs();
//			}
//			
//			File imageFile = new File(filePath +  File.separatorChar + file.getOriginalFilename());
//			// 上传文件(如果出错，无法将出错的文件删除，其实也不需要删除，自己不使用就可以了)
//			file.transferTo(imageFile);
			
			String filePath = HttpClientUtil.uploadCustomerFile(file, customerId);
			
			
			CustomerDynamicFileEntity bean = new CustomerDynamicFileEntity();
			bean.setCustomerDynamicId(entity.getId());
			bean.setFileName(file.getOriginalFilename());
			bean.setFilePath(filePath);
			customerDynamicFileMapper.insert(bean);
		}
		
		return true;
	}


	@Override
	public List<LinkedHashMap<Object, Object>> getCustomerDynamicList(Map<Object, Object> map) {
		return customerDynamicLogMapper.getCustomerDynamicList(map);
	}


	@Override
	public Long getCustomerDynamicListCount(Map<Object, Object> map) {
		return customerDynamicLogMapper.getCustomerDynamicListCount(map);
	}
	
	
	
	
}
