package cn.daliedu.service.impl;

import cn.daliedu.entity.UserOrgEntity;
import cn.daliedu.mapper.UserOrgMapper;
import cn.daliedu.service.UserOrgService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户组织表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-23
 */
@Service
public class UserOrgServiceImpl extends ServiceImpl<UserOrgMapper, UserOrgEntity> implements UserOrgService {

}
