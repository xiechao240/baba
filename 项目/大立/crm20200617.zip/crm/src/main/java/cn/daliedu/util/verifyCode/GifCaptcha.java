package cn.daliedu.util.verifyCode;

import com.alibaba.fastjson.util.IOUtils;
import cn.daliedu.util.StringUtil;
import cn.daliedu.util.verifyCode.gif.GifEncoder;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.OutputStream;

/**
 * GIF 验证码类
 */
public class GifCaptcha extends Captcha
{
    private GifCaptcha(int width, int height)
    {
        this.width = width;
        this.height = height;
    }

    public GifCaptcha(int width, int height, int len)
    {
        this(width, height);
        this.len = len;
    }

    /**
     * @param width  宽
     * @param height 高
     * @param len    位数
     * @param font   字体
     */
    public GifCaptcha(int width, int height, int len, Font font)
    {
        this(width, height, len);
        this.font = font;
    }

    @Override
    public void out(OutputStream oos)
    {
        char[] rands = alphas();

        try
        {
            GifEncoder gifEncoder = new GifEncoder(); // gif 编码类
            // 生成字符
            gifEncoder.start(oos);
            gifEncoder.setQuality(180);
            gifEncoder.setDelay(100);
            gifEncoder.setRepeat(0);
            BufferedImage frame;

            Color fontColor[] = new Color[len];

            for (int i = 0; i < len; i++)
            {
                fontColor[i] = new Color(20 + num(110), 20 + num(110), 20 + num(110));
            }

            for (int i = 0; i < len; i++)
            {
                frame = graphicsImage(fontColor, rands, i);
                gifEncoder.addFrame(frame);
                frame.flush();
            }

            gifEncoder.finish();
        }
        finally
        {
            IOUtils.close(oos);
        }
    }

    /**
     * 画随机码图
     *
     * @param fontColor 随机字体颜色
     * @param text      字符数组
     * @param flag      透明度使用
     */
    private BufferedImage graphicsImage(Color[] fontColor, char[] text, int flag)
    {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        // 获得图形上下文
        Graphics2D g2d = (Graphics2D)image.getGraphics();
        // 利用指定颜色填充背景
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, width, height);

        int h = height - ((height - font.getSize()) >> 1);
        int w = width / (len + 1);
        g2d.setFont(font);

        AlphaComposite ac3;
        for (int i = 0; i < len; i++)
        {
            ac3 = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, getAlpha(flag, i));
            g2d.setComposite(ac3);
            g2d.setColor(fontColor[i]);
            g2d.drawOval(num(width), num(height), 5 + num(10), 5 + num(10));
            g2d.drawString(text[i] + StringUtil.EMPTY, (width - (len - i) * w) + (w - font.getSize()) + 1, h - 4);
        }

        g2d.dispose();
        return image;
    }

    /**
     * 获取透明度, 从 0 到 1, 自动计算步长
     *
     * @return float 透明度
     */
    private float getAlpha(int i, int j)
    {
        int num = i + j;
        float r = (float)1 / len, s = (len + 1) * r;
        return num > len ? (num * r - s) : num * r;
    }
}
