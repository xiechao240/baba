package cn.daliedu.controller.api.console;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.UnauthorizedException;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.MenuEntity;
import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.RoleEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.UserRoleEntity;
import cn.daliedu.entity.json.GlobalJson;
import cn.daliedu.entity.json.OrgJson;
import cn.daliedu.entity.json.RoleJson;
import cn.daliedu.entity.json.UserJson;
import cn.daliedu.entity.web.SmsCodeVO;
import cn.daliedu.enums.ResultCodeEnum;
import cn.daliedu.enums.UserTypeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.MenuService;
import cn.daliedu.service.OrgService;
import cn.daliedu.service.RoleService;
import cn.daliedu.service.UserOrgAreaService;
import cn.daliedu.service.UserRoleService;
import cn.daliedu.service.UserService;
import cn.daliedu.shiro.redis.RedisUtil;
import cn.daliedu.util.JsonUtil;
import cn.daliedu.util.Log4jUtil;
import cn.daliedu.util.MD5Util;
import cn.daliedu.util.PageUtil;
import cn.daliedu.util.Result;
import cn.daliedu.util.SMSCodeValidate;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * 当前登录用户相关信息获取接口控制器
 * @author xiechao
 * @time 2019年5月13日 上午10:33:58
 * @version 1.0.0 
 * @description
 */
@Api(description = "用户操作相关接口")
@RestController
@RequestMapping(value = "${rest.path}/console/user") 
public class UserController {
	@Resource
	RedisUtil redisUtil;
	
	@Autowired
	UserService userService;
	
	@Autowired
	RoleService roleService;
	
	@Autowired
	OrgService deptService;
	
	@Autowired
	MenuService menuService;
	
	@Autowired
	UserRoleService userRoleService;
	
	@Autowired
	UserOrgAreaService userOrgAreaService;
	
	@Autowired
	OrgService orgService;
	
	/**
	 * 员工修改密码接口
	 **/
	@ApiOperation(value = "【个人中心】修改员工账号，调此接口前，需要调用获取短信验证码接口（登录状态修改账号）")
	@ApiJsonObject(name = "updateUserAccount", value = {
			@ApiJsonProperty(name = UserJson.password),
			@ApiJsonProperty(name = UserJson.mobile),
			@ApiJsonProperty(name = UserJson.validateCode)})
	@ApiImplicitParam(name = "params", required = true, dataType = "updateUserAccount")
	@RequestMapping(value = "/updateUserAccount", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Result updateUserAccount(@RequestBody String params)  {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String password = String.valueOf(jsonObject.get("password"));
			String mobile = String.valueOf(jsonObject.get("mobile"));
			String validateCode = String.valueOf(jsonObject.get("validateCode"));

			StringUtil.validateIsNull(password, "请输入密码");
			StringUtil.validateIsNull(mobile, "请输入手机号码");
			StringUtil.validateIsNull(validateCode, "请输入验证码");
			
			//必须是6-16位的字母、数字、下划线（这里字母、数字、下划线是指任意组合，没有必须三类均包含）
//			String REGEX_PASSWORD = "^[\\w_]{6,16}$";
			//必需6-16位的密码，可包含特殊字符
			String REGEX_PASSWORD = "^[0-9a-zA-Z~!@#$^&%*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]{6,}$";
			if(!password.matches(REGEX_PASSWORD)){
//				throw new BusinessException("密码为6到16位的字母，数字，下划线任意组合，不能包含特殊字符！");
				throw new BusinessException("密码为6到16位的字母，数字，下划线任意组合，可包含特殊字符！");
			}

			Object object = SecurityUtils.getSubject().getPrincipal();
			UserEntity user = null;
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				user = this.userService.getById(bean.getId()); //从这里面获取到的信息，还要进行下面的查询，防止用户重新授权过
			}
			
			//校验用户输入的原密码是否正确
			StringUtil.validateString(user.getPassword(), MD5Util.encrypt(password), "您输入的密码不正确，请重新输入");
			
			//校验用户输入的手机号码在系统中是否存在
			if(userService.validateMobileExist(mobile)){
				throw new BusinessException("此手机号码在系统是已经作为账号使用，请更换手机号，或联系管理员");
			}
			
			SMSCodeValidate smsCodeValidate = new SMSCodeValidate();
			boolean flag = smsCodeValidate.validateCode(mobile, validateCode);
			if(flag){
				user.setMobile(mobile);
				user.setLoginName(mobile);
				userService.updateById(user);
				
				return Result.success("更新成功");
			}
			return Result.error("操作失败，请稍后再试！");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("操作失败，请稍后再试！");
		}
	}
	
	
	/**
	 * 员工修改密码接口
	 **/
	@ApiOperation(value = "【忘记密码】修改账号密码，调此接口前，需要调用获取短信验证码接口（未登录状态修改密码）")
	@ApiJsonObject(name = "updateUserAccountPassword", value = {
			@ApiJsonProperty(name = UserJson.password),
			@ApiJsonProperty(name = UserJson.mobile),
			@ApiJsonProperty(name = UserJson.validateCode)})
	@ApiImplicitParam(name = "params", required = true, dataType = "updateUserAccountPassword")
	@RequestMapping(value = "/updateUserAccountPassword", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Result updateUserAccountPassword(@RequestBody String params)  {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String password = String.valueOf(jsonObject.get("password"));
			String mobile = String.valueOf(jsonObject.get("mobile"));
			String validateCode = String.valueOf(jsonObject.get("validateCode"));

			StringUtil.validateIsNull(password, "请输入密码");
			StringUtil.validateIsNull(mobile, "请输入手机号码");
			StringUtil.validateIsNull(validateCode, "请输入验证码");
			
			//必须是6-16位的字母、数字、下划线（这里字母、数字、下划线是指任意组合，没有必须三类均包含）
//			String REGEX_PASSWORD = "^[\\w_]{6,16}$";
			//必需6-16位的密码，可包含特殊字符
			String REGEX_PASSWORD = "^[0-9a-zA-Z~!@#$^&%*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]{6,}$";
			if(!password.matches(REGEX_PASSWORD)){
//				throw new BusinessException("密码为6到16位的字母，数字，下划线任意组合，不能包含特殊字符！");
				throw new BusinessException("密码为6到16位的字母，数字，下划线任意组合，可包含特殊字符！");
			}

			
			//校验用户输入的手机号码在系统中是否存在，如果存在，则有这个用户
			if(userService.validateMobileExist(mobile)){
				SMSCodeValidate smsCodeValidate = new SMSCodeValidate();
				boolean flag = smsCodeValidate.validateCode(mobile, validateCode);
				if(flag){
					UserEntity user = userService.getUserByMobile(mobile);
					if(user!=null){
						user.setPassword(MD5Util.encrypt(password));
						userService.updateById(user);
						return Result.success("更新成功");
					}
				}
			}
			
			return Result.error("操作失败，请稍后再试！");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("操作失败，请稍后再试！");
		}
	}
	
	
	/**
	 * 员工修改密码接口
	 **/
	@ApiOperation(value = "【个人中心】员工修改密码接口")
	@ApiJsonObject(name = "updateUserPassword", value = {
			@ApiJsonProperty(name = UserJson.oldPassword),
			@ApiJsonProperty(name = UserJson.newPassword)})
	@ApiImplicitParam(name = "params", required = true, dataType = "updateUserPassword")
	@RequestMapping(value = "/updateUserPassword", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Result updateUserPassword(@RequestBody String params)  {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String oldPassword = String.valueOf(jsonObject.get("oldPassword"));
			String newPassword = String.valueOf(jsonObject.get("newPassword"));

			StringUtil.validateIsNull(oldPassword, "请输入旧密码");
			StringUtil.validateIsNull(newPassword, "请输入新密码");

			Subject subject = SecurityUtils.getSubject();
			Object object = subject.getPrincipal();
			UserEntity user = null;
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				user = this.userService.getById(bean.getId()); //从这里面获取到的信息，还要进行下面的查询，防止用户重新授权过
			}

			StringUtil.validateString(user.getPassword(), MD5Util.encrypt(oldPassword), "您输入的原密码不正确，请重新输入");

			user.setPassword(MD5Util.encrypt(newPassword));
			this.userService.updateById(user);
			return Result.success("修改密码成功");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("操作失败，请稍后再试！");
		}
	}

	/**
	 * 员工修改基础资料接口
	 **/
	@ApiOperation(value = "【个人中心】员工修改基本资料接口,目前来看，可能只需要修改邮箱即可")
	@ApiJsonObject(name = "updateUserBaseInfo", value = {
//			@ApiJsonProperty(name = UserJson.userName),
//			@ApiJsonProperty(name = UserJson.sex),
//			@ApiJsonProperty(name = UserJson.mobile),
			@ApiJsonProperty(name = UserJson.email)})
	@ApiImplicitParam(name = "params", required = true, dataType = "updateUserBaseInfo")
	@RequestMapping(value = "/updateUserBaseInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Result updateUserBaseInfo(@RequestBody String params)  {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);

//			String userName = String.valueOf(jsonObject.get("userName"));
//			String sex = String.valueOf(jsonObject.get("sex"));
//			String mobile = String.valueOf(jsonObject.get("mobile"));
			String email = String.valueOf(jsonObject.get("email"));

//			StringUtil.validateIsNull(userName, "请输入名称");
//			StringUtil.validateIsNull(sex, "请输入性别");
//			StringUtil.validateIsNull(mobile, "请输入手机号码");
			StringUtil.validateIsNull(email, "请输入邮箱账号");

			Subject subject = SecurityUtils.getSubject();
			Object object = subject.getPrincipal();
			UserEntity user = null;
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				user = this.userService.getById(bean.getId()); //从这里面获取到的信息，还要进行下面的查询，防止用户重新授权过
			}
//			user.setUserName(userName);
//			user.setSex(sex);
//			user.setMobile(mobile);
			user.setEmail(email);
			this.userService.updateById(user);

			return Result.success("修改基本信息成功");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("操作失败，请稍后再试！");
		}
	}
	
	
	//1. 获取用户信息接口
	@ApiOperation(value = "获取当前用户信息")
	@PostMapping("/getUserInfoById")
	public Result getUserInfoById() {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            UserEntity user = userService.getById(bean.getId()); //从这里面获取到的信息，还要进行下面的查询，防止用户重新授权过，
				
	            return Result.success(user);
	            //如果要去null处理，就改写下面的代码
//				Map<Object, Object> map = new LinkedHashMap<Object, Object>();
//				if(user!=null){
//					// 使用json返回也可以，但是没有顺序，使用 LinkedHashMap就有顺序
//					// JSONObject json = new JSONObject();
//					map.put("id", vip.getId());
//					map.put("loginName", vip.getLoginName());
//					map.put("name", StringUtil.stringAndNull(vip.getName()));
	//
//					return Result.success(map);
//				}
//				return Result.error("无法获取用户信息");
			}
			return Result.error("无法获取用户信息");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取当前用户信息失败，失败原因：" + e.getMessage());
		}
	}
	
	
	//1. 获取用户信息接口
	@ApiOperation(value = "当前用户拥有的分校(超级管理员将返回所有的分校)")
	@PostMapping("/getBranchOrgByUserId")
	public Result getBranchOrgByUserId() {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity user = (UserEntity) object;
					
		        List<OrgEntity> list = orgService.getBranchOrgByUserId(user.getId());
		        return Result.success(list);
			}
			return Result.error("无法获取用户分校信息");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("当前用户拥有的分校信息失败，失败原因：" + e.getMessage());
		}
	}
	
	
//	//1. 获取用户信息接口
//	@ApiOperation(value = "获取用户的所有信息（包含用户的角色，部门，分校等数据）")
//	@PostMapping("/getUserAllInfoById")
//	public Result getUserAllInfoById() {
//		try{
			//下面这种一次性加载的方式，无法做到即时生效，拆分成独立的接口比较好
//			//1. 获取用户的信息
//			
//			//2.获取用户的角色
//			
//			//3.获取用的部门
//			
//			//3.获取用户的分校
//			
//			Map<Object, Object> map = new LinkedHashMap<>();
////			map.put("user", user);
////			map.put("roleList", roleList);
////			map.put("orgId", orgId);
////			map.put("branchOrgList", branchOrgList);
////			
////			return Result.success(map);
//			
//			return Result.error("无法获取用户信息");
//		}catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("获取当前用户信息失败，失败原因：" + e.getMessage());
//		}
//	}
	
	//2. 获取用户菜单接口
	@ApiOperation(value = "获取当前用户所有菜单，不包含按钮，以树形结构返回结果集")
	@PostMapping("/findNavTree")
	public Result findNavTree(){
		try{
			Subject subject = SecurityUtils.getSubject();
			UserEntity user = (UserEntity) subject.getPrincipal();
			List<MenuEntity> menuList = menuService.findTree(user.getId(), "1");
			
			return Result.success(menuList);
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取当前用户菜单失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
	
	@ApiOperation(value = "根据传入的用户类型，获取同级别的交接人员列表(如果此接口没返回数据，则前端给予提示：暂无可交接的人员，请联系系统管理员)")
	@ApiJsonObject(name = "findUserListByUserType", value = { 
			@ApiJsonProperty(name = UserJson.userId),
			@ApiJsonProperty(name = UserJson.userType),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "findUserListByUserType")
	@PostMapping("/findUserListByUserType")
	public Result findUserListByUserType(@RequestBody String params)  {
		try {
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
			String userType = String.valueOf(jsonObject.get("userType"));
			String userId = String.valueOf(jsonObject.get("userId"));
			
			StringUtil.validateIsNull(userId, "需要交接的用户ID不能为空");
			StringUtil.validateIsNull(userType, "用户类型不能为空");
			StringUtil.validateIsNull(pageNum, "请输入页码");
			StringUtil.validateIsNull(pageSize, "请输入每页记录数");
			
			//核心逻辑：1.超级管理员，只能交接给超级管理员   
			//2.区域管理员，只能交接给区域管理员（如果要交给一个分校的校长，可将校长提升为区域管理员）  
			//3.分校校长，只能交接给分校校长  
			//4.部门管理员，可交接给部门管理员，分校校长 
			//5.销售人员，可交接给销售人员，部门管理员，分校校长  
			//6.普通用户，可交接给销售人员，部门管理员，分校校长
			
			Subject subject = SecurityUtils.getSubject();
			UserEntity user = (UserEntity) subject.getPrincipal();
			
			Map<Object, Object> paramMap = new HashMap<Object, Object>();
			paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
            paramMap.put("pageSize", Integer.parseInt(pageSize));
			
			List<LinkedHashMap<Object, Object>> list = null;
			Long total = null;
			
			//如果需要交接的人是代理商，则只能加载代理商用户
			if(userType.equals(UserTypeEnum.TYPE_7.getValue())){
				if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue())){
					paramMap.put("searchType", "1");
				}else{
					paramMap.put("searchType", "2");
				}
				list = userService.findAgentUserListByUserId(paramMap);
				total = userService.findAgentUserListByUserIdCount(paramMap);
			}else{
				//如果当前登录的是超级管理员，才可以点交接超级管理员
				if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue())){
					if(userType.equals(UserTypeEnum.TYPE_1.getValue())){
						//加载可交接的超级管理员列表 
						paramMap.put("searchType", "1");
						paramMap.put("userType", UserTypeEnum.TYPE_1.getValue());
					}
					if(userType.equals(UserTypeEnum.TYPE_2.getValue())){
						//加载可交接的区域管理员列表
						paramMap.put("searchType", "1");
						paramMap.put("userType", UserTypeEnum.TYPE_2.getValue());
					}
					if(userType.equals(UserTypeEnum.TYPE_3.getValue())){
						//加载可交接的分校管理员列表,根据需要交接的userId加载用户所在的分校的分校管理员
						paramMap.put("userId", userId);
						paramMap.put("userType", UserTypeEnum.TYPE_3.getValue());
					}
					if(userType.equals(UserTypeEnum.TYPE_4.getValue())){
						//加载需要交接的人当前所在部门的部门管理员列表
						paramMap.put("userId", userId);
						paramMap.put("userType", UserTypeEnum.TYPE_4.getValue());
					}
					list = userService.findUserListByUserType(paramMap);
					total = userService.findUserListByUserTypeCount(paramMap);
					
					if(userType.equals(UserTypeEnum.TYPE_5.getValue()) || userType.equals(UserTypeEnum.TYPE_6.getValue())){
						//加载交接人所在的分校的所有人员
						//1.获取交接人所在的分校
						OrgEntity branchOrgEntity = orgService.getUserBranchOrgByUserId(userId);
						
			            paramMap.put("orgId", branchOrgEntity.getId());
			            paramMap.put("userName", "");
			            paramMap.put("state", "1");
			            list = userService.findUserListByOrgIdAndChildren(paramMap);
			            total = userService.findUserListByOrgIdAndChildrenCount(paramMap);
					}
				}
				
				//如果当前登录的是区域管理员
				if(user.getUserType().equals(UserTypeEnum.TYPE_2.getValue())){
					if(userType.equals(UserTypeEnum.TYPE_1.getValue())){
						return Result.error("您当前无权限操作超级管理员的交接");
					}
					if(userType.equals(UserTypeEnum.TYPE_2.getValue())){
						//加载可交接的区域管理员列表
						paramMap.put("searchType", "1");
						paramMap.put("userType", UserTypeEnum.TYPE_2.getValue());
					}
					if(userType.equals(UserTypeEnum.TYPE_3.getValue())){
						//加载可交接的分校管理员列表,根据需要交接的userId加载用户所在的分校的分校管理员
						paramMap.put("userId", userId);
						paramMap.put("userType", UserTypeEnum.TYPE_3.getValue());
					}
					if(userType.equals(UserTypeEnum.TYPE_4.getValue())){
						//加载需要交接的人当前所在部门的部门管理员列表
						paramMap.put("userId", userId);
						paramMap.put("userType", UserTypeEnum.TYPE_4.getValue());
					}
					list = userService.findUserListByUserType(paramMap);
					total = userService.findUserListByUserTypeCount(paramMap);
					
					if(userType.equals(UserTypeEnum.TYPE_5.getValue()) || userType.equals(UserTypeEnum.TYPE_6.getValue())){
						//加载交接人所在的分校的所有人员
						OrgEntity branchOrgEntity = orgService.getUserBranchOrgByUserId(userId);
						
			            paramMap.put("orgId", branchOrgEntity.getId());
			            paramMap.put("userName", "");
			            paramMap.put("state", "1");
			            list = userService.findUserListByOrgIdAndChildren(paramMap);
			            total = userService.findUserListByOrgIdAndChildrenCount(paramMap);
					}
				}
				
				if(user.getUserType().equals(UserTypeEnum.TYPE_3.getValue())){
					if(userType.equals(UserTypeEnum.TYPE_1.getValue())){
						return Result.error("您当前无权限操作超级管理员的交接");
					}
					if(userType.equals(UserTypeEnum.TYPE_2.getValue())){
						return Result.error("您当前无权限操作区域管理员的交接");
					}
					if(userType.equals(UserTypeEnum.TYPE_3.getValue())){
						//加载可交接的分校管理员列表,根据需要交接的userId加载用户所在的分校的分校管理员
						paramMap.put("userId", userId);
						paramMap.put("userType", UserTypeEnum.TYPE_3.getValue());
					}
					if(userType.equals(UserTypeEnum.TYPE_4.getValue())){
						//加载需要交接的人当前所在部门的部门管理员列表
						paramMap.put("userId", userId);
						paramMap.put("userType", UserTypeEnum.TYPE_4.getValue());
					}
					list = userService.findUserListByUserType(paramMap);
					total = userService.findUserListByUserTypeCount(paramMap);
					
					if(userType.equals(UserTypeEnum.TYPE_5.getValue()) || userType.equals(UserTypeEnum.TYPE_6.getValue())){
						//加载交接人所在的分校的所有人员
						OrgEntity branchOrgEntity = orgService.getUserBranchOrgByUserId(userId);
						
			            paramMap.put("orgId", branchOrgEntity.getId());
			            paramMap.put("userName", "");
			            paramMap.put("state", "1");
			            list = userService.findUserListByOrgIdAndChildren(paramMap);
			            total = userService.findUserListByOrgIdAndChildrenCount(paramMap);
					}
				}
				
				if(user.getUserType().equals(UserTypeEnum.TYPE_4.getValue())){
					if(userType.equals(UserTypeEnum.TYPE_1.getValue())){
						return Result.error("您当前无权限操作超级管理员的交接");
					}
					if(userType.equals(UserTypeEnum.TYPE_2.getValue())){
						return Result.error("您当前无权限操作区域管理员的交接");
					}
					if(userType.equals(UserTypeEnum.TYPE_3.getValue())){
						//加载可交接的分校管理员列表,根据需要交接的userId加载用户所在的分校的分校管理员
						return Result.error("您当前无权限操作分校管理员的交接");
					}
					if(userType.equals(UserTypeEnum.TYPE_4.getValue())){
						//加载需要交接的人当前所在部门的部门管理员列表
						paramMap.put("userId", userId);
						paramMap.put("userType", UserTypeEnum.TYPE_4.getValue());
					}
					list = userService.findUserListByUserType(paramMap);
					total = userService.findUserListByUserTypeCount(paramMap);
					
					if(userType.equals(UserTypeEnum.TYPE_5.getValue()) || userType.equals(UserTypeEnum.TYPE_6.getValue())){
						//加载交接人所在的分校的所有人员
						OrgEntity branchOrgEntity = orgService.getUserBranchOrgByUserId(userId);
						
			            paramMap.put("orgId", branchOrgEntity.getId());
			            paramMap.put("userName", "");
			            paramMap.put("state", "1");
			            list = userService.findUserListByOrgIdAndChildren(paramMap);
			            total = userService.findUserListByOrgIdAndChildrenCount(paramMap);
					}
				}
				
				if(user.getUserType().equals(UserTypeEnum.TYPE_5.getValue()) || user.getUserType().equals(UserTypeEnum.TYPE_6.getValue())
						|| user.getUserType().equals(UserTypeEnum.TYPE_7.getValue())){
					throw new BusinessException("你当前无权限操作此业务");
				}
			}
			
            
			
			if(list!=null && list.size()>0){
				IPage page  = new Page();
				page.setTotal(total.longValue());
				page.setSize(Long.parseLong(pageSize));
				page.setRecords(list);
				return Result.success(page);
			}
			return Result.error("没有符合条件的数据");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("查询失败，请稍后再试！");
		}
	}
	
	
	@ApiOperation(value = "将一个用户交接给另一个用户")
	@ApiJsonObject(name = "receiveToNewUser", value = { 
			@ApiJsonProperty(name = UserJson.userId),
			@ApiJsonProperty(name = UserJson.receiveUserId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "receiveToNewUser")
	@PostMapping("/receiveToNewUser")
	public Result receiveToNewUser(@RequestBody String params)  {
		try {
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String userId = String.valueOf(jsonObject.get("userId"));
			String receiveUserId = String.valueOf(jsonObject.get("receiveUserId"));
			
			StringUtil.validateIsNull(userId, "需要交接的用户ID不能为空");
			StringUtil.validateIsNull(receiveUserId, "交接的用户ID不能为空");
			
			//核心逻辑：
			boolean flag = userService.receiveToNewUser(userId, receiveUserId);
			if(flag){
				return Result.success("交接成功");
			}
			
			return Result.error("交接失败，请联系系统管理员");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("交接失败，请稍后再试！");
		}
	}
	
	
	@ApiOperation(value = "查询指定分校下的所有用户（带分页），目前在接收人，跟进人列表，删除人列表，共享人列表，还原给同事列表都可以使用")
	@ApiJsonObject(name = "findUserListByBranchOrgId", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "findUserListByBranchOrgId")
	@PostMapping("/findUserListByBranchOrgId")
	public Result findUserListByBranchOrgId(@RequestBody String params)  {
		try {
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
			String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
			
			StringUtil.validateIsNull(pageNum, "请输入页码");
			StringUtil.validateIsNull(pageSize, "请输入每页记录数");
			
            Map<Object, Object> paramMap = new HashMap<Object, Object>();
            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
            paramMap.put("pageSize", Integer.parseInt(pageSize));
            paramMap.put("branchOrgId", branchOrgId);
			
			List<UserEntity> list = userService.getUserListByBranchOrgId(paramMap);
			if(list!=null && list.size()>0){
				Long total = userService.getUserListByBranchOrgIdCount(paramMap);
				
				//将用户的角色ID给赋值，其实不应该在后端 这里写这个逻辑，增加了一些性能的开销，应该由前端调编辑用户接口再来加载用户的角色
//				for(UserEntity user : list){
//					String userId = user.getId();
////					String userType = map.get("user_type").toString();
//					UserRoleEntity userRoleEntity = userRoleService.getRoleByUserId(userId);
//					if(userRoleEntity!=null){
//						map.put("role_id", userRoleEntity.getRoleId());
//					}
//					//将用户的分校集合返回给前台
//					String orgIds = userOrgAreaService.getUserOrgAreaIdsByUserId(userId);
//					if(orgIds!=null && !orgIds.equals("")){
//						map.put("orgIds", orgIds.split(","));
//					}else{
//						map.put("orgIds", "[]");
//					}
//				}
				
				IPage page  = new Page();
				page.setTotal(total.longValue());
				page.setSize(Long.parseLong(pageSize));
				page.setRecords(list);
				return Result.success(page);
			}
			return Result.error("没有符合条件的数据");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("查询失败，请稍后再试！");
		}
	}
	
	
//	@ApiOperation(value = "查询当前登录的用户所在的分校下的所有用户（带分页），目前在导入客户时选择推广人员时使用，此方法有问题，如果当前登录的用户是超级管理员，区域管理员，那么就有多家分校")
//	@ApiJsonObject(name = "findUserListByUserBranchOrgId", value = { 
//			@ApiJsonProperty(name = GlobalJson.pageNum),
//			@ApiJsonProperty(name = GlobalJson.pageSize)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "findUserListByUserBranchOrgId")
//	@PostMapping("/findUserListByUserBranchOrgId")
//	public Result findUserListByUserBranchOrgId(@RequestBody String params)  {
//		try {
//			System.out.println("params参数为：" + params);
//			
//			JSONObject jsonObject = JSON.parseObject(params);
//			String pageNum = String.valueOf(jsonObject.get("pageNum"));
//			String pageSize = String.valueOf(jsonObject.get("pageSize"));
//			
//			StringUtil.validateIsNull(pageNum, "请输入页码");
//			StringUtil.validateIsNull(pageSize, "请输入每页记录数");
//			
//			Subject subject = SecurityUtils.getSubject();
//			UserEntity user = (UserEntity) subject.getPrincipal();
//			OrgEntity branchOrgEnttiy = orgService.getUserBranchOrgByUser(user);
//			
//            Map<Object, Object> paramMap = new HashMap<Object, Object>();
//            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
//            paramMap.put("pageSize", Integer.parseInt(pageSize));
//            paramMap.put("orgId", branchOrgEnttiy.getId());
//            paramMap.put("userName", "");
//            paramMap.put("state", "1");
//			
//			List<LinkedHashMap<Object, Object>> list = userService.findUserListByOrgIdAndChildren(paramMap);
//			if(list!=null && list.size()>0){
//				Long total = userService.findUserListByOrgIdAndChildrenCount(paramMap);
//				
//				//将用户的角色ID给赋值，其实不应该在后端 这里写这个逻辑，增加了一些性能的开销，应该由前端调编辑用户接口再来加载用户的角色
//				for(LinkedHashMap<Object, Object> map : list){
//					String userId = map.get("id").toString();
////					String userType = map.get("user_type").toString();
//					UserRoleEntity userRoleEntity = userRoleService.getRoleByUserId(userId);
//					if(userRoleEntity!=null){
//						map.put("role_id", userRoleEntity.getRoleId());
//					}
//					//将用户的分校集合返回给前台
//					String orgIds = userOrgAreaService.getUserOrgAreaIdsByUserId(userId);
//					if(orgIds!=null && !orgIds.equals("")){
//						map.put("orgIds", orgIds.split(","));
//					}else{
//						map.put("orgIds", "[]");
//					}
//				}
//				
//				IPage page  = new Page();
//				page.setTotal(total.longValue());
//				page.setSize(Long.parseLong(pageSize));
//				page.setRecords(list);
//				return Result.success(page);
//			}
//			return Result.error("没有符合条件的数据");
//		} catch (BusinessException e) {
//			e.printStackTrace();
//			return Result.error(e.getMessage());
//		} catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("查询失败，请稍后再试！");
//		}
//	}
	
	
	@ApiOperation(value = "获取推广人列表，加载用户能访问的分校内的用户作为推广人(带分页)", notes = "这样做可以跨分校")
	@ApiJsonObject(name = "getFollowUserList", value = { 
			@ApiJsonProperty(name = UserJson.userName),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getFollowUserList")
	@PostMapping("/getFollowUserList")
	public Result getFollowUserList(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				UserEntity user = userService.getById(bean.getId());
				
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String userName = String.valueOf(jsonObject.get("userName"));//跟进人名称
				
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				
	            
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	    		
	            paramMap.put("userName", userName);
	            paramMap.put("userType", user.getUserType());//将用户类型传递至后端sql，用来判断是否为超级管理员
	            paramMap.put("userId", user.getId());//当前用户ID,用于排除掉自己，列表中不能出现自己
	            
	            List<UserEntity> list = userService.getFollowUserList(paramMap);
	            if(list!=null && list.size()>0){
					Long total = userService.getFollowUserListCount(paramMap);
					
					IPage<UserEntity> page  = new Page<UserEntity>();
					page.setTotal(total.longValue());
					page.setSize(Long.parseLong(pageSize));
					page.setRecords(list);
					return Result.success(page);
				}
	            return Result.success("当前用户下没有数据");
			}
			return Result.error("无法获取列表");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取列表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
	@ApiOperation(value = "查询代理商下面的员工（带分页），后台已经进行权限过滤，除超级管理员外，其他的用户，只能查询到自己发展的代理商")
	@ApiJsonObject(name = "findUserListByAgent", value = { 
			@ApiJsonProperty(name = UserJson.state),
			@ApiJsonProperty(name = UserJson.loginNameOrUserName),
			@ApiJsonProperty(name = OrgJson.orgId),
			@ApiJsonProperty(name = OrgJson.branchOrgId),//目前此参数可不传，为将来按业务组查代理商预留
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "findUserListByAgent")
	@PostMapping("/findUserListByAgent")
	public Result findUserListByAgent(@RequestBody String params)  {
		try {
			System.out.println("params参数为：" + params);
			Subject subject = SecurityUtils.getSubject();
			UserEntity user = (UserEntity) subject.getPrincipal();
			
			JSONObject jsonObject = JSON.parseObject(params);
			String state = String.valueOf(jsonObject.get("state"));
			String loginNameOrUserName = String.valueOf(jsonObject.get("loginNameOrUserName"));
			String orgId = String.valueOf(jsonObject.get("orgId"));
			String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
			
			StringUtil.validateIsNull(orgId, "请输入机构ID");
			StringUtil.validateIsNull(pageNum, "请输入页码");
			StringUtil.validateIsNull(pageSize, "请输入每页记录数");
//			StringUtil.validateIsNull(state, "请输入账号状态");
			
            Map<Object, Object> paramMap = new HashMap<Object, Object>();
            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
            paramMap.put("pageSize", Integer.parseInt(pageSize));
            if(orgId!=null && !orgId.equals("") && !orgId.equals("null")){
            	paramMap.put("orgId", orgId);
            }else{
            	paramMap.put("orgId", null);
            }
            paramMap.put("loginNameOrUserName", loginNameOrUserName);
            paramMap.put("state", state);
            paramMap.put("branchOrgId", branchOrgId);
            paramMap.put("createUserId", user.getId());
            paramMap.put("userType", user.getUserType());
			
			List<LinkedHashMap<Object, Object>> list = userService.findUserListByAgent(paramMap);
			if(list!=null && list.size()>0){
				Long total = userService.findUserListByAgentCount(paramMap);
				
				//将用户的角色ID给赋值，其实不应该在后端 这里写这个逻辑，增加了一些性能的开销，应该由前端调编辑用户接口再来加载用户的角色
				for(LinkedHashMap<Object, Object> map : list){
					String userId = map.get("id").toString();
//					String userType = map.get("user_type").toString();
					UserRoleEntity userRoleEntity = userRoleService.getRoleByUserId(userId);
					if(userRoleEntity!=null){
						map.put("role_id", userRoleEntity.getRoleId());
						map.put("role_name", roleService.getById(userRoleEntity.getRoleId()).getName());
					}
					//将用户的分校集合返回给前台
					String orgIds = userOrgAreaService.getUserOrgAreaIdsByUserId(userId);
					if(orgIds!=null && !orgIds.equals("")){
						map.put("orgIds", orgIds.split(","));
					}else{
						map.put("orgIds", "[]");
					}
				}
				
				IPage page  = new Page();
				page.setTotal(total.longValue());
				page.setSize(Long.parseLong(pageSize));
				page.setRecords(list);
				return Result.success(page);
			}
			return Result.error("没有符合条件的数据");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("查询失败，请稍后再试！");
		}
	}
	
	/** 
	 * 查询机构下面的员工（带分页）
	 **/
	@ApiOperation(value = "查询机构下面的员工（带分页）,目前改造为只查询指定节点的用户,在后台机构与员工管理中有使用")
	@ApiJsonObject(name = "findUserListByOrgId", value = { 
			@ApiJsonProperty(name = UserJson.state),
			@ApiJsonProperty(name = UserJson.loginNameOrUserName),
			@ApiJsonProperty(name = OrgJson.orgId),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "findUserListByOrgId")
	@PostMapping("/findUserListByOrgId")
	public Result findUserListByOrgId(@RequestBody String params)  {
		try {
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String orgId = String.valueOf(jsonObject.get("orgId"));
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
			String userName = String.valueOf(jsonObject.get("loginNameOrUserName"));
			String state = String.valueOf(jsonObject.get("state"));
			
			StringUtil.validateIsNull(orgId, "请输入机构ID");
			StringUtil.validateIsNull(pageNum, "请输入页码");
			StringUtil.validateIsNull(pageSize, "请输入每页记录数");
			StringUtil.validateIsNull(state, "请输入员工状态");
			
            Map<Object, Object> paramMap = new HashMap<Object, Object>();
            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
            paramMap.put("pageSize", Integer.parseInt(pageSize));
            if(orgId!=null && !orgId.equals("") && !orgId.equals("null")){
            	paramMap.put("orgId", orgId);
            }
            paramMap.put("userName", userName);
            paramMap.put("state", state);
            
            UserEntity user = (UserEntity) SecurityUtils.getSubject().getPrincipal();
            //顶级节点，只有超级管理员，与区域管理员，可以进行查询到数据
            if(orgId.equals("1")){
            	if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue()) || user.getUserType().equals(UserTypeEnum.TYPE_2.getValue())){
    			}else{
    				return Result.error("没有符合条件的数据");
    			}
            }
			
			
			List<LinkedHashMap<Object, Object>> list = userService.findUserListByOrgId(paramMap);
			if(list!=null && list.size()>0){
				Long total = userService.findUserListByOrgIdCount(paramMap);
				
				//将用户的角色ID给赋值，其实不应该在后端 这里写这个逻辑，增加了一些性能的开销，应该由前端调编辑用户接口再来加载用户的角色
				for(LinkedHashMap<Object, Object> map : list){
					String userId = map.get("id").toString();
//					String userType = map.get("user_type").toString();
					UserRoleEntity userRoleEntity = userRoleService.getRoleByUserId(userId);
					if(userRoleEntity!=null){
						map.put("role_id", userRoleEntity.getRoleId());
						map.put("role_name", roleService.getById(userRoleEntity.getRoleId()).getName());
					}
					//将用户的分校集合返回给前台
					String orgIds = userOrgAreaService.getUserOrgAreaIdsByUserId(userId);
					if(orgIds!=null && !orgIds.equals("")){
						map.put("orgIds", orgIds.split(","));
					}else{
						map.put("orgIds", "[]");
					}
				}
				
				IPage page  = new Page();
				page.setTotal(total.longValue());
				page.setSize(Long.parseLong(pageSize));
				page.setRecords(list);
				return Result.success(page);
			}
			return Result.error("没有符合条件的数据");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("查询失败，请稍后再试！");
		}
	}
	
	
	/** 
	 * 查询机构下面的员工（带分页）
	 **/
	@ApiOperation(value = "查询机构与子机构下面的员工（带分页）")
	@ApiJsonObject(name = "findUserListByOrgIdAndChildren", value = { 
//			@ApiJsonProperty(name = UserJson.state),
//			@ApiJsonProperty(name = UserJson.loginNameOrUserName),
			@ApiJsonProperty(name = OrgJson.orgId),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "findUserListByOrgIdAndChildren")
	@PostMapping("/findUserListByOrgIdAndChildren")
	public Result findUserListByOrgIdAndChildren(@RequestBody String params)  {
		try {
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String orgId = String.valueOf(jsonObject.get("orgId"));
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
//			String userName = String.valueOf(jsonObject.get("loginNameOrUserName"));
//			String state = String.valueOf(jsonObject.get("state"));
			
			StringUtil.validateIsNull(orgId, "请输入机构ID");
			StringUtil.validateIsNull(pageNum, "请输入页码");
			StringUtil.validateIsNull(pageSize, "请输入每页记录数");
//			StringUtil.validateIsNull(state, "请输入员工状态");
			
            Map<Object, Object> paramMap = new HashMap<Object, Object>();
            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
            paramMap.put("pageSize", Integer.parseInt(pageSize));
            if(orgId!=null && !orgId.equals("") && !orgId.equals("null")){
            	paramMap.put("orgId", orgId);
            }
            paramMap.put("userName", "");
//            paramMap.put("state", state);
            
            UserEntity user = (UserEntity) SecurityUtils.getSubject().getPrincipal();
            //顶级节点，只有超级管理员，与区域管理员，可以进行查询到数据
            if(orgId.equals("1")){
            	if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue()) || user.getUserType().equals(UserTypeEnum.TYPE_2.getValue())){
    			}else{
    				return Result.error("没有符合条件的数据");
    			}
            }
			
			
			List<LinkedHashMap<Object, Object>> list = userService.findUserListByOrgIdAndChildren(paramMap);
			if(list!=null && list.size()>0){
				Long total = userService.findUserListByOrgIdAndChildrenCount(paramMap);
				
				//将用户的角色ID给赋值，其实不应该在后端 这里写这个逻辑，增加了一些性能的开销，应该由前端调编辑用户接口再来加载用户的角色
				for(LinkedHashMap<Object, Object> map : list){
					String userId = map.get("id").toString();
//					String userType = map.get("user_type").toString();
					UserRoleEntity userRoleEntity = userRoleService.getRoleByUserId(userId);
					if(userRoleEntity!=null){
						map.put("role_id", userRoleEntity.getRoleId());
						map.put("role_name", roleService.getById(userRoleEntity.getRoleId()).getName());
					}
					//将用户的分校集合返回给前台
					String orgIds = userOrgAreaService.getUserOrgAreaIdsByUserId(userId);
					if(orgIds!=null && !orgIds.equals("")){
						map.put("orgIds", orgIds.split(","));
					}else{
						map.put("orgIds", "[]");
					}
				}
				
				IPage page  = new Page();
				page.setTotal(total.longValue());
				page.setSize(Long.parseLong(pageSize));
				page.setRecords(list);
				return Result.success(page);
			}
			return Result.error("没有符合条件的数据");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("查询失败，请稍后再试！");
		}
	}
	
	
	/** 
	 * 查询机构下面的员工（带分页）
	 **/
	@ApiOperation(value = "查询禁用的员工，已离职的员工（带分页）")
	@ApiJsonObject(name = "findUserListByUserState", value = { 
			@ApiJsonProperty(name = UserJson.state),
			@ApiJsonProperty(name = UserJson.loginNameOrUserName),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "findUserListByUserState")
	@PostMapping("/findUserListByUserState")
	public Result findUserListByUserState(@RequestBody String params)  {
		try {
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
			String userName = String.valueOf(jsonObject.get("loginNameOrUserName"));
			String state = String.valueOf(jsonObject.get("state"));
			
			StringUtil.validateIsNull(pageNum, "请输入页码");
			StringUtil.validateIsNull(pageSize, "请输入每页记录数");
			StringUtil.validateIsNull(state, "请输入员工状态");
			
            
            Map<Object, Object> paramMap = new HashMap<Object, Object>();
            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
            paramMap.put("pageSize", Integer.parseInt(pageSize));
//            paramMap.put("userName", userName);
            paramMap.put("state", state);
            
            UserEntity user = (UserEntity) SecurityUtils.getSubject().getPrincipal();
			if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue())){
				paramMap.put("userType", UserTypeEnum.TYPE_1.getValue());
			}else if(user.getUserType().equals(UserTypeEnum.TYPE_2.getValue())){
				paramMap.put("userType", UserTypeEnum.TYPE_2.getValue());
				
				List<OrgEntity> orgList = orgService.getBranchOrgByUser(user);
				if(orgList!=null && orgList.size()>0){
            		String orgId = "";
    				for(OrgEntity entity : orgList){
    					orgId = orgId + "'" + entity.getId() + "'" + ",";
    				}
    				paramMap.put("branchOrgId", orgId.substring(0, orgId.length()-1));
            	}
			}else if(user.getUserType().equals(UserTypeEnum.TYPE_3.getValue()) || user.getUserType().equals(UserTypeEnum.TYPE_4.getValue())){
				OrgEntity orgEntity = orgService.getUserBranchOrgByUser(user);
				paramMap.put("userType", UserTypeEnum.TYPE_3.getValue());
				paramMap.put("orgId", orgEntity.getId());
			}else{
				throw new BusinessException("您所在的用户组当前无权限操作，请联系系统管理员");
			}
			
//			paramMap.put("branchOrgId", '2');
			List<LinkedHashMap<Object, Object>> list = userService.findUserListByUserState(paramMap);
			if(list!=null && list.size()>0){
				Long total = userService.findUserListByUserStateCount(paramMap);
				
				//将用户的角色ID给赋值，其实不应该在后端 这里写这个逻辑，增加了一些性能的开销，应该由前端调编辑用户接口再来加载用户的角色
				for(LinkedHashMap<Object, Object> map : list){
					String userId = map.get("id").toString();
//					String userType = map.get("user_type").toString();
					UserRoleEntity userRoleEntity = userRoleService.getRoleByUserId(userId);
					if(userRoleEntity!=null){
						map.put("role_id", userRoleEntity.getRoleId());
						map.put("role_name", roleService.getById(userRoleEntity.getRoleId()).getName());
					}
//					//将用户的分校集合返回给前台
//					String orgIds = userOrgAreaService.getUserOrgAreaIdsByUserId(userId);
//					if(orgIds!=null && !orgIds.equals("")){
//						map.put("orgIds", orgIds.split(","));
//					}else{
//						map.put("orgIds", "[]");
//					}
				}
				
				IPage page  = new Page();
				page.setTotal(total.longValue());
				page.setSize(Long.parseLong(pageSize));
				page.setRecords(list);
				return Result.success(page);
			}
			return Result.error("没有符合条件的数据");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("查询失败，请稍后再试！");
		}
	}
	
	
	
	
//	@ApiOperation(value = "用户查询接口,包含已禁用，已离职员工查询(带分页)")
//	@ApiJsonObject(name = "findUserByLoginNameOrName", value = { 
//			@ApiJsonProperty(name = GlobalString.pageNum),
//			@ApiJsonProperty(name = GlobalString.pageSize),
//			@ApiJsonProperty(name = UserJson.state),
//			@ApiJsonProperty(name = UserJson.loginNameOrUserName)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "findUserByLoginNameOrName")
//	@PostMapping("/findUserByLoginNameOrName")
//	public Result findUserByLoginNameOrName(@RequestBody String params){
//		try{
//			System.out.println("params参数为：" + params);
//			
//			JSONObject jsonObject = JSON.parseObject(params);
//			String pageNum = String.valueOf(jsonObject.get("pageNum"));
//			String pageSize = String.valueOf(jsonObject.get("pageSize"));
//			String state = String.valueOf(jsonObject.get("state"));
//			String loginNameOrUserName = String.valueOf(jsonObject.get("loginNameOrUserName"));
//			
////			StringUtil.validateIsNull(loginNameOrUserName, "请输入查询条件");
//			StringUtil.validateIsNull(pageNum, "请输入页码");
//			StringUtil.validateIsNull(pageSize, "请输入每页记录数");
//			
//			IPage<UserEntity> page = userService.findUserListByLoginNameOrUserName(Integer.parseInt(pageNum), Integer.parseInt(pageSize), loginNameOrUserName, state);
//			
//			return Result.success(page);
//		} catch (BusinessException e) {
//			e.printStackTrace();
//			return Result.error(e.getMessage());
//		}catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("获取当前用户菜单失败，失败原因：" + e.getMessage());
//		}
//	}
	
//	@ApiOperation(value = "获取当前用户菜单，查找parentId下一层级的子菜单（不包括子菜单下的子菜单）")
//	@ApiJsonObject(name = "getUserMenuByParentId", value = { 
//			@ApiJsonProperty(name = MenuJson.parentId)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "getUserMenuByParentId")
//	@PostMapping("/getUserMenuByParentId")
//	public Result getUserMenuByParentId(@RequestBody String params){
//		try{
//			System.out.println("params参数为：" + params);
//			
//			JSONObject jsonObject = JSON.parseObject(params);
//			String parentId = jsonObject.get("parentId").toString();
//			
//			StringUtil.validateIsNull(parentId, "请输入菜单parentId");
//			
//			
//			Subject subject = SecurityUtils.getSubject();
//			UserEntity user = (UserEntity) subject.getPrincipal();
//			
//			return null;
////            return Result.success(menuNodeList);
//		} catch (BusinessException e) {
//			e.printStackTrace();
//			return Result.error(e.getMessage());
//		}catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("获取当前用户菜单失败，失败原因：" + e.getMessage());
//		}
//	}
	
	
	//3. 获取用户角色接口
	@ApiOperation(value = "获取当前用户的角色集合")
	@PostMapping("/getUserRoleList")
	public Result getUserRoleList(){
		try{
			Subject subject = SecurityUtils.getSubject();
			UserEntity user = (UserEntity) subject.getPrincipal();
			
			//查询用户对应的角色
			List<RoleEntity> roleIds = roleService.getUserRoleList(user.getId(), null, null);
			
            return Result.success(roleIds);
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取当前的角色集合失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
	
	
	@ApiOperation(value = "新增用户接口")
	@ApiJsonObject(name = "saveUser", value = { 
			@ApiJsonProperty(name = UserJson.userName),
			@ApiJsonProperty(name = UserJson.sex),
			@ApiJsonProperty(name = UserJson.mobile),
			@ApiJsonProperty(name = UserJson.password),
			@ApiJsonProperty(name = UserJson.orgId),
			@ApiJsonProperty(name = UserJson.userType),
			@ApiJsonProperty(name = UserJson.orgName),
			@ApiJsonProperty(name = RoleJson.roleId),
			@ApiJsonProperty(name = UserJson.email),
			@ApiJsonProperty(name = UserJson.orgIds)})
	@ApiImplicitParam(name = "params", required = true, dataType = "saveUser")
	@PostMapping("/saveUser")
	public Result saveUser(@RequestBody String params){
		try{
			System.out.println("params参数为：" + params);
			
			boolean flag = userService.saveUser(params);
			if(flag){
				return Result.success("新增用户成功！");
			}
			return Result.error("新增用户失败，请联系管理员！");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("新增用户失败，失败原因：" + e.getMessage());
		}
	}
	
	/** 
	 * 编辑用户前，调校验接口
	 **/
	@ApiOperation(value = "点击新增员工按钮，调校验接口，校验当前登录的用户是否有权限创建相应分校的员工")
	@ApiJsonObject(name = "addUserValidate", value = {
			@ApiJsonProperty(name = OrgJson.orgId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "addUserValidate")
	@RequestMapping(value = "/addUserValidate", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Result addUserValidate(@RequestBody String params)  {
		try {
			Object object = SecurityUtils.getSubject().getPrincipal();
			UserEntity user = this.userService.getById(((UserEntity) object).getId()); 
			
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String orgId = String.valueOf(jsonObject.get("orgId"));
			
			StringUtil.validateIsNull(orgId, "请选择机构");
			
			boolean flag = false;
			List<OrgEntity> set = orgService.getBranchOrgByUserId(user.getId());
			for(OrgEntity entity : set){
				if(entity.getId().equals(orgId)){
					flag = true;
					continue;
				}
			}
			if(flag){
				return Result.success("可以新增员工");
			}else{
				return Result.success("您当前无权限在此分校下新建员工");
			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("操作失败，请稍后再试！");
		}
	}
	
	/** 
	 * 编辑用户前，调校验接口
	 **/
	@ApiOperation(value = "编辑用户前，调校验接口，校验是否有权限编辑此用户")
	@ApiJsonObject(name = "editUserValidate", value = {
			@ApiJsonProperty(name = UserJson.userId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "editUserValidate")
	@RequestMapping(value = "/editUserValidate", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Result editUserValidate(@RequestBody String params)  {
		try {
			Object object = SecurityUtils.getSubject().getPrincipal();
			UserEntity user = this.userService.getById(((UserEntity) object).getId()); 
			
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String userId = String.valueOf(jsonObject.get("userId"));
			
			StringUtil.validateIsNull(userId, "请勾选员工");
			
			UserEntity bean = this.userService.getById(userId);
			if(bean.getUserType().equals(UserTypeEnum.TYPE_1.getValue())){
				return Result.error("超级管理员账号不允许编辑");
			}
			
			if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue())){
				return Result.success("");
			}
			
			if(user.getId().equals(bean.getId())){
				return Result.error("您不能修改自己的后台资料，基础资料请到首页进行修改");
			}
			
			if(Integer.parseInt(user.getUserType())<=Integer.parseInt(bean.getUserType())){
				return Result.success("");
			}else{
				return Result.error("您无权限编辑此用户");
			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("操作失败，请稍后再试！");
		}
	}
	
	
	
	/** 
	 * 编辑用户前，调校验接口
	 **/
	@ApiOperation(value = "批量移动用户前，调校验接口，校验是否选中的员工符合要求，防止超级管理员，编辑超级管理员，防止普通管理员，编辑普通管理员，防止将不同分校的人，转到一个分校去")
	@ApiJsonObject(name = "removeUserValidate", value = {
			@ApiJsonProperty(name = UserJson.userIds)})
	@ApiImplicitParam(name = "params", required = true, dataType = "removeUserValidate")
	@RequestMapping(value = "/removeUserValidate", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Result removeUserValidate(@RequestBody String params)  {
		try {
			Object object = SecurityUtils.getSubject().getPrincipal();
			UserEntity user = this.userService.getById(((UserEntity) object).getId()); 
			
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String userIds = String.valueOf(jsonObject.get("userIds"));
			
			StringUtil.validateIsNull(userIds, "请勾选员工");
			
			List<String> userIdList = JsonUtil.getJsonToList(userIds, String.class);
			if(userIdList!=null && userIdList.size()>0){
				List<UserEntity> list = userService.list(new QueryWrapper<UserEntity>().in("id", userIdList));
				for(UserEntity entity : list){
					//如果移动的用户中包含超级管理员，不允许移动
					if(entity.getUserType().equals(UserTypeEnum.TYPE_1.getValue())){
						throw new BusinessException("您编辑的用户中包含超级管理员，请重新勾选");
					}
					//如果当前登录的用户为超级管理员，也不允许移动别的超级管理员
					if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue()) && user.getUserType().equals(entity.getUserType())){
						throw new BusinessException("您编辑的用户中包含超级管理员，请重新勾选");
					}
					//如果当前使用的用户为普通管理员，不允许移动别的普通管理员
					if(user.getUserType().equals(UserTypeEnum.TYPE_2.getValue()) && user.getUserType().equals(entity.getUserType())){
						throw new BusinessException("您编辑的用户中包含普通管理员，请重新勾选");
					}
				}
				return Result.success("");
			}else{
				return Result.error("请勾选需要操作的员工");
			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("操作失败，请稍后再试！");
		}
	}
	
	
	
	/** 
	 * 批量更新员工状态接口
	 **/
	@ApiOperation(value = "批量更新员工状态接口（支持批量禁用员工，启用员工，离职员工）", notes = "员工ID以字符串（1,2,3）传到服务端")
	@ApiJsonObject(name = "batchOperationUserState", value = {
			@ApiJsonProperty(name = UserJson.userIds),
			@ApiJsonProperty(name = UserJson.state)})
	@ApiImplicitParam(name = "params", required = true, dataType = "batchOperationUserState")
	@RequestMapping(value = "/batchOperationUserState", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Result batchOperationUserState(@RequestBody String params)  {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String userIds = String.valueOf(jsonObject.get("userIds"));
			String state = String.valueOf(jsonObject.get("state"));
			
			StringUtil.validateIsNull(userIds, "请勾选员工");
			StringUtil.validateIsNull(state, "请选择状态");
			
			List<String> userIdList = JsonUtil.getJsonToList(userIds, String.class);
			if(userIdList!=null && userIdList.size()>0){
				boolean flag = userService.updateUserStateBatch(userIdList, state);
				if(flag){
					return Result.success("操作成功");
				}
			}else{
				return Result.error("请勾选需要操作的员工");
			}
			
			return Result.error("操作失败，请联系管理员");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("操作失败，请稍后再试！");
		}
	}

	/**
	 * 编辑员工复杂资料接口
	 **/
	@ApiOperation(value = "编辑员工资料接口接口")
	@ApiJsonObject(name = "updateUserInfo", value = {
			@ApiJsonProperty(name = UserJson.userId),
			@ApiJsonProperty(name = UserJson.userName),
			@ApiJsonProperty(name = UserJson.sex),
			@ApiJsonProperty(name = UserJson.mobile),
			@ApiJsonProperty(name = UserJson.password),
			@ApiJsonProperty(name = UserJson.orgId),
			@ApiJsonProperty(name = UserJson.orgName),
			@ApiJsonProperty(name = UserJson.userType),
			@ApiJsonProperty(name = UserJson.roleId),
			@ApiJsonProperty(name = UserJson.email),
			@ApiJsonProperty(name = UserJson.orgIds)})
	@ApiImplicitParam(name = "params", required = true, dataType = "updateUserInfo")
	@RequestMapping(value = "/updateUserInfo", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Result updateUserInfo(@RequestBody String params)  {
		try {
			System.out.println("params参数为：" + params);
			
			boolean flag = userService.updateUserInfo(params);
			if(flag){
				return Result.success("编辑员工资料成功");
			}
			return Result.error("编辑员工资料出错，请联系系统管理员");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("操作失败，请稍后再试！");
		}
	}

	

	/**
	 * 批量编辑员工所属组织接口
	 **/
	@ApiOperation(value = "批量编辑员工所属组织接口")
	@ApiJsonObject(name = "updateUserOrgBatch", value = {
			@ApiJsonProperty(name = UserJson.userIds),
			@ApiJsonProperty(name = UserJson.orgId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "updateUserOrgBatch")
	@RequestMapping(value = "/updateUserOrgBatch", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public Result updateUserOrgBatch(@RequestBody String params)  {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String userIds = String.valueOf(jsonObject.get("userIds"));
			String orgId = String.valueOf(jsonObject.get("orgId"));

			StringUtil.validateIsNull(userIds, "请勾选员工");
			StringUtil.validateIsNull(orgId, "请选择部门");
			
			List<String> userIdList = JsonUtil.getJsonToList(userIds, String.class);
			if(userIdList!=null && userIdList.size()>0){
				boolean flag = userService.updateUserOrgBatch(userIdList, orgId);
				if(flag){
					return Result.success("操作成功");
				}
			}else{
				return Result.error("请勾选需要操作的员工");
			}
			
			return Result.error("操作成功失败，请联系管理员");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("操作失败，请稍后再试！");
		}
	}
	
//	@ApiOperation(value = "获取用户能访问的机构id集合")
////	@RequiresPermissions("user:feat:auth")
////	@RequiresPermissions(value = {"user:feat:auth","sys:user:auth"})
//	@PostMapping("/getUserOrgIds")
//	public Result getUserOrgIds(){
//		try{
//			Subject subject = SecurityUtils.getSubject();
//			LoginUserInfo info = (LoginUserInfo) subject.getPrincipal();
//			
////			subject.hasRole("开发管理员");
////			subject.checkRole("开发管理员");
//			
////			subject.hasRole("项目管理员");
////			subject.checkRole("项目管理员");
//			
////			subject.checkPermission("sys:dict:edit");
////			System.out.println("是否有权限：" + subject.isPermitted("sys:dict:edit"));;
//			
//			
////			subject.checkPermission("sys:dict:edit2");
////			System.out.println("是否有权限：" + subject.isPermitted("sys:dict:edit2"));;
//			
//			UserEntity user = userService.getById(info.getUser().getId()); 
//			List<Integer> orgIds = orgService.getUserAccessibleOrgIds(user.getDataScope(), user.getOrgId());
//            return Result.success(orgIds);
//		}catch (UnauthorizedException e){
//			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
//		}catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("获取用户能访问的机构id集合失败，失败原因：" + e.getMessage());
//		}
//	}
	
	
}
