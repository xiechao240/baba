package cn.daliedu.config.param;

import org.springframework.beans.factory.annotation.Value;
/**
 * @author xiechao
 * @time 2019年1月9日 上午10:33:55
 * @version 1.0.0 
 * @description 加载yml配置文件中的值
 */
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

/**
 * 系统参数常量获取类
 * @author xiechao
 * @time 2019年1月9日 上午10:58:42
 * @version 1.0.0
 * @description spring-boot启动时会加载application.yml文件中内容，这个类指定加载开发人员需要用到的常量，
 *              由于spring @value注解不支持往静态变量上赋值，所以需要在属性的set方法上把这个注解加上，才能正确赋值
 *              【注意：】此类，成员变量可以为静态static的，但get,set方法前面不能有static关键字，spring不支持这样的特性,其实get方法不用写也可以，目前所有get方法已经去掉了
 *              这种方式还是不可取，添加一个参数太麻烦了，还是使用get  set的方式方便些
 */
// @Component
@Configuration
// @ConfigurationProperties(locations = {"classpath:config/myProps.yml"},prefix="myProps") //加载除application.yml之外，指定的yml文件
// @ConfigurationProperties(prefix = "properties")
//指定加载配置在application.yml中properties这一段配置
public class SysParamConfig {
	/**
	 * 配置为1时，使用分机器集群，此时不会读取job_excuse_address_port属性，配置为0时，使用同一台机器集群，此时读取job_excuse_address_port属性进行区分
	 */
	public static String JOB_EXCUSE_TYPE;
	
	/**
	 * 同一台机器集群，只有此属性值不同即可
	 */
	public static String JOB_EXCUSE_ADDRESS_PORT;
	/**
	 * 配置部署的可以执行定时任务的机器
	 */
	public static String JOB_EXCUSE_ADDRESS;
	
	/**
	 * 文件上传模式
	 */
	public static String UPLOAD_TYPE;
	
	/**
	 * 系统上传文件路径配置
	 */
	public static String UPLOAD_FILE_PATH;
	
	/**
	 * 上传文件的域名路径
	 */
	public static String UPLOAD_FILE_DOMAIN_NAME_PATH;
	
	/**
	 * 录音文件上传地址
	 */
	public static String UPLOAD_FILE_PATH_CALL;
	
	/**
	 * 国际化语言环境，中文
	 */
	public static String LANGUAGE_ZH_CN;
	
	public static String UPLOAD_FILE_URL;
	
	
	
	

	@Value("${sysparam.upload_file_url}")
	public  void setUPLOAD_FILE_URL(String uPLOAD_FILE_URL) {
		UPLOAD_FILE_URL = uPLOAD_FILE_URL;
	}



	@Value("${sysparam.upload_file_path_call}")
	public  void setUPLOAD_FILE_PATH_CALL(String uPLOAD_FILE_PATH_CALL) {
		UPLOAD_FILE_PATH_CALL = uPLOAD_FILE_PATH_CALL;
	}

	
	
	@Value("${sysparam.job_excuse_address}")
	public  void setJOB_EXCUSE_ADDRESS(String jOB_EXCUSE_ADDRESS) {
		JOB_EXCUSE_ADDRESS = jOB_EXCUSE_ADDRESS;
	}


	@Value("${sysparam.language}")
	public void setLANGUAGE_ZH_CN(String lANGUAGE_ZH_CN) {
		LANGUAGE_ZH_CN = lANGUAGE_ZH_CN;
	}


	@Value("${sysparam.upload_file_path}")
	public  void setUPLOAD_FILE_PATH(String uPLOAD_FILE_PATH) {
		UPLOAD_FILE_PATH = uPLOAD_FILE_PATH;
	}


	@Value("${sysparam.upload_file_domain_name_path}")
	public  void setUPLOAD_FILE_DOMAIN_NAME_PATH(String uPLOAD_FILE_DOMAIN_NAME_PATH) {
		UPLOAD_FILE_DOMAIN_NAME_PATH = uPLOAD_FILE_DOMAIN_NAME_PATH;
	}


	@Value("${sysparam.upload_type}")
	public void setUPLOAD_TYPE(String uPLOAD_TYPE) {
		UPLOAD_TYPE = uPLOAD_TYPE;
	}

	@Value("${sysparam.job_excuse_type}")
	public  void setJOB_EXCUSE_TYPE(String jOB_EXCUSE_TYPE) {
		JOB_EXCUSE_TYPE = jOB_EXCUSE_TYPE;
	}

	@Value("${sysparam.job_excuse_address_port}")
	public  void setJOB_EXCUSE_ADDRESS_PORT(String jOB_EXCUSE_ADDRESS_PORT) {
		JOB_EXCUSE_ADDRESS_PORT = jOB_EXCUSE_ADDRESS_PORT;
	}
	
	/**
	 * 判断是否运行job
	 * @return
	 */
	public static boolean jobIsRun(){
		String port = SysParamConfig.JOB_EXCUSE_ADDRESS_PORT;
		if(port.equals("8090")){
			return true;
		}
		return false;
	}
	
	

}