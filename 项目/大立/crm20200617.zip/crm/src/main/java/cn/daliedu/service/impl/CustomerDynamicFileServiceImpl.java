package cn.daliedu.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.entity.CustomerDynamicFileEntity;
import cn.daliedu.mapper.CustomerDynamicFileMapper;
import cn.daliedu.service.CustomerDynamicFileService;

/**
 * <p>
 * 客户动态上传的文件或图片 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-29
 */
@Service
public class CustomerDynamicFileServiceImpl extends ServiceImpl<CustomerDynamicFileMapper, CustomerDynamicFileEntity> implements CustomerDynamicFileService {
	
	@Resource
	CustomerDynamicFileMapper customerDynamicFileMapper;
	
	@Override
	public List<CustomerDynamicFileEntity> getCustomerDynamicFileById(String customerDynamicId) {
		return customerDynamicFileMapper.selectList(new QueryWrapper<CustomerDynamicFileEntity>().eq("customer_dynamic_id", customerDynamicId));
	}
	
	
}
