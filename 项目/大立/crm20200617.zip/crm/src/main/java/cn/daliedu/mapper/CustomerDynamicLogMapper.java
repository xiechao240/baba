package cn.daliedu.mapper;

import cn.daliedu.entity.CustomerDynamicLogEntity;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 客户动态记录表，如新建客户，客户资料变更等操作记录 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-10-19
 */
public interface CustomerDynamicLogMapper extends BaseMapper<CustomerDynamicLogEntity> {
	/**
	 * 获取客户动态列表
	 * @param map
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerDynamicList(Map<Object, Object> map);
	
	/**
	 * 获取客户动态列表总数
	 * @param map
	 * @return
	 */
	public Long getCustomerDynamicListCount(Map<Object, Object> map);
}
