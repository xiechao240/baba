package cn.daliedu.service;

import cn.daliedu.entity.UserCustomerCallEntity;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户客户通话表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-11-23
 */
public interface UserCustomerCallService extends IService<UserCustomerCallEntity> {
	/**
	 * 保存客户通话录音文件，app端单独上传录音文件使用，其实是更新用户客户通话数据中的录音文件属性
	 * @param userCustomerCallId
	 * @param file
	 * @throws Exception
	 */
	public void saveCallRecordingFile(String userCustomerCallId, MultipartFile file) throws Exception;
	
	/**
	 * 【员工联系记录】获取员工联系记录列表
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getCallContactRecordList(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【员工联系记录】获取员工联系记录列表总数
	 * @param map 查询组合参数集合
	 */
	public Long getCallContactRecordListCount(Map<Object, Object> map);
	
	/**
	 * 保存通话记录
	 * @param params 前端传递的json
	 * @return
	 * @throws Exception
	 */
	public String saveCallRecord(String params) throws Exception;
	
	/**
	 * 保存通话记录（同时保存通话录音）
	 * @param customerId 客户ID
	 * @param userId 用户ID
	 * @param callNumber 呼出号码
	 * @param callState 应答状态
	 * @param startTime 开始时间
	 * @param endTime 结束时间
	 * @param answerTime 接听时间
	 * @param file	录音文件
	 * @return
	 * @throws Exception
	 */
	public boolean saveCallRecordAndRecording(String userId, String customerId,
			String callType, String callNumber, String callState, 
			String startTime,  String endTime, String answerTime, 
			MultipartFile file) throws Exception;
}
