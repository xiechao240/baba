package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.time.LocalDateTime;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 公告表
 * </p>
 *
 * @author xiechao
 * @since 2019-10-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_notice")
public class NoticeEntity extends Model<NoticeEntity> {

    private static final long serialVersionUID = 1L;
    

    /**
     * 公告ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;

    /**
     * 公告标题
     */
    private String title;

    /**
     * 发布人
     */
    private String releaseUserId;

    /**
     * 创建时间，修改公告相当于重新创建公告，所以时间存创建时间即可
     */
    private LocalDateTime createDate;
    
    /**
     * 更新时间
     */
    private LocalDateTime updateDate;

    /**
     * 浏览人数
     */
    private Integer browseCount;

    /**
     * 公告内容
     */
    private String content;

    /**
     * 是否置顶，1：置顶，0：不置顶
     */
    private String isStop;

//    /**
//     * 删除标记，1：已删除，0：未删除
//     */
//    @TableLogic
//    @TableField(fill = FieldFill.INSERT_UPDATE)
//    private String deleted;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
