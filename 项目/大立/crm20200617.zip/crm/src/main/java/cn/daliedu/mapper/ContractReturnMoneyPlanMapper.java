package cn.daliedu.mapper;

import cn.daliedu.entity.ContractReturnMoneyPlanEntity;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 合同回款计划表 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-10-31
 */
public interface ContractReturnMoneyPlanMapper extends BaseMapper<ContractReturnMoneyPlanEntity> {
	
	/**
	 * 定时任务调度，更新回款计划状态为逾期未完成
	 * @return
	 */
	public Integer updateReturnMoneyStateByScheduleTask();
	
	/**
	 * 获取合同回款计划，回款记录列表
	 * @param map
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getContractReturnMoneyPlanList(Map<Object, Object> map);
	
	/**
	 * 获取合同回款计划，回款记录列表总数
	 * @param map
	 * @return
	 */
	public Long getContractReturnMoneyPlanListCount(Map<Object, Object> map);
	
	/**
	 * 获取客户合同回款计划，回款记录列表
	 * @param map
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getContractReturnMoneyPlanByCustomerIdList(Map<Object, Object> map);
	
	/**
	 * 获取客户合同回款计划，回款记录列表总数
	 * @param map
	 * @return
	 */
	public Long getContractReturnMoneyPlanByCustomerIdListCount(Map<Object, Object> map);
	
	/**
	 * 获取合同的计划期次列表
	 * @param map
	 */
	public List<LinkedHashMap<Object, Object>> getReturnMoneyNumList(Map<Object, Object> map);
	
	/**
	 * 获取当前合同回款期次的最大值，能前端点击 （期次+）号使用
	 * @param contractId
	 * @return
	 */
	public Integer getReturnMoneyNumMax(String contractId);
}
