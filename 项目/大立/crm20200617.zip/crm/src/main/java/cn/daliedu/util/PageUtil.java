package cn.daliedu.util;

/**
 * 分页相关的工具类
 * @author xiechao
 * @time 2020年3月3日 下午5:03:03
 * @version 1.0.0 
 * @description 
 */
public class PageUtil {
	
	/**
	 * 根据传入的页码，每页显示数据的大小，计算查询数据的startRow开始坐标
	 * @param pageNum 指定的页面序号
	 * @param pageSize 每页显示的数据大小
	 * @return
	 * @throws Exception
	 */
	public static Integer getStartRow(String pageNum, String pageSize) throws Exception{
		int startRow = 0;
		Integer pageNum1 = Integer.parseInt(pageNum);
		Integer pageSize1 = Integer.parseInt(pageSize);
		if(pageNum1!=null && pageNum1>0){
			startRow = (pageNum1-1)*pageSize1;
		}
		return startRow;
	}
}
