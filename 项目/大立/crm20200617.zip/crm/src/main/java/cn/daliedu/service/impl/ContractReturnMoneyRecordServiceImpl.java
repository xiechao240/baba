package cn.daliedu.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.entity.ContractReturnMoneyRecordEntity;
import cn.daliedu.mapper.ContractReturnMoneyRecordMapper;
import cn.daliedu.service.ContractReturnMoneyRecordService;

/**
 * <p>
 * 合同回款记录表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-31
 */
@Service
public class ContractReturnMoneyRecordServiceImpl extends ServiceImpl<ContractReturnMoneyRecordMapper, ContractReturnMoneyRecordEntity> implements ContractReturnMoneyRecordService {
	
	@Resource
	ContractReturnMoneyRecordMapper contractReturnMoneyRecordMapper;

	
	
	
	
}
