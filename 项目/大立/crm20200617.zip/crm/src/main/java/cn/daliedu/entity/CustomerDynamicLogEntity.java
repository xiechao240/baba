package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 客户动态记录表，如新建客户，客户资料变更等操作记录
 * </p>
 *
 * @author xiechao
 * @since 2019-11-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_customer_dynamic_log")
public class CustomerDynamicLogEntity extends Model<CustomerDynamicLogEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;

    /**
     * 客户ID
     */
    private String customerId;

    /**
     * 客户动态类别，见数据字典dynamic_type中定义
     */
    private String dynamicType;

    /**
     * 动态类别下的子类别（用来存储此类别下的子类别）
     */
    private String dynamicTypeSub;

    /**
     * 动态名称，如：新增客户资料，新增客户，添加销售计划，发送短信，添加跟进记录
     */
    private String dynamicName;

    /**
     * 动态的内容
     */
    private String dynamicContent;

    /**
     * 动态产生时间
     */
    private LocalDateTime createDate;

    /**
     * 动态产生人，此表不需要直接关联userId因为动态是属于客户的，不直接属于用户（跟进记录数，也可通过此字段进行统计）
     */
    private String dynamicUserId;

    /**
     * 变更前内容（不一定都有值）
     */
    private String oldValue;

    /**
     * 变更后内容（不一定都有值）
     */
    private String newValue;

    /**
     * 详情ID（用于点击客户动态中的新增回款计划或新增回款记录查看详情），此字段用来存储调用不同的接口时传参，比如传合同ID,回款计划ID，前端根据动态类别调用不同的接口
     */
    private String detailId;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
