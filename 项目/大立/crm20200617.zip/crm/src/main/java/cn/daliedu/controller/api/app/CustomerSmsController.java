package cn.daliedu.controller.api.app;


import org.apache.shiro.SecurityUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import org.springframework.web.bind.annotation.RestController;

import cn.daliedu.entity.UserEntity;
import cn.daliedu.util.Result;


/**
 * <p>
 * 客户发送短信表 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2020-06-16
 */
@Api("客户发送短信服务接口")
@RestController
@RequestMapping(value = "${rest.path}/app/customer") 
public class CustomerSmsController {
	
//	@ApiOperation(value = "【电话排名】电话联系统计表(带分页),目前只实现按分校进行排名，后续再实现按部门排名，有返回接通总次数，接通次数，原型上少了接通次数")
//	@PostMapping("/getCallRankingByContact")
//	public Result getCallRankingByContact(@ApiParam(value="用户客户通话唯一ID",required=true)@RequestParam(required=true) String customerIds ) {
//		try{
//			Object object = SecurityUtils.getSubject().getPrincipal();
//			if (object instanceof UserEntity) {
//				UserEntity bean = (UserEntity) object;
//	            
//				
//	            return Result.error("当前用户下没有电话联系统计");
//			}
//			return Result.error("无法获取电话联系统计列表");
//		}catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("无法获取电话联系统计列表，失败原因：" + e.getMessage());
//		}
//	}
}
