package cn.daliedu.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * 短信发送工具类（此类为安证通连接公司内部研发的短信平台工具类，目前我已经全新开发了一个SMSUtil类）
 * 
 * @author xiechao
 * @time 2019年2月14日 上午11:18:24
 * @version 1.0.0
 * @description
 */
public class SMSUtilBak {
	private static Logger logger = LoggerFactory.getLogger(SMSUtilBak.class);
	private static String sendurl = "http://www.ztsms.cn:8800/"; // 短信平台发送地址
	private static String smsusername = "zhouyi";// 短信平台用户名
	private static String smspassword = "BJaztesa2008";// 短信平台用户密码
	private static String productid = "676766";// 短信平台产品ID

	public static String sendSms(String mobile, String content) throws Exception {
		JSONObject json = new JSONObject();
		json.put("msg", content);
		json.put("toPhones", mobile);
		json.put("account", smsusername);
		json.put("password", smspassword);
		
		String xh = "";// 扩展号留空
		
		String sendUrl = sendurl + "sendXSms.do?username=" + smsusername + "&password=" + smspassword + "&mobile=" + mobile
				+ "&content=" + URLEncoder.encode(content, "UTF-8") + "&productid=" + productid + "&xh=" + xh;

		URL url = new URL(sendUrl);

		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setUseCaches(false);
		conn.setRequestProperty("Content-Type", "application/json");
		conn.setRequestMethod("POST");
		conn.setDoOutput(true);
		conn.connect();

		String data = new BASE64Encoder().encode(json.toString().getBytes(StandardCharsets.UTF_8));
		Log4jUtil.info(data);

		conn.getOutputStream().write(data.getBytes());
		conn.getOutputStream().flush();
		conn.getOutputStream().close();

		BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

		String line = "";
		StringBuilder sb = new StringBuilder();
		while ((line = br.readLine()) != null) {
			sb.append(line);
		}

		String result = new String(new BASE64Decoder().decodeBuffer(sb.toString()), StandardCharsets.UTF_8);

		br.close();
		return result;
	}

	// 添加个产品ID，区分验证码和通知
	public static String sendSms(String mobile, String content, int type) {

		String sendUrl = null;
		String xh = "";// 扩展号留空
		if (type == 1) {
			productid = "676767";
		}
		try {// 否则发到手机乱码
			sendUrl = sendurl + "sendXSms.do?username=" + smsusername + "&password=" + smspassword + "&mobile=" + mobile
					+ "&content=" + URLEncoder.encode(content, "UTF-8") + "&productid=" + productid + "&xh=" + xh;
		} catch (Exception uee) {
			logger.error(uee.toString());
		}

		logger.info("短信内容为------------->:" + mobile + content);
		String result = getUrl(sendUrl);
		logger.info(getRm(result));
		return result;
	}

	public static String getUrl(String urlString) {
		StringBuffer sb = new StringBuffer();
		try {
			URL url = new URL(urlString);
			URLConnection conn = url.openConnection();
			conn.setReadTimeout(15000);
			BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			for (String line = null; (line = reader.readLine()) != null;) {
				sb.append(line + "\n");
			}
			reader.close();
		} catch (Exception e) {
			logger.error(e.toString());
		}
		String result = "";
		try {
			result = URLDecoder.decode(sb.toString(), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		return result;
	}

	public static String getRm(String res) {
		String s = null;
		String[] str = res.split(",");
		if (str[0].equals("-1")) {
			s = "用户名或者密码不正确或用户禁用";
		} else if (str[0].equals("1")) {
			s = "发送成功，消息编号：" + str[1];
		} else if (str[0].equals("0")) {
			s = "发送失败，消息编号：" + str[1];
		} else if (str[0].equals("2")) {
			s = "余额不够或扣费错误";
		} else if (str[0].equals("3")) {
			s = "扣费失败异常（请联系客服）";
		} else if (str[0].equals("5")) {
			s = "短信定时成功，消息编号：" + str[1];
		} else if (str[0].equals("6")) {
			s = "有效号码为空";
		} else if (str[0].equals("7")) {
			s = "短信内容为空";
		} else if (str[0].equals("8")) {
			s = "无签名";
		} else if (str[0].equals("9")) {
			s = "没有Url提交权限";
		} else if (str[0].equals("10")) {
			s = "发送号码过多";
		} else if (str[0].equals("11")) {
			s = "产品ID异常或产品禁用";
		} else if (str[0].equals("12")) {
			s = "参数异常";
		} else if (str[0].equals("13")) {
			s = "30分种重复提交";
		} else if (str[0].equals("14")) {
			s = "用户名或密码不正确，产品余额为0，禁止提交，联系客服";
		} else if (str[0].equals("15")) {
			s = "Ip验证失败";
		} else if (str[0].equals("19")) {
			s = "短信内容过长，最多支持500个";
		} else if (str[0].equals("20")) {
			s = "定时时间不正确";
		}
		return s;
	}

	public static Integer getRn(String send, Integer smscount) {
		int sendnum = 0;
		if (send.length() % 70 != 0) {
			sendnum = (send.length() / 70 + 1) * smscount;
		} else {
			sendnum = send.length() / 70 * smscount;
		}
		return sendnum;
	}

	public static void main(String[] args) {
		String sms = SMSUtilBak.sendSms("18390986952", "【一签通云平台电子印章及数字证书平台】您的个人证书《》将于过期，请及时登录平台进行延期，以免影响您的正常使用。", 0);
		Log4jUtil.info("发送消息后返回内容：" + sms); // 发送消息后返回内容：
												// 1,201902141124005410
		Log4jUtil.info(SMSUtilBak.getRm(sms)); // 发送成功，消息编号： 201902141124005410
	}
}
