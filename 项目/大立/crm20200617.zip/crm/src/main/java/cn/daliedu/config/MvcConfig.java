//package cn.daliedu.config;
//
//import org.springframework.boot.web.servlet.FilterRegistrationBean;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.servlet.LocaleResolver;
//import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
//import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
//
//import cn.daliedu.config.filter.CorsFilter;
//import cn.daliedu.config.i18n.MyLocaleResolver;
//
///**
// * @author xiechao
// * @time 2020年1月16日 下午4:21:31
// * @version 1.0.0 
// * @description 
// */
///*springboot2.x以后，支持jdk1.8，运用了jdk1.8的一些特性。jdk1.8支持在接口中添加default方法，
//而此方法具有具体的方法实现。静态资源和拦截器的处理，不再继承“WebMvcConfigurerAdapter”方法。
//而是直接实现“WebMvcConfigurer”接口。通过重写接口中的default方法，来增加额外的配置。     
//
//所以已经不再需要在此类中写方法及实现了
//*/
//@Configuration
//public class MvcConfig extends WebMvcConfigurationSupport{
//	
//	
//}
