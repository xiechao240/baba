package cn.daliedu.mapper;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * 用户可查看的业务组公海与部门数据，用户可拥有多个分校的数据查看权限，其实就是存储用户从属于多个分校 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-09-23
 */
public interface ReportMapper{
	
	
	/**
	 * 【工作效率统计】跟进次数（根据用户ID获取用户一段时间范围内的跟进次数）
	 * @param map
	 * @return
	 */
	public BigDecimal getFollowRecoreCount(Map<Object, Object> map);
	
	/**
	 * 【工作效率统计】电话次数（根据用户ID获取用户一段时间范围内的有效电话次数）
	 * @param map
	 * @return
	 */
	public BigDecimal getCallCount(Map<Object, Object> map);
	
	/**
	 * 【工作效率统计】联系客户数
	 * @param map
	 * @return
	 */
	public BigDecimal getContactCustomerCount(Map<Object, Object> map);
	
	/**
	 * 按合同ID,统计合同的回款金额
	 */
	public HashMap<Object, Object> findContractReturnMoneyCount(String contractId);
	
	/**
	 * 统计用户所有部门合同数,合同总金额
	 * @param map
	 * @return
	 */
	public HashMap<Object, Object> findUserIdContractCount(Map<Object, Object> map);
	
	/**
	 * 统计用户所有部门已回款金额，未回款金额
	 * @param map
	 * @return
	 */
	public HashMap<Object, Object> findUserIdContractReturnMoneyCount(Map<Object, Object> map);
	
	
	/**
	 * 统计指定分校下所有部门合同数,合同总金额，查询逻辑为：1.先查询出分校下有所有用户 2.再查询用户的所有合同数
	 * @param map
	 * @return
	 */
	public HashMap<Object, Object> findOrgIdContractCount(Map<Object, Object> map);
	
	/**
	 * 统计指定分校下所有部门已回款金额，未回款金额，查询逻辑为：1.先查询出分校下有所有用户  2.再查询用户的所有合同数 3.再查询合同对应的所有回款计划
	 * @param map
	 * @return
	 */
	public HashMap<Object, Object> findOrgIdContractReturnMoneyCount(Map<Object, Object> map);
	
	/**
	 * 统计分校下所有合同数,合同总金额，查询逻辑为：1.先查询出分校下有所有用户 2.再查询用户的所有合同数
	 * @param map
	 * @return
	 */
	public HashMap<Object, Object> findbranchOrgIdContractCount(Map<Object, Object> map);
	
	/**
	 * 统计分校下所有已回款金额，未回款金额，查询逻辑为：1.先查询出分校下有所有用户  2.再查询用户的所有合同数 3.再查询合同对应的所有回款计划
	 * @param map
	 * @return
	 */
	public HashMap<Object, Object> findbranchOrgIdContractReturnMoneyCount(Map<Object, Object> map);
}
