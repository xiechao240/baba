package cn.daliedu.util;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringEscapeUtils;


import com.google.common.collect.Lists;

import cn.daliedu.exception.BusinessException;

/**
 * 字符串工具类
 *
 * @author ThinkGem
 * @version 2013-05-22
 */
public class StringUtil extends org.apache.commons.lang3.StringUtils {
	private static final char SEPARATOR = '_';

	private static final String CHARSET_NAME = "UTF-8";
	
	/**
	 * 获取指定字符串出现的次数
	 * 
	 * @param srcText 源字符串
	 * @param findText 要查找的字符串
	 * @return
	 */
	public static int countStr(String srcText, String findText) {
		int count = 0;
		int index = 0;
		while ((index = srcText.indexOf(findText, index)) != -1) {
			index = index + findText.length();
			count++;
		}
		return count;
		// 下面的写法，当需要统计 含$的字符串时，个数就不准
		// int count = 0;
		// Pattern p = Pattern.compile(findText);
		// Matcher m = p.matcher(srcText);
		// while (m.find()) {
		// count++;
		// }
		// return count;
	}
	
	/**
	 * 将String数组转为int数组
	 * @param arrs
	 * @return
	 */
	public static int[] stringToInt(String[] arrs){
		int[] ints = new int[arrs.length];
		for(int i=0;i<arrs.length;i++){
			ints[i]=Integer.parseInt(arrs[i]);
		}
		return ints;
	}
//		int[] ints = new int[arrs.length];
		
//		for(int i=0;i<arrs.length;i++){
//
//		ints[i]=Integer.parseInt(arrs[i]);}
//		    return ints;
//		}
	
	/**
	 * 将空对象转换为字符串 “”空值，避免空指针异常
	 * @param object
	 * @return
	 */
	public static String nullValueConvert(Object object){
		if(object==null){
			return "";
		}else{
			return object.toString();
		}
	}
	
	public static String nullValueConvert(String str){
		if(str==null){
			return "";
		}else if(str.equals("null")){
			return "";
		}else{
			return str;
		}
		
	}

	/**
	 * 转换为字节数组
	 */
	public static byte[] getBytes(String str) {
		if (str != null) {
			try {
				return str.getBytes(CHARSET_NAME);
			} catch (UnsupportedEncodingException e) {
				return null;
			}
		} else {
			return null;
		}
	}

	/**
	 * 转换为字节数组
	 */
	public static String toString(byte[] bytes) {
		try {
			return new String(bytes, CHARSET_NAME);
		} catch (UnsupportedEncodingException e) {
			return EMPTY;
		}
	}

	/**
	 * 替换掉 HTML 标签方法
	 */
	public static String replaceHtml(String html) {
		if (isBlank(html)) {
			return EMPTY;
		}

		String regEx = "<.+?>";
		Pattern p = Pattern.compile(regEx);
		Matcher m = p.matcher(html);

		return m.replaceAll(EMPTY);
	}

	/**
	 * 替换为手机识别的 HTML, 去掉样式及属性, 保留回车
	 */
	public static String replaceMobileHtml(String html) {
		if (html == null) {
			return EMPTY;
		}

		return html.replaceAll("<([a-z]+?)\\s+?.*?>", "<$1>");
	}

	// /**
	// * 替换为手机识别的 HTML, 去掉样式及属性, 保留回车
	// */
	// public static String toHtml(String txt)
	// {
	// if (txt == null)
	// {
	// return EMPTY;
	// }
	//
	// return replace(replace(EncodesUtil.escapeHtml(txt), "\n", "<br/>"), "\t",
	// "&nbsp; &nbsp; ");
	// }

	/**
	 * 缩略字符串(不区分中英文字符)
	 *
	 * @param str
	 *            目标字符串
	 * @param length
	 *            截取长度
	 */
	public static String abbr(String str, int length) {
		if (str == null) {
			return EMPTY;
		}

		try {
			StringBuilder sb = new StringBuilder();
			int currentLength = 0;
			for (char c : replaceHtml(StringEscapeUtils.unescapeHtml4(str)).toCharArray()) {
				currentLength += String.valueOf(c).getBytes(CHARSET_NAME).length;
				if (currentLength <= length - 3) {
					sb.append(c);
				} else {
					sb.append("...");
					break;
				}
			}
			return sb.toString();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		return EMPTY;
	}

	public static String abbr2(String param, int length) {
		if (param == null) {
			return EMPTY;
		}

		StringBuilder result = new StringBuilder();
		int n = 0;
		char temp;
		boolean isCode = false; // 是不是 HTML 代码
		boolean isHTML = false; // 是不是 HTML 特殊字符, 如&nbsp;
		for (int i = 0; i < param.length(); i++) {
			temp = param.charAt(i);
			if (temp == '<') {
				isCode = true;
			} else if (temp == '&') {
				isHTML = true;
			} else if (temp == '>' && isCode) {
				n = n - 1;
				isCode = false;
			} else if (temp == ';' && isHTML) {
				isHTML = false;
			}
			try {
				if (!isCode && !isHTML) {
					n += String.valueOf(temp).getBytes(CHARSET_NAME).length;
				}
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}

			if (n <= length - 3) {
				result.append(temp);
			} else {
				result.append("...");
				break;
			}
		}
		// 取出截取字符串中的 HTML 标记
		String temp_result = result.toString().replaceAll("(>)[^<>]*(<?)", "$1$2");

		// 去掉不需要结素标记的 HTML 标记
		temp_result = temp_result.replaceAll(
				"</?(AREA|BASE|BASEFONT|BODY|BR|COL|COLGROUP|DD|DT|FRAME|HEAD|HR|HTML|IMG|INPUT|ISINDEX|LI|LINK|META|OPTION|P|PARAM|TBODY|TD|TFOOT|TH|THEAD|TR|area|base|basefont|body|br|col|colgroup|dd|dt|frame|head|hr|html|img|input|isindex|li|link|meta|option|p|param|tbody|td|tfoot|th|thead|tr)[^<>]*/?>",
				EMPTY);

		// 去掉成对的 HTML 标记
		temp_result = temp_result.replaceAll("<([a-zA-Z]+)[^<>]*>(.*?)</\\1>", "$2");

		// 用正则表达式取出标记
		Pattern p = Pattern.compile("<([a-zA-Z]+)[^<>]*>");
		Matcher m = p.matcher(temp_result);
		List<String> endHTML = Lists.newArrayList();
		while (m.find()) {
			endHTML.add(m.group(1));
		}

		// 补全不成对的HTML标记
		for (int i = endHTML.size() - 1; i >= 0; i--) {
			result.append("</");
			result.append(endHTML.get(i));
			result.append(">");
		}

		return result.toString();
	}

	/**
	 * 转换为 Double 类型
	 */
	public static Double toDouble(Object val) {
		if (val == null) {
			return 0D;
		}

		try {
			return Double.valueOf(trim(val.toString()));
		} catch (Exception e) {
			return 0D;
		}
	}

	/**
	 * 转换为 Float 类型
	 */
	public static Float toFloat(Object val) {
		return toDouble(val).floatValue();
	}

	/**
	 * 转换为 Long 类型
	 */
	public static Long toLong(Object val) {
		return toDouble(val).longValue();
	}

	/**
	 * 转换为 Integer 类型
	 */
	public static Integer toInteger(Object val) {
		return toLong(val).intValue();
	}

	// /**
	// * 获得 i18n 字符串
	// */
	// public static String getMessage(String code, Object[] args)
	// {
	// LocaleResolver localLocaleResolver =
	// SpringContextHolder.getBean(LocaleResolver.class);
	// HttpServletRequest request =
	// ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
	// Locale localLocale = localLocaleResolver.resolveLocale(request);
	// return SpringContextHolder.getApplicationContext().getMessage(code, args,
	// localLocale);
	// }

	// /**
	// * 获得用户远程地址
	// */
	// public static String getRemoteAddr(HttpServletRequest request)
	// {
	// String remoteAddr = request.getHeader("X-Real-IP");
	// if (isNotBlank(remoteAddr))
	// {
	// remoteAddr = request.getHeader("X-Forwarded-For");
	// }
	// else if (isNotBlank(remoteAddr))
	// {
	// remoteAddr = request.getHeader("Proxy-Client-IP");
	// }
	// else if (isNotBlank(remoteAddr))
	// {
	// remoteAddr = request.getHeader("WL-Proxy-Client-IP");
	// }
	// return remoteAddr != null ? remoteAddr : request.getRemoteAddr();
	// }

	/**
	 * 驼峰命名法工具
	 *
	 * @return toCamelCase(" hello_world ") == "helloWorld"
	 *         toCapitalizeCamelCase("hello_world") == "HelloWorld"
	 *         toUnderScoreCase("helloWorld") = "hello_world"
	 */
	public static String toCamelCase(String s) {
		if (s == null) {
			return null;
		}

		s = s.toLowerCase();

		StringBuilder sb = new StringBuilder(s.length());
		boolean upperCase = false;
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);

			if (c == SEPARATOR) {
				upperCase = true;
			} else if (upperCase) {
				sb.append(Character.toUpperCase(c));
				upperCase = false;
			} else {
				sb.append(c);
			}
		}

		return sb.toString();
	}

	/**
	 * 驼峰命名法工具
	 *
	 * @return toCamelCase(" hello_world ") == "helloWorld"
	 *         toCapitalizeCamelCase("hello_world") == "HelloWorld"
	 *         toUnderScoreCase("helloWorld") = "hello_world"
	 */
	public static String toCapitalizeCamelCase(String s) {
		if (s == null) {
			return null;
		}
		s = toCamelCase(s);
		return s.substring(0, 1).toUpperCase() + s.substring(1);
	}

	/**
	 * 驼峰命名法工具
	 *
	 * @return toCamelCase(" hello_world ") == "helloWorld"
	 *         toCapitalizeCamelCase("hello_world") == "HelloWorld"
	 *         toUnderScoreCase("helloWorld") = "hello_world"
	 */
	public static String toUnderScoreCase(String s) {
		if (s == null) {
			return null;
		}

		StringBuilder sb = new StringBuilder();
		boolean upperCase = false;
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);

			boolean nextUpperCase = true;

			if (i < (s.length() - 1)) {
				nextUpperCase = Character.isUpperCase(s.charAt(i + 1));
			}

			if ((i > 0) && Character.isUpperCase(c)) {
				if (!upperCase || !nextUpperCase) {
					sb.append(SEPARATOR);
				}
				upperCase = true;
			} else {
				upperCase = false;
			}

			sb.append(Character.toLowerCase(c));
		}

		return sb.toString();
	}

	/**
	 * 转换为 JS 获取对象值, 生成三目运算返回结果
	 *
	 * @param objectString
	 *            对象串 例如：row.user.id
	 *            返回：!row?'':!row.user?'':!row.user.id?'':row.user.id
	 */
	public static String jsGetVal(String objectString) {
		StringBuilder result = new StringBuilder();
		StringBuilder val = new StringBuilder();
		String[] valls = split(objectString, ".");
		for (String val1 : valls) {
			val.append(".").append(val1);
			result.append("!").append(val.substring(1)).append("?'':");
		}
		result.append(val.substring(1));
		return result.toString();
	}

	/**
	 * 校验身份证合法性
	 * 
	 * @param objString
	 * @return
	 */
	public static void validateIdCard(String idNumber, String msg) throws BusinessException {
		idNumber = idNumber.trim();
		String regexString = "^[1-9]\\d{5}\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}$|^[1-9]\\d{5}(18|19|([23]\\d))\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$";
		Pattern pattern = Pattern.compile(regexString);
		boolean flag = pattern.matcher(idNumber).matches();
		if (!flag) {
			throw new BusinessException(msg);
		}
	}

	/**
	 * 校验是否为空
	 * 
	 * @param object
	 *            校验参数对象
	 * @param msg
	 *            如果为空或null字符串，返回的提示
	 * @throws BusinessException
	 */
	public static void validateIsNull(String object, String msg) throws BusinessException {
		if (object == null || object.trim().equals("") || object.equals("null")) {
			throw new BusinessException(msg);
		}
	}
	
	/**
	 * 校验是否为空
	 * 
	 * @param object
	 *            校验参数对象
	 * @param msg
	 *            如果为空，返回的提示
	 * @throws BusinessException
	 */
	public static void validateIsNull(Object object, String msg) throws BusinessException {
		if (object == null || object.toString().trim().equals("")) {
			throw new BusinessException(msg);
		}
	}

	/**
	 * 校验两个字符串是否相等
	 *
	 * @param str
	 * @param str2
	 *            校验参数对象
	 * @param msg
	 *            如果两个字符串不相等，返回的提示
	 * @throws BusinessException
	 */
	public static void validateString(String str, String str2, String msg) throws BusinessException {
		if (!str.equals(str2)) {
			throw new BusinessException(msg);
		}
	}
	


	/**
	 * 校验手机号码
	 * 
	 * @param mobile
	 * @param msg
	 * @throws BusinessException
	 */
	public static void validateMobile(String mobile, String msg) throws BusinessException {
		mobile = mobile.replaceAll(" ", "");
		// 手机号码正则验证
		String regexMobile = "^1([3-9][0-9])\\d{8}$";
		Pattern patternMobile = Pattern.compile(regexMobile);
		boolean flag = patternMobile.matcher(mobile).matches();
		if (!flag) {
			throw new BusinessException(msg);
		}
	}
	
	/**
	 * 校验手机号码
	 * 
	 * @param mobile
	 * @param msg
	 * @throws BusinessException
	 */
	public static boolean validateMobile(String mobile) throws BusinessException {
		mobile = mobile.replaceAll(" ", "");
		// 手机号码正则验证
		String regexMobile = "^1([3-9][0-9])\\d{8}$";
		Pattern patternMobile = Pattern.compile(regexMobile);
		boolean flag = patternMobile.matcher(mobile).matches();
		if (!flag) {
			return false;
		}
		return true;
	}

	/**
	 * 校验银行卡号
	 * 
	 * @param bankCode
	 * @param msg
	 * @throws BusinessException
	 */
	public static void validateBandCard(String bankCode, String msg) throws BusinessException {
		// 验证
		if (!bankCode.matches("^\\d{12,19}$")) {
			throw new BusinessException(msg);
		}
//		// 倒转
//		String reverseCode = new StringBuffer(bankCode).reverse().toString();
//		char[] array = reverseCode.toCharArray();
//		int sumOdd = 0;
//		int sumEven = 0;
//		for (int i = 0; i < reverseCode.length(); i++) {
//			int num = Integer.parseInt(String.valueOf(array[i]));
//			if (i % 2 == 0) { // 奇数位
//				sumEven += num;
//			} else { // 偶数位
//				num = num * 2;
//				if (num > 9) {
//					num = num - 9;
//				}
//				sumOdd += num;
//			}
//		}
//		if ((sumOdd + sumEven) % 10 != 0) {
//			throw new BusinessException(msg);
//		}

	}

	/**
	 * 邮箱校验
	 * 
	 * @param email
	 * @param msg
	 * @throws BusinessException
	 */
	public static void validateEmail(String email, String msg) throws BusinessException {
		email = email.trim();
		String regexEmail = "^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*\\.[a-zA-Z0-9]{2,6}$";
		Pattern patternEmail = Pattern.compile(regexEmail);
		boolean flag = patternEmail.matcher(email).matches();
		if (!flag) {
			throw new BusinessException(msg);
		}
	}

	/**
	 * 网站正则校验
	 * @param webSite
	 * @param msg
	 * @throws BusinessException
	 */
	public static void validateWebSite(String webSite, String msg) throws BusinessException {
        webSite = webSite.trim();
		Pattern patternWebSite = Pattern
				.compile("^([a-zA-Z0-9]([a-zA-Z0-9\\-]{0,61}[a-zA-Z0-9])?\\.)+[a-zA-Z]{2,6}$");

		boolean flagWebSite = patternWebSite.matcher(webSite).matches();
		if (!flagWebSite) {
			throw new BusinessException(msg);
		}
	}
	
	/**
	 * 密码校验
	 * @param passwoed
	 * @param msg
	 * @throws BusinessException
	 */
	public static void validatePassword(String passwoed, String msg) throws BusinessException {

		Pattern patternPasswoed = Pattern.compile("^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,20}$");
		boolean flagPasswoed = patternPasswoed.matcher(passwoed).matches();
		if (!flagPasswoed) {
			throw new BusinessException(msg);
		}
	}
	
	/**
	 * 字符串去空格
	 * @param objString
	 * @return
	 */
	public static String stringToTrim(String objString){
		if (objString != null) {
			objString = objString.trim();
			return objString;
		}
		return  objString;
	}
	
	/**
	 * 金钱校验
	 * @param money
	 * @param msg
	 * @throws BusinessException
	 */
	public static void validateMoney(String money,String msg) throws BusinessException{
		Pattern pattern = Pattern.compile("^(([1-9]{1}\\d*)|([0]{1}))(\\.(\\d){0,2})?$"); 
		boolean flag = pattern.matcher(money).matches();
		if (!flag) {
			throw new BusinessException(msg);
		}
		// 判断输入的金额是否大于等于设定值  -1表示大于等于
		if (new BigDecimal(money).compareTo(new BigDecimal(9999999999.99))>-1) {
			throw new BusinessException(msg);
		}	
	}
	
	/**
	 * 手机电话同时校验
	 * @param money
	 * @param msg
	 * @throws BusinessException
	 */
	public static void validatePhoneAndMobile(String objString,String msg) throws BusinessException{
		Pattern pattern = Pattern.compile("^((\\d{3,4}[-+*/_－— ]?)?\\d{6,8}|1[3-9][0-9]\\d{8})$"); 
		boolean flag = pattern.matcher(objString).matches();
		if (!flag) {
			throw new BusinessException(msg);
		}
	}
	
	/**
	 * 保留最多两位小数的百分比校验
	 * @param money
	 * @param msg
	 * @throws BusinessException
	 */
	public static void validatePercentage(String objString,String msg) throws BusinessException{
//		Pattern pattern = Pattern.compile("^\\d{0,2}+\\.?\\d{0,2}$");
		Pattern pattern = Pattern.compile("^(((\\d{1,2})[.]((\\d{1,2})?))|100|(?:0|[1-9][0-9]?)|100.00|100.0)$");
		boolean flag = pattern.matcher(objString).matches();
		if (!flag) {
			throw new BusinessException(msg);
		}
	}
	
	/**
	 * 用于处理传递的参数，如果参数为null，则返回“”,如果参数不为null则进行去空格处理
	 * @param objString
	 * @return
	 */
	public static String stringAndNull(String objString){
		if(objString!=null && !objString.trim().equals("")){
			return objString.trim();
		}
		return "";
	}
}
