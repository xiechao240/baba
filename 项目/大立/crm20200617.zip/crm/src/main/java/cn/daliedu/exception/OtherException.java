package cn.daliedu.exception;

/**
 * 其他异常，少数场景使用，比如数据导出成文件返回给前端接口，不能定义返回值为Result，但无数据又希望给前端提示，就抛出此异常，然后全局拦截给前端返回
 * （暂未使用，通过其他办法解决了）
 * @author xiechao
 * @time 2019年2月18日 上午10:13:15
 * @version 1.0.0
 * @description
 */
public class OtherException extends Exception {
	private static final long serialVersionUID = 1L;

	public OtherException(String message) {
		super(message);
	}

	public OtherException(String message, Throwable cause) {
		super(message, cause);
	}

	public OtherException(Throwable cause) {
		super(cause);
	}
}
