package cn.daliedu.service;

import com.baomidou.mybatisplus.extension.service.IService;

import cn.daliedu.entity.RoleMenuEntity;

/**
 * <p>
 * 角色菜单 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
public interface RoleMenuService extends IService<RoleMenuEntity> {
	
	/**
	 * 保存角色ID对应的菜单
	 * @param list
	 * @param roleId
	 * @return
	 * @throws Exception
	 */
	public boolean saveRoleMenuByRoleId(String[] menuIdList, String roleId) throws Exception ;
}
