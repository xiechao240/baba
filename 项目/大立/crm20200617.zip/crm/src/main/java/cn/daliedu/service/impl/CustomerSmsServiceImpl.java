package cn.daliedu.service.impl;

import cn.daliedu.entity.CustomerSmsEntity;
import cn.daliedu.mapper.CustomerSmsMapper;
import cn.daliedu.service.CustomerSmsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 客户发送短信表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2020-06-16
 */
@Service
public class CustomerSmsServiceImpl extends ServiceImpl<CustomerSmsMapper, CustomerSmsEntity> implements CustomerSmsService {

}
