package cn.daliedu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import cn.daliedu.entity.CustomerDynamicFileEntity;

/**
 * <p>
 * 客户动态上传的文件或图片 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-10-29
 */
public interface CustomerDynamicFileMapper extends BaseMapper<CustomerDynamicFileEntity> {
	
}
