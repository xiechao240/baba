package cn.daliedu.service;

import cn.daliedu.entity.CustomerTagGroupEntity;

import java.util.List;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 客户标签分组表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-24
 */
public interface CustomerTagGroupService extends IService<CustomerTagGroupEntity> {
	
	/**
	 * 根据客户标签分组类型ID，获取当前客户标签对应的最大值
	 * @param customerTagTypeId 客户标签分组类型ID
	 */
	public Integer getMaxCustomerTagValue(String branchOrgId);
	
	/**
	 * 还原为系统客户分组
	 * @param branchOrgId 分校ID
	 * @return
	 */
	boolean restoreCustomerTagGroupByBranchOrgId(String branchOrgId);
	
	/**
	 * 获取客户标签分组及分组明细
	 * @param branchOrgId 如果不传分校ID，则加载系统初始化的客户标签分组
	 * @return
	 */
	public List<CustomerTagGroupEntity> findCustomerTagGroupAndTagDetailList(String branchOrgId);
	
	/**
	 * 获取客户标签分组
	 * @param branchOrgId 如果不传分校ID，则加载系统初始化的客户标签分组
	 * @return
	 */
	public List<CustomerTagGroupEntity> findCustomerTagGroupList(String branchOrgId);
	
	/**
	 * 判断数据库中是否已经存在客户分组标签，简单防止同名的标签加入
	 * @param customerTagTypeName
	 * @return
	 */
	public boolean existsCustomerTagTypeName(String customerTagTypeName);
	
	/**
	 * 删除客户标签分组，同时删除客户标签分组明细
	 * @param customerTagTypeId
	 * @return
	 */
	public boolean removeCustomerTagGroup(Integer customerTagTypeId)  throws Exception;
}
