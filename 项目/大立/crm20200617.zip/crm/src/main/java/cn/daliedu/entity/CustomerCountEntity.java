package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.time.LocalDate;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 每天统计分校的客户总数与用户的客户总数
 * </p>
 *
 * @author xiechao
 * @since 2019-12-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_customer_count")
public class CustomerCountEntity extends Model<CustomerCountEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;

    /**
     * 数据类型，1：分校，2：用户
     */
    private String dataType;

    /**
     * 分校ID
     */
    private String branchOrgId;

    /**
     * 用户ID
     */
    private String userId;

    /**
     * 客户数量
     */
    private Integer customerCount;

    /**
     * 统计日期
     */
    private LocalDate createDate;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
