package cn.daliedu.service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

import com.baomidou.mybatisplus.extension.service.IService;

import cn.daliedu.entity.CustomerDynamicLogEntity;

/**
 * <p>
 * 客户动态记录表，如新建客户，客户资料变更等操作记录 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-19
 */
public interface CustomerDynamicLogService extends IService<CustomerDynamicLogEntity> {
	
	/**
	 * 获取客户动态列表
	 * @param map
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerDynamicList(Map<Object, Object> map);
	
	/**
	 * 获取客户动态列表总数
	 * @param map
	 * @return
	 */
	public Long getCustomerDynamicListCount(Map<Object, Object> map);
	
	/**
	 * 用户在前端页面上操作增加跟进记录，并可以上传图片
	 * @param dynamicContent 增加的动态内容 
	 * @customerId 客户ID
	 * @return
	 * @throws Exception
	 */
	public boolean insertFollowLog(String customerId, String dynamicContent) throws Exception;
	
	
	/**
	 * 用户在前端页面上操作增加跟进记录，并可以上传图片
	 * @param dynamicContent 增加的动态内容 
	 * @param files 增加的文件列表
	 * @return
	 * @throws Exception
	 */
	public boolean insertFollowLog(HttpServletRequest request, String customerId, String dynamicContent, MultipartFile[] files) throws Exception;
}
