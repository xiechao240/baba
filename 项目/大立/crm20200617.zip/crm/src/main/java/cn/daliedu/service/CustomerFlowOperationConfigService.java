package cn.daliedu.service;

import cn.daliedu.entity.CustomerFlowOperationConfigEntity;
import cn.daliedu.entity.json.CustomerFlowOperationConfigJson;

import java.util.LinkedHashMap;
import java.util.List;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 客户流转操作配置表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-15
 */
public interface CustomerFlowOperationConfigService extends IService<CustomerFlowOperationConfigEntity> {
	
	/**
	 * 获取所有的客户流转原因操作配置
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getAllCustomerFlowOperation();
	
	/**
	 * 根据类型获取客户流转原因配置
	 * @param operationType
	 * @return
	 */
	public List<CustomerFlowOperationConfigEntity> getCustomerFlowOperationConfigByType(String operationType);
	
	/**
	 * 保存客户流转操作配置(前端只需要传递操作配置数组即可，因为配置数据已经包含原因)
	 * @param arrList
	 * @return
	 */
	public boolean saveCustomerFlowOperationConfig(CustomerFlowOperationConfigJson[] arrList);
}
