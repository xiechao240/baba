package cn.daliedu.service;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.baomidou.mybatisplus.extension.service.IService;

import cn.daliedu.entity.CustomerEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.json.CustomerModel;
import cn.daliedu.util.Result;

/**
 * <p>
 * 客户表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-26
 */
public interface CustomerService extends IService<CustomerEntity> {
	
	
	/**
	 * 获取用户联系客户的次数（首页目前有使用到）
	 * @param map
	 * @return
	 */
	public BigDecimal getCustomerContactCountByUserId(Map<Object, Object> map);
	
	/**
	 * 共享给同事的客户--》取消共享
	 * @param customerIdList
	 * @return
	 * @throws Exception
	 */
	public boolean updateCancelShareToUserCustomer(List<String> customerIdList) throws Exception;
	
	/**
	 * 共享给我的客户--》移除客户
	 * @param customerIdList
	 * @return
	 * @throws Exception
	 */
	public boolean removeShareToMyCustomer(List<String> customerIdList) throws Exception;
	
	/**
	 * （资源库）领取客户
	 * @param customerGroupTypeId 客户分组类型ID
	 * @param customerIdList 客户ID集合
	 * @return
	 * @throws Exception
	 */
	public boolean updateGetCustomerByRepository(String customerGroupTypeId, List<String> customerIdList) throws Exception;
	
	/**
	 * （分校回收站）领取客户
	 * @param customerGroupTypeId 客户分组类型ID
	 * @param customerIdList 客户ID集合
	 * @return
	 * @throws Exception
	 */
	public boolean updateGetCustomerByBusinessGroupSea(String customerGroupTypeId, List<String> customerIdList) throws Exception;
	
	/**
	 * （公司回收站）领取客户
	 * @param customerGroupTypeId 客户分组类型ID
	 * @param customerIdList 客户ID集合
	 * @return
	 * @throws Exception
	 */
	public boolean updateGetCustomerByCompanySea(String branchOrgId, String customerGroupTypeId, List<String> customerIdList) throws Exception;
	
	/**
	 * （资源库）将客户分配给相应用用户
	 * @param userId  用户ID
	 * @param customerId  客户ID
	 * @return
	 */
	public boolean updateAllocationCustomerByCustomerIdRepository(String userId, List<String> customerIdList)  throws Exception;
	
	/**
	 * （分校回收站）将客户分配给相应用用户
	 * @param userId  用户ID
	 * @param customerId  客户ID
	 * @return
	 */
	public boolean updateAllocationCustomerByCustomerIdBusinessGroupSea(String userId, List<String> customerIdList)  throws Exception;
	
	/**
	 * （公司回收站）将客户分配给相应用用户
	 * @param userId  用户ID
	 * @param customerId  客户ID
	 * @return
	 */
	public boolean updateAllocationCustomerByCustomerIdCompanySea(String branchOrgId, String userId, List<String> customerIdList)  throws Exception;
	
	
	/**
	 * 【客户数量统计报表】获取用户流失的客户数量
	 * @param map
	 * @return
	 */
	public BigDecimal getLossCustomerCountByUser(Map<Object, Object> map);
	
	
	/**
	 * 【客户数量统计报表】获取分校的用户流失的客户数量
	 * @param map
	 * @return
	 */
	public BigDecimal getLossCustomerCountByBranch(Map<Object, Object> map);
	
	/**
	 * 【客户数量统计报表】获取用户创建的客户数量
	 * @param map
	 * @return
	 */
	public BigDecimal getCreateCustomerCountByUser(Map<Object, Object> map);
	
	
	/**
	 * 【客户数量统计报表】获取分校的用户创建的客户数量
	 * @param map
	 * @return
	 */
	public BigDecimal getCreateCustomerCountByBranch(Map<Object, Object> map);
	
	/**
	 * 【客户活跃度统计报表】获取最近联系的客户数量
	 * @param contactNum
	 * @return
	 */
	public BigDecimal getLatelyContactCustomerCount(Map<Object, Object> map);
	
	/**
	 * 【客户活跃度统计报表】根据客户联系次数获取客户数量
	 * @param contactNum
	 * @return
	 */
	public BigDecimal getCustomerContactCount(Map<Object, Object> map);
	
	/**
	 * 【客户活跃度统计报表】根据分校ID获取分校客户数量
	 * @param branchOrgId
	 * @return
	 */
	public BigDecimal getBranchCustomerCount(Map<Object, Object> map);
	
	/**
	 * 【客户数量统计报表】根据分校ID获取分校客户数量
	 * @param branchOrgId
	 * @return
	 */
	public Integer getCustomerCountByBranchOrgId(String branchOrgId);
	
	/**
	 * 【客户数量统计报表】根据用户ID获取客户数量
	 * @param branchOrgId
	 * @return
	 */
	public Integer getCustomerCountByUserId(String userId);
	
	/**
	 * 【客户活跃度统计报表】获取整个大立教育客户数量（用于超级管理员查看）
	 * @return
	 */
	public Integer getAllCustomerCount();
	
	
	/**
	 * 【客户管理】综合查询获取客户列表
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerListByCustomerManage(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【客户管理】综合查询获取客户列表总数
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerListByCustomerManageCount(Map<Object, Object> map);
	
	/**
	 * 【推广管理】综合查询获取客户列表
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerListByPromotionManage(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【客户查重】获取客户列表
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerListByRepetition(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【客户查重】获取客户列表
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public Long getCustomerListByRepetitionCount(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【推广管理】综合查询获取客户列表总数
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerListByPromotionManageCount(Map<Object, Object> map);
	
	/**
	 * 根据客户id,获取客户的共享关系
	 * @param id 客户id
	 */
	public List<LinkedHashMap<Object, Object>>  getShareRelation(String customerId);
	
	/**
	 * 新增客户
	 * @param model 客户数据模型
	 * @param user 当前操作的用户
	 * @return
	 * @throws Exception
	 */
	public boolean saveCustomer(CustomerModel model, MultipartFile file, UserEntity user) throws Exception;
	
	/**
	 * 修改客户
	 * @param model 客户数据模型
	 * @param user 当前操作的用户
	 * @return
	 * @throws Exception
	 */
	public boolean updateCustomerByCustomerId(CustomerModel model, MultipartFile file, UserEntity user) throws Exception;
	
	/**
	 * 真正删除客户（回收站彻底删除客户）
	 * @param customerIds
	 * @return
	 * @throws Exception
	 */
	public boolean deleteCustomerFromRepositoryByCustomerId(String customerIds) throws Exception;
	
	/**
	 * 根据客户ID，删除客户
	 * @param customerIds
	 * @param causeId 删除原因ID
	 * @param cause 删除原因
	 * @return
	 * @throws Exception
	 */
	public boolean deleteCustomerByCustomerId(String customerIds, String causeId, String cause) throws Exception;
	
	/**
	 * 根据客户ID，删除客户（公司大公海删除客户）
	 * @param customerIds
	 * @param causeId 删除原因ID
	 * @param cause 删除原因
	 * @return
	 * @throws Exception
	 */
	public boolean deleteCustomerBeFromCompanySeaByCustomerId(String customerIds, String causeId, String cause) throws Exception;
	
	
	/**
	 * 根据客户ID，删除客户（业务组公海删除客户）
	 * @param customerIds
	 * @param causeId 删除原因ID
	 * @param cause 删除原因
	 * @return
	 * @throws Exception
	 */
	public boolean deleteCustomerBeFromBusinessGroupSeaByCustomerId(String customerIds, String causeId, String cause) throws Exception;
	
	/**
	 * 根据客户ID，放弃客户至公司大公海
	 * @param customerIds
	 * @param causeId 放弃原因ID
	 * @param cause 放弃原因
	 * @return
	 * @throws Exception
	 */
	public boolean updateWaiveCustomerToCompanySea(String customerIds, String causeId, String cause) throws Exception;
	
	/**
	 * 根据客户ID，放弃客户至当前用户所在的业务组公海
	 * @param customerIds
	 * @param causeId 放弃原因ID
	 * @param cause 放弃原因
	 * @return
	 * @throws Exception
	 */
	public boolean updateWaiveCustomerToBusinessGroupSea(String customerIds, String causeId, String cause) throws Exception;
	
	/**
	 * 根据客户ID，将客户更新至资源库
	 * @param customerIds
	 * @return
	 * @throws Exception
	 */
	public boolean updateCustomerToRepository(String customerIds) throws Exception;
	
	/**
	 * 转让客户给同事接口
	 * @param customerIds 转让的客户id集合
	 * @param causeId 转让原因id
	 * @param cause 转让原因
	 * @param userIds 转让的接收人id集合
	 * @return
	 * @throws Exception
	 */
	public boolean updateTransferCustomerToUser(String customerIds, Integer causeId, String cause, String userId) throws Exception;
	
	/**
	 * 共享客户给同事接口
	 * @param customerIds 共享的客户id集合
	 * @param userIds 共享的接收人userId集合
	 * @param shareType 共享类型  1：保留原有共享关系，新增共享同事，2：用新的共享同事覆盖原有共享关系
	 * @return
	 * @throws Exception
	 */
	public boolean updateShareCustomerToUser(String customerIds, String userIds, String shareType) throws Exception;
	
	
	/**
	 * 获取当前管理员管理的机构及下属机构，员工删除的客户列表（即回收站里面显示客户列表）
	 * @param map
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> findCustomerRecycledList(Map<Object, Object> map);
	
	/**
	 * 获取当前管理员管理的机构及下属机构，员工删除的客户列表总数（即回收站里面显示客户列表）
	 * @param map
	 * @return
	 */
	public Long findCustomerRecycledListCount(Map<Object, Object> map);
	
	/**
	 * 根据客户ID，将客户还原给同事
	 * @param customerId
	 * @param userId
	 */
	public boolean updateRestoreCustomerByCustomerId(String customerId, String userId);
	
	/**
	 * 将客户还原至公司大公海
	 * @param customerId
	 * @return
	 */
	public boolean updateRestoreCustomerToCompanySea(String customerId) throws Exception;
	
	/**
	 * 将客户还原至业务组公海
	 * @param customerId 客户ID
	 * @param branchOrgId 业务组公海ID(即机构ID)
	 * @return
	 */
	public boolean updateRestoreCustomerToBusinessGroupSea(String customerId, String branchOrgId) throws Exception;
	
	
	
	/**
	 * 根据用户id查询我的客户列表
	 * @param map 查询组合参数集合
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerList(Map<Object, Object> map);
	
	/**
	 * 根据用户id查询业务组公海的客户列表
	 * @param map 查询组合参数集合
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerListByBusinessGroupSea(Map<Object, Object> map);
	
	/**
	 * 查询我导入的客户列表
	 * @param map 查询组合参数集合
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerListByImport(Map<Object, Object> map);
	
	/**
	 * 查询我推广的的客户列表
	 * @param map 查询组合参数集合
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerListByGeneralize(Map<Object, Object> map);
	
	/**
	 * 查询资源库的客户列表
	 * @param map 查询组合参数集合
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerListByRepository(Map<Object, Object> map);
	
	
	/**
	 * 查询我导入的客户列表数量
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerListByImportCount(Map<Object, Object> map);
	
	/**
	 * 查询我推广的的客户列表数量
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerListByGeneralizeCount(Map<Object, Object> map);
	
	/**
	 * 查询资源库的客户列总数
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerListByRepositoryCount(Map<Object, Object> map);
	
	/**
	 * 根据用户id查询业务组公海的客户列表总数
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerListByBusinessGroupSeaCount(Map<Object, Object> map);
	
	/**
	 * 根据用户id查询业务组的客户列表(代理商用户查询)
	 * @param map 查询组合参数集合
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerListByAgentsSearch(Map<Object, Object> map);
	/**
	 * 根据用户id查询业务组的客户列表总数(代理商用户查询)
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerListByAgentsSearchCount(Map<Object, Object> map);
	/**
	 * 查询公司大公海的客户列表
	 * @param map 查询组合参数集合
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerListByCompanySea(Map<Object, Object> map);
	
	/**
	 * 根据用户id查询我的客户列表总数
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerListCount(Map<Object, Object> map);
	
	
	
	/**
	 * 查询公司大公海的客户列表总数
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerListByCompanySeaCount(Map<Object, Object> map);
	
	/**
	 * 客户导入接口
	 * @param customerGroupTypeId 客户分组ID
	 * @param departmentId 部门ID
	 * @param branchOrgId  公海ID(业务组ID)
	 * @param importType 导入类别
	 * @param isSupplementCustomerInfo 是否完善客户资料
	 * @param userId 当选择导入给同事时，此参数传选择的同事ID过来
	 * @param file 导入客户的excel文件
	 * @param customerQuality 客户质量
	 * @param customerIntentionLevel 客户意向程度
	 * @param customerIntentionContent 客户意向内容
	 * @param promotionUserId 推广人
	 * @return
	 * @throws Exception
	 */
	public Result saveCustomerImport(String customerGroupTypeId, String branchOrgId, String departmentId, String importType, 
			String isSupplementCustomerInfo, String userId, String customerQuality, 
			String customerIntentionLevel,
			String customerIntentionContent, String promotionUserId, MultipartFile file) throws Exception;
	
	/**
	 * 根据手机号码判断客户是否存在（唯一的判断标准）
	 * @param mobile 手机号码
	 * @return
	 */
	public List<CustomerEntity> getCustomerListByMobile(String mobile);
	
	/**
	 * 
	 * @param mobile
	 * @return
	 */
	public boolean existsCustomerByMobile(String mobile);
	
	/**
	 * 根据手机号码，分校ID，判断客户是否在分校中已经存在
	 * @param mobile 手机号码
	 * @param branchOrgId 分校ID
	 * @return
	 */
	public List<CustomerEntity> getCustomerListByMobileAndBranchOrgId(String mobile, String branchOrgId);
	
	/**
	 * 获取代理商导入的客户
	 * @param userId 用户ID
	 * @param mobile 客户手机号码
	 * @return
	 */
	public List<CustomerEntity> getCustomerListByAgentImportMobile(String userId, String mobile);
	
	/**
	 * 根据手机号码与分校ID，判断分校是否已经存在此客户
	 * @param mobile 手机号码
	 * @param branchOrgId 分校ID
	 * @return
	 */
	public boolean existsCustomerByMobileAndBranchOrgId(String mobile, String branchOrgId);
	
	
	
	/**
	 * 批量移动客户分组
	 * @param customerIds 客户ID集合
	 * @param customerGroupTypeId 客户分组ID
	 * @return
	 */
	public boolean moveCustomerGroupByCustomerId(String customerIds, String customerGroupTypeId);
	
	/**
	 * 更新客户阶段
	 * @param customerId 客户ID
	 * @param customerStage 客户阶段
	 * @return
	 */
	public boolean updateCustomerStage(String customerId, String customerStage) throws Exception;
	
	/**
	 * 回滚客户阶段
	 * @param customerId 客户ID
	 * @param customerStage 客户阶段
	 * @return
	 */
	public boolean updateReturnCustomerStage(String customerId, String customerStage) throws Exception;
}
