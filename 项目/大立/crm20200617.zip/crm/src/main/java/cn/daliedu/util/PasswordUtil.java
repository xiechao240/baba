package cn.daliedu.util;

import org.apache.shiro.crypto.hash.SimpleHash;

public class PasswordUtil {
	
	/**
	 * 这个方法不够严谨，同样的密码，加盐后还是同样的值，这样还是能够容易破解
	 * @param password
	 * @return
	 */
	@Deprecated
	public static String getPassword(String password) {
		byte[] salt = null;
		String hashAlgorithmName = "MD5";
		int hashIterations = 5;
		return new SimpleHash(hashAlgorithmName, password, salt, hashIterations).toString();
	}
	
	/**
	 * 根据用户ID及密码进行加盐，确保加盐后的结果是唯一的
	 * @param userId 用户ID
	 * @param password 密码
	 * @return
	 */
	public static String getPassword(String userId, String password) {
		byte[] salt = null;
		String hashAlgorithmName = "MD5";
		int hashIterations = 5;
		return new SimpleHash(hashAlgorithmName, userId + password, salt, hashIterations).toString();
	}
	
	public static void main(String[] args) {
		System.out.println(PasswordUtil.getPassword("123456"));
		System.out.println(PasswordUtil.getPassword("xie", "123456"));
		System.out.println(PasswordUtil.getPassword("chao", "123456"));
	}
}
