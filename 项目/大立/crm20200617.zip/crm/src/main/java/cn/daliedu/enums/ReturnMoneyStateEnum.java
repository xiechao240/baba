package cn.daliedu.enums;

/**
 * 回款状态枚举类
 * @author xiechao
 * @time 2019年1月9日 下午5:51:51
 * @version 1.0.0
 * @description 
 */
public enum ReturnMoneyStateEnum {
	/**
	 * 回款状态：未完成
	 */
	TYPE_0("0", "未完成"), 
	/**
	 * 回款状态：完成
	 */
	TYPE_1("1", "完成"),
	/**
	 * 回款状态：逾期未完成
	 */
	TYPE_2("2", "逾期未完成");

	private String value;
	private String desc;

	ReturnMoneyStateEnum(final String value, final String desc) {
		this.value = value;
		this.desc = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
	
	
	/**
     * 根据枚举值获取枚举描述
     * @param key
     * @return
     */
    public static String getDesc(String value){
    	String returnStr = "";
        for (ReturnMoneyStateEnum e: ReturnMoneyStateEnum.values()){
            if(e.getValue().equals(value)){
            	returnStr = e.getDesc();
            	break;
            }
        }
		return returnStr;
    }
}