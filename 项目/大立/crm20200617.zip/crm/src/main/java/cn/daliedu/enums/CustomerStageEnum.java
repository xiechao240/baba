package cn.daliedu.enums;

/**
 * 客户阶段枚举类(客户阶段定义好了，就不可变，比如，状态码5，就是缴费阶段，如果可变，那很多逻辑就都要改)
 * @author xiechao
 * @time 2019年9月27日 下午2:44:36
 * @version 1.0.0 
 * @description 1：新入库，2：初步沟通，3：多次沟通，4：截杀，5：缴费
 */
public enum  CustomerStageEnum {  
	/**
	 * 客户阶段：新入库
	 */
	TYPE_1("1", "新入库"), 
	/**
	 * 客户阶段：初步沟通
	 */
	TYPE_2("2", "初步沟通"),
	/**
	 * 客户阶段：多次沟通
	 */
	TYPE_3("3", "多次沟通"),
	/**
	 * 客户阶段：截杀
	 */
	TYPE_4("4", "截杀"),
	
	/**
	 * 客户阶段：缴费
	 */
	TYPE_5("5", "缴费");


	private String value;
	private String desc;

	CustomerStageEnum(final String value, final String desc) {
		this.value = value;
		this.desc = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
	
	/**
     * 根据枚举值获取枚举描述
     * @param key
     * @return
     */
    public static String getDesc(String value){
    	String returnStr = "";
        for (CustomerStageEnum e: CustomerStageEnum.values()){
            if(e.getValue().equals(value)){
            	returnStr = e.getDesc();
            	break;
            }
        }
		return returnStr;
    }
    
    /**
     * 判断数值是否属于枚举类的值
     * @param key
     * @return
     */
    public static boolean isInclude(String value){
        boolean include = false;
        for (CustomerStageEnum e: CustomerStageEnum.values()){
            if(e.getValue().equals(value)){
                include = true;
                break;
            }
        }
        return include;
    }
}