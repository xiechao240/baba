//package cn.daliedu.util;
//
//import java.io.IOException;
//import java.net.URLEncoder;
//import java.util.Date;
//import java.util.TreeMap;
//
//import org.apache.commons.lang.time.DateFormatUtils;
//import org.apache.log4j.Logger;
//import org.json.JSONObject;
//
//import com.aliyuncs.DefaultAcsClient;
//import com.aliyuncs.IAcsClient;
//import com.aliyuncs.dysmsapi.model.v20170525.SendSmsRequest;
//import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
//import com.aliyuncs.exceptions.ClientException;
//import com.aliyuncs.http.MethodType;
//import com.aliyuncs.profile.DefaultProfile;
//import com.aliyuncs.profile.IClientProfile;
//import com.changh.sccms.api.DaliEduExcepion;
//import com.changh.sccms.api.DaliInterface;
//import com.changh.sccms.entity.Smstest;
//
///**
// * 此类为大立公司别人写的，包含阿里云发送短信，电信发送短信，我已经改写至SMSUtil类中
// * @author xiechao
// * @time 2019年12月26日 上午9:49:54
// * @version 1.0.0 
// * @description
// */
//public class SendUtils implements DaliInterface {
//	// 电信
//	private static String app_id = "300129840000034964";
//	private static String app_secret = "741581c0eba398f052cb197c3ac1bcbe";
//	private static Logger log = Logger.getLogger(SendUtils.class.getName());
//
//	// 阿里云
//	private static final String product = "Dysmsapi";// 短信API产品名称（短信产品名固定，无需修改）
//	private static final String domain = "dysmsapi.aliyuncs.com";// 短信API产品域名（接口地址固定，无需修改）
//	private static final String accessKeyId = "hnblga1pqamuj7yi0n1b2qdu";// 你的accessKeyId
//	private static final String accessKeySecret = "vICsq+LZWGNtZ9MO6SruJdCAryw=";// 你的accessKeySecret
//
//	/**
//	 *
//	 * @Title: sendSms
//	 * @Description: TODO(发送验证码短信)
//	 * @param: @param smstest
//	 * @param: @param type 短信种类
//	 * @param: @return
//	 * @param: @throws DaliEduExcepion
//	 * @return: void
//	 * @throws
//	 */
//	public static void sendSms(Smstest smstest, String type) throws DaliEduExcepion {
//		smstest.setAddTime(new Date());
//		smstest.setValidateCode(BaseUtil.getRandCode());
//		smstest.setSmsType(Constant.SENDSMSTYPE_CODE);//验证码
//		if (type.equals(String.valueOf(Constant.SENDSMS_TELECOM))) {//电信
//			int i = 0;
//			int res_code = 1;
//			do {
//				i++;
//				res_code = telecom(smstest);
//			} while (res_code != 0 && i <= 3);
//		} else {//阿里云
//			String params = "{\"code\":\"" + smstest.getValidateCode() + "\"}";
//			aliyun(smstest, Constant.ALIYUNSENDSMSTEMPLATE_CODE, params);//验证码模板
//		}
//	}
//
//	/**
//	 *
//	 * @Title: sendSmsAccount
//	 * @Description: TODO(发送账号密码短信)
//	 * @param: @param smstest
//	 * @param: @param type 短信种类
//	 * @param: @return
//	 * @param: @throws DaliEduExcepion
//	 * @return: void
//	 * @throws
//	 */
//	public static void sendSmsAccount(Smstest smstest, String type) throws DaliEduExcepion {
//		if (type.equals(String.valueOf(Constant.SENDSMS_TELECOM))) {//电信
//			int i = 0;
//			int res_code = 1;
//			String params = "{\"password\":\"" + smstest.getPassWord() + "\", \"name\":\"" + smstest.getName() + "\"}";
//			do {
//				i++;
//				res_code = telecom(smstest, params, Constant.TELECOMSENDSMSTEMPLATE_REGISTER);
//			} while (res_code != 0 && i <= 3);
//		} else {//阿里云
//			String params = "{\"password\":\"" + smstest.getPassWord() + "\", \"name\":\"" + smstest.getName() + "\"}";
//			aliyun(smstest, Constant.ALIYUNSENDSMSTEMPLATE_REGISTER, params);
//		}
//	}
//
//	/**
//	 *
//	 * @Title: sendSmsCourse
//	 * @Description: TODO(发送课程开通短信)
//	 * @param: @param smstest
//	 * @param: @param type 短信种类
//	 * @param: @return
//	 * @param: @throws DaliEduExcepion
//	 * @return: void
//	 * @throws
//	 */
//	public static void sendSmsCourse(Smstest smstest, String type) throws DaliEduExcepion {
//		if (type.equals(String.valueOf(Constant.SENDSMS_TELECOM))) {//电信
//			int i = 0;
//			int res_code = 1;
//			String params = "{\"course\":\"" + smstest.getCourse() + "\", \"name\":\"" + smstest.getName() + "\"}";
//			do {
//				i++;
//				res_code = telecom(smstest, params, Constant.TELECOMSENDSMSTEMPLATE_COURSE);
//			} while (res_code != 0 && i <= 3);
//		} else {//阿里云
//			String params = "{\"course\":\"" + smstest.getCourse() + "\", \"name\":\"" + smstest.getName() + "\"}";
//			aliyun(smstest, Constant.ALIYUNSENDSMSTEMPLATE_COURSE, params);
//		}
//	}
//
//	/**
//	 *
//	 * @Title: aliyun
//	 * @Description: TODO(阿里云接口)
//	 * @param: @param smstest
//	 * @param: @param templateCode 短信模板
//	 * @param: @param params 参数
//	 * @param: @throws DaliEduExcepion
//	 * @return: void
//	 * @throws
//	 */
//	@SuppressWarnings("deprecation")
//	private static void aliyun(Smstest smstest, String templateCode, String params) throws DaliEduExcepion {
//		try {
//			// 设置超时时间-可自行调整
//			System.setProperty("sun.net.client.defaultConnectTimeout", "120000");
//			System.setProperty("sun.net.client.defaultReadTimeout", "120000");
//			IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou", accessKeyId, accessKeySecret);
//			DefaultProfile.addEndpoint("cn-hangzhou", "cn-hangzhou", product, domain);
//			IAcsClient acsClient = new DefaultAcsClient(profile);
//			// 组装请求对象
//			SendSmsRequest request = new SendSmsRequest();
//			// 使用post提交
//			request.setMethod(MethodType.POST);
//			// 必填:待发送手机号。支持以逗号分隔的形式进行批量调用，批量上限为1000个手机号码,批量调用相对于单条调用及时性稍有延迟,验证码类型的短信推荐使用单条调用的方式；发送国际/港澳台消息时，接收号码格式为国际区号+号码，如“85200000000”
//			request.setPhoneNumbers(smstest.getMobileNumber());
//			// 必填:短信签名-可在短信控制台中找到
//			request.setSignName("大立教育");
//			// 必填:短信模板-可在短信控制台中找到，发送国际/港澳台消息时，请使用国际/港澳台短信模版
//			request.setTemplateCode(templateCode);
//			//参数传递
//			request.setTemplateParam(params);
//			// 请求失败这里会抛ClientException异常
//			SendSmsResponse sendSmsResponse = acsClient.getAcsResponse(request);
//			if (sendSmsResponse.getCode() == null || !sendSmsResponse.getCode().equals("OK")) {
//				throw new DaliEduExcepion(ERROR_403, sendSmsResponse.getMessage());
//			}
//		} catch (ClientException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			throw new DaliEduExcepion(ERROR_403, e.getErrMsg());
//		}
//	}
//
//	/**
//	 *
//	 * @Title: telecom
//	 * @Description: TODO(电信验证码接口)
//	 * @param: @param smstest
//	 * @param: @return
//	 * @param: @throws DaliEduExcepion
//	 * @return: int
//	 * @throws
//	 */
//	private static int telecom(Smstest smstest) throws DaliEduExcepion {
//		try {
//			String access_token = getAccess_token();
//			String timestamp = DateFormatUtils.format(smstest.getAddTime(), "yyyy-MM-dd HH:mm:ss");
//			TreeMap<String, String> paramsMap = new TreeMap<>();
//			paramsMap.put("app_id", app_id);
//			paramsMap.put("access_token", access_token);
//			paramsMap.put("timestamp", timestamp);
//			String getUrl = "http://api.189.cn/v2/dm/randcode/token?app_id=" + app_id + "&access_token=" + access_token
//					+ "&timestamp=" + URLEncoder.encode(timestamp, "UTF-8") + "&sign=" + ParamsSign.value(paramsMap, app_secret);
//			String resJson = HttpInvoker.httpGet(getUrl);
//			JSONObject json = new JSONObject(resJson);
//			TreeMap<String, String> paramsMap1 = new TreeMap<>();
//			paramsMap1.put("app_id", app_id);
//			paramsMap1.put("access_token", access_token);
//			paramsMap1.put("timestamp", timestamp);
//			paramsMap1.put("token", String.valueOf(json.get("token")));
//			paramsMap1.put("phone", smstest.getMobileNumber());
//			paramsMap1.put("exp_time", "2");
//			paramsMap1.put("randcode", smstest.getValidateCode());
//			String postUrl = "http://api.189.cn/v2/dm/randcode/sendSms?app_id=" + app_id + "&access_token="
//					+ access_token + "&timestamp=" + URLEncoder.encode(timestamp, "UTF-8");
//			String postEntity = "token=" + json.get("token") + "&phone=" + smstest.getMobileNumber()
//					+ "&randcode=" + smstest.getValidateCode() + "&exp_time=2&sign=" + ParamsSign.value(paramsMap1, app_secret);
//			String resJson1 = HttpInvoker.httpPost(postUrl, null, postEntity);
//			JSONObject json2 = new JSONObject(resJson1);
//			int res_code = json2.getInt("res_code");
//			log.info("短信回调res_code:" + res_code);
//			return res_code;
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new DaliEduExcepion(ERROR_400, "发送短信失败！！！");
//		}
//	}
//
//	/**
//	 *
//	 * @Title: telecom
//	 * @Description: TODO(电信模板接口)
//	 * @param: @param smstest
//	 * @param: @param identify 短信模板
//	 * @param: @param String 参数模板
//	 * @param: @param template 模板ID
//	 * @param: @return
//	 * @param: @throws DaliEduExcepion
//	 * @return: int
//	 * @throws
//	 */
//	private static int telecom(Smstest smstest, String params, String template) throws DaliEduExcepion {
//		try {
//			String access_token = getAccess_token();
//			String timestamp = DateFormatUtils.format(smstest.getAddTime(), "yyyy-MM-dd HH:mm:ss");
//			String postUrl = "http://api.189.cn/v2/emp/templateSms/sendSms";
//			String postEntity = "app_id=" + app_id + "&access_token="
//					+ access_token + "&acceptor_tel=" + smstest.getMobileNumber() + "&template_id="
//					+ template + "&template_param=" + params
//					+ "&timestamp=" + URLEncoder.encode(timestamp, "utf-8");
//			String resJson = HttpInvoker.httpPost(postUrl, null, postEntity);
//			JSONObject json = new JSONObject(resJson);
//			int res_code = json.getInt("res_code");
//			log.info("短信回调res_code:" + res_code);
//			return res_code;
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new DaliEduExcepion(ERROR_400, "发送短信失败！！！");
//		}
//	}
//
//	/**
//	 *
//	 * @Title: getAccess_token
//	 * @Description: TODO(获取Access_token)
//	 * @param: @return
//	 * @param: @throws DaliEduExcepion
//	 * @return: String
//	 * @throws
//	 */
//	private static String getAccess_token() throws DaliEduExcepion {
//		String res_code;
//		JSONObject json;
//		int i = 0;
//		do {
//			i++;
//			String postUrl = "https://oauth.api.189.cn/emp/oauth2/v3/access_token"; // 获取access_token的地址
//			TreeMap<String, String> paramsMap1 = new TreeMap<>();
//			paramsMap1.put("app_secret", app_secret);
//			paramsMap1.put("grant_type", "client_credentials");
//			paramsMap1.put("app_id", app_id);
//			String postEntity = "grant_type=" + "client_credentials" + "&app_id=" + app_id + "&app_secret="
//					+ app_secret;
//			String resJson = null;
//			try {
//				resJson = HttpInvoker.httpPost(postUrl, null, postEntity);
//			} catch (IOException e) {
//				throw new DaliEduExcepion(ERROR_403, "获取access_token的地址失败！！！");
//			}
//			json = new JSONObject(resJson);
//			res_code = json.getString("res_code");
//		} while (!"0".equals(res_code) && i <= 3);
//		return (String) json.get("access_token");
//	}
//}
