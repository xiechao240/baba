package cn.daliedu.util;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.Random;
import java.util.TreeMap;

import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import cn.daliedu.entity.SmsTemplateEntity;
import cn.daliedu.exception.BusinessException;

/**
 * 采用阿里云发送短信方案，目前限制比较严格，需要在阿里后台提交每种短信的模板，还要进行审核
 * @author xiechao
 * @time 2019年12月26日 下午4:40:30
 * @version 1.0.0 
 * @description
 */
public class SMSUtil {
	// 阿里云
	private static final String product = "Dysmsapi";// 短信API产品名称（短信产品名固定，无需修改）
	private static final String domain = "dysmsapi.aliyuncs.com";// 短信API产品域名（接口地址固定，无需修改）
	private static final String accessKeyId = "hnblga1pqamuj7yi0n1b2qdu";// 你的accessKeyId
	private static final String accessKeySecret = "vICsq+LZWGNtZ9MO6SruJdCAryw=";// 你的accessKeySecret
	
	/**
	 * 发送短信
	 * @param mobile 手机号码
	 * @param smsTemplateEntity 短信模板实体类属性
	 * @param param 短信模板中的参数
	 * @return
	 * @throws Exception
	 */
	public static boolean sendSms(String mobile, SmsTemplateEntity smsTemplateEntity, String... param) throws Exception{
		JsonObject templateParamJson = new JsonObject();
		Integer count = StringUtil.countStr(smsTemplateEntity.getTemplateContent(), "$");
		if(count==1){
			if(param.length!=1){
				throw new BusinessException("发送短信参数传递错误");
			}
			templateParamJson.addProperty(smsTemplateEntity.getParam1(), param[0]);
		}
		if(count==2){
			if(param.length!=2){
				throw new BusinessException("发送短信参数传递错误");
			}
			templateParamJson.addProperty(smsTemplateEntity.getParam1(), param[0]);
			templateParamJson.addProperty(smsTemplateEntity.getParam2(), param[1]);
		}
		if(count==3){
			if(param.length!=3){
				throw new BusinessException("发送短信参数传递错误");
			}
			templateParamJson.addProperty(smsTemplateEntity.getParam1(), param[0]);
			templateParamJson.addProperty(smsTemplateEntity.getParam2(), param[1]);
			templateParamJson.addProperty(smsTemplateEntity.getParam3(), param[2]);
		}
		if(count>3){
			throw new BusinessException("暂不支持大于3个变量参数的模板短信发送");
		}
		return sendSms(mobile, smsTemplateEntity.getTemplateCode(), templateParamJson.toString());
	}


	
	/**
	 * 发送短信
	 * @param mobile 手机号码
	 * @param templateCode 短信模板编号
	 * @param templateParamJson 短信参数内容json字符串，如：{"code":"988756"}
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("deprecation")
	public static boolean sendSms(String mobile, String templateCode, String templateParamJson) throws Exception {
		// 设置超时时间-可自行调整
		System.setProperty("sun.net.client.defaultConnectTimeout", "10000");
		System.setProperty("sun.net.client.defaultReadTimeout", "10000");
		// 初始化ascClient,暂时不支持多region（请勿修改）
		IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou", accessKeyId, accessKeySecret);
		DefaultProfile.addEndpoint("cn-hangzhou", "cn-hangzhou", product, domain);
		IAcsClient acsClient = new DefaultAcsClient(profile);
		// 组装请求对象
		SendSmsRequest request = new SendSmsRequest();
		// 使用post提交
		request.setMethod(MethodType.POST);
		// 必填:待发送手机号。支持以逗号分隔的形式进行批量调用，批量上限为1000个手机号码,批量调用相对于单条调用及时性稍有延迟,验证码类型的短信推荐使用单条调用的方式；发送国际/港澳台消息时，接收号码格式为00+国际区号+号码，如“0085200000000”
		request.setPhoneNumbers(mobile);
		// 必填:短信签名-可在短信控制台中找到
		request.setSignName("大立教育");
		// 必填:短信模板-可在短信控制台中找到，发送国际/港澳台消息时，请使用国际/港澳台短信模版
		request.setTemplateCode(templateCode);
		// 可选:模板中的变量替换JSON串,如模板内容为"亲爱的${name},您的验证码为${code}"时,此处的值为
		// 友情提示:如果JSON中需要带换行符,请参照标准的JSON协议对换行符的要求,比如短信内容中包含\r\n的情况在JSON中需要表示成\\r\\n,否则会导致JSON在服务端解析失败
		// request.setTemplateParam("{\"code\":\"988756\"}");
		request.setTemplateParam(templateParamJson);
		// 请求失败这里会抛ClientException异常
		SendSmsResponse sendSmsResponse = acsClient.getAcsResponse(request);
		if (sendSmsResponse.getCode() != null && sendSmsResponse.getCode().equals("OK")) {
			// 请求成功
			// System.out.println("=====success====");
			return true;
		} else {
			// System.out.println("=====fail=======");
			System.out.println("短信发送失败，返回状态码：" + sendSmsResponse.getCode());
			return false;
		}
	}
	

	
	public static void main(String[] args) {
		String str = "尊敬的用户，您在大立教育的的登录账号为${name}，密码为${password}，请不要把密码泄露给其他人。";
		System.out.println(StringUtil.countStr(str, "$"));

		JsonArray array = new JsonArray();
		JsonObject lan1 = new JsonObject();

		lan1.addProperty("id", 1);

		lan1.addProperty("name", "Java");

		lan1.addProperty("ide", "Eclipse");

		// 将 lan1 添加到 array
		array.add(lan1);

		System.out.println(array);
		System.out.println(lan1);
		System.out.println(lan1.toString());
	}
}
