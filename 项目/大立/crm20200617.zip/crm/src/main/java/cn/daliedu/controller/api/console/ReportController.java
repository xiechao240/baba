package cn.daliedu.controller.api.console;


import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.ContractEntity;
import cn.daliedu.entity.CustomerDynamicFileEntity;
import cn.daliedu.entity.CustomerTagEntity;
import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.json.ContractJson;
import cn.daliedu.entity.json.ContractModel;
import cn.daliedu.entity.json.CustomerJson;
import cn.daliedu.entity.json.CustomerModel;
import cn.daliedu.entity.json.GlobalJson;
import cn.daliedu.entity.json.OrgJson;
import cn.daliedu.entity.json.UserJson;
import cn.daliedu.entity.web.CustomerContactVO;
import cn.daliedu.entity.web.CustomerTagAndCountVO;
import cn.daliedu.enums.DynamicTypeEnum;
import cn.daliedu.enums.UserTypeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.ContractReturnMoneyPlanService;
import cn.daliedu.service.ContractService;
import cn.daliedu.service.CustomerCountService;
import cn.daliedu.service.CustomerService;
import cn.daliedu.service.CustomerTagService;
import cn.daliedu.service.OrgService;
import cn.daliedu.service.ReportService;
import cn.daliedu.service.UserCustomerCallService;
import cn.daliedu.service.UserService;
import cn.daliedu.util.ArithUtil;
import cn.daliedu.util.BigDecimalUtil;
import cn.daliedu.util.DateUtil;
import cn.daliedu.util.JsonUtil;
import cn.daliedu.util.LocalDateTimeUtil;
import cn.daliedu.util.PageUtil;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import cn.daliedu.util.TimerUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * <p>
 * 报表 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2019-10-31
 */
@Api(description = "报表模块所有接口（按echartsjs格式返回数据给前端）")
@RestController
@RequestMapping("${rest.path}/report")
public class ReportController {
	@Autowired
	ReportService reportService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	OrgService orgService;
	
	@Autowired
	ContractService contractService;
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	CustomerTagService customerTagService;
	
	@Autowired
	ContractReturnMoneyPlanService contractReturnMoneyPlanService;
	
	@Autowired
	UserCustomerCallService userCustomerCallService;
	
	@Autowired
	CustomerCountService customerCountService;
	
	
	@ApiOperation(value = "【客户标签变化统计】")
	@ApiJsonObject(name = "getCustomerTagUpdateCount", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.customerTagIds),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerTagUpdateCount")
	@RequiresPermissions("sys:report:customerTagUpdateCount:view")
	@PostMapping("/getCustomerTagUpdateCount")
	public Result getCustomerTagUpdateCount(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
				String customerTagIds = String.valueOf(jsonObject.get("customerTagIds"));
				
				StringUtil.validateIsNull(customerTagIds, "请选择客户标签");
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				
				
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            paramMap.put("branchOrgId", branchOrgId);
	            
	            
	            //客户选择的标签集合
	            List<String> customerTagIdList = JsonUtil.getJsonToList(customerTagIds, String.class);
	           
	            if(customerTagIdList!=null && customerTagIdList.size()>0){
	            	String customerTag = "";
    				for(String str : customerTagIdList){
    					customerTag = customerTag + "'" + str + "'" + ",";
    				}
    				paramMap.put("customerTagIds", customerTag.substring(0, customerTag.length()-1));
	            	
	            	//获取客户标签变化的用户
		            List<LinkedHashMap<Object, Object>> list = userService.getCustomerTagUpdateByUser(paramMap);
		            if(list!=null && list.size()>0){
		            	for(LinkedHashMap<Object, Object> map : list){
		            		List<CustomerTagAndCountVO> tempList = new ArrayList<CustomerTagAndCountVO>();
		            		for(String customerTagId : customerTagIdList){
		            			paramMap.put("userId", map.get("user_id"));
		            			paramMap.put("customerTagId", customerTagId);
		            			Integer customerTagIdCount = userService.getCustomerTagUpdateByCustomerTag(paramMap);
		            			
		            			CustomerTagAndCountVO vo = new CustomerTagAndCountVO();
		            			vo.setCustomerTagId(customerTagId);
		            			vo.setCustomerTagIdCount(customerTagIdCount);
		            			tempList.add(vo);
							}
		            		map.put("tagIdList", tempList);
			            }
		            	
		            	//添加合计这一项
		            	LinkedHashMap<Object, Object> dataCountMap = new LinkedHashMap<Object, Object>();
		            	dataCountMap.put("user_id", "");
		            	dataCountMap.put("user_name", "合计");
		            	
		            	List<CustomerTagAndCountVO> tempList = new ArrayList<CustomerTagAndCountVO>();
		            	for(String customerTagId : customerTagIdList){
	            			paramMap.put("customerTagId", customerTagId);
	            			Integer customerTagIdCount = userService.getCustomerTagUpdateByCustomerTagAllCount(paramMap);
	            			
	            			CustomerTagAndCountVO vo = new CustomerTagAndCountVO();
	            			vo.setCustomerTagId(customerTagId);
	            			vo.setCustomerTagIdCount(customerTagIdCount);
	            			tempList.add(vo);
						}
		            	dataCountMap.put("tagIdList", tempList);
		            	
		            	list.add(dataCountMap);
		            	
		            	return Result.success(list);
		            }else{
		            	return Result.error("当前分校下没有标签变化统计");
		            }
				}else{
					return Result.error("当前分校下没有标签变化统计");
				}
			}
			return Result.error("无法获取分校下的客户标签变化统计列表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("无法获取分校下的客户标签变化统计列表，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【电话联系统计】电话联系明细表，已经有返回通话总次数，接通次数")
	@ApiJsonObject(name = "getCallContactDetailCount", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCallContactDetailCount")
	@RequiresPermissions("sys:report:callContactDetailCount:view")
	@PostMapping("/getCallContactDetailCount")
	public Result getCallContactDetailCount(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
				
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            paramMap.put("branchOrgId", branchOrgId);
	            
	            
	            if(startDateTime.equals(endDateTime)){
	            	List<LinkedHashMap<Object, Object>> list = userService.getCallContactDetailCount(paramMap);
		            if(list!=null && list.size()>0){
		            	for(LinkedHashMap<Object, Object> map : list){
			            	//添加联系人数属性
			            	Integer contactCustomerCount = userService.getCallContactCustomerCount(paramMap);
			            	map.put("contact_customer_count", contactCustomerCount);
			            	map.put("date", startDateTime);
			            	
			            	TimerUtil tt = new TimerUtil();	
		            		tt.setSeconds(Integer.valueOf(map.get("call_time").toString()));//秒数
		            		String callTime = tt.getMinutes() + "分" + tt.getSeconds() + "秒";
		            		map.put("call_time", callTime);
			            }
		            	
		            	//添加合计这一项
		            	LinkedHashMap<Object, Object> dataCountMap = new LinkedHashMap<Object, Object>();
		            	
		            	List<LinkedHashMap<Object, Object>> dataCountList = userService.getCallContactDetailCount(paramMap);
		            	for(LinkedHashMap<Object, Object> map : dataCountList){
		            		TimerUtil tt = new TimerUtil();	
		            		tt.setSeconds(Integer.valueOf(map.get("call_time").toString()));//秒数
		            		String callTime = tt.getMinutes() + "分" + tt.getSeconds() + "秒";
		            		
		            		dataCountMap.put("success_rate", map.get("success_rate"));
		            		dataCountMap.put("call_time", callTime);
		            		dataCountMap.put("call_count", map.get("call_count"));
		            		dataCountMap.put("call_count_success", map.get("call_count_success"));
		            		dataCountMap.put("call_avg_time", map.get("call_avg_time"));
		            	}
		            	Integer contactCustomerCount = userService.getCallContactCustomerCount(paramMap);
		            	dataCountMap.put("contact_customer_count", contactCustomerCount);
		            	dataCountMap.put("date", "合计");
		            	
		            	list.add(dataCountMap);
		            	
		            	return Result.success(list);
		            }else{
		            	return Result.error("当前用户下没有电话联系统计");
		            }
	            }else{
	            	List<Object> dataList = new ArrayList<Object>();
	            	
	            	List<String> dateList = DateUtil.getDatesBetweenTwoDate(startDateTime, endDateTime);
		            for(String date : dateList){
		            	paramMap.put("startDateTime", date);
			            paramMap.put("endDateTime", date);
		            	List<LinkedHashMap<Object, Object>> list = userService.getCallContactDetailCount(paramMap);
		            	
			            if(list!=null && list.size()>0){
			            	for(LinkedHashMap<Object, Object> map : list){
				            	//添加联系人数属性
				            	Integer contactCustomerCount = userService.getCallContactCustomerCount(paramMap);
				            	map.put("contact_customer_count", contactCustomerCount);
				            	map.put("date", date);
				            	
				            	TimerUtil tt = new TimerUtil();	
			            		tt.setSeconds(Integer.valueOf(map.get("call_time").toString()));//秒数
			            		String callTime = tt.getMinutes() + "分" + tt.getSeconds() + "秒";
			            		map.put("call_time", callTime);
			            		
				            	dataList.add(map);
				            }
			            }
		            }
		            
		            paramMap.put("startDateTime", startDateTime);
		            paramMap.put("endDateTime", endDateTime);
	            	//添加合计这一项
	            	LinkedHashMap<Object, Object> dataCountMap = new LinkedHashMap<Object, Object>();
	            	
	            	List<LinkedHashMap<Object, Object>> list = userService.getCallContactDetailCount(paramMap);
	            	for(LinkedHashMap<Object, Object> map : list){
	            		TimerUtil tt = new TimerUtil();	
	            		tt.setSeconds(Integer.valueOf(map.get("call_time").toString()));//秒数
	            		String callTime = tt.getMinutes() + "分" + tt.getSeconds() + "秒";
	            		
	            		dataCountMap.put("success_rate", map.get("success_rate"));
	            		dataCountMap.put("call_time", callTime);
	            		dataCountMap.put("call_count", map.get("call_count"));
	            		dataCountMap.put("call_count_success", map.get("call_count_success"));
	            		dataCountMap.put("call_avg_time", map.get("call_avg_time"));
	            	}
	            	Integer contactCustomerCount = userService.getCallContactCustomerCount(paramMap);
	            	dataCountMap.put("contact_customer_count", contactCustomerCount);
	            	dataCountMap.put("date", "合计");
	            	
	            	
	            	dataList.add(dataCountMap);
	            	
	            	return Result.success(dataList);
	            }
			}
			return Result.error("无法获取电话联系统计列表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("无法获取电话联系统计列表，失败原因：" + e.getMessage());
		}
	}
	
//	@ApiOperation(value = "【工作效率统计报表】总联系次数(图形数据出来，再做实现)")
//	@ApiJsonObject(name = "getWorkEfficiencyReportByContactCount", value = { 
//			@ApiJsonProperty(name = OrgJson.branchOrgId),
//			@ApiJsonProperty(name = CustomerJson.startDateTime),
//			@ApiJsonProperty(name = CustomerJson.endDateTime)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "getWorkEfficiencyReportByContactCount")
//	@RequiresPermissions("sys:report:workEfficiency:view")
//	@PostMapping("/getWorkEfficiencyReportByContactCount")
//	public Result getWorkEfficiencyReportByContactCount(@RequestBody String params) {
//		return null;
//	}
//	
//	@ApiOperation(value = "【工作效率统计报表】跟进记录数(图形数据出来，再做实现)")
//	@ApiJsonObject(name = "getWorkEfficiencyReportByFollowRecore", value = { 
//			@ApiJsonProperty(name = OrgJson.branchOrgId),
//			@ApiJsonProperty(name = CustomerJson.startDateTime),
//			@ApiJsonProperty(name = CustomerJson.endDateTime)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "getWorkEfficiencyReportByFollowRecore")
//	@RequiresPermissions("sys:report:workEfficiency:view")
//	@PostMapping("/getWorkEfficiencyReportByFollowRecore")
//	public Result getWorkEfficiencyReportByFollowRecore(@RequestBody String params) {
//		return null;
//	}
//	
//	@ApiOperation(value = "【工作效率统计报表】电话(图形数据出来，再做实现)")
//	@ApiJsonObject(name = "getWorkEfficiencyReportByCall", value = { 
//			@ApiJsonProperty(name = OrgJson.branchOrgId),
//			@ApiJsonProperty(name = CustomerJson.startDateTime),
//			@ApiJsonProperty(name = CustomerJson.endDateTime)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "getWorkEfficiencyReportByCall")
//	@RequiresPermissions("sys:report:workEfficiency:view")
//	@PostMapping("/getWorkEfficiencyReportByCall")
//	public Result getWorkEfficiencyReportByCall(@RequestBody String params) {
//		return null;
//	}
//	
//	@ApiOperation(value = "【工作效率统计报表】联系客户(图形数据出来，再做实现)")
//	@ApiJsonObject(name = "getWorkEfficiencyReportByContactCustomer", value = { 
//			@ApiJsonProperty(name = OrgJson.branchOrgId),
//			@ApiJsonProperty(name = CustomerJson.startDateTime),
//			@ApiJsonProperty(name = CustomerJson.endDateTime)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "getWorkEfficiencyReportByContactCustomer")
//	@RequiresPermissions("sys:report:workEfficiency:view")
//	@PostMapping("/getWorkEfficiencyReportByContactCustomer")
//	public Result getWorkEfficiencyReportByContactCustomer(@RequestBody String params) {
//		return null;
//	}
//	
//	
//	@ApiOperation(value = "【工作效率统计报表】新增客户(图形数据出来，再做实现)")
//	@ApiJsonObject(name = "getWorkEfficiencyReportByAddCustomer", value = { 
//			@ApiJsonProperty(name = OrgJson.branchOrgId),
//			@ApiJsonProperty(name = CustomerJson.startDateTime),
//			@ApiJsonProperty(name = CustomerJson.endDateTime)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "getWorkEfficiencyReportByAddCustomer")
//	@RequiresPermissions("sys:report:workEfficiency:view")
//	@PostMapping("/getWorkEfficiencyReportByAddCustomer")
//	public Result getWorkEfficiencyReportByAddCustomer(@RequestBody String params) {
//		return null;
//	}
	
	
	@ApiOperation(value = "【工作效率统计报表】")
	@ApiJsonObject(name = "getWorkEfficiencyReport", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime),
			@ApiJsonProperty(name = GlobalJson.pageNum), 
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getWorkEfficiencyReport")
	@RequiresPermissions("sys:report:workEfficiency:view")
	@PostMapping("/getWorkEfficiencyReport")
	public Result getWorkEfficiencyReport(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				
	            
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            paramMap.put("branchOrgId", branchOrgId);
	            
	            
	            List<LinkedHashMap<Object, Object>> list = userService.getAddCustomerCountTopList(paramMap);
	            for(LinkedHashMap<Object, Object> map : list){
	            	//1.把联系客户数添加进来
	            	paramMap.put("userId", map.get("user_id"));
	            	BigDecimal contactCustomerCount = reportService.getContactCustomerCount(paramMap);
	            	map.put("contact_customer_count", contactCustomerCount);
	            	//2.把电话次数添加进来
	            	BigDecimal callCount = reportService.getCallCount(paramMap);
	            	map.put("call_count", callCount);
	            	//3.跟进记录数添加进来(新建客户，修改客户资料不算跟进记录)
	            	BigDecimal followRecoreCount = reportService.getFollowRecoreCount(paramMap);
	            	map.put("follow_recore_count", followRecoreCount);
	            	//4.把总联系次数添加进来
	            	map.put("all_contact_count", BigDecimalUtil.add(callCount, followRecoreCount));
	            }
	            
	            if(list!=null && list.size()>0){
	            	Long total = userService.getAddCustomerCountTopListCount(paramMap);
					
					IPage page  = new Page();
					page.setTotal(total.longValue());
					page.setSize(Long.parseLong(pageSize));
					page.setRecords(list);
					return Result.success(page);
	            }
	            
	            return Result.error("当前用户下没有工作效率统计");
			}
			return Result.error("无法获取工作效率统计列表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("无法工作效率统计列表，失败原因：" + e.getMessage());
		}
	}
	
	
	
	@ApiOperation(value = "【客户活跃度统计报表】")
	@ApiJsonObject(name = "getCustomerActivenessReport", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerActivenessReport")
	@RequiresPermissions("sys:report:customerActiveness:view")
	@PostMapping("/getCustomerActivenessReport")
	public Result getCustomerActivenessReport(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
				
	            
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            
	            if(branchOrgId!=null && !branchOrgId.equals("") && !branchOrgId.equals("null")){
	            	paramMap.put("branchOrgId", branchOrgId);
	            }
//	            else{
//	            	//加载用户当前能访问的分校范围
//	            	paramMap.put("branchOrgId", branchOrgId);
//	            	List<OrgEntity> list = orgService.getBranchOrgByUserId(bean.getId());
//	            	if(list!=null && list.size()>0){
//	            		String orgId = "";
//	    				for(OrgEntity entity : list){
//	    					orgId = orgId + "'" + entity.getId() + "'" + ",";
//	    				}
//	    				paramMap.put("branchOrgId", orgId.substring(0, orgId.length()-1));
//	            	}
//	            }
	            
	            //如果是admin超级管理员账号，则统计整个公司的客户数，如果是普通管理员，则统计用户能查看的分校范围的客户或指定的某一个分校的客户
	            //这个表格，客户联系次数，需要带上客户的创建时间去统计，所以下面这个参数要改为map,不仅要统计分校，还要统计创建时间
//	            BigDecimal customerAllCount = customerService.getBranchCustomerCount(branchOrgId);
	            BigDecimal customerAllCount = customerService.getCustomerContactCount(paramMap);
	            
	            //客户联系次数统计list
	            List<CustomerContactVO> contactNumList = new ArrayList<CustomerContactVO>();
	            
	            //1.统计联系1次的客户数
	            paramMap.put("contactNum", 1);
	            BigDecimal num1 = customerService.getCustomerContactCount(paramMap);
	            
	            CustomerContactVO contactNum1 = new CustomerContactVO();
	            contactNum1.setContactName("1次");
	            contactNum1.setCustomerCount(num1);
	            contactNum1.setPercentage(BigDecimalUtil.divide(num1, customerAllCount));
	            
	            //2.统计联系2次的客户数
	            paramMap.put("contactNum", 2);
	            BigDecimal num2 = customerService.getCustomerContactCount(paramMap);
	            
	            CustomerContactVO contactNum2 = new CustomerContactVO();
	            contactNum2.setContactName("2次");
	            contactNum2.setCustomerCount(num2);
	            contactNum2.setPercentage(BigDecimalUtil.divide(num2, customerAllCount));
	            
	            //3.统计联系3次的客户数
	            paramMap.put("contactNum", 3);
	            BigDecimal num3 = customerService.getCustomerContactCount(paramMap);
	            
	            CustomerContactVO contactNum3 = new CustomerContactVO();
	            contactNum3.setContactName("3次");
	            contactNum3.setCustomerCount(num3);
	            contactNum3.setPercentage(BigDecimalUtil.divide(num3, customerAllCount));
	            
	            //4.统计联系4次及以上的客户数
	            paramMap.put("contactNum", 4);
	            BigDecimal num4 = customerService.getCustomerContactCount(paramMap);
	            
	            CustomerContactVO contactNum4 = new CustomerContactVO();
	            contactNum4.setContactName("4次及以上");
	            contactNum4.setCustomerCount(num4);
	            contactNum4.setPercentage(BigDecimalUtil.divide(num4, customerAllCount));
	            
	            //5.统计未联系的客户数
	            BigDecimal num0 = BigDecimalUtil.subtract(customerAllCount, num1, num2, num3, num4);
	            
	            CustomerContactVO contactNum0 = new CustomerContactVO();
	            contactNum0.setContactName("未联系");
	            contactNum0.setCustomerCount(BigDecimalUtil.divide(num0, customerAllCount));
	            contactNum0.setPercentage(BigDecimalUtil.divide(num0, customerAllCount));
	            
	            
	            //6.统计合计的客户数
	            CustomerContactVO contactNumAll = new CustomerContactVO();
	            contactNumAll.setContactName("合计");
	            contactNumAll.setCustomerCount(customerAllCount);
	            contactNumAll.setPercentage(BigDecimalUtil.divide(customerAllCount, customerAllCount));
	            
	            
	            contactNumList.add(contactNum0);
	            contactNumList.add(contactNum1);
	            contactNumList.add(contactNum2);
	            contactNumList.add(contactNum3);
	            contactNumList.add(contactNum4);
	            contactNumList.add(contactNumAll);
	            
	            
	            //客户最近联系时间统计list
	            List<CustomerContactVO> latelyContactList = new ArrayList<CustomerContactVO>();
	            //去除日期，重新统计客户总数,因为上面的是统计一段时间范围内创建的客户数，再去做统计报表，下面的表格为：统计全分校或全公司的客户
	            paramMap.remove("startDateTime");
	            paramMap.remove("endDateTime");
	            customerAllCount = customerService.getBranchCustomerCount(paramMap);
	           
	            //1.统计7天内联系的客户
	    		paramMap.put("startDateTime", DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-7), "yyyy-MM-dd"));
		        paramMap.put("endDateTime", DateUtil.getCurrentDateString("yyyy-MM-dd"));
		        BigDecimal lately1 = customerService.getLatelyContactCustomerCount(paramMap);
		        
		        CustomerContactVO latelyNum1 = new CustomerContactVO();
		        latelyNum1.setContactName("7天内");
		        latelyNum1.setCustomerCount(lately1);
		        latelyNum1.setPercentage(BigDecimalUtil.divide(lately1, customerAllCount));
		        
	            //2.统计8-30天内联系的客户
		        paramMap.put("startDateTime", DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-30), "yyyy-MM-dd"));
		        paramMap.put("endDateTime", DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-8), "yyyy-MM-dd"));
		        BigDecimal lately2 = customerService.getLatelyContactCustomerCount(paramMap);
		        
		        CustomerContactVO latelyNum2 = new CustomerContactVO();
		        latelyNum2.setContactName("8-30天内");
		        latelyNum2.setCustomerCount(lately2);
		        latelyNum2.setPercentage(BigDecimalUtil.divide(lately2, customerAllCount));
		        
	            //3.统计31-60天内联系的客户
		        paramMap.put("startDateTime", DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-60), "yyyy-MM-dd"));
		        paramMap.put("endDateTime", DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-31), "yyyy-MM-dd"));
		        BigDecimal lately3 = customerService.getLatelyContactCustomerCount(paramMap);
		        
		        CustomerContactVO latelyNum3 = new CustomerContactVO();
		        latelyNum3.setContactName("31-60天内");
		        latelyNum3.setCustomerCount(lately3);
		        latelyNum3.setPercentage(BigDecimalUtil.divide(lately3, customerAllCount));
		        
	            //4.统计60天以上联系的客户
		        paramMap.put("startDateTime", DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-5000), "yyyy-MM-dd"));//开始时间设置一个超大的值，少写一个方法，通用性更强
		        paramMap.put("endDateTime", DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-61), "yyyy-MM-dd"));
		        BigDecimal lately4 = customerService.getLatelyContactCustomerCount(paramMap);
		        
		        CustomerContactVO latelyNum4 = new CustomerContactVO();
		        latelyNum4.setContactName("60天以上");
		        latelyNum4.setCustomerCount(lately4);
		        latelyNum4.setPercentage(BigDecimalUtil.divide(lately4, customerAllCount));
		        
	            //5.统计未联系的客户
		        BigDecimal lately0 = BigDecimalUtil.subtract(customerAllCount, lately1, lately2, lately3, lately4);
		        
		        CustomerContactVO latelyNum0 = new CustomerContactVO();
		        latelyNum0.setContactName("未联系");
		        latelyNum0.setCustomerCount(BigDecimalUtil.divide(lately0, customerAllCount));
		        latelyNum0.setPercentage(BigDecimalUtil.divide(lately0, customerAllCount));
		        
	            //6.统计合计的客户数
		        CustomerContactVO latelyNumAll = new CustomerContactVO();
		        latelyNumAll.setContactName("合计");
		        latelyNumAll.setCustomerCount(customerAllCount);
		        latelyNumAll.setPercentage(BigDecimalUtil.divide(customerAllCount, customerAllCount));
		        
	            
		        latelyContactList.add(latelyNum1);
		        latelyContactList.add(latelyNum2);
		        latelyContactList.add(latelyNum3);
		        latelyContactList.add(latelyNum4);
		        latelyContactList.add(latelyNum0);
		        latelyContactList.add(latelyNumAll);
	            
	            Map<String, List<CustomerContactVO>> allDataMap = new HashMap<String, List<CustomerContactVO>>();
	            allDataMap.put("contactNumList", contactNumList);
	            allDataMap.put("latelyContactList", latelyContactList);
	            
	            if(allDataMap!=null && allDataMap.size()>0){
	            	return Result.success(allDataMap);
	            }
	            
	            return Result.error("当前用户下没有客户活跃度统计");
			}
			return Result.error("无法获取客户活跃度统计列表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("无法获取客户活跃度统计列表，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【员工联系记录】原型界面上，联系方式--》跟进记录，是不需要的,应该是联系方式--》电话，手机，前端根据返回的call_type：通话类型，转化显示：座机（呼出）")
	@ApiJsonObject(name = "getCallContactRecord", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.customerNameOrMobile),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime),
			@ApiJsonProperty(name = CustomerJson.callType),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCallContactRecord")
	@RequiresPermissions("sys:report:callContactRecord:view")
	@PostMapping("/getCallContactRecord")
	public Result getCallContactRecord(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
				String customerNameOrMobile = String.valueOf(jsonObject.get("customerNameOrMobile"));
				String callType = String.valueOf(jsonObject.get("callType"));
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				
	            
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	    		
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            paramMap.put("customerNameOrMobile", customerNameOrMobile);
	            paramMap.put("branchOrgId", branchOrgId);
	            paramMap.put("callType", callType);
	            
	            
	            
	            List<LinkedHashMap<Object, Object>> list = userCustomerCallService.getCallContactRecordList(paramMap);
	            if(list!=null && list.size()>0){
	            	for(LinkedHashMap<Object, Object> map : list){
	            		String startTime = map.get("start_time").toString();
	            		map.put("start_time", LocalDateTimeUtil.getDateTime(startTime));
	            	}
					Long total = userCustomerCallService.getCallContactRecordListCount(paramMap);
					
					IPage page  = new Page();
					page.setTotal(total.longValue());
					page.setSize(Long.parseLong(pageSize));
					page.setRecords(list);
					return Result.success(page);
				}
	            return Result.error("当前用户下员工联系记录统计");
			}
			return Result.error("无法获取员工联系记录统计列表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("无法获取员工联系记录统计列表，失败原因：" + e.getMessage());
		}
	}
	
	
	
	
	@ApiOperation(value = "【电话排名】电话联系统计表(带分页),目前只实现按分校进行排名，后续再实现按部门排名，有返回接通总次数，接通次数，原型上少了接通次数")
	@ApiJsonObject(name = "getCallRankingByContact", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.orderbyParam),
			@ApiJsonProperty(name = CustomerJson.sortType),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCallRankingByContact")
	@RequiresPermissions("sys:report:callRanking:view")
	@PostMapping("/getCallRankingByContact")
	public Result getCallRankingByContact(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
				String orderbyParam = String.valueOf(jsonObject.get("orderbyParam"));
				String sortType = String.valueOf(jsonObject.get("sortType"));
				
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				
	            
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	    		
	            paramMap.put("userId", bean.getId());
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            paramMap.put("branchOrgId", branchOrgId);
	            paramMap.put("oderbyParam", orderbyParam);
	            paramMap.put("oderbyParam", sortType);
	            
	            
	            List<LinkedHashMap<Object, Object>> list = userService.getCallRankingByContactList(paramMap);
	            if(list!=null && list.size()>0){
					Long total = userService.getCallRankingByContactListCount(paramMap);
					
					IPage page  = new Page();
					page.setTotal(total.longValue());
					page.setSize(Long.parseLong(pageSize));
					page.setRecords(list);
					return Result.success(page);
				}
	            return Result.error("当前用户下没有电话联系统计");
			}
			return Result.error("无法获取电话联系统计列表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("无法获取电话联系统计列表，失败原因：" + e.getMessage());
		}
	}
	
	
	
	@ApiOperation(value = "【合同回款金额统计】，传入用户ID查看用户下所有的合同回款情况",
			notes = "returnType,1:返回分校下的合同统计结果，2：返回分校下的部门合同统计结果，3：返回分校下的用户合同统计结果，4：返回部门下的用户合同统计结果   5:返回用户下的所有合同统计结果")
	@ApiJsonObject(name = "getContractReturnMoneyListByUserId", value = {
			@ApiJsonProperty(name = UserJson.userId),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getContractReturnMoneyListByUserId")
	@RequiresPermissions("sys:report:contractReturnMoneyList:view")
	@PostMapping("/getContractReturnMoneyListByUserId")
	public Result getContractReturnMoneyListByUserId(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				UserEntity user = userService.getById(bean.getId());
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String userId = String.valueOf(jsonObject.get("userId"));
				
				StringUtil.validateIsNull(userId, "请输入用户ID");
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				

				Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            paramMap.put("userId", userId);
	            
	            
	            List<LinkedHashMap<Object, Object>> list =  contractService.getContractListByUserId(paramMap);
	            for(LinkedHashMap<Object, Object> map : list){
	            	String contractId = map.get("id").toString();
	            	HashMap<Object, Object> contractReturnMoneyMap = reportService.findContractReturnMoneyCount(contractId);
					map.put("returnType", "5");//返回返回用户下的所有合同统计结果
					if(contractReturnMoneyMap!=null && contractReturnMoneyMap.size()>0){
						String str = StringUtil.nullValueConvert(contractReturnMoneyMap.get("already_return_money"));
						map.put("alreadyReturnMoney", str.equals("") ? 0 : str);
						map.put("noReturnMoney", contractReturnMoneyMap.get("no_return_money"));
					}else{
						map.put("alreadyReturnMoney", "0");
						map.put("noReturnMoney", "0");
					}
	            }
	            
	            if(list!=null && list.size()>0){
					return Result.success(list);
				}
	            return Result.error("当前无数据");
			}
			return Result.error("无法获取用户下的销售金额统计报表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取用户下的部门销售金额统计报表失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "【合同回款金额统计】，传入分校下的部门ID查看部门下的用户的销售情况",
			notes = "returnType,1:返回分校下的合同统计结果，2：返回分校下的部门合同统计结果，3：返回分校下的用户合同统计结果，4：返回部门下的用户合同统计结果   5:返回用户下的所有合同统计结果")
	@ApiJsonObject(name = "getContractReturnMoneyListByOrgId", value = {
			@ApiJsonProperty(name = OrgJson.orgId),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getContractReturnMoneyListByOrgId")
	@RequiresPermissions("sys:report:contractReturnMoneyList:view")
	@PostMapping("/getContractReturnMoneyListByOrgId")
	public Result getContractReturnMoneyListByOrgId(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				UserEntity user = userService.getById(bean.getId());
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String orgId = String.valueOf(jsonObject.get("orgId"));
				
				StringUtil.validateIsNull(orgId, "请输入部门ID");
				

				Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            paramMap.put("orgId", orgId);
	            
	            List<LinkedHashMap<Object, Object>> list = new ArrayList<LinkedHashMap<Object, Object>>();
	            
	            List<UserEntity> userList = userService.getUserListByOrgId(orgId);
            	//按用户统计每个用户的销售情况
            	for(UserEntity entity : userList){
            		LinkedHashMap<Object, Object> map = new LinkedHashMap<Object, Object>();
					map.put("userId", entity.getId());
					map.put("userName", entity.getUserName());
					map.put("returnType", "4");//返回部门下的用户合同统计结果
					
					//统计合同数，合同总金额
					HashMap<Object, Object> contractCountMap = reportService.findUserIdContractCount(paramMap);
					if(contractCountMap!=null && contractCountMap.size()>0 && Integer.parseInt(contractCountMap.get("contract_count").toString())>0){
						map.put("contractCount", contractCountMap.get("contract_count"));
						map.put("amount", contractCountMap.get("amount"));
					}else{
						map.put("contractCount", "0");
						map.put("amount", "0");
					}
					
					//已回款金额，未回款金额
					HashMap<Object, Object> contractReturnMoneyMap = reportService.findUserIdContractReturnMoneyCount(paramMap);
					if(contractReturnMoneyMap!=null && contractReturnMoneyMap.size()>0){
						String str = StringUtil.nullValueConvert(contractReturnMoneyMap.get("already_return_money"));
						map.put("alreadyReturnMoney", str.equals("") ? 0 : str);
						map.put("noReturnMoney", contractReturnMoneyMap.get("no_return_money"));
					}else{
						map.put("alreadyReturnMoney", "0");
						map.put("noReturnMoney", "0");
					}
					
					list.add(map);
            	}
	            
	            if(list!=null && list.size()>0){
					return Result.success(list);
				}
	            return Result.error("当前无数据");
			}
			return Result.error("无法获取分校下的部门销售金额统计报表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取分校下的部门销售金额统计报表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【合同回款金额统计】，传入分校ID查看分校下的部门（或用户）的销售情况，如果分校下没有部门，将返回分校下的用户的销售情况",
			notes = "returnType,1:返回分校下的合同统计结果，2：返回分校下的部门合同统计结果，3：返回分校下的用户合同统计结果，4：返回部门下的用户合同统计结果   5:返回用户下的所有合同统计结果")
	@ApiJsonObject(name = "getContractReturnMoneyListBybranchOrgId", value = {
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getContractReturnMoneyListBybranchOrgId")
	@RequiresPermissions("sys:report:contractReturnMoneyList:view")
	@PostMapping("/getContractReturnMoneyListBybranchOrgId")
	public Result getContractReturnMoneyListBybranchOrgId(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
//				UserEntity user = userService.getById(bean.getId());
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
				
				StringUtil.validateIsNull(branchOrgId, "请输入分校ID");
				

				Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            
	            List<LinkedHashMap<Object, Object>> list = new ArrayList<LinkedHashMap<Object, Object>>();
	            
	            //校验此分校下面是否存在部门，如果无部门，则直接返回这个部门下面的每个员工的合同统计结果集
	            List<OrgEntity> orgList = orgService.getNextLevelOrgByOrgId(branchOrgId);
	            if(orgList!=null && orgList.size()>0){
	            	//按部门统计每个部门的销售情况
	            	for(OrgEntity entity : orgList){
						LinkedHashMap<Object, Object> map = new LinkedHashMap<Object, Object>();
						map.put("orgId", entity.getId());
						map.put("orgName", entity.getOrgName());
						map.put("returnType", "2");//给前端做判断使用，返回类型为2：返回分校下的部门合同统计结果集
						paramMap.put("orgId", entity.getId());//添加部门参数去按部门查询
						
						//统计合同数，合同总金额
						HashMap<Object, Object> contractCountMap = reportService.findOrgIdContractCount(paramMap);
						if(contractCountMap!=null && contractCountMap.size()>0 && Integer.parseInt(contractCountMap.get("contract_count").toString())>0){
							map.put("contractCount", contractCountMap.get("contract_count"));
							map.put("amount", contractCountMap.get("amount"));
						}else{
							map.put("contractCount", "0");
							map.put("amount", "0");
						}
						
						//已回款金额，未回款金额
						HashMap<Object, Object> contractReturnMoneyMap = reportService.findOrgIdContractReturnMoneyCount(paramMap);
						if(contractReturnMoneyMap!=null && contractReturnMoneyMap.size()>0){
							String str = StringUtil.nullValueConvert(contractReturnMoneyMap.get("already_return_money"));
							map.put("alreadyReturnMoney", str.equals("") ? 0 : str);
							map.put("noReturnMoney", contractReturnMoneyMap.get("no_return_money"));
						}else{
							map.put("alreadyReturnMoney", "0");
							map.put("noReturnMoney", "0");
						}
						
						list.add(map);
					}
	            }else{
	            	//如果无部门
	            	Map<Object, Object> mm = new HashMap<>();
	            	mm.put("branchOrgId", branchOrgId);
	            	List<UserEntity> userList = userService.getUserListByBranchOrgId(mm);
	            	//按用户统计每个用户的销售情况
	            	for(UserEntity entity : userList){
	            		LinkedHashMap<Object, Object> map = new LinkedHashMap<Object, Object>();
						map.put("orgId", entity.getId());
						map.put("userName", entity.getUserName());
						map.put("returnType", "3");//给前端做判断使用，返回类型为3：返回分校下的用户合同统计结果集
						paramMap.put("userId", entity.getId());//添加用户参数去按用户查询
						
						//统计合同数，合同总金额
						HashMap<Object, Object> contractCountMap = reportService.findUserIdContractCount(paramMap);
						if(contractCountMap!=null && contractCountMap.size()>0 && Integer.parseInt(contractCountMap.get("contract_count").toString())>0){
							map.put("contractCount", contractCountMap.get("contract_count"));
							map.put("amount", contractCountMap.get("amount"));
						}else{
							map.put("contractCount", "0");
							map.put("amount", "0");
						}
						
						//已回款金额，未回款金额
						HashMap<Object, Object> contractReturnMoneyMap = reportService.findUserIdContractReturnMoneyCount(paramMap);
						if(contractReturnMoneyMap!=null && contractReturnMoneyMap.size()>0){
							String str = StringUtil.nullValueConvert(contractReturnMoneyMap.get("already_return_money"));
							map.put("alreadyReturnMoney", str.equals("") ? 0 : str);
							map.put("noReturnMoney", contractReturnMoneyMap.get("no_return_money"));
						}else{
							map.put("alreadyReturnMoney", "0");
							map.put("noReturnMoney", "0");
						}
						
						list.add(map);
	            	}
	            }
	            
	            if(list!=null && list.size()>0){
					return Result.success(list);
				}
	            return Result.error("当前无数据");
			}
			return Result.error("无法获取分校下的销售金额统计报表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取分校下的销售金额统计报表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【合同回款金额统计】，分校统计报表（原型界面上的，员工/部门 筛选条件没什么作用，因为结果集就已经是按分校进行展现的）",
			notes = "returnType,1:返回分校下的合同统计结果，2：返回分校下的部门合同统计结果，3：返回分校下的用户合同统计结果，4：返回部门下的用户合同统计结果   5:返回用户下的所有合同统计结果")
	@ApiJsonObject(name = "getContractReturnMoneyList", value = { 
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getContractReturnMoneyList")
	@RequiresPermissions("sys:report:contractReturnMoneyList:view")
	@PostMapping("/getContractReturnMoneyList")
	public Result getContractReturnMoneyList(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				UserEntity user = userService.getById(bean.getId());
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				
				

				Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            
	            //如果前端传入了分校id，则执行如下的逻辑（以后如果原型修改，需要传分校，则放开下面这段代码即可）
//	            if(orgIds!=null && !orgIds.equals("null") && !orgIds.equals("")){
//					List<String> orgIdList = JsonHelper.getJsonToList(orgIds, String.class);
//					String orgId = "";
//					for(String str : orgIdList){
//						orgId = orgId + "'" + str + "'" + ",";
//					}
//					paramMap.put("orgIds", orgId.substring(0, orgId.length()-1));
//				}else{
					//如果前端没传分校id，则判断用户能查看到的分校范围进行判断
//					List<OrgEntity> list = orgService.getBranchOrgByUserId(user.getId());
//					String orgId = "";
//					for(OrgEntity entity : list){
//						orgId = orgId + "'" + entity.getId() + "'" + ",";
//					}
//					paramMap.put("orgIds", orgId.substring(0, orgId.length()-1));
//				}
	            
	            List<OrgEntity> orgList = orgService.getBranchOrgByUserId(user.getId());
				String orgId = "";
				for(OrgEntity entity : orgList){
					orgId = orgId + "'" + entity.getId() + "'" + ",";
				}
				paramMap.put("orgId", orgId.substring(0, orgId.length()-1));
				
				List<LinkedHashMap<Object, Object>> list = new ArrayList<LinkedHashMap<Object, Object>>();
				//分别统计每个分校的，合同数，合同总金额，已回款金额，未回款金额
				for(OrgEntity entity : orgList){
					LinkedHashMap<Object, Object> map = new LinkedHashMap<Object, Object>();
					map.put("orgId", entity.getId());
					map.put("orgName", entity.getOrgName());
					map.put("returnType", "1");//给前端做判断使用，返回类型为1：返回分校下合同统计结果集
					
					//统计合同数，合同总金额
					HashMap<Object, Object> contractCountMap = reportService.findbranchOrgIdContractCount(paramMap);
					if(contractCountMap!=null && contractCountMap.size()>0 && Integer.parseInt(contractCountMap.get("contract_count").toString())>0){
						map.put("contractCount", contractCountMap.get("contract_count"));
						map.put("amount", contractCountMap.get("amount"));
					}else{
						map.put("contractCount", "0");
						map.put("amount", "0");
					}
					
					//已回款金额，未回款金额
					HashMap<Object, Object> contractReturnMoneyMap = reportService.findbranchOrgIdContractReturnMoneyCount(paramMap);
					if(contractReturnMoneyMap!=null && contractReturnMoneyMap.size()>0){
						String str = StringUtil.nullValueConvert(contractReturnMoneyMap.get("already_return_money"));
						map.put("alreadyReturnMoney", str.equals("") ? 0 : str);
						map.put("noReturnMoney", contractReturnMoneyMap.get("no_return_money"));
					}else{
						map.put("alreadyReturnMoney", "0");
						map.put("noReturnMoney", "0");
					}
					
					list.add(map);
				}
				
	            
	            if(list!=null && list.size()>0){
					return Result.success(list);
				}
	            return Result.error("当前无数据");
			}
			return Result.error("无法获取销售金额统计，合同回款金额统计报表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取销售金额统计，合同回款金额统计报表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
	
	@ApiOperation(value = "【回款管理报表】(合同属于用户，因为谁创建的合同业绩就归谁), 查负责人列表，传入分校orgId，调用findUserByOrgId接口")
	@ApiJsonObject(name = "getContractReturnMoneyPlanList", value = { 
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime),
			@ApiJsonProperty(name = UserJson.orgIds),
			@ApiJsonProperty(name = ContractJson.createUserId),
			@ApiJsonProperty(name = ContractJson.returnMoneyState),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getContractReturnMoneyPlanList")
	@RequiresPermissions("sys:report:contractReturnMoneyPlanList:view")
	@PostMapping("/getContractReturnMoneyPlanList")
	public Result getContractReturnMoneyPlanList(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				UserEntity user = userService.getById(bean.getId());
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String createUserId = String.valueOf(jsonObject.get("createUserId"));
				String orgIds = String.valueOf(jsonObject.get("orgIds"));
				String returnMoneyState = String.valueOf(jsonObject.get("returnMoneyState"));
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				

				Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            paramMap.put("createUserId", createUserId);
	            paramMap.put("returnMoneyState", returnMoneyState);
	            
	            //如果前端传入了分校id，则执行如下的逻辑
	            if(orgIds!=null && !orgIds.equals("null") && !orgIds.equals("")){
					List<String> orgIdList = JsonUtil.getJsonToList(orgIds, String.class);
					String orgId = "";
					for(String str : orgIdList){
						orgId = orgId + "'" + str + "'" + ",";
					}
					paramMap.put("orgIds", orgId.substring(0, orgId.length()-1));
				}else{
					//如果前端没传分校id，则判断用户能查看到的分校范围进行判断
					List<OrgEntity> orgList = orgService.getBranchOrgByUserId(user.getId());
					String orgId = "";
					for(OrgEntity entity : orgList){
						orgId = orgId + "'" + entity.getId() + "'" + ",";
					}
					paramMap.put("orgIds", orgId.substring(0, orgId.length()-1));
				}

	            
	            List<LinkedHashMap<Object, Object>> list = contractReturnMoneyPlanService.getContractReturnMoneyPlanList(paramMap);
	            if(list!=null && list.size()>0){
	            	
					Long total = contractReturnMoneyPlanService.getContractReturnMoneyPlanListCount(paramMap);
					
					IPage page  = new Page();
					page.setTotal(total.longValue());
					page.setSize(Long.parseLong(pageSize));
					page.setRecords(list);
					return Result.success(page);
				}
	            return Result.error("当前无数据");
			}
			return Result.error("无法获取回款记录统计报表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取回款记录统计报表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【客户管理】")
	@ApiJsonObject(name = "getCustomerListByCustomerManage", value = { 
			@ApiJsonProperty(name = CustomerJson.customerStage),
			@ApiJsonProperty(name = CustomerJson.customerTagIdList),
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = OrgJson.departmentId),
			@ApiJsonProperty(name = CustomerJson.followUserId),
			@ApiJsonProperty(name = CustomerJson.updateStartDate),
			@ApiJsonProperty(name = CustomerJson.updateEndDate),
			@ApiJsonProperty(name = CustomerJson.customerIntentionContent),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerListByCustomerManage")
	@RequiresPermissions("sys:report:customerListByCustomerManage:view")
	@PostMapping("/getCustomerListByCustomerManage")
	public Result getCustomerListByCustomerManage(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String customerStage = String.valueOf(jsonObject.get("customerStage"));//客户阶段
				String customerTagIdList = String.valueOf(jsonObject.get("customerTagIdList"));//客户标签集合
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));//分校ID
				String departmentId = String.valueOf(jsonObject.get("departmentId"));//部门ID
				String followUserId = String.valueOf(jsonObject.get("followUserId"));
				String updateStartDate = String.valueOf(jsonObject.get("updateStartDate"));
				String updateEndDate = String.valueOf(jsonObject.get("updateEndDate"));
				String customerIntentionContent = String.valueOf(jsonObject.get("customerIntentionContent"));
				
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				StringUtil.validateIsNull(branchOrgId, "请选择分校ID");
				
	            
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	    		
	            paramMap.put("customerStage", customerStage);
	            paramMap.put("customerTagIdList", customerTagIdList);
	            paramMap.put("userId", bean.getId());//用来查自己权限范围内的业务组的客户
	            paramMap.put("followUserId", followUserId);//前端传入的跟进人ID
	            paramMap.put("updateStartDate", updateStartDate);
	            paramMap.put("updateEndDate", updateEndDate);
	            paramMap.put("customerIntentionContent", customerIntentionContent);
	            
	            
	            paramMap.put("branchOrgId", branchOrgId);//必需按分校来
	            paramMap.put("departmentId", departmentId);
//	            if(branchOrgId!=null && !branchOrgId.equals("") && !branchOrgId.equals("null")){
//	            	paramMap.put("branchOrgId", branchOrgId);
//	            } else{
//	            	//加载用户当前能访问的分校范围
//	            	paramMap.put("branchOrgId", branchOrgId);
//	            	List<OrgEntity> orgList = orgService.getBranchOrgByUserId(bean.getId());
//	            	if(orgList!=null && orgList.size()>0){
//	            		String orgId = "";
//	    				for(OrgEntity entity : orgList){
//	    					orgId = orgId + "'" + entity.getId() + "'" + ",";
//	    				}
//	    				paramMap.put("branchOrgId", orgId.substring(0, orgId.length()-1));
//	            	}
//	            }
	            
	            
	            List<LinkedHashMap<Object, Object>> list = customerService.getCustomerListByCustomerManage(paramMap);
	            if(list!=null && list.size()>0){
	            	//将每个客户的标签添加进去，与创建人加进去
					for(LinkedHashMap<Object, Object> map : list){
						//添加客户标签
						String customerId = map.get("id").toString();
						List<LinkedHashMap<Object, Object>> customerTagList = customerTagService.getCustomerTagListByCustomerId(customerId);
	            		if(customerTagList!=null && customerTagList.size()>0){
	            			map.put("customerTagList", customerTagList);
	            		}else{
	            			map.put("customerTagList", "");
	            		}
	            		
	            		//添加 创建人
	            		String createUserId = map.get("create_user_id").toString();
	            		UserEntity createUser = userService.getById(createUserId);
	            		if(createUser!=null){
	            			map.put("create_user_name", createUser.getUserName());
	            		}
	            		
	            		//添加客户所属分校名称，将每个客户的分校加进去，因为有时候客户是没有分校的，不在sql语句里面进行处理
	            		OrgEntity orgEntity = orgService.getBranchOrgByCustomerId(customerId);
	            		if(orgEntity!=null){
	            			map.put("branch_org_name", orgEntity.getOrgName());
	            		}else{
	            			map.put("branch_org_name", "");
	            		}
	            	}
	            	
					Long total = customerService.getCustomerListByCustomerManageCount(paramMap);
					
					IPage page  = new Page();
					page.setTotal(total.longValue());
					page.setSize(Long.parseLong(pageSize));
					page.setRecords(list);
					return Result.success(page);
				}
	            return Result.error("当前用户下没有客户");
			}
			return Result.error("无法获取客户列表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("无法获取客户列表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【推广管理】")
	@ApiJsonObject(name = "getCustomerListByPromotionManage", value = { 
			@ApiJsonProperty(name = CustomerJson.customerStage),
			@ApiJsonProperty(name = CustomerJson.customerTagIdList),
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = OrgJson.departmentId),
			@ApiJsonProperty(name = CustomerJson.promotionUserId),
			@ApiJsonProperty(name = CustomerJson.updateStartDate),
			@ApiJsonProperty(name = CustomerJson.updateEndDate),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerListByPromotionManage")
	@RequiresPermissions("sys:report:getCustomerListByPromotionManage:view")
	@PostMapping("/getCustomerListByPromotionManage")
	public Result getCustomerListByPromotionManage(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String customerStage = String.valueOf(jsonObject.get("customerStage"));//客户阶段
				String customerTagIdList = String.valueOf(jsonObject.get("customerTagIdList"));//客户标签集合
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));//分校ID
				String departmentId = String.valueOf(jsonObject.get("departmentId"));//部门ID
				String promotionUserId = String.valueOf(jsonObject.get("promotionUserId"));
				String updateStartDate = String.valueOf(jsonObject.get("updateStartDate"));
				String updateEndDate = String.valueOf(jsonObject.get("updateEndDate"));
				
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				StringUtil.validateIsNull(branchOrgId, "请选择分校ID");
				StringUtil.validateIsNull(promotionUserId, "请选择推广人");
	            
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	    		
	            paramMap.put("customerStage", customerStage);
	            paramMap.put("customerTagIdList", customerTagIdList);
	            paramMap.put("userId", bean.getId());//用来查自己权限范围内的业务组的客户
	            paramMap.put("promotionUserId", promotionUserId);//前端传入的推广人ID
	            paramMap.put("updateStartDate", updateStartDate);
	            paramMap.put("updateEndDate", updateEndDate);
	            
	            
	            paramMap.put("branchOrgId", branchOrgId);//必需按分校来
	            paramMap.put("departmentId", departmentId);
	            
	            List<LinkedHashMap<Object, Object>> list = customerService.getCustomerListByPromotionManage(paramMap);
	            if(list!=null && list.size()>0){
	            	//将每个客户的标签添加进去，与创建人加进去
					for(LinkedHashMap<Object, Object> map : list){
						//添加客户标签
						String customerId = map.get("id").toString();
						List<LinkedHashMap<Object, Object>> customerTagList = customerTagService.getCustomerTagListByCustomerId(customerId);
	            		if(customerTagList!=null && customerTagList.size()>0){
	            			map.put("customerTagList", customerTagList);
	            		}else{
	            			map.put("customerTagList", "");
	            		}
	            		
	            		//添加 创建人
	            		String createUserId = map.get("create_user_id").toString();
	            		UserEntity createUser = userService.getById(createUserId);
	            		if(createUser!=null){
	            			map.put("create_user_name", createUser.getUserName());
	            		}
	            		
	            		//添加客户所属分校名称，将每个客户的分校加进去，因为有时候客户是没有分校的，不在sql语句里面进行处理
	            		OrgEntity orgEntity = orgService.getBranchOrgByCustomerId(customerId);
	            		if(orgEntity!=null){
	            			map.put("branch_org_name", orgEntity.getOrgName());
	            		}else{
	            			map.put("branch_org_name", "");
	            		}
	            	}
	            	
					Long total = customerService.getCustomerListByPromotionManageCount(paramMap);
					
					IPage page  = new Page();
					page.setTotal(total.longValue());
					page.setSize(Long.parseLong(pageSize));
					page.setRecords(list);
					return Result.success(page);
				}
	            return Result.error("当前用户下没有客户");
			}
			return Result.error("无法获取客户列表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("无法获取客户列表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【客户查重】统计各分校重复客户(包含分校回收站中的)，公司回收站的客户不统计，不需要传分校ID进行筛选，只做一个全结果集的展现，暂时不需要右键菜单")
	@ApiJsonObject(name = "getCustomerListByRepetition", value = { 
			@ApiJsonProperty(name = CustomerJson.mobile),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerListByRepetition")
//	@RequiresPermissions("sys:report:getCustomerListByRepetition:view")
	@PostMapping("/getCustomerListByRepetition")
	public Result getCustomerListByRepetition(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String mobile = String.valueOf(jsonObject.get("mobile"));
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				
	            
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("mobile", mobile);
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	    		
	            
	            List<LinkedHashMap<Object, Object>> list = customerService.getCustomerListByRepetition(paramMap);
	            if(list!=null && list.size()>0){
	            	//将每个客户的标签添加进去，与创建人加进去
					for(LinkedHashMap<Object, Object> map : list){
						//添加客户标签
						String customerId = map.get("id").toString();
						List<LinkedHashMap<Object, Object>> customerTagList = customerTagService.getCustomerTagListByCustomerId(customerId);
	            		if(customerTagList!=null && customerTagList.size()>0){
	            			map.put("customerTagList", customerTagList);
	            		}else{
	            			map.put("customerTagList", "");
	            		}
	            		
	            		//添加 创建人
	            		String createUserId = map.get("create_user_id").toString();
	            		UserEntity createUser = userService.getById(createUserId);
	            		if(createUser!=null && !createUser.equals("")){
	            			map.put("create_user_name", createUser.getUserName());
	            		}
	            		
	            		//添加跟进人
	            		String followUserId = String.valueOf(map.get("follow_user_id"));
	            		if(followUserId!=null && !followUserId.equals("")){
	            			UserEntity followUser = userService.getById(followUserId);
		            		if(createUser!=null){
		            			map.put("follow_user_name", followUser.getUserName());
		            		}
	            		}else{
	            			map.put("follow_user_name", "");
	            		}
	            		
	            		//添加推广人
	            		String promotionUserId = String.valueOf(map.get("promotion_user_id"));
	            		if(promotionUserId!=null && !promotionUserId.equals("")){
	            			UserEntity promotionUser = userService.getById(promotionUserId);
		            		if(createUser!=null){
		            			map.put("promotion_user_name", promotionUser.getUserName());
		            		}
	            		}else{
	            			map.put("promotion_user_name", "");
	            		}
	            		
	            		
	            		//添加客户所属分校名称，将每个客户的分校加进去，因为有时候客户是没有分校的，不在sql语句里面进行处理
	            		OrgEntity orgEntity = orgService.getBranchOrgByCustomerId(customerId);
	            		if(orgEntity!=null){
	            			map.put("branch_org_name", orgEntity.getOrgName());
	            		}else{
	            			map.put("branch_org_name", "");
	            		}
	            	}
	            	
					Long total = customerService.getCustomerListByRepetitionCount(paramMap);
					
					IPage page  = new Page();
					page.setTotal(total.longValue());
					page.setSize(Long.parseLong(pageSize));
					page.setRecords(list);
					return Result.success(page);
				}
	            return Result.error("当前没有重复的客户");
			}
			return Result.error("无法获取客户列表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("无法获取客户列表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【合同管理报表】(合同属于用户，因为谁创建的合同业绩就归谁), 查负责人列表，传入分校orgId，调用findUserByOrgId接口")
	@ApiJsonObject(name = "getContractListReport", value = { 
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime),
			@ApiJsonProperty(name = UserJson.orgIds),
			@ApiJsonProperty(name = ContractJson.createUserId),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getContractListReport")
	@RequiresPermissions("sys:report:contractListReport:view")
	@PostMapping("/getContractListReport")
	public Result getContractListReport(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				UserEntity user = userService.getById(bean.getId());
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String createUserId = String.valueOf(jsonObject.get("createUserId"));
				String orgIds = String.valueOf(jsonObject.get("orgIds"));
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				

				Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            paramMap.put("createUserId", createUserId);
	            
	            //如果前端传入了分校id，则执行如下的逻辑
	            if(orgIds!=null && !orgIds.equals("null") && !orgIds.equals("")){
					List<String> orgIdList = JsonUtil.getJsonToList(orgIds, String.class);
					String orgId = "";
					for(String str : orgIdList){
						orgId = orgId + "'" + str + "'" + ",";
					}
					paramMap.put("orgIds", orgId.substring(0, orgId.length()-1));
				}else{
					//如果前端没传分校id，则判断用户能查看到的分校范围进行判断
					List<OrgEntity> orgList = orgService.getBranchOrgByUserId(user.getId());
					String orgId = "";
					for(OrgEntity entity : orgList){
						orgId = orgId + "'" + entity.getId() + "'" + ",";
					}
					paramMap.put("orgIds", orgId.substring(0, orgId.length()-1));
				}

	            
	            List<LinkedHashMap<Object, Object>> list = reportService.getContractList(paramMap);
	            if(list!=null && list.size()>0){
	            	
					Long total = reportService.getContractListCount(paramMap);
					
					IPage page  = new Page();
					page.setTotal(total.longValue());
					page.setSize(Long.parseLong(pageSize));
					page.setRecords(list);
					return Result.success(page);
				}
	            return Result.error("当前无数据");
			}
			return Result.error("无法获取合同管理统计报表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取合同管理统计报表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
	
	
	@ApiOperation(value = "【客户创建记录统计报表】,普通管理员与超级管理员点筛选时，/api/console/user/getBranchOrgByUserId 获取当前用户拥有的分校(超级管理员将返回所有的分校)获取拥有的权限的分校树形菜单" +
			"，复选框形式，可自定义勾选，普通用户或代理商用户，则无筛选按钮，显示自己名字即可")
	@ApiJsonObject(name = "getCustomerCreateRecordList", value = { 
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime),
			@ApiJsonProperty(name = CustomerJson.customerNameOrCompanyName),
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerCreateRecordList")
	@RequiresPermissions("sys:report:customerCreateRecordList:view")
	@PostMapping("/getCustomerCreateRecordList")
	public Result getCustomerCreateRecordList(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				UserEntity user = userService.getById(bean.getId());
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String customerNameOrCompanyName = String.valueOf(jsonObject.get("customerNameOrCompanyName"));
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				

				Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            paramMap.put("customerNameOrCompanyName", customerNameOrCompanyName);
	            
	            //如果前端传入了分校id，则执行如下的逻辑
//	            if(orgIds!=null && !orgIds.equals("null") && !orgIds.equals("")){
//					List<String> orgIdList = JsonUtil.getJsonToList(orgIds, String.class);
//					String orgId = "";
//					for(String str : orgIdList){
//						orgId = orgId + "'" + str + "'" + ",";
//					}
//					paramMap.put("orgIds", orgId.substring(0, orgId.length()-1));
//				}else{
//					//如果前端没传分校id，则判断用户能查看到的分校范围进行判断
//					List<OrgEntity> orgList = orgService.getBranchOrgByUserId(user.getId());
//					String orgId = "";
//					for(OrgEntity entity : orgList){
//						orgId = orgId + "'" + entity.getId() + "'" + ",";
//					}
//					paramMap.put("orgIds", orgId.substring(0, orgId.length()-1));
//				}
	            
	            paramMap.put("branchOrgId", branchOrgId);

	            
	            List<LinkedHashMap<Object, Object>> list = reportService.getCustomerCreateRecordList(paramMap);
	            if(list!=null && list.size()>0){
	            	
					Long total = reportService.getCustomerCreateRecordListCount(paramMap);
					
					IPage page  = new Page();
					page.setTotal(total.longValue());
					page.setSize(Long.parseLong(pageSize));
					page.setRecords(list);
					return Result.success(page);
				}
	            return Result.error("当前无数据");
			}
			return Result.error("无法获取客户创建记录统计报表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户创建记录统计报表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
	@ApiOperation(value = "【客户数量统计报表】,普通管理员与超级管理员点筛选时，/api/console/user/getBranchOrgByUserId 获取当前用户拥有的分校(超级管理员将返回所有的分校)获取拥有的权限的分校树形菜单" +
			"，复选框形式，可自定义勾选，普通用户或代理商用户，则无筛选按钮，显示自己名字即可(目前只实现以分校为单位的客户数量统计，个人的数量统计，后续实现),时间范围，不能为无限，默认传最近一周的时间范围")
	@ApiJsonObject(name = "getCustomerCountList", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = UserJson.userId),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerCountList")
	@RequiresPermissions("sys:report:customerCount:view")
	@PostMapping("/getCustomerCountList")
	public Result getCustomerCountList(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				UserEntity user = userService.getById(bean.getId());
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
				String userId = String.valueOf(jsonObject.get("userId"));
				
				StringUtil.validateIsNull(branchOrgId, "请输入分校ID");
				
				if(startDateTime!=null && !startDateTime.equals("") && !startDateTime.equals("null")){
				}else{
					startDateTime = DateUtil.getCurrentDateString("yyyy-MM-dd");
					endDateTime = DateUtil.getCurrentDateString("yyyy-MM-dd");
				}
				
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            paramMap.put("userId", userId);
	            
//	            if(branchOrgId!=null && !branchOrgId.equals("") && !branchOrgId.equals("null")){
//	            	paramMap.put("branchOrgId", branchOrgId);
//	            }else{
//	            	//加载用户当前所在的分校
//	            	OrgEntity orgEntity = orgService.getUserBranchOrgByOrgId(user.getOrgId());
//	            	paramMap.put("branchOrgId", orgEntity.getId());
//	            }
	            paramMap.put("branchOrgId", branchOrgId);
	            
	            
	            List<LinkedHashMap<Object, Object>> list = new ArrayList<LinkedHashMap<Object, Object>>();
	            List<String> dateList = DateUtil.getDatesBetweenTwoDate(startDateTime, endDateTime); //使用这种方式来统计
	            if(userId!=null && !userId.equals("") && !userId.equals("null")){
	            	paramMap.put("userId", userId);
	            	paramMap.put("dataType", "2");
	            	for(String date : dateList){
    	            	LinkedHashMap<Object, Object> map = new LinkedHashMap<Object, Object>();
    	            	
    	            	paramMap.put("startDateTime", date);
    		            paramMap.put("endDateTime", date);
    		            paramMap.put("date", date);
    		            
    	            	//1.统计新增的客户数量
    	            	BigDecimal createCustomerCount = customerService.getCreateCustomerCountByUser(paramMap);
    	            	//2.统计流失的客户数量
    	            	BigDecimal lossCustomerCount = customerService.getLossCustomerCountByUser(paramMap);
    	            	//3.统计客户总数(分为统计用户的，统计分校的)
    	            	Integer customerCount = customerCountService.getCustomerCountByScheduled(paramMap);
    	            	if(customerCount==null){
    	            		customerCount = 0;
    	            	}
    	            	map.put("date", date);
    	            	map.put("createCustomerCount", createCustomerCount);
    	            	map.put("lossCustomerCount", lossCustomerCount);
    	            	map.put("customerCount", customerCount);
    	            	
    	            	list.add(map);
    	            }
            	}else{
            		for(String date : dateList){
    	            	LinkedHashMap<Object, Object> map = new LinkedHashMap<Object, Object>();
    	            	
    	            	paramMap.put("startDateTime", date);
    		            paramMap.put("endDateTime", date);
    		            paramMap.put("date", date);
    	            	paramMap.put("dataType", "1");
    	            	
    	            	//1.统计新增的客户数量
    	            	BigDecimal createCustomerCount = customerService.getCreateCustomerCountByBranch(paramMap);
    	            	//2.统计流失的客户数量
    	            	BigDecimal lossCustomerCount = customerService.getLossCustomerCountByBranch(paramMap);
    	            	//3.统计客户总数(分为统计用户的，统计分校的)
    	            	Integer customerCount = customerCountService.getCustomerCountByScheduled(paramMap);
    	            	if(customerCount==null){
    	            		customerCount = 0;
    	            	}
    	            	map.put("date", date);
    	            	map.put("createCustomerCount", createCustomerCount);
    	            	map.put("lossCustomerCount", lossCustomerCount);
    	            	map.put("customerCount", customerCount);
    	            	
    	            	list.add(map);
    	            }
            	}
	            
	            if(list!=null && list.size()>0){
	            	return Result.success(list);
	            }
	            return Result.error("暂无统计数据");
			}
			return Result.error("无法获取分校下客户数量统计报表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("无法获取分校下客户数量统计报表，失败原因：" + e.getMessage());
		}
	}
	
	
	
}
