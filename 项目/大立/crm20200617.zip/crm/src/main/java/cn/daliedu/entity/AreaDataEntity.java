package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 区域数据表
 * </p>
 *
 * @author xiechao
 * @since 2019-11-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_area_data")
public class AreaDataEntity extends Model<AreaDataEntity> {

    private static final long serialVersionUID = 1L;
    
    
    // 上级机构名称（ 非数据库字段）
//    @TableField(exist = false)
//    private String parentName;
    
    // 下级组织机构（ 非数据库字段）
    @TableField(exist = false)
    private List<AreaDataEntity> children;
    
    // 机构层级（ 非数据库字段）
    @TableField(exist = false)
    private Integer level;
    

    /**
     * 区域ID,主键ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private Integer id;

    /**
     * 城市名称
     */
    private String cityName;

    /**
     * 上级区域ID
     */
    private Integer parentId;

    /**
     * 短名称
     */
    private String shortName;

    /**
     * 排序号
     */
    private Integer depth;

    /**
     * 城市编码
     */
    private String cityCode;

    /**
     * 邮政编码
     */
    private String zipCode;

    /**
     * 区域全名称路径
     */
    private String mergerName;

    /**
     * 经度
     */
    private String longitude;

    /**
     * 纬度
     */
    private String latitude;

    /**
     * 拼音
     */
    private String pinyin;

    /**
     * 是否启用
     */
    private Integer isUse;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
