package cn.daliedu.service.impl;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.entity.CustomerSelfDefineItemConfigDetailEntity;
import cn.daliedu.entity.CustomerSelfDefineItemConfigEntity;
import cn.daliedu.entity.CustomerTagGroupDetailEntity;
import cn.daliedu.entity.CustomerTagGroupEntity;
import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.UserOrgEntity;
import cn.daliedu.enums.OrgTypeEnum;
import cn.daliedu.enums.UserTypeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.mapper.CustomerSelfDefineItemConfigDetailMapper;
import cn.daliedu.mapper.CustomerSelfDefineItemConfigMapper;
import cn.daliedu.mapper.CustomerTagGroupDetailMapper;
import cn.daliedu.mapper.CustomerTagGroupMapper;
import cn.daliedu.mapper.OrgMapper;
import cn.daliedu.mapper.UserOrgMapper;
import cn.daliedu.service.CustomerSelfDefineItemConfigService;
import cn.daliedu.service.CustomerTagGroupService;
import cn.daliedu.service.OrgService;
import cn.daliedu.service.UserService;

/**
 * <p>
 * 机构管理 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
@Service
public class OrgServiceImpl extends ServiceImpl<OrgMapper, OrgEntity> implements OrgService {
	@Autowired
	UserService userService;
	
	@Autowired
	OrgService orgService;
	
	@Autowired
	CustomerTagGroupService customerTagGroupService;
	
	@Autowired
	CustomerSelfDefineItemConfigService customerSelfDefineItemConfigService;
	
	
	@Resource
	OrgMapper orgMapper;

	@Resource
	UserOrgMapper userOrgMapper;
	
	@Resource
	CustomerTagGroupMapper customerTagGroupMapper;
	
	@Resource
	CustomerTagGroupDetailMapper customerTagGroupDetailMapper;
	
	@Resource
	CustomerSelfDefineItemConfigMapper customerSelfDefineItemConfigMapper;
	
	@Resource
	CustomerSelfDefineItemConfigDetailMapper customerSelfDefineItemConfigDetailMapper;
	
	
	
	
	
	@Override
	public boolean saveOrg(OrgEntity entity) {
		orgMapper.insert(entity);
		if(entity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_2.getValue())){
			customerTagGroupService.restoreCustomerTagGroupByBranchOrgId(entity.getId());
			customerSelfDefineItemConfigService.restoreCustomerSelfDefineItemByBranchOrgId(entity.getId());
		}
		return false;
	}

	@Override
	public List<OrgEntity> getDepartmentListByBranchOrgId(String branchOrgId) {
		return orgMapper.selectList(new QueryWrapper<OrgEntity>().eq("parent_id", branchOrgId).eq("org_type", "3"));
	}

	@Override
	public List<OrgEntity> getBranchOrg() {
		return orgMapper.selectList(new QueryWrapper<OrgEntity>()
				.eq("org_type", OrgTypeEnum.ORG_TYPE_2.getValue()));
	}

	@Override
	public List<OrgEntity> getNextLevelOrgByOrgId(String orgId) {
		return orgMapper.selectList(new QueryWrapper<OrgEntity>()
				.eq("parent_id", orgId).eq("org_type", OrgTypeEnum.ORG_TYPE_3.getValue()));
	}

	@Override
	public List<OrgEntity> findTreeOrgList() {
		List<OrgEntity> tempOrgList = new ArrayList<>();
		
		List<OrgEntity> orgList = new ArrayList<OrgEntity>();
		
		UserEntity bean = (UserEntity) SecurityUtils.getSubject().getPrincipal();
		UserEntity user = userService.getById(bean.getId());
		if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue())){
			orgList = orgMapper.selectList(new QueryWrapper<OrgEntity>().orderByAsc("org_type").orderByAsc("order_num"));
		}else{
			//其他类型的用户，要进行菜单权限加载的限制
			//1.加载用户有权限的所有分校，分校所属的省份以及分校下对应的部门
			List<OrgEntity> userBranchOrgList = getBranchOrgByUserId(user.getId());
			Map<Object, Object> paramMap = new HashMap<Object, Object>();
			
			for(OrgEntity entity : userBranchOrgList){
				paramMap.put("orgId", entity.getId());
				List<OrgEntity> branchOrgList = orgMapper.getUserProvinceBranchDepartmentOrgList(paramMap);
				orgList.addAll(branchOrgList);
			}
			
			//2.加载用户有权限的所有的分校所在的省份，此步骤已经合并至第1步里面去了
			//3.加载顶级节点，大立教育
			orgList.add(orgService.getById("1"));
			//4.加载大立教育下面的代理商,只允许下面几种用户可以加载到代理商节点，其实应该做到菜单里面去，可以动态配置
			if(user.getUserType().equals(UserTypeEnum.TYPE_2.getValue()) || user.getUserType().equals(UserTypeEnum.TYPE_3.getValue()) 
					|| user.getUserType().equals(UserTypeEnum.TYPE_3.getValue())){
				List<OrgEntity> agentOrgList = orgMapper.getAgentOrgList();
				orgList.addAll(agentOrgList);
			}
			
			
			Set<OrgEntity> orgSetList = new HashSet<OrgEntity>();
			orgSetList.addAll(orgList);
			orgList = null;
			orgList = new ArrayList<OrgEntity>(orgSetList);
		}
			
		
		for (OrgEntity entity : orgList) {
			//if (entity.getParentId() == null || entity.getParentId() == 0) {
			if (entity.getParentId() == null || entity.getParentId().equals("0")) {
				entity.setLevel(0);
				entity.setValue(entity.getOrgName());
				tempOrgList.add(entity);
			}
		}
		
		//一定要有下面这一行，可以进行排序操作
		orgList.sort((o1, o2) -> o1.getOrderNum().compareTo(o2.getOrderNum()));
		findChildren(tempOrgList, orgList);
		return tempOrgList;
	}

	private void findChildren(List<OrgEntity> tempOrgList, List<OrgEntity> orgList) {
		for (OrgEntity entity : tempOrgList) {
			List<OrgEntity> children = new ArrayList<>();
			for (OrgEntity bean : orgList) {
				if (entity.getId() != null && entity.getId().equals(bean.getParentId())) {
//					bean.setParentName(entity.getOrgName());
					bean.setLevel(entity.getLevel() + 1);
					bean.setValue(bean.getOrgName());
					children.add(bean);
				}
			}
			entity.setChildren(children);
			children.sort((o1, o2) -> o1.getOrderNum().compareTo(o2.getOrderNum()));
			findChildren(children, orgList);
		}
	}

	@Override
	public List<OrgEntity> getBranchOrgTree() {
		
		List<OrgEntity> orgList = orgMapper.selectList(new QueryWrapper<OrgEntity>().in("org_type", OrgTypeEnum.ORG_TYPE_1.getValue(), OrgTypeEnum.ORG_TYPE_2.getValue()));
		
		List<OrgEntity> tempOrgList = new ArrayList<>();
		for (OrgEntity entity : orgList) {
			//如果是省份的话，那么就作为返回数据的根节点返回,此算法有点小遗憾，需要告诉他根节点
			if(entity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_1.getValue())){
				entity.setLevel(0);
				tempOrgList.add(entity);
			}
		}
		findChildren(tempOrgList, orgList);
		return tempOrgList;
	}

	@Override
	public void deleteOrg(String id) throws Exception {
		OrgEntity orgEntity = this.getById(id);
		
		List<String> list = new ArrayList<String>();
		//查询机构下是否已经存在用户，如果存在，则不允许删除
		this.recursionOrg(list, id);
		this.orgMapper.delete(new QueryWrapper<OrgEntity>().in("parent_id", list).or().eq("id", id));
		
		if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_2.getValue())){
			//删除客户标签分组
			List<CustomerTagGroupEntity> groupList = customerTagGroupMapper.selectList(new QueryWrapper<CustomerTagGroupEntity>().eq("branch_org_id", orgEntity.getId()));
			if(!CollectionUtils.isEmpty(groupList)){
				groupList.stream().forEach(entity -> {
					customerTagGroupDetailMapper.delete(new QueryWrapper<CustomerTagGroupDetailEntity>().eq("customer_tag_type_id", entity.getCustomerTagTypeId()));
				});
			}
			customerTagGroupMapper.delete(new QueryWrapper<CustomerTagGroupEntity>().eq("branch_org_id", orgEntity.getId()));
			
			//删除客户自定义组信息
			List<CustomerSelfDefineItemConfigEntity> customerGroupList = customerSelfDefineItemConfigMapper.selectList(new QueryWrapper<CustomerSelfDefineItemConfigEntity>().eq("branch_org_id", orgEntity.getId()));
			if(!CollectionUtils.isEmpty(customerGroupList)){
				customerGroupList.stream().forEach(entity -> {
					customerSelfDefineItemConfigDetailMapper.delete(new QueryWrapper<CustomerSelfDefineItemConfigDetailEntity>().eq("item_id", entity.getItemId()));
				});
			}
			customerSelfDefineItemConfigMapper.delete(new QueryWrapper<CustomerSelfDefineItemConfigEntity>().eq("branch_org_id", orgEntity.getId()));
		}
		
	}

	/**
	 * 递归查询机构
	 * @param list 保存机构ID的集合
	 * @param id 机构ID
	 * @throws Exception
	 */
	private void recursionOrg(List<String> list, String id) throws Exception {
		Integer count = this.userOrgMapper.selectCount(new QueryWrapper<UserOrgEntity>().eq("org_id", id));//判断机构下是否有员工
		if (count > 0) {
			throw new BusinessException("该部门中已创建员工,不允许删除部门");
		}
		List<OrgEntity> orgList = this.orgMapper.selectList(new QueryWrapper<OrgEntity>().eq("parent_id", id));
		list.add(id);
		if (null != orgList && orgList.size() > 0) {
			for (OrgEntity org : orgList) {
				this.recursionOrg(list, org.getId());
			}
		}
	}
	
	

	@Override
	public OrgEntity getUserBranchOrgByUser(UserEntity user) throws Exception {
		List<OrgEntity> list = new ArrayList<OrgEntity>();
		
		this.recursionBranchOrg(list, user.getOrgId());//递归找到当前用户所在的分校
		if(list!=null && list.size()>0){
			return list.get(0);
		}
		return null;
	}
	
	@Override
	public OrgEntity getUserBranchOrgByUserId(String userId) throws Exception {
		UserEntity user = userService.getById(userId);
		return getUserBranchOrgByUser(user);
	}

	@Override
	public OrgEntity getUserBranchOrgByOrgId(String orgId) throws Exception{
		List<OrgEntity> list = new ArrayList<OrgEntity>();
		
		this.recursionBranchOrg(list, orgId);//递归找到当前用户所在的分校
		if(list!=null && list.size()>0){
			return list.get(0);
		}
		return null;
	}
	
	/**
	 * 递归查询用户所在的分校,只能从分校或者分校下面的部门开始往上查，如果传入的机构ID为顶级机构或者省份，或者代理商之类的则直接抛出异常
	 * @param id 机构ID
	 * @throws Exception
	 */
	private void recursionBranchOrg(List<OrgEntity> list, String orgId) throws Exception{
		//机构类型，0：顶级机构， 1：省份或直辖市，2：分校，3：部门， 4：代理商
		OrgEntity bean = orgMapper.selectById(orgId);
		if(bean.getOrgType().equals(OrgTypeEnum.ORG_TYPE_0.getValue()) 
				|| bean.getOrgType().equals(OrgTypeEnum.ORG_TYPE_1.getValue()) 
				|| bean.getOrgType().equals(OrgTypeEnum.ORG_TYPE_4.getValue()) 
				|| bean.getOrgType().equals(OrgTypeEnum.ORG_TYPE_5.getValue())
				|| bean.getOrgType().equals(OrgTypeEnum.ORG_TYPE_6.getValue())){
			throw new BusinessException("您当前所在的组织机构有问题，您无权限操作，请联系管理员");
		}
		
		if(bean.getOrgType().equals(OrgTypeEnum.ORG_TYPE_2.getValue())){
			list.add(bean);
		}else{
			recursionBranchOrg(list, bean.getParentId());
		}
	}

	@Override
	public List<OrgEntity> getBranchOrgByUserId(String userId) {
		UserEntity user = userService.getById(userId);
		//如果是超级管理员或代理商，则可以加载全部的分校业务组列表
		if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue())){
			return orgMapper.selectList(new QueryWrapper<OrgEntity>().eq("org_type", OrgTypeEnum.ORG_TYPE_2.getValue()));
		}else{
			//普通用户或管理员则加载自己的分校范围列表
			return orgMapper.getUserBusinessGroupListByUserId(userId);
		}
	}
	
	
	@Override
	public List<OrgEntity> getBranchOrgByUser(UserEntity user) {
		//如果是超级管理员或代理商，则可以加载全部的分校业务组列表
		if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue())){
			return orgMapper.selectList(new QueryWrapper<OrgEntity>().eq("org_type", OrgTypeEnum.ORG_TYPE_2.getValue()));
		}else{
			//普通用户或管理员则加载自己的分校范围列表
			return orgMapper.getUserBusinessGroupListByUserId(user.getId());
		}
	}

	@Override
	public OrgEntity getBranchOrgByCustomerId(String customerId) throws Exception {
		return orgMapper.getBranchOrgByCustomerId(customerId);
	}
	
	
}
