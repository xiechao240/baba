package cn.daliedu.util;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
/**
 * @author xiechao
 * @time 2019年3月30日 上午10:48:09
 * @version 1.0.0 
 * @description 各种流的转换
 */
public class StreamUtil {
	/**
	 * 输入流转换为输出流
	 * @param in
	 * @return
	 * @throws Exception
	 */
    public static ByteArrayOutputStream inputStreamToOutputStream(final InputStream in) throws Exception {
        final ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
        int ch;
        while ((ch = in.read()) != -1) {
            swapStream.write(ch);
        }
        return swapStream;
    }

    /**
     * 输出流转换为输入流
     * @param out
     * @return
     * @throws Exception
     */
    public static ByteArrayInputStream outputStreamToInputStream(final OutputStream out) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        baos = (ByteArrayOutputStream) out;
        final ByteArrayInputStream swapStream = new ByteArrayInputStream(baos.toByteArray());
        return swapStream;
    }

    /**
     * 输入流转字符串
     * @param in
     * @return
     * @throws Exception
     */
    public static String inputStreamToString(final InputStream in) throws Exception {
        final ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
        int ch;
        while ((ch = in.read()) != -1) {
            swapStream.write(ch);
        }
        return swapStream.toString();
    }

    /**
     * 输出流转字符串
     * @param out
     * @return
     * @throws Exception
     */
    public static String outputStreamToString(final OutputStream out) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        baos = (ByteArrayOutputStream) out;
        final ByteArrayInputStream swapStream = new ByteArrayInputStream(baos.toByteArray());
        return swapStream.toString();
    }

    /**
     * 字符串转输入流
     * @param in
     * @return
     * @throws Exception
     */
    public static ByteArrayInputStream stringToInputStream(final String in) throws Exception {
        final ByteArrayInputStream input = new ByteArrayInputStream(in.getBytes());
        return input;
    }

    /**
     * 字符串转输出流
     * @param in
     * @return
     * @throws Exception
     */
    public static ByteArrayOutputStream StringToOutputStream(final String in) throws Exception {
        return inputStreamToOutputStream(stringToInputStream(in));
    }
}
