package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 用户短信发送记录表
 * </p>
 *
 * @author xiechao
 * @since 2019-12-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_user_sms_record")
public class UserSmsRecordEntity extends Model<UserSmsRecordEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    private String id;

    /**
     * 用户ID
     */
    private String userId;

    /**
     * 分校ID（可用于统计每个分样发送的短信量）
     */
    private String branchOrgId;

    /**
     * 短信模板类型编码
     */
    private String templateCode;

    /**
     * 发送时间
     */
    private LocalDateTime createDateTime;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
