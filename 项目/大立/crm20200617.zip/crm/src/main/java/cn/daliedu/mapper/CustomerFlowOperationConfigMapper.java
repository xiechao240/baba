package cn.daliedu.mapper;

import cn.daliedu.entity.CustomerFlowOperationConfigEntity;

import java.util.LinkedHashMap;
import java.util.List;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 客户流转操作配置表 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-10-15
 */
public interface CustomerFlowOperationConfigMapper extends BaseMapper<CustomerFlowOperationConfigEntity> {
	
	/**
	 * 删除所有数据
	 * @return
	 */
	public Integer deleteAllData();
	
	/**
	 * 获取所有的客户流转原因操作配置
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getAllCustomerFlowOperation();
}
