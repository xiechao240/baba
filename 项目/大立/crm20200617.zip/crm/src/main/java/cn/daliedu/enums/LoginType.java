package cn.daliedu.enums;

/**
 * @author xiechao
 * @time 2019年3月26日 下午3:10:08
 * @version 1.0.0 
 * @description 
 */
public enum  LoginType {
    PASSWORD("password"), // 密码登录
    NOPASSWD("nopassword"); // 免密登录

    private String code;// 状态值

    private LoginType(String code) {
        this.code = code;
    }
    public String getCode () {
        return code;
    }
}
