package cn.daliedu.service;

import cn.daliedu.entity.CustomerSmsEntity;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 客户发送短信表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2020-06-16
 */
public interface CustomerSmsService extends IService<CustomerSmsEntity> {

}
