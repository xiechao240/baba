package cn.daliedu.controller.api.app;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.UnauthorizedException;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.CustomerEntity;
import cn.daliedu.entity.CustomerSelfDefineItemConfigEntity;
import cn.daliedu.entity.CustomerTagGroupEntity;
import cn.daliedu.entity.DictEntity;
import cn.daliedu.entity.DictManyDetailEntity;
import cn.daliedu.entity.DictManyEntity;
import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.json.CustomerJson;
import cn.daliedu.entity.json.CustomerModel;
import cn.daliedu.entity.json.CustomerTagJson;
import cn.daliedu.entity.json.GlobalJson;
import cn.daliedu.entity.json.OrgJson;
import cn.daliedu.entity.json.UserJson;
import cn.daliedu.enums.CustomerStageEnum;
import cn.daliedu.enums.ResultCodeEnum;
import cn.daliedu.enums.SexEnum;
import cn.daliedu.enums.UserTypeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.CustomerSelfDefineItemConfigService;
import cn.daliedu.service.CustomerService;
import cn.daliedu.service.CustomerTagGroupService;
import cn.daliedu.service.CustomerTagService;
import cn.daliedu.service.DictManyService;
import cn.daliedu.service.DictService;
import cn.daliedu.service.MenuService;
import cn.daliedu.service.OrgService;
import cn.daliedu.service.RoleService;
import cn.daliedu.service.UserCustomerService;
import cn.daliedu.service.UserOrgAreaService;
import cn.daliedu.service.UserRoleService;
import cn.daliedu.service.UserService;
import cn.daliedu.util.FileUtil;
import cn.daliedu.util.JsonUtil;
import cn.daliedu.util.LocalDateTimeUtil;
import cn.daliedu.util.PageUtil;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;


/**
 * 客户相关接口控制器
 * @author xiechao
 * @time 2019年5月13日 上午10:33:58
 * @version 1.0.0 
 * @description
 */
@Api(description="app客户相关接口")
@RestController
@RequestMapping(value = "${rest.path}/app/customer") 
public class AppCustomerController {
	
	@Autowired
	UserService userService;
	
	@Autowired
	RoleService roleService;
	
	@Autowired
	OrgService orgService;
	
	@Autowired
	MenuService menuService;
	
	@Autowired
	UserRoleService userRoleService;
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	CustomerTagService customerTagService;
	
	@Autowired
	UserCustomerService userCustomerService;
	
	@Autowired
	UserOrgAreaService userOrgAreaService;
	
	@Autowired
	DictManyService dictManyService;
	
	@Autowired
	DictService dictService;
	
	@Autowired
	CustomerSelfDefineItemConfigService customerSelfDefineItemConfigService;
	
	@Autowired
	CustomerTagGroupService customerTagGroupService;
	
	//获取筛选条件
	@ApiOperation(value = "获取客户部分资料,用于app端点开客户查看部分客户信息")
	@ApiImplicitParam(name = "customerId", dataType = "String", required = true, value = "客户ID")
	@GetMapping("customer-info-part")
	public Result getCustomerInfoPart(@RequestParam(required = true) String customerId) {
		try {
			// 获取客户信息
			CustomerEntity entity = customerService.getById(customerId);
			if(entity!=null){
				// 获取客户阶段
				List<DictEntity> customerStageList = dictService.getDictValueByType("customer_stage");
				
				//获取客户标签
				List<LinkedHashMap<Object, Object>> customerTagList = customerTagService.getCustomerTagListByCustomerId(customerId);

				Map<Object, Object> dataMap = new LinkedHashMap<Object, Object>();
				dataMap.put("customer", entity);
				dataMap.put("customerStageList", customerStageList);
				if(customerTagList!=null && customerTagList.size()>0){
					dataMap.put("customerTagList", customerTagList);
	    		}else{
	    			dataMap.put("customerTagList", null);
	    		}

				return Result.success(dataMap);
			}
			return Result.error("当前客户不存在");
		} catch (UnauthorizedException e) {
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户资料失败，失败原因：" + e.getMessage());
		}
	}
	
	//获取筛选条件
	@ApiOperation(value = "根据客户ID，获取客户所在的分校的对应客户标签集合")
	@ApiImplicitParam(name = "customerId", dataType = "String", required = true, value = "客户ID")
	@GetMapping("customer-tag-group-by-customer-id")
	public Result getCustomerTagGroupByCustomerId(@RequestParam(required = true) String customerId) {
		try {
			// 获取客户信息
			CustomerEntity entity = customerService.getById(customerId);
			if (entity != null) {
				//获取分校的客户标签列表
				List<CustomerTagGroupEntity> customerTagGroupList = customerTagGroupService.findCustomerTagGroupAndTagDetailList(entity.getBranchOrgId());
				
				Map<Object, Object> dataMap = new LinkedHashMap<Object, Object>();
				dataMap.put("customerTagGroupList", customerTagGroupList);
				
				return Result.success(dataMap);
			}
			return Result.error("当前客户不存在");
		} catch (UnauthorizedException e) {
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户标签失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
	@ApiOperation(value = "新增客户")
	@PostMapping(value = "/save-customer", consumes = "multipart/*", headers = "content-type=multipart/form-data")
	public Result saveCustomer(@ApiParam(value="客户json参数模型",required=true)@RequestParam(required=true) String model, 
			@ApiParam(value="上传的文件",required=true)@RequestParam(required=false, value = "file") MultipartFile file) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				UserEntity user = userService.getById(bean.getId());
				CustomerModel customerModel = null;
				try{
					customerModel = JsonUtil.getJsonToBean(model, CustomerModel.class);
				}catch(Exception e){
					return Result.error("app应用端，请求参数出错", model);
				}
				
				
				boolean flag = customerService.saveCustomer(customerModel, file, user);
				if(flag){
					return Result.success("新增客户成功");
				}
				return Result.error("新增客户失败，请联系管理员");
			}
			return Result.error("非法请求");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("新增客户失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "修改客户")
	@PostMapping("/update-customer-by-customer-id")
	public Result updateCustomerByCustomerId(@ApiParam(value="客户json参数模型",required=true)@RequestParam(required=true) String model, 
			@ApiParam(value="上传的文件",required=true)@RequestParam(required=false, value = "file") MultipartFile file) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				UserEntity user = userService.getById(bean.getId());
				
				CustomerModel customerModel = null;
				try{
					customerModel = JsonUtil.getJsonToBean(model, CustomerModel.class);
				}catch(Exception e){
					return Result.error("app应用端，请求参数出错", model);
				}
				
				boolean flag = customerService.updateCustomerByCustomerId(customerModel, file, user);
				if(flag){
					return Result.success("修改客户成功");
				}
				return Result.error("修改客户失败，请联系管理员");
			}
			return Result.error("非法请求");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("新增客户失败，失败原因：" + e.getMessage());
		}
	}
	
	
	//获取筛选条件
//	@ApiOperation(value="客户查询获取筛选条件")
//	@ApiImplicitParam(name = "branchOrgId", dataType ="String", required = true, value = "分校ID")
//	@GetMapping("filter-condition")
//	public Result getFilterCondition(@RequestParam(required=true)String branchOrgId){
//		try{
//			//获取客户分组
//			List<DictEntity> customerGroupList = dictService.getDictValueByType("customer_group");
//			//获取客户阶段
//			List<DictEntity> customerStageList = dictService.getDictValueByType("customer_stage");
//			//获取分校的客户标签列表
//			List<CustomerTagGroupEntity> customerTagGroupList = customerTagGroupService.findCustomerTagGroupAndTagDetailList(branchOrgId);
//			
//			Map<Object, Object> dataMap = new LinkedHashMap<Object, Object>();
//			dataMap.put("customerGroupList", customerGroupList);
//			dataMap.put("customerStageList", customerStageList);
//			dataMap.put("customerTagGroupList", customerTagGroupList);
//			
//			return Result.success(dataMap);
//		}catch (UnauthorizedException e){
//			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
//		}catch (BusinessException e) {
//			return Result.error(e.getMessage());
//		}catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("新增客户失败，失败原因：" + e.getMessage());
//		}
//	}
	
	@ApiOperation(value="新增客户时，静态数据条件")
	@GetMapping("add-customer-condition")
	public Result addCustomerCondition(){
		try{
			//获取客户来源
			List<DictManyEntity> customerSourceList = dictManyService.getDictValueByTag("customer_source_type");
			for(DictManyEntity entity : customerSourceList){
				List<DictManyDetailEntity> customerSourceDetails = dictManyService.getDictDetailByTagId(entity.getTagId().toString());
				entity.setCustomerSourceDetails(customerSourceDetails);
			}
			
			//获取客户分组
			List<DictEntity> customerGroupList = dictService.getDictValueByType("customer_group");
			//获取客户质量
			List<DictEntity> customerStageList = dictService.getDictValueByType("customer_quality");
			//客户意向程度
			List<DictEntity> customerIntentionLevel = dictService.getDictValueByType("customer_intention_level");
			//客户意向内容
			List<DictEntity> customerIntentionContent = dictService.getDictValueByType("customer_intention_content");
			//用户拥有的分校列表
			Object object = SecurityUtils.getSubject().getPrincipal();
			UserEntity user = (UserEntity) object;
			List<OrgEntity> branchOrgList = orgService.getBranchOrgByUserId(user.getId());
			
			Map<Object, Object> dataMap = new LinkedHashMap<Object, Object>();
			dataMap.put("customerSourceList", customerSourceList);
			dataMap.put("customerGroupList", customerGroupList);
			dataMap.put("customerStageList", customerStageList);
			dataMap.put("customerIntentionLevel", customerIntentionLevel);
			dataMap.put("customerIntentionContent", customerIntentionContent);
			dataMap.put("branchOrgList", branchOrgList);
			
			return Result.success(dataMap);
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("新增客户时获取条件，失败原因：" + e.getMessage());
		}
	}
	
	

	
	
}
