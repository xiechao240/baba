package cn.daliedu.mapper;

import cn.daliedu.entity.CustomerSelfDefineItemConfigEntity;

import java.util.List;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 客户自定义类别配置表 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2020-05-20
 */
public interface CustomerSelfDefineItemConfigMapper extends BaseMapper<CustomerSelfDefineItemConfigEntity> {
	/**
	 * 根据客户标签分组类型ID，获取当前客户标签对应的最大值
	 * @param customerTagTypeId 客户标签分组类型ID
	 */
	public Integer getMaxCustomerSelfDefineItemValueByBranchOrgId(String branchOrgId);
	
	public Integer getMaxCustomerSelfDefineItemValue();
	
//	/**
//	 * 获取系统全局的自定义标签
//	 * @return
//	 */
//	public List<CustomerSelfDefineItemConfigEntity> getCustomerSelfDefineItemListByGlobal();
//	
//	/**
//	 * 获取分校的自定义标签
//	 * @param branchOrgId
//	 * @return
//	 */
//	public List<CustomerSelfDefineItemConfigEntity> getCustomerSelfDefineItemListByBranchOrgId(String branchOrgId);
}
