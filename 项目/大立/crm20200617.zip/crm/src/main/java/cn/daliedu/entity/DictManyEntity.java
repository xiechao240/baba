package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import java.util.List;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 存储2个维度的，一对多的数据字典
 * </p>
 *
 * @author xiechao
 * @since 2019-11-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("sys_dict_many")
public class DictManyEntity extends Model<DictManyEntity> {

    private static final long serialVersionUID = 1L;
    
    @TableField(exist=false)
    private List<DictManyDetailEntity> customerSourceDetails;

    /**
     * 数据字典标签ID
     */
    @TableId(value = "tag_id", type = IdType.UUID)
    private Integer tagId;

    /**
     * 数据标签英文名
     */
    private String tag;

    /**
     * 数据标签中文名称
     */
    private String tagName;

    /**
     * 数据标签描述
     */
    private String remark;

    /**
     * 排序值
     */
    private Integer orderNum;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;


    @Override
    protected Serializable pkVal() {
        return this.tagId;
    }

}
