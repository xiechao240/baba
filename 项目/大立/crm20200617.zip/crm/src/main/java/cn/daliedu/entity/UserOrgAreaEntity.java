package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 用户可查看的业务组公海与部门数据，用户可拥有多个分校的数据查看权限，可以不配置此数据，那么就只能查看自己的数据
 * </p>
 *
 * @author xiechao
 * @since 2019-09-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("sys_user_org_area")
public class UserOrgAreaEntity extends Model<UserOrgAreaEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;

    /**
     * 用户ID
     */
    private String userId;

    /**
     * 分校ID，存储用户可以查看的分校数据
     */
    private String branchOrgId;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
