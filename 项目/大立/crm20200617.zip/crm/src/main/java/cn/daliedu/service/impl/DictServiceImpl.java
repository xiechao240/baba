package cn.daliedu.service.impl;

import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.entity.DictEntity;
import cn.daliedu.mapper.DictMapper;
import cn.daliedu.service.DictService;

/**
 * <p>
 * 数据字典表，存储系统中静态的或少量变动的格式化数据 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-21
 */
@Service
public class DictServiceImpl extends ServiceImpl<DictMapper, DictEntity> implements DictService {
	@Resource
	DictMapper dictMapper;
	
	
	@Override
	public List<LinkedHashMap<String, String>> getDictType() throws Exception {
		return dictMapper.getDictType();
	}

	
	@Override
	public List<DictEntity> getDictValueByType(String tag) throws Exception {
		return dictMapper.selectList(new QueryWrapper<DictEntity>().eq("tag", tag));
	}
	
	
	@Override
	public List<DictEntity> findDictListByIsCustomerTag(String isCustomerTag) {
		return dictMapper.selectList(new QueryWrapper<DictEntity>().eq("is_customer_tag", isCustomerTag).groupBy("tag"));
	}
	
	
	@Override
	public DictEntity getDictValueByTagAndRemark(String tag, String remark) throws Exception {
		return dictMapper.selectOne(new QueryWrapper<DictEntity>().eq("tag", tag).eq("remark", remark).last("limit 1"));
	}


	@Override
	public List<DictEntity> findDictListByTag(String tag) {
		return dictMapper.selectList(new QueryWrapper<DictEntity>().eq("tag", tag).orderByAsc("order_num"));
	}
	
	@Override
	public boolean saveDict(DictEntity dict) throws Exception {
		Integer value = this.dictMapper.getValueMax(dict.getTag()) + 1;
		dict.setValue(String.valueOf(value));
		int num = this.dictMapper.insert(dict);
		if (num > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean updateDict(DictEntity dict) throws Exception {
		int num = this.dictMapper.updateById(dict);
		if (num > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean deleteDictById(String id) throws Exception {
		int num = this.dictMapper.deleteById(id);
		if (num > 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean deleteDictByTag(String tag) throws Exception {
		int num = this.dictMapper.delete(new QueryWrapper<DictEntity>().eq("tag", tag));
		if (num > 0) {
			return true;
		}
		return false;
	}

}
