package cn.daliedu.mapper;

import cn.daliedu.entity.MenuEntity;

import java.util.List;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 菜单管理 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
public interface MenuMapper extends BaseMapper<MenuEntity> {
	
	/**
	 * 加载指定节点下的子孙菜单，以树形结构返回
	 * @param parentId 父节点菜单
	 * @return
	 */
	public List<MenuEntity> getTreeMenuListByParentId(int parentId);
	
	/**
	 * 根据角色ID获取角色对应的菜单
	 * @param roleId
	 * @return
	 */
	public List<MenuEntity> getMenuListByRoleId(String roleId);
	
	
	/**
	 * 根据用户ID获取用户拥有的所有角色对应的菜单
	 * @param userId
	 * @return
	 */
	public List<MenuEntity> getMenuListByUserId(String userId);
	
}
