package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 系统参数表
 * </p>
 *
 * @author xiechao
 * @since 2020-02-12
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("sys_parameter")
public class ParameterEntity extends Model<ParameterEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;

    /**
     * 参数名称
     */
    private String paramName;

    /**
     * 参数key
     */
    private String paramKey;

    /**
     * 参数值
     */
    private String paramValue;

    /**
     * 参数描述
     */
    private String paramDesc;

    /**
     * 参数排序
     */
    private Integer paramSort;

    /**
     * 创建人ID
     */
    private String createrById;

    /**
     * 创建人名称
     */
    private String createrByName;

    /**
     * 创建时间
     */
    private LocalDateTime createDateTime;

    /**
     * 修改人ID
     */
    private String updaterById;

    /**
     * 修改人名称
     */
    private String updaterByName;

    /**
     * 修改时间
     */
    private LocalDateTime updateDateTime;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
