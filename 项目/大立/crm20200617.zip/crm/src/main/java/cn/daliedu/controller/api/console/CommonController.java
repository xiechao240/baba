package cn.daliedu.controller.api.console;

import javax.annotation.Resource;

import org.apache.shiro.authz.UnauthorizedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cn.daliedu.config.param.SmsParamConfig;
import cn.daliedu.entity.SmsTemplateEntity;
import cn.daliedu.entity.web.SmsCodeVO;
import cn.daliedu.enums.ResultCodeEnum;
import cn.daliedu.enums.SmsTemplateCodeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.SmsTemplateService;
import cn.daliedu.service.UserService;
import cn.daliedu.shiro.redis.RedisUtil;
import cn.daliedu.util.JsonUtil;
import cn.daliedu.util.Log4jUtil;
import cn.daliedu.util.MessageUtil;
import cn.daliedu.util.RandomUtil;
import cn.daliedu.util.Result;
import cn.daliedu.util.SMSUtil;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;


/**
 * 此类存放整个系统都需要使用的公共接口
 * 
 * @author xiechao
 * @time 2019年2月18日 上午10:02:41
 * @version 1.0.0
 * @description
 */
@Api(description = "公共基础接口")
@RestController
@RequestMapping(value = "${rest.path}/common") // "${rest.path}/contract/common"
public class CommonController {
	
	@Autowired
	UserService userService;

	@Resource
	RedisUtil redisUtil;
	
	@Autowired
	SmsTemplateService smsTemplateService;
	
	/**
	 * 
	 * @param mobile
	 * @return
	 */
	@ApiOperation(value = "获取手机验证码")
	@ApiImplicitParam(paramType = "query", dataType = "String", name = "mobile", value = "手机号", required = true)
	@GetMapping("/getSmsValidateCode")
	public Result getSmsValidateCode(@RequestParam String mobile) {
		try {
			// 校验手机号码
			StringUtil.validateIsNull(mobile, "请填写手机号码");
			mobile = mobile.replaceAll(" ", "");
			StringUtil.validateMobile(mobile, "请填写正确手机号码");

			// 先验证1分钟内不能重复获取
			if (SmsParamConfig.RE_SEND_CHECK > 0) {
				Object obj = redisUtil.get(mobile);
				if (obj != null) {
					String jsonStr = (String) obj;
					Log4jUtil.info("redis中获取存储的手机验证码：" + jsonStr);
					SmsCodeVO smsCodeVO = JsonUtil.getJsonToBean(jsonStr, SmsCodeVO.class);
					if (smsCodeVO != null
							&& (System.currentTimeMillis() - smsCodeVO.getSendTime()) < SmsParamConfig.RE_SEND_CHECK
									* 60 * 1000) {
						throw new BusinessException(MessageUtil.getMessage("sign.sms.code.reSend"));
					}
				}
			}

			String smsCode = RandomUtil.randomNumber(6);
			SmsTemplateEntity smsTemplateEntity = smsTemplateService.getSmsTemplateByTemplateCode(SmsTemplateCodeEnum.SMS_175582380.getValue());
			boolean flag = SMSUtil.sendSms(mobile, smsTemplateEntity, smsCode);
			
			if(flag){
				// 验证码发送成功，存入redis
				Long nowTime = System.currentTimeMillis();
				// 获得验证码有效时间，秒
				Long activeTime = SmsParamConfig.ACTIVE_TIME;
				// 计算验证码失效时间
				Long expireTime = nowTime + (activeTime * 1000);

				SmsCodeVO smsCodeVO = new SmsCodeVO();
				smsCodeVO.setPhone(mobile);
				smsCodeVO.setSmsCode(smsCode);
				smsCodeVO.setSendTime(nowTime);
				smsCodeVO.setExpireTime(expireTime);
				smsCodeVO.setFailCounts(0);

				redisUtil.set(mobile, JsonUtil.toJson(smsCodeVO), activeTime);

				// 成功发送验证码
				return Result.success("验证码发送成功，验证码为：" + smsCode, smsCode);
			}

			return Result.error("验证码发送失败，请联系管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("验证码获取失败，失败原因：" + e.getMessage());
		}
	}
	
	
//	/**
//	 * 必需声明为@GetMapping类型，前端需要下载图片，<img src=""/>
//	 * @param request
//	 * @param response
//	 * @return   注意此接口，必需为 void 返回值，因为返回的是文件数据
//	 * @throws Exception
//	 */
//	@ApiOperation(value="获取图形验证码接口",produces="application/octet-stream") //增加此参数即可完成下载
//	@GetMapping(value = "/getImgValidateCode")
//	public void getImgValidateCode(HttpServletRequest request, HttpServletResponse response){
//		OutputStream oos = null;
//		try{
//			HttpSession session = request.getSession();
//			
//			// 重置response对象中的缓冲区，该方法可以不写，但是你要保证response缓冲区没有其他数据，否则导出可能会出现问题，建议加上
//			// 加上下面这一行，待观察以解决付龙威测试的时候，有报：java.net.SocketException: Connection reset
//			// by peer: socket write error错
//			response.reset();
//			response.setHeader("Pragma", "No-cache");
//	        response.setHeader("Cache-Control", "no-cache");
//	        response.setDateHeader("Expires", 0);
//	        response.setContentType("image/gif");  //这里写在gif也是可以的，不用写成bmp了，因为我这个代码也有生成gif版本验证码的
//
//			Captcha captcha = new PngCaptcha(100, 40, 4);
//			oos = response.getOutputStream();
//			captcha.out(oos);
//			
//
//			String validateCode = captcha.getText();
//			session.setAttribute("validateCode", validateCode);
//		}catch (Exception e) {
//			e.printStackTrace();
//		}finally {
//			if(oos!=null){
//				try {
//					oos.flush();
//					oos.close();
//				} catch (Exception e2) {
//					e2.printStackTrace();
//				}
//			}
//		}
//	}
	
	
//	/**
//	 * 校验图形验证码接口
//	 * @param request
//	 * @return
//	 */
//	@ApiOperation(value="校验图形验证码接口") //增加此参数即可完成下载
//	@GetMapping(value = "/validateImgValidateCode")
//	public Result validateImgValidateCode(HttpServletRequest request){
//		HttpSession session = request.getSession();
//		String validateCode = (String)session.getAttribute("validateCode");
////		System.out.println("验证码为：" + validateCode);
//		return Result.success(validateCode);
//	}
	


}
