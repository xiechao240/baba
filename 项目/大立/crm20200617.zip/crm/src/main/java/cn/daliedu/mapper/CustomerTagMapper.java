package cn.daliedu.mapper;

import java.util.LinkedHashMap;
import java.util.List;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import cn.daliedu.entity.CustomerTagEntity;

/**
 * <p>
 * 客户标签表，用户为客户打上的标签，其实就是作为一个筛选条件，一个客户只能从属于一类标签中的一个值，注意客户标签与用户无关 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-10-24
 */
public interface CustomerTagMapper extends BaseMapper<CustomerTagEntity> {
	
	/**
	 * 根据客户ID获取客户标签
	 * @param map
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerTagListByCustomerId(String customerId);
	
}
