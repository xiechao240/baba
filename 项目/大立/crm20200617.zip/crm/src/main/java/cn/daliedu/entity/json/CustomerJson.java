package cn.daliedu.entity.json;

import cn.daliedu.config.swagger.model.ApiSingleParam;

/**
 * <p>
 * swagger注释属性：客户属性json
 * </p>
 *
 * @author xiechao
 * @since 2019-05-06
 */
public class CustomerJson{
	
	@ApiSingleParam(value = "ID集合", example = "[1,2,3]")
	public static final String ids = "ids";
	
	@ApiSingleParam(value = "客户ID", example = "1")
	public static final String id = "id";
	
	@ApiSingleParam(value = "客户ID", example = "1")
	public static final String customerId = "customerId";
	
	@ApiSingleParam(value = "客户ID集合", example = "[1,2,3]")
	public static final String customerIds = "customerIds";
	
	@ApiSingleParam(value = "客户标签ID集合", example = "[1,2,3]")
	public static final String customerTagIds = "customerTagIds";
	
	@ApiSingleParam(value = "我的客户类型，1：我的客户，2：共享给我的客户，3：共享给同事的客户,此参数为必传参数，默认传1，即查我的客户", example = "1")
    public static final String myCustomerType = "myCustomerType";
	
	@ApiSingleParam(value = "客户意向内容", example = "1")
	public static final String customerIntentionContent = "customerIntentionContent";
	

	@ApiSingleParam(value = "客户分组类型（见数据字典sys_dict表customer_group的定义，1：一般客户，2：意向客户，3：已成交客户，4：无意向客户，5：拉黑客户，6：其他）", example = "1")
	public static final String customerGroupTypeId = "customerGroupTypeId";
	
	@ApiSingleParam(value = "客户阶段，1：新入库，2：初步沟通，3：多次沟通，4：截杀，5：缴费", example = "1")
	public static final String customerStage = "customerStage";
	
	@ApiSingleParam(value = "客户姓名", example = "大客户")
	public static final String customerName = "customerName";
	
	
	@ApiSingleParam(value = "性别，1：男，2：女，3：未知", example = "1")
	public static final String sex = "sex";
	
	@ApiSingleParam(value = "客户来源类型（见数据字典sys_dict表customer_source_type的定义，0：非代理商，1：代理商）", example = "1")
	public static final String customerSourceType = "customerSourceType";
	
	
	
	@ApiSingleParam(value = "客户来源名称类型（见数据字典sys_dict表customer_source_name的定义）", example = "1")
	public static final String customerSourceName = "customerSourceName"; 
	
	@ApiSingleParam(value = "客户来源名称对应的值（见数据字典sys_dict表customer_source_name的定义）", example = "1")
	public static final String customerSourceNameValue = "customerSourceNameValue"; 
	
	@ApiSingleParam(value = "客户标签ID集合", example = "1,2,3")
	public static final String customerTagIdList = "customerTagIdList";
	
	
	@ApiSingleParam(value = "微信号", example = "xiechao")
	public static final String weixinId = "weixinId";
	
	@ApiSingleParam(value = "qq号", example = "543043491")
	public static final String qq = "qq";
	
	@ApiSingleParam(value = "手机", example = "18312346952")
	public static final String mobile = "mobile";
	
	@ApiSingleParam(value = "座机", example = "0731-88888888")
	public static final String phone = "phone";
	
	@ApiSingleParam(value = "邮箱", example = "543043491@qq.com")
	public static final String email = "email";
	
	@ApiSingleParam(value = "地区(省)ID", example = "100000")
	public static final String provinceId = "provinceId";
	
	@ApiSingleParam(value = "地区(省)名称", example = "中国")
	public static final String provinceName = "provinceName";
	
	@ApiSingleParam(value = "地区(市)ID", example = "110100")
	public static final String cityId = "cityId";
	
	@ApiSingleParam(value = "地区(市)名称", example = "北京市")
	public static final String cityName = "cityName";
	
	@ApiSingleParam(value = "地区(区)ID", example = "110101")
	public static final String areaId = "areaId";
	
	@ApiSingleParam(value = "地区(区)名称", example = "东城区")
	public static final String areaName = "areaName";
	
	@ApiSingleParam(value = "公司名称", example = "大立教育")
	public static final String companyName = "companyName";
	
	@ApiSingleParam(value = "地址", example = "鑫远-鑫悦汇")
	public static final String address = "address";
	
	@ApiSingleParam(value = "备注", example = "新创建")
	public static final String remark = "remark";
	
	@ApiSingleParam(value = "工作年限", example = "5")
	public static final String jobAge = "jobAge";
	
	@ApiSingleParam(value = "学历", example = "本科")
	public static final String education = "education";
	
	@ApiSingleParam(value = "专业", example = "计算机")
	public static final String professional = "professional";
	
	@ApiSingleParam(value = "客户活动表单页面网址", example = "www.baidu.com")
	public static final String customerActivityPage = "customerActivityPage";
	
	@ApiSingleParam(value = "客户活动页面分类", example = "3")
	public static final String customerActivityTypePage = "customerActivityTypePage";
	
	
	@ApiSingleParam(value = "备注2", example = "备注2")
	public static final String remark2 = "remark2";
	
	@ApiSingleParam(value = "一建科目2", example = "一建科目2")
	public static final String yijiankemu2 = "yijiankemu2";
	
	@ApiSingleParam(value = "班级名称2", example = "班级名称2")
	public static final String banjimingcheng2 = "banjimingcheng2";
	
	@ApiSingleParam(value = "开始时间", example = "2019-10-01")
	public static final String startDateTime = "startDateTime";
	
	@ApiSingleParam(value = "结束时间", example = "2020-12-31")
	public static final String endDateTime = "endDateTime";
	
	@ApiSingleParam(value = "跟进人ID", example = "1")
	public static final String followUserId = "followUserId";
	
	@ApiSingleParam(value = "推广人ID", example = "1")
	public static final String promotionUserId = "promotionUserId";
	
	@ApiSingleParam(value = "删除人ID", example = "1")
	public static final String deleteUserId = "deleteUserId";
	
	
	@ApiSingleParam(value = "标题", example = "")
	public static final String title = "title";
	
	@ApiSingleParam(value = "客户操作类型，1：删除客户，2：转让客户，3：放弃客户", example = "1")
	public static final String operationType = "operationType";
	
	@ApiSingleParam(value = "原因ID", example = "")
	public static final String causeId = "causeId";
	
	@ApiSingleParam(value = "原因", example = "")
	public static final String cause = "cause";
	
	@ApiSingleParam(value = "1：保留原有共享关系，新增共享同事，2：用新的共享同事覆盖原有共享关系", example = "1")
	public static final String shareType = "shareType";
	
	
	
	@ApiSingleParam(value = "跟进类型(此参数为必填，默认为1),1：所有员工，2：在职员工，3：离职员工，4：无人跟进,", example = "1")
	public static final String followType = "followType";
	
	@ApiSingleParam(value = "放弃类型，原因ID", example = "")
	public static final String waiveCauseId = "waiveCauseId";
	
	@ApiSingleParam(value = "更新动态开始时间", example = "2019-10-01")
	public static final String updateStartDate = "updateStartDate";
	
	@ApiSingleParam(value = "更新动态结束时间", example = "2019-10-31")
	public static final String updateEndDate = "updateEndDate";
	
	@ApiSingleParam(value = "创建开始时间", example = "2019-10-01")
	public static final String createStartDate = "createStartDate";
	
	@ApiSingleParam(value = "创建结束时间", example = "2020-10-31")
	public static final String createEndDate = "createEndDate";
	
	
	@ApiSingleParam(value = "公海ID(其实就是orgId的值)", example = "1")
	public static final String seaId = "seaId";
	
	@ApiSingleParam(value = "导入类型，1：导入给自己，2：导入至公海", example = "1")
	public static final String importType = "importType";
	
	@ApiSingleParam(value = "是否补充已有客户资料信息，1：补充，0：不补充", example = "1")
	public static final String isSupplementCustomerInfo = "isSupplementCustomerInfo";
	
	
	@ApiSingleParam(value = "客户动态ID", example = "1")
	public static final String customerDynamicId = "customerDynamicId";
	
	@ApiSingleParam(value = "客户名称或公司名称", example = "长沙客户")
	public static final String customerNameOrCompanyName = "customerNameOrCompanyName";
	
	@ApiSingleParam(value = "客户名称或电话号码", example = "张三")
	public static final String customerNameOrMobile = "customerNameOrMobile";
	
	@ApiSingleParam(value = "导入客户的批次号", example = "20200609112208")
	public static final String importBatchNo = "importBatchNo";
	
	@ApiSingleParam(value = "联系方式（呼出方式）", example = "1：座机，2：手机")
	public static final String callType = "callType";
	
	@ApiSingleParam(value = "排序字段，success_rate：接通率，call_time：通话时长，call_count：拨打次数，call_avg_time：平均通话时长", example = "success_rate")
	public static final String orderbyParam = "orderbyParam";
	
	
	@ApiSingleParam(value = "排序类别,desc:倒序，asc：正序", example = "desc")
	public static final String sortType = "sortType";
	
}
