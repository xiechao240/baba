package cn.daliedu.util;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.web.OrgTreeNode;


/**
 * 此方法已废弃掉，目前直接写在OrgServiceImpl实现类中，已经很完美了
 * @author xiechao
 * @time 2020年3月6日 上午10:42:35
 * @version 1.0.0 
 * @description
 */
public class OrgTreeUtil {
	/**
	 * 根据父节点找到下面的子孙节点
	 * @param materialGroupList 节点集合
	 * @param treeNode  根据节点查找子孙节点
	 * @return
	 */
	public static OrgTreeNode packageTree(List<OrgEntity> list, OrgTreeNode treeNode) {
		if (list != null && list.size() > 0) {
			list.forEach(entity -> judgeObj(entity, treeNode));
			if (treeNode.getChildren() != null && treeNode.getChildren().size() > 0) {
				treeNode.getChildren().forEach(r -> packageTree(list, r));
			}
		}
		return treeNode;
	}

	public static void judgeObj(OrgEntity entity, OrgTreeNode rootTree) {
		List<OrgTreeNode> children = rootTree.getChildren();
		if (children == null) {
			children = new ArrayList<>();
		}
		if (entity.getParentId() != null && rootTree.getId().equals(entity.getParentId())) {
			children.add(OrgTreeNode.builder()
					.id(entity.getId())
					.name(entity.getOrgName())
	                .orderNum(entity.getOrderNum())
					.parentId(entity.getParentId()).build());
			rootTree.setChildren(children);
		}
	}
	
	public static OrgTreeNode getTree(List<OrgEntity> list){
		OrgTreeNode treeNode = rootTree(rootOrgEntity(list));
		if (list != null && list.size() > 0) {
			list.forEach(entity -> judgeObj(entity, treeNode));
			if (treeNode.getChildren() != null && treeNode.getChildren().size() > 0) {
				treeNode.getChildren().forEach(r -> packageTree(list, r));
			}
		}
		return treeNode;
	}
	
	public static OrgEntity rootOrgEntity(List<OrgEntity> list){
		return list.stream()
                .filter(entity -> entity.getParentId() == null)
                .collect(Collectors.toList()).get(0);
	}
	
	public static OrgTreeNode rootTree(OrgEntity rootOrgEntity){
		return OrgTreeNode.builder()
        .id(rootOrgEntity.getId())
        .name(rootOrgEntity.getOrgName())
        .orderNum(rootOrgEntity.getOrderNum())
        .parentId(null)
        .build();
	}
}
