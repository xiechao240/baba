package cn.daliedu.enums;

/**
 * 呼出方式枚举类
 * @author xiechao
 * @time 2019年9月27日 下午2:44:36
 * @version 1.0.0 
 * @description
 */
public enum  CallTypeEnum {
	/**
	 * 呼出方式：座机
	 */
	TYPE_1("1", "座机"), 
	/**
	 * 呼出方式：手机
	 */
	TYPE_2("2", "手机");

	private String value;
	private String desc;

	CallTypeEnum(final String value, final String desc) {
		this.value = value;
		this.desc = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
	
	 /**
     * 根据枚举值获取枚举描述
     * @param key
     * @return
     */
    public static String getDesc(String value){
    	String returnStr = "";
        for (CallTypeEnum e: CallTypeEnum.values()){
            if(e.getValue().equals(value)){
            	returnStr = e.getDesc();
            	break;
            }
        }
		return returnStr;
    }
    
    /**
     * 根据枚举描述获取枚举值
     * @param key
     * @return
     */
    public static String getValue(String desc){
    	String returnStr = "";
        for (CallTypeEnum e: CallTypeEnum.values()){
            if(e.getDesc().equals(desc)){
            	returnStr = e.getValue();
            	break;
            }
        }
		return returnStr;
    }
    
    /**
     * 判断数值是否属于枚举类的值
     * @param key
     * @return
     */
    public static boolean isInclude(String value){
        boolean include = false;
        for (CallTypeEnum e: CallTypeEnum.values()){
            if(e.getValue().equals(value)){
                include = true;
                break;
            }
        }
        return include;
    }
}