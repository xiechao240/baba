package cn.daliedu.mapper;

import cn.daliedu.entity.UserCustomerCallEntity;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 用户客户通话表 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-11-23
 */
public interface UserCustomerCallMapper extends BaseMapper<UserCustomerCallEntity> {
	
	/**
	 * 【员工联系记录】获取员工联系记录列表
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getCallContactRecordList(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【员工联系记录】获取员工联系记录列表总数
	 * @param map 查询组合参数集合
	 */
	public Long getCallContactRecordListCount(Map<Object, Object> map);
}
