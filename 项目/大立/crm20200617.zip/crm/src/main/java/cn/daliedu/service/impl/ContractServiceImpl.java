package cn.daliedu.service.impl;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.entity.ContractEntity;
import cn.daliedu.entity.ContractReturnMoneyPlanEntity;
import cn.daliedu.entity.ContractReturnMoneyRecordEntity;
import cn.daliedu.entity.CustomerDynamicLogEntity;
import cn.daliedu.entity.CustomerEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.json.ContractModel;
import cn.daliedu.entity.json.ReturnMoneyPlanModel;
import cn.daliedu.enums.ContractStateEnum;
import cn.daliedu.enums.DynamicTypeEnum;
import cn.daliedu.enums.ReturnMoneyStateEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.mapper.ContractMapper;
import cn.daliedu.mapper.ContractReturnMoneyPlanMapper;
import cn.daliedu.mapper.ContractReturnMoneyRecordMapper;
import cn.daliedu.mapper.CustomerDynamicLogMapper;
import cn.daliedu.mapper.CustomerMapper;
import cn.daliedu.service.ContractReturnMoneyPlanService;
import cn.daliedu.service.ContractService;
import cn.daliedu.service.CustomerService;
import cn.daliedu.util.BigDecimalUtil;
import cn.daliedu.util.LocalDateTimeUtil;
import cn.daliedu.util.LocalDateUtil;
import cn.daliedu.util.StringUtil;

/**
 * <p>
 * 客户合同表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-31
 */
@Service
public class ContractServiceImpl extends ServiceImpl<ContractMapper, ContractEntity> implements ContractService {
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	ContractReturnMoneyPlanService contractReturnMoneyPlanService;
	
	@Autowired
	ContractService contractService;
	
	@Resource
	ContractMapper contractMapper;
	
	@Resource
	CustomerDynamicLogMapper customerDynamicLogMapper;
	
	@Resource
	ContractReturnMoneyPlanMapper contractReturnMoneyPlanMapper;
	
	@Resource
	ContractReturnMoneyRecordMapper contractReturnMoneyRecordMapper;
	
	@Resource
	CustomerMapper customerMapper;
	
	
	
	@Override
	public BigDecimal getReturnMoneyByUserId(Map<Object, Object> map) throws Exception {
		return contractMapper.getReturnMoneyByUserId(map);
	}



	@Override
	public List<LinkedHashMap<Object, Object>> getContractAmountCountByBranch(Map<Object, Object> map)
			throws Exception {
		return contractMapper.getContractAmountCountByBranch(map);
	}



	@Override
	public BigDecimal getCreateContactCountByUserId(Map<Object, Object> map) {
		return contractMapper.getCreateContactCountByUserId(map);
	}



	@Override
	public List<LinkedHashMap<Object, Object>> getContractListByUserId(Map<Object, Object> map) throws Exception {
		return contractMapper.getContractListByUserId(map);
	}



	@Override
	public List<LinkedHashMap<Object, Object>> getReturnMoneyNumList(Map<Object, Object> map) {
		return contractReturnMoneyPlanMapper.getReturnMoneyNumList(map);
	}



	@Override
	public boolean saveContractReturnMoneyPlan(ContractModel model) throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity bean = (UserEntity) object;
			
			String customerId = String.valueOf(model.getCustomerId());
			String contractId = String.valueOf(model.getContractId());
			
			StringUtil.validateIsNull(contractId, "请选择对应的合同");
			StringUtil.validateIsNull(customerId, "请选择对应的客户");
			
			ReturnMoneyPlanModel[] returnMoneyPlanModels = model.getReturnMoneyPlanList();
			
			for(ReturnMoneyPlanModel returnMoneyPlanModel : returnMoneyPlanModels){
				String returnMoneyNum = String.valueOf(returnMoneyPlanModel.getReturnMoneyNum());
				String planReturnMoneyDate = String.valueOf(returnMoneyPlanModel.getPlanReturnMoneyDate());
				String planReturnMoney = String.valueOf(returnMoneyPlanModel.getPlanReturnMoney());
				String remark = String.valueOf(returnMoneyPlanModel.getRemark());
				
				StringUtil.validateIsNull(planReturnMoneyDate, "请输入计划回款日期");
				StringUtil.validateIsNull(planReturnMoney, "请输入计划回款金额");
				
				ContractReturnMoneyPlanEntity entity = new ContractReturnMoneyPlanEntity();
				entity.setCustomerId(customerId);
				entity.setContractId(contractId);
				entity.setReturnMoneyNum(Integer.parseInt(returnMoneyNum));
				entity.setPlanReturnMoneyDate(LocalDateUtil.getLocalDate(planReturnMoneyDate, null));
				entity.setPlanReturnMoney(new BigDecimal(planReturnMoney));
				entity.setNoReturnMoney(new BigDecimal(planReturnMoney));//新增时未回款金额，即计划回款金额
				entity.setRemark(remark);
				entity.setReturnMoneyState(ReturnMoneyStateEnum.TYPE_0.getValue());//新增回款计划时，设置默认状态为未完成
				entity.setCreateDate(LocalDateTime.now());
				entity.setUpdateDate(LocalDateTime.now());
				
				contractReturnMoneyPlanMapper.insert(entity);
			}
			
			CustomerEntity entity = customerService.getById(customerId);
			entity.setUpdateTime(LocalDateTime.now());
			entity.setRecentDynamicDateTime(LocalDateTime.now());
			entity.setRecentDynamicContent("新增回款计划");
			customerMapper.updateById(entity);
			
			//记录动态日志
			CustomerDynamicLogEntity dynamicLogEntity = new CustomerDynamicLogEntity();
			dynamicLogEntity.setCustomerId(customerId);
			dynamicLogEntity.setDynamicType(DynamicTypeEnum.TYPE_11.getValue());
			dynamicLogEntity.setDynamicName(DynamicTypeEnum.TYPE_11.getDesc());
			dynamicLogEntity.setDynamicContent("增加回款计划");//如果新增客户的时候，没有写备注，此项将为空
			dynamicLogEntity.setCreateDate(LocalDateTime.now());
			dynamicLogEntity.setDynamicUserId(bean.getId());
			
			if(customerDynamicLogMapper.insert(dynamicLogEntity)>0){
				return true;
			}
		}
		return false;
	}



	@Override
	public boolean saveContractReturnMoneyRecord(String params) throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity bean = (UserEntity) object;
			
			JSONObject jsonObject = JSON.parseObject(params);
			String customerId = String.valueOf(jsonObject.get("customerId"));
			String contractId = String.valueOf(jsonObject.get("contractId"));
			String returnMoneyDate = String.valueOf(jsonObject.get("returnMoneyDate"));
			String returnMoneyStr = String.valueOf(jsonObject.get("returnMoney"));
			String returnMoneyNum = String.valueOf(jsonObject.get("returnMoneyNum"));
			String payType = String.valueOf(jsonObject.get("payType"));
			String returnMoneyType = String.valueOf(jsonObject.get("returnMoneyType"));
			String receiptUserId = String.valueOf(jsonObject.get("receiptUserId"));
			String remark = String.valueOf(jsonObject.get("remark"));
			
			StringUtil.validateIsNull(customerId, "请输入客户ID");
			StringUtil.validateIsNull(contractId, "请选择合同");
			StringUtil.validateIsNull(returnMoneyNum, "请输入回款期次");
			StringUtil.validateIsNull(returnMoneyStr, "请输入回款金额");
			StringUtil.validateIsNull(receiptUserId, "请输入收款人");
			
			BigDecimal returnMoney = new BigDecimal(returnMoneyStr);
			
			//增加回款的数据正确性校验
			ContractReturnMoneyPlanEntity planEntity = contractReturnMoneyPlanService.getReturnMoneyPlan(contractId, Integer.parseInt(returnMoneyNum));
//			BigDecimal planReturnMoney = planEntity.getPlanReturnMoney();//计划回款的金额
			BigDecimal alreadyReturnMoney = planEntity.getAlreadyReturnMoney();//已回款的金额
			BigDecimal noReturnMoney = planEntity.getNoReturnMoney();//未回款的金额
			
			//如果回款金额大于未回款金额，则给出提示
			if(returnMoney.compareTo(noReturnMoney) == 1){
				throw new BusinessException("您输入的回款金额大于未回款金额，请输入正确的回款金额");
			}
			
			
			//1. 增加回款记录数据
			ContractReturnMoneyRecordEntity entity = new ContractReturnMoneyRecordEntity();
			entity.setReturnMoneyDate(LocalDateUtil.getLocalDate(returnMoneyDate, null));
			entity.setReturnMoney(new BigDecimal(returnMoneyStr));
			entity.setCustomerId(customerId);
			entity.setContractId(contractId);
			entity.setReturnMoneyNum(Integer.parseInt(returnMoneyNum));
			entity.setPayType(payType);
			entity.setReturnMoneyType(returnMoneyType);
			entity.setReceiptUserId(receiptUserId);
			entity.setCreateDate(LocalDateTime.now());
			entity.setRemark(remark);
			
			CustomerEntity customerEntity = customerService.getById(customerId);
			customerEntity.setUpdateTime(LocalDateTime.now());
			customerEntity.setRecentDynamicDateTime(LocalDateTime.now());
			customerEntity.setRecentDynamicContent("新增回款记录");
			customerMapper.updateById(customerEntity);
			
			if(contractReturnMoneyRecordMapper.insert(entity)>0){
				ContractEntity contractEntity = contractService.getById(contractId);
				
				//2. 根据合同ID及期次数，找到对应的回款计划，将对应的已回款金额，未回款金额进行扣减
				planEntity.setAlreadyReturnMoney(BigDecimalUtil.add(alreadyReturnMoney, returnMoney));//设置已回款金额为：原来的回款金额+这次的回款金额
				planEntity.setNoReturnMoney(BigDecimalUtil.subtract(noReturnMoney, returnMoney));//设置未回款金额为：原来的未回款金额-这次的回款金额
				if(returnMoney.compareTo(noReturnMoney) == 0){
					//如果已经全部回款，则更新合同本期次
					planEntity.setReturnMoneyState(ReturnMoneyStateEnum.TYPE_1.getValue());
					
					contractEntity.setContractState(ContractStateEnum.STATE_1.getValue());
					
					contractMapper.updateById(contractEntity);//如果已经回完款，那么合同就为已完成的状态
				}
				//回款状态：逾期未完成，采用定时任务去做
				contractReturnMoneyPlanMapper.updateById(planEntity);
				
				//3. 增加客户动态，记录回款动态
				String dynamicContent = "合同：" + contractEntity.getTitle() + "    期次：" +  returnMoneyNum + "    已回款金额：" + BigDecimalUtil.add(alreadyReturnMoney, returnMoney).toString();
				
				CustomerDynamicLogEntity dynamicLogEntity = new CustomerDynamicLogEntity();
				dynamicLogEntity.setCustomerId(customerId);
				dynamicLogEntity.setDynamicType(DynamicTypeEnum.TYPE_12.getValue());
				dynamicLogEntity.setDynamicName(DynamicTypeEnum.TYPE_12.getDesc());
				dynamicLogEntity.setDynamicContent(dynamicContent);//合同：合同1    期次：1    已回款金额：50.00
				dynamicLogEntity.setCreateDate(LocalDateTime.now());
				dynamicLogEntity.setDynamicUserId(bean.getId());
				dynamicLogEntity.setDetailId("");//待设置此id
				
				customerDynamicLogMapper.insert(dynamicLogEntity);
				
				return true;
			}
		}
		return false;
	}
	
	@Override
	public IPage<ContractEntity> getContractListByCustomerId(Integer pageNum, Integer pageSize, String customerId) {
		// 设置分页
		if (pageNum <= 0) {
			pageNum = 1;
		}
		IPage<ContractEntity> page = new Page<ContractEntity>();
		page.setCurrent(pageNum);
		page.setSize(pageSize);
		
		QueryWrapper<ContractEntity> queryWrapper = new QueryWrapper<ContractEntity>();
		queryWrapper.eq("customer_id", customerId);

		return contractMapper.selectPage(page, queryWrapper);
	}
	
	
	@Override
	public List<LinkedHashMap<Object, Object>> getContractListByCustomerId(Map<Object, Object> map) {
		return contractMapper.getContractListByCustomerId(map);
	}



	@Override
	public Long getContractListByCustomerIdCount(Map<Object, Object> map) {
		return contractMapper.getContractListByCustomerIdCount(map);
	}



	@Override
	public boolean saveContract(String params) throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity bean = (UserEntity) object;
			
			JSONObject jsonObject = JSON.parseObject(params);
			String customerId = String.valueOf(jsonObject.get("customerId"));
			String title = String.valueOf(jsonObject.get("title"));
			String amount = String.valueOf(jsonObject.get("amount"));
			String contractDate = String.valueOf(jsonObject.get("contractDate"));
			String graduationYear = String.valueOf(jsonObject.get("graduationYear"));
//			String professionType = String.valueOf(jsonObject.get("professionType"));
			String companyMarketDiscounts = String.valueOf(jsonObject.get("companyMarketDiscounts"));
			String tutionDate = String.valueOf(jsonObject.get("tutionDate"));
			String remark = String.valueOf(jsonObject.get("remark"));
			String contractState = String.valueOf(jsonObject.get("contractState"));
			
			StringUtil.validateIsNull(customerId, "请输入客户ID");
			StringUtil.validateIsNull(title, "请输入合同标题");
			StringUtil.validateIsNull(amount, "请输入合同总金额");
			StringUtil.validateIsNull(contractDate, "请选择签约日期");
			StringUtil.validateIsNull(tutionDate, "请选择开课日期");
			StringUtil.validateIsNull(contractState, "请选择合同状态");
			
			ContractEntity contractEntity = new ContractEntity();
			contractEntity.setCustomerId(customerId);
			contractEntity.setTitle(title);
			contractEntity.setAmount(new BigDecimal(amount));
			contractEntity.setContractDate(LocalDateUtil.getLocalDate(contractDate, null));//签约日期
			contractEntity.setGraduationYear(graduationYear);
//			contractEntity.setProfessionType(professionType);
			contractEntity.setCompanyMarketDiscounts(companyMarketDiscounts);
			contractEntity.setTutionDate(LocalDateTimeUtil.getLocalDateTime(tutionDate, null));//开课日期
//			contractEntity.setContractState(ContractStateEnum.STATE_0.getValue());
			contractEntity.setContractState(contractState);//现在改为可以新建合同，前端输入合同状态
			contractEntity.setCreateUserId(bean.getId());
			contractEntity.setCreateDate(LocalDateTime.now());
			contractEntity.setUpdateDate(LocalDateTime.now());
			contractEntity.setRemark(remark);
			
			
			if(contractMapper.insert(contractEntity)>0){
				CustomerEntity entity = customerService.getById(customerId);
				entity.setUpdateTime(LocalDateTime.now());
				entity.setRecentDynamicDateTime(LocalDateTime.now());
				entity.setRecentDynamicContent("新建合同");
				customerMapper.updateById(entity);
				
				CustomerDynamicLogEntity dynamicLogEntity = new CustomerDynamicLogEntity();
				dynamicLogEntity.setCustomerId(customerId);
				dynamicLogEntity.setDynamicType(DynamicTypeEnum.TYPE_6.getValue());
				dynamicLogEntity.setDynamicName(DynamicTypeEnum.TYPE_6.getDesc());
				dynamicLogEntity.setDynamicContent(title);//填写合同标题
				dynamicLogEntity.setDynamicUserId(bean.getId());
				dynamicLogEntity.setCreateDate(LocalDateTime.now());
				
				customerDynamicLogMapper.insert(dynamicLogEntity);
				
				return true;
			}
		}
		return false;
	}
	
	
	@Override
	public boolean updateContract(String params) throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity bean = (UserEntity) object;
			
			JSONObject jsonObject = JSON.parseObject(params);
			String contractId = String.valueOf(jsonObject.get("contractId"));
			String customerId = String.valueOf(jsonObject.get("customerId"));
			String title = String.valueOf(jsonObject.get("title"));
			String amount = String.valueOf(jsonObject.get("amount"));
			String contractDate = String.valueOf(jsonObject.get("contractDate"));
			String graduationYear = String.valueOf(jsonObject.get("graduationYear"));
			String professionType = String.valueOf(jsonObject.get("professionType"));
			String companyMarketDiscounts = String.valueOf(jsonObject.get("companyMarketDiscounts"));
			String tutionDate = String.valueOf(jsonObject.get("tutionDate"));
			
			StringUtil.validateIsNull(contractId, "请输入合同ID");
			StringUtil.validateIsNull(customerId, "请输入客户ID");
			StringUtil.validateIsNull(title, "请输入合同标题");
			StringUtil.validateIsNull(amount, "请输入合同总金额");
			StringUtil.validateIsNull(contractDate, "请选择签约日期");
			StringUtil.validateIsNull(tutionDate, "请选择开课日期");
			
			ContractEntity contractEntity = new ContractEntity();
			contractEntity.setId(contractId);
			contractEntity.setCustomerId(customerId);
			contractEntity.setTitle(title);
			contractEntity.setAmount(new BigDecimal(amount));
			contractEntity.setContractDate(LocalDateUtil.getLocalDate(contractDate, null));
			contractEntity.setGraduationYear(graduationYear);
			contractEntity.setProfessionType(professionType);
			contractEntity.setCompanyMarketDiscounts(companyMarketDiscounts);
			contractEntity.setCreateUserId(bean.getId());
			contractEntity.setUpdateDate(LocalDateTime.now());
			
			if(contractMapper.updateById(contractEntity)>0){
				return true;
			}
		}
		return false;
	}
	
	
	
	@Override
	public boolean updateContractReturnMoneyPlan(String params) throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
//			UserEntity bean = (UserEntity) object;
			
			JSONObject jsonObject = JSON.parseObject(params);
			String contractId = String.valueOf(jsonObject.get("contractId"));
			String returnMoneyNum = String.valueOf(jsonObject.get("returnMoneyNum"));
			String planReturnMoneyDate = String.valueOf(jsonObject.get("planReturnMoneyDate"));
			String planReturnMoney = String.valueOf(jsonObject.get("planReturnMoney"));
			String remark = String.valueOf(jsonObject.get("remark"));
			
			StringUtil.validateIsNull(contractId, "请选择对应的合同");
			StringUtil.validateIsNull(planReturnMoneyDate, "请输入计划回款日期");
			StringUtil.validateIsNull(planReturnMoney, "请输入计划回款金额");
			
			ContractReturnMoneyPlanEntity entity = new ContractReturnMoneyPlanEntity();
			entity.setPlanReturnMoneyDate(LocalDateUtil.getLocalDate(planReturnMoneyDate, null));
			entity.setPlanReturnMoney(new BigDecimal(planReturnMoney));
			entity.setRemark(remark);
			
			contractReturnMoneyPlanMapper.update(entity, new UpdateWrapper<ContractReturnMoneyPlanEntity>()
					.eq("contract_id", contractId).eq("return_money_num", Integer.parseInt(returnMoneyNum)));
			
		}
		return false;
	}



	

	
	
}
