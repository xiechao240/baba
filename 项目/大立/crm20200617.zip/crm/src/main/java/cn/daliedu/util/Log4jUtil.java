package cn.daliedu.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.daliedu.enums.LogEnum;



/**
 * 此类可以实现系统按不同的层级进行日志记录，
 * @author xiechao
 * @time 2019年2月20日 下午2:11:09
 * @version 1.0.0 
 * @description 使用方式：
 * 			Logger log = LogUtil_Bak.getExceptionLogger();
	    	Logger log1 = LogUtil_Bak.getBussinessLogger();
	    	Logger log2 = LogUtil_Bak.getDBLogger();
	    	log.error("getExceptionLogger===日志测试");
	    	log1.info("getBussinessLogger===日志测试");
	    	log2.debug("getDBLogger===日志测试");
	    	
	    	也可直接连写：LogUtil_Bak.getBussinessLogger().info("");
	    	
	    	目前还在这个类中编写了trace()，debug()， info()，  warn()，error()方法，直接调用的话，默认使用的是log4j2.yml中的全局配置，则日志信息将写入exception文件夹下面的日志中
 */
public class Log4jUtil {
    /**
     * 获取业务日志logger对象
     *
     * @return
     */
    public static Logger getBussinessLogger() {
        return LoggerFactory.getLogger(LogEnum.BUSSINESS.getCategory());
    }
 
    /**
     * 获取平台日志logger对象
     *
     * @return
     */
    public static Logger getPlatformLogger() {
        return LoggerFactory.getLogger(LogEnum.PLATFORM.getCategory());
    }
 
    /**
     * 获取数据库日志logger对象
     *
     * @return
     */
    public static Logger getDBLogger() {
        return LoggerFactory.getLogger(LogEnum.DB.getCategory());
    }
 
    /**
     * 获取异常日志logger对象
     *
     * @return
     */
    public static Logger getExceptionLogger() {
        return LoggerFactory.getLogger(LogEnum.EXCEPTION.getCategory());
    }
    
    
    /**
	 * 获取最原始被调用的堆栈信息
	 * 
	 * @return
	 */
	private static StackTraceElement findCaller() {
		// 获取堆栈信息
		StackTraceElement[] callStack = Thread.currentThread().getStackTrace();
		if (null == callStack) {
			return null;
		}
		// 最原始被调用的堆栈信息
		StackTraceElement caller = null;
		// 日志类名称
		String logClassName = Log4jUtil.class.getName();
		// 循环遍历到日志类标识
		boolean isEachLogClass = false;

		// 遍历堆栈信息，获取出最原始被调用的方法信息
		for (StackTraceElement strackTraceEle : callStack) {
			// 遍历到日志类
			if (logClassName.equals(strackTraceEle.getClassName())) {
				isEachLogClass = true;
			}
			// 下一个非日志类的堆栈，就是最原始被调用的方法
			if (isEachLogClass) {
				if (!logClassName.equals(strackTraceEle.getClassName())) {
					isEachLogClass = false;
					caller = strackTraceEle;
					break;
				}
			}
		}
		return caller;
	}

	/**
	 * 自动匹配请求类名，生成logger对象，此处 logger name 值为 [className].[methodName]() Line:
	 * [fileLine]
	 * 
	 * @return
	 * @author yzChen
	 * @date 2016年10月13日 下午11:50:59
	 */
	private static Logger logger() {
		StackTraceElement caller = findCaller();// 最原始被调用的堆栈对象
		if (caller == null) {
			return LoggerFactory.getLogger(Log4jUtil.class);
		} else {
			return LoggerFactory.getLogger(
					caller.getClassName() + "." + caller.getMethodName() + "() Line: " + caller.getLineNumber());
		}
	}

	/**
	 * 不调用日志策略，则默认日志记录至exception文件夹下
	 * @param msg 日志信息
	 * @param e 异常信息
	 */
	public static void trace(String msg) {
		trace(msg, null);
	}

	/**
	 * 不调用日志策略，则默认日志记录至exception文件夹下
	 * @param msg 日志信息
	 * @param e 异常信息
	 */
	public static void trace(String msg, Throwable e) {
		logger().trace(msg, e);
	}

	/**
	 * 不调用日志策略，则默认日志记录至exception文件夹下
	 * @param msg 日志信息
	 */
	public static void debug(String msg) {
		debug(msg, null);
	}

	/**
	 * 不调用日志策略，则默认日志记录至exception文件夹下
	 * @param msg 日志信息
	 * @param e 异常信息
	 */
	public static void debug(String msg, Throwable e) {
		logger().debug(msg, e);
	}
	
	/**
	 * 不调用日志策略，则默认日志记录至exception文件夹下
	 * @param msg 日志信息
	 */
	public static void info(String msg) {
		info(msg, null);
	}

	/**
	 * 不调用日志策略，则默认日志记录至exception文件夹下
	 * @param msg 日志信息
	 * @param e 异常信息
	 */
	public static void info(String msg, Throwable e) {
		logger().info(msg, e);
	}

	/**
	 * 不调用日志策略，则默认日志记录至exception文件夹下
	 * @param msg 日志信息
	 */
	public static void warn(String msg) {
		warn(msg, null);
	}

	/**
	 * 不调用日志策略，则默认日志记录至exception文件夹下
	 * @param msg 日志信息
	 * @param e 异常信息
	 */
	public static void warn(String msg, Throwable e) {
		logger().warn(msg, e);
	}

	/**
	 * 不调用日志策略，则默认日志记录至exception文件夹下
	 * @param msg 日志信息
	 */
	public static void error(String msg) {
		error(msg, null);
	}

	/**
	 * 不调用日志策略，则默认日志记录至exception文件夹下
	 * @param msg 日志信息
	 * @param e 异常信息
	 */
	public static void error(String msg, Throwable e) {
		logger().error(msg, e);
	}
 
 
}
