package cn.daliedu.service;

import cn.daliedu.entity.UserRoleEntity;


import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户角色 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
public interface UserRoleService extends IService<UserRoleEntity> {
	
	/**
	 * 根据用户ID获取用户的角色
	 * @param userId
	 * @return
	 */
	public UserRoleEntity getRoleByUserId(String userId);
	
	
	
}
