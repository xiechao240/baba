package cn.daliedu.shiro.redis;


import com.alibaba.fastjson.JSON;
import cn.daliedu.enums.ResultCodeEnum;
import cn.daliedu.util.Log4jUtil;
import cn.daliedu.util.Result;

import cn.daliedu.entity.UserEntity;

import org.apache.shiro.cache.Cache;
import org.apache.shiro.cache.CacheManager;
import org.apache.shiro.session.Session;
import org.apache.shiro.session.mgt.DefaultSessionKey;
import org.apache.shiro.session.mgt.SessionManager;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.filter.AccessControlFilter;
import org.apache.shiro.web.util.WebUtils;
 
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
 
 
public class SessionControlFilter extends AccessControlFilter {
    private String kickoutUrl; //踢出后到的地址
    private boolean kickoutAfter = false; //踢出之前登录的/之后登录的用户 默认踢出之前登录的用户
    private int maxSession = 1; //同一个帐号最大会话数 默认1
 
    private SessionManager sessionManager;
    private Cache<String, Deque<Serializable>> cache;
 
    /**
     * 在允许访问的时候执行此方法，我这里：当允许访问的时候，什么也不做，直接访问false去执行下面的，当不允许访问的时候应该执行的逻辑
     * 他的逻辑是这样：先调用isAccessAllowed，如果返回的是true，则直接放行执行后面的filter和servlet，如果返回的是false，
     * 则继续执行后面的onAccessDenied方法，如果后面返回的是true则也可以有权限继续执行后面的filter和servelt。
     * 
     */
    /**
    *
    * 表示是否允许访问；mappedValue就是[urls]配置中拦截器参数部分，如果允许访问返回true，否则false；
    * (感觉这里应该是对白名单（不需要登录的接口）放行的)
    * 如果isAccessAllowed返回true则onAccessDenied方法不会继续执行
    * 这里可以用来判断一些不被通过的链接（个人备注）
    * * 表示是否允许访问 ，如果允许访问返回true，否则false；
    * @param request
    * @param response
    * @param mappedValue 表示写在拦截器中括号里面的字符串 mappedValue 就是 [urls] 配置中拦截器参数部分
    * @return
    * @throws Exception
    * */
    @Override
    protected boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue) throws Exception {
    	HttpServletResponse httpServletResponse = WebUtils.toHttp(response);
    	Subject subject = getSubject(request, response);
    	
//    	System.out.println("subject.isAuthenticated()状态：" + subject.isAuthenticated());
//    	System.out.println("isLoginRequest(request, response)状态：" + isLoginRequest(request, response));
//    	System.out.println("subject.getPrincipal() != null状态：" + subject.getPrincipal() != null);
    	
//        if(!subject.isAuthenticated()) {
//            //如果没有登录，直接进行之后的流程
//        	System.out.println("进入。。。");
//        	timeOutJson(httpServletResponse);
//            return true;
//        }
//        return false;
    	
//        return false;
        if (isLoginRequest(request, response)) {
            return true;
        } else {
            //Subject subject = getSubject(request, response);
            // If principal is not null, then the user is known and should be allowed access.
            return subject.getPrincipal() != null;
        }
    	
//      Subject subject = getSubject(request, response);
//      // If principal is not null, then the user is known and should be allowed access.
//      boolean flag = subject.getPrincipal() != null;
//      System.out.println("session的结果：" + flag);
//      return flag;
    }
 
    /**
     * 在不允许访问的时候执行此方法
     */
    /**
     * 表示当访问拒绝时是否已经处理了；如果返回true表示需要继续处理；如果返回false表示该拦截器实例已经处理了，将直接返回即可。
     * onAccessDenied是否执行取决于isAccessAllowed的值，如果返回true则onAccessDenied不会执行；如果返回false，执行onAccessDenied
     * 如果onAccessDenied也返回false，则直接返回，不会进入请求的方法（只有isAccessAllowed和onAccessDenied的情况下）
     * */
    @Override
    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {
    	HttpServletResponse httpServletResponse = WebUtils.toHttp(response);
//    	System.out.println("超时了。。。。。。。。。。");
        //前端http请求中code为403的时候跳转到登陆页，R.fail()为你返回给前端的json对象
//        RenderUtil.renderJson(httpServletResponse, R.fail(RetEnum.LOGIN_EXPIRED.getRet(),RetEnum.LOGIN_EXPIRED.getMsg()));
        timeOutJson(httpServletResponse);
        return true;
        
//    	return false;
    	
//    	Subject subject = getSubject(request, response);
//        if(!subject.isAuthenticated() && !subject.isRemembered()) {
//            //如果没有登录，直接进行之后的流程
//        	System.out.println("进入。。。");
//        	timeOutJson(httpServletResponse);
//            return false;
//        }
        
//        
//        String username = "";
// 
//        Session session = subject.getSession();
////        User user = (User) subject.getPrincipal();
////        username = user.getName();
//        Object object = subject.getPrincipal();
//        if(object instanceof User){
//        	User user = (User)object;
//        	username = user.getName();
//        }
//        if(object instanceof Vip){
//        	Vip user = (Vip)object;
//        	username = user.getLoginName();
//        }
//        
//        Serializable sessionId = session.getId();
// 
//        Log4jUtil.info("操作缓存：" + username);
//        Log4jUtil.info("sessionId:" + sessionId);
//        
//        //读取缓存   没有就存入
//        Deque<Serializable> deque = cache.get(username);
// 
//        //如果此用户没有session队列，也就是还没有登录过，缓存中没有
//        //就new一个空队列，不然deque对象为空，会报空指针
//        if(deque == null){
//            deque = new LinkedList<Serializable>();
//        }
// 
//        //如果队列里没有此sessionId，且用户没有被踢出；放入队列
//        if(!deque.contains(sessionId) && session.getAttribute("kickout") == null) {
//            //将sessionId存入队列
//            deque.push(sessionId);
//            //将用户的sessionId队列缓存
//            cache.put(username, deque);
//        }
// 
//        //如果队列里的sessionId数超出最大会话数，开始踢人
//        while(deque.size() > maxSession) {
//            Serializable kickoutSessionId = null;
//            if(kickoutAfter) { //如果踢出后者
//            	Log4jUtil.info("踢出后   者。。。。");
//                kickoutSessionId = deque.removeFirst();
//                //踢出后再更新下缓存队列
//                cache.put(username, deque);
//            } else { //否则踢出前者
//            	Log4jUtil.info("踢出前   者。。。。");
//                kickoutSessionId = deque.removeLast();
//                //踢出后再更新下缓存队列
//                cache.put(username, deque);
//            }
// 
//            try {
//                //获取被踢出的sessionId的session对象
//                Session kickoutSession = sessionManager.getSession(new DefaultSessionKey(kickoutSessionId));
//                if(kickoutSession != null) {
//                	Log4jUtil.info("已经踢出了。。。。。");
//                    //设置会话的kickout属性表示踢出了
//                    kickoutSession.setAttribute("kickout", true);
//                }
//            } catch (Exception e) {//ignore exception
// 
//            }
//        }
// 
//        //如果被踢出了，直接退出，重定向到踢出后的地址
//        if (session.getAttribute("kickout") != null) {
//            //会话被踢出了
//            try {
//            	Log4jUtil.info("被踢出了，直接退出。。。。");
//                //退出登录
//                subject.logout();
//            } catch (Exception e) { //ignore
//            }
//            saveRequest(request);
// 
//            Map<String, String> resultMap = new HashMap<String, String>();
//            //判断是不是Ajax请求
//            if ("XMLHttpRequest".equalsIgnoreCase(((HttpServletRequest) request).getHeader("X-Requested-With"))) {
//                resultMap.put("user_status", "300");
//                resultMap.put("message", "您已经在其他地方登录，请重新登录！");
//                //输出json串
//                out(response, resultMap);
//            }else{
//                //重定向
//                WebUtils.issueRedirect(request, response, kickoutUrl);
//            }
//            return false;
//        }
//        return true;
    }
    
	/**
     * session超时给前端返回json信息
     */
    private  void timeOutJson(HttpServletResponse response) {
        try {
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            PrintWriter writer = response.getWriter();
//            writer.write(JSON.toJSONString());
            writer.write(JSON.toJSONString(Result.error(ResultCodeEnum.USER_SESSION_TIME_OUT)));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
 
    private void out(ServletResponse hresponse, Map<String, String> resultMap)
            throws IOException {
        try {
            hresponse.setCharacterEncoding("UTF-8");
            PrintWriter out = hresponse.getWriter();
            out.println(JSON.toJSONString(resultMap));
            out.flush();
            out.close();
        } catch (Exception e) {
            System.err.println("KickoutSessionFilter.class 输出JSON异常，可以忽略。");
        }
    }
 
    public String getKickoutUrl() {
        return kickoutUrl;
    }
 
    public void setKickoutUrl(String kickoutUrl) {
        this.kickoutUrl = kickoutUrl;
    }
 
    public boolean isKickoutAfter() {
        return kickoutAfter;
    }
 
    public void setKickoutAfter(boolean kickoutAfter) {
        this.kickoutAfter = kickoutAfter;
    }
 
    public int getMaxSession() {
        return maxSession;
    }
 
    public void setMaxSession(int maxSession) {
        this.maxSession = maxSession;
    }
 
    public SessionManager getSessionManager() {
        return sessionManager;
    }
 
    public void setSessionManager(SessionManager sessionManager) {
        this.sessionManager = sessionManager;
    }
 
    public Cache<String, Deque<Serializable>> getCache() {
        return cache;
    }
 
    public void setCache(CacheManager cacheManager) {
        this.cache = cacheManager.getCache("shiro_redis_cache");
    }
}
