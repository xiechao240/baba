package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import java.util.List;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 客户标签分组表
 * </p>
 *
 * @author xiechao
 * @since 2019-10-24
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_customer_tag_group")
public class CustomerTagGroupEntity extends Model<CustomerTagGroupEntity> {

    private static final long serialVersionUID = 1L;
    

    /**
     * 客户标签分组类型ID，主键ID
     */
    @TableId(value = "customer_tag_type_id", type = IdType.AUTO)
    private Integer customerTagTypeId;
    
    @TableField(exist = false)
    private List<CustomerTagGroupDetailEntity> customerTagGroupDetailList;
    
    /**
     * 分校ID
     */
    private String branchOrgId;
    

    /**
     * 客户标签分组类型名称
     */
    private String customerTagTypeName;

    /**
     * 描述此数据标签值的含义
     */
    private String remark;

    /**
     * 排序值
     */
    private Integer orderNum;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
    
    /**
     * 是否是初始数据模板
     */
    private Boolean isInit;


    @Override
    protected Serializable pkVal() {
        return this.customerTagTypeId;
    }

}
