package cn.daliedu.service.impl;

import cn.daliedu.entity.CustomerTagGroupDetailEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.mapper.CustomerTagGroupDetailMapper;
import cn.daliedu.service.CustomerTagGroupDetailService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import java.time.LocalDateTime;
import java.util.List;

import javax.annotation.Resource;

import org.apache.shiro.SecurityUtils;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 客户标签分组明细表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-24
 */
@Service
public class CustomerTagGroupDetailServiceImpl extends ServiceImpl<CustomerTagGroupDetailMapper, CustomerTagGroupDetailEntity> implements CustomerTagGroupDetailService {

	@Resource
	CustomerTagGroupDetailMapper customerTagGroupDetailMapper;
	
	@Override
	public List<CustomerTagGroupDetailEntity> getCustomerTagGroupDetailByCustomerTagTypeId(String customerTagTypeId) {
		return customerTagGroupDetailMapper.selectList(new QueryWrapper<CustomerTagGroupDetailEntity>().eq("customer_tag_type_id", customerTagTypeId).orderByAsc("order_num"));
	}

	@Override
	public boolean saveCustomerTagGroupDetail(String customerTagTypeId, String customerTagName) throws Exception {
		Integer orderNum = customerTagGroupDetailMapper.getMaxCustomerTagDetailValueByCustomerTagTypeId(Integer.parseInt(customerTagTypeId));
		
		CustomerTagGroupDetailEntity entity = new CustomerTagGroupDetailEntity();
		entity.setCreateTime(LocalDateTime.now());
		entity.setCustomerTagName(customerTagName);
		entity.setOrderNum(orderNum==null ? 0 : orderNum+1);
		entity.setCustomerTagTypeId(Integer.parseInt(customerTagTypeId));
		
		Object object = SecurityUtils.getSubject().getPrincipal();
		UserEntity user = null;
		if (object instanceof UserEntity) {
			user = (UserEntity) object;
			entity.setCreateBy(user.getId());
		}
		
		int num = customerTagGroupDetailMapper.insert(entity);
		if(num>0){
			return true;
		}
		return false;
	}

	@Override
	public boolean existsCustomerTagName(String customerTagTypeId, String customerTagName) {
		List<CustomerTagGroupDetailEntity> list = customerTagGroupDetailMapper.selectList(new QueryWrapper<CustomerTagGroupDetailEntity>()
				.eq("customer_tag_type_id", Integer.parseInt(customerTagTypeId))
				.eq("customer_tag_name", customerTagName));
		if(list!=null && list.size()>0){
			return true;
		}
		return false;
	}
	

	@Override
	public boolean existsCustomerTagNameByTagId(String customerTagTypeId, String customerTagName) {
		List<CustomerTagGroupDetailEntity> list = customerTagGroupDetailMapper.selectList(new QueryWrapper<CustomerTagGroupDetailEntity>()
				.eq("customer_tag_type_id", Integer.parseInt(customerTagTypeId))
				.eq("customer_tag_name", customerTagName));
		if(list!=null && list.size()>0){
			return true;
		}
		return false;
	}
	
	

	
}
