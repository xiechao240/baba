package cn.daliedu.entity.web;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author xiechao
 * @time 2019年11月28日 上午9:25:45
 * @version 1.0.0 
 * @description 
 */
@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class CustomerContactVO {

	private static final long serialVersionUID = 3947907013587170251L;
	
	/**
	 * 排序号(前端如果需要，再加上此字段即可)
	 */
//	private Integer orderNum;
	
	/**
	 * 联系名称
	 */
	private String contactName;
	/**
	 * 客户数
	 */
	private BigDecimal customerCount;
	
	/**
	 * 百分比
	 */
	private BigDecimal percentage;

	/**
	 * @return the contactName
	 */
	public String getContactName() {
		return contactName;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
}
