package cn.daliedu.controller.api.console;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.CustomerTagGroupDetailEntity;
import cn.daliedu.entity.json.CustomerTagGroupJson;
import cn.daliedu.entity.json.OrgJson;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.CustomerTagGroupDetailService;
import cn.daliedu.service.CustomerTagService;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 客户标签分组明细表 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2019-10-24
 */
@Api(description = "客户标签分组明细接口")
@RestController
@RequestMapping("${rest.path}/console/customerTagGroupDetail")
public class CustomerTagGroupDetailController {
	
	@Autowired
	CustomerTagService customerTagService;
	
	@Autowired
	CustomerTagGroupDetailService customerTagGroupDetailService;
	
	@ApiOperation(value = "根据客户标签分组类型ID，加载客户标签分组下的标签明细")
	@ApiJsonObject(name = "getCustomerTagGroupDetail", value = {
			@ApiJsonProperty(name = CustomerTagGroupJson.customerTagTypeId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerTagGroupDetail")
	@PostMapping("/getCustomerTagGroupDetail")
	public Result getCustomerTagGroupDetail(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String customerTagTypeId = String.valueOf(jsonObject.get("customerTagTypeId"));
			
			StringUtil.validateIsNull(customerTagTypeId, "请输入客户标签分组类型ID");
			
			customerTagTypeId  = customerTagTypeId.trim();
			
			List<CustomerTagGroupDetailEntity> list = customerTagGroupDetailService.getCustomerTagGroupDetailByCustomerTagTypeId(customerTagTypeId);
			
			return Result.success(list);
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户标签分组下的明细失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "新增客户标签明细接口")
	@ApiJsonObject(name = "saveCustomerTagGroupDetail", value = { 
			@ApiJsonProperty(name = CustomerTagGroupJson.customerTagName),
			@ApiJsonProperty(name = CustomerTagGroupJson.customerTagTypeId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "saveCustomerTagGroupDetail")
	@PostMapping("/saveCustomerTagGroupDetail")
	public Result saveCustomerTagGroupDetail(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String customerTagName = String.valueOf(jsonObject.get("customerTagName"));
			String customerTagTypeId = String.valueOf(jsonObject.get("customerTagTypeId"));
			
			StringUtil.validateIsNull(customerTagName, "请输入标签名称");
			StringUtil.validateIsNull(customerTagTypeId, "请输入分组标签ID");
			
			//判断标签名称是否存在
			if(customerTagGroupDetailService.existsCustomerTagName(customerTagTypeId, customerTagName)){
				return Result.error("此客户标签已经存在，请重新输入");
			}else{
				boolean flag = customerTagGroupDetailService.saveCustomerTagGroupDetail(customerTagTypeId, customerTagName);
				if(flag){
					return Result.success("新增成功");
				}else{
					return Result.error("新增失败");
				}
			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("新增数据字典类型失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "修改客户标签明细接口")
	@ApiJsonObject(name = "updateCustomerTagGroupDetail", value = {
			@ApiJsonProperty(name = CustomerTagGroupJson.customerTagTypeId),
			@ApiJsonProperty(name = CustomerTagGroupJson.customerTagId),
			@ApiJsonProperty(name = CustomerTagGroupJson.customerTagName),
			@ApiJsonProperty(name = OrgJson.orderNum)})
	@ApiImplicitParam(name = "params", required = true, dataType = "updateCustomerTagGroupDetail")
	@PostMapping("/updateCustomerTagGroupDetail")
	public Result updateCustomerTagGroupDetail(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String customerTagTypeId = String.valueOf(jsonObject.get("customerTagTypeId"));
			String customerTagId = String.valueOf(jsonObject.get("customerTagId"));
			String customerTagName = String.valueOf(jsonObject.get("customerTagName"));
			String orderNum = String.valueOf(jsonObject.get("orderNum"));
			
			StringUtil.validateIsNull(customerTagTypeId, "请输入客户标签类别ID不能为空");
			StringUtil.validateIsNull(customerTagId, "请输入客户标签ID不能为空");
			StringUtil.validateIsNull(customerTagName, "请输入客户标签名称不能为空");
			StringUtil.validateIsNull(orderNum, "请输入排序号");
			
			//判断标签名称是否存在
//			if(customerTagGroupDetailService.existsCustomerTagNameByTagId(customerTagTypeId, customerTagName)){
//				return Result.error("此客户标签已经存在，请重新输入");
//			}else{
				CustomerTagGroupDetailEntity entity = new CustomerTagGroupDetailEntity();
				entity.setCustomerTagId(Integer.parseInt(customerTagId));
				entity.setCustomerTagName(customerTagName);
				entity.setOrderNum(Integer.parseInt(orderNum));
				
				if(customerTagGroupDetailService.updateById(entity)){
					return Result.success("修改成功！");
				}
				return Result.error("修改失败！");
//			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("修改数据字典失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "删除标签明细接口(如果已经被客户使用，则不允许删除)")
	@ApiJsonObject(name = "deleteCustomerTagGroupDetail", value = {
			@ApiJsonProperty(name = CustomerTagGroupJson.customerTagId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "deleteCustomerTagGroupDetail")
	@PostMapping("/deleteCustomerTagGroupDetail")
	public Result deleteCustomerTagGroupDetail(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String customerTagId = String.valueOf(jsonObject.get("customerTagId"));
			
			StringUtil.validateIsNull(customerTagId, "客户标签ID不能为空");
			
			if(customerTagService.existsCustomerTagIdUse(customerTagId)){
				return Result.error("此标签已经被使用，不能删除");
			}else{
				CustomerTagGroupDetailEntity entity = new CustomerTagGroupDetailEntity();
				entity.setCustomerTagId(Integer.parseInt(customerTagId));
				
				boolean flag = customerTagGroupDetailService.removeById(entity);
				if(flag){
					return Result.success("删除标签成功！");
				}
				return Result.error("删除标签失败！");
			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("删除标签失败，失败原因：" + e.getMessage());
		}
	}
}
