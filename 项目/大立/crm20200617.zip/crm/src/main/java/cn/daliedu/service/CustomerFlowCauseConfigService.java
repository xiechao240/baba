package cn.daliedu.service;

import cn.daliedu.entity.CustomerFlowCauseConfigEntity;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 客户流转原因配置表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-15
 */
public interface CustomerFlowCauseConfigService extends IService<CustomerFlowCauseConfigEntity> {

}
