package cn.daliedu.entity.json;

import cn.daliedu.config.swagger.model.ApiSingleParam;

/**
 * <p>
 * swagger注释属性：合同属性json
 * </p>
 *
 * @author xiechao
 * @since 2019-05-06
 */
public class ContractJson{
	
	
	@ApiSingleParam(value = "创建人用户ID(即负责人ID)", example = "1")
	public static final String createUserId = "createUserId";
	
	@ApiSingleParam(value = "合同ID", example = "1")
	public static final String contractId = "contractId";
	
	@ApiSingleParam(value = "标题", example = "合同1")
	public static final String title = "title";
	
	@ApiSingleParam(value = "合同总金额", example = "100.00")
	public static final String amount = "amount";
	
	@ApiSingleParam(value = "签约日期", example = "2019-11-01")
	public static final String contractDate = "contractDate";
	
	@ApiSingleParam(value = "毕业年份", example = "2019-11")
	public static final String graduationYear = "graduationYear";
	
	@ApiSingleParam(value = "专业类型", example = "计算机")
	public static final String professionType = "professionType";
	
	@ApiSingleParam(value = "公司市场优惠", example = "优惠100元")
	public static final String companyMarketDiscounts = "companyMarketDiscounts";
	
	@ApiSingleParam(value = "开课时间", example = "2019-11-01 09:00:00")
	public static final String tutionDate = "tutionDate";
	
	@ApiSingleParam(value = "合同状态，0：未完成，1：已完成", example = "1")
	public static final String contractState = "contractState";
	
	@ApiSingleParam(value = "期次", example = "1")
	public static final String returnMoneyNum = "returnMoneyNum";
	
	@ApiSingleParam(value = "计划回款日期", example = "2019-11-01")
	public static final String planReturnMoneyDate = "planReturnMoneyDate";
	
	
	@ApiSingleParam(value = "回款日期", example = "2019-11-01")
	public static final String returnMoneyDate = "returnMoneyDate";
	
	@ApiSingleParam(value = "计划回款金额", example = "100.00")
	public static final String planReturnMoney = "planReturnMoney";
	
	@ApiSingleParam(value = "回款金额", example = "100.00")
	public static final String returnMoney = "returnMoney";
	
	@ApiSingleParam(value = "备注", example = "备注")
	public static final String remark = "remark";
	
	@ApiSingleParam(value = "付款方式（见数据字典pay_type定义）", example = "1")
	public static final String payType = "payType";
	
	
	@ApiSingleParam(value = "回款类型（见数据字典return_money_type定义）", example = "1")
	public static final String returnMoneyType = "returnMoneyType";
	
	@ApiSingleParam(value = "收款人ID（下拉框选择的用户ID）", example = "1")
	public static final String receiptUserId = "receiptUserId";
	
	
	@ApiSingleParam(value = "回款状态（0：未完成，1：完成，2：逾期未完成）", example = "1")
	public static final String returnMoneyState = "returnMoneyState";
	
	
}
