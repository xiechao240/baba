package cn.daliedu.exception;

/**
 * 自定义业务层异常
 * 
 * @author xiechao
 * @time 2019年2月18日 上午10:13:15
 * @version 1.0.0
 * @description
 */
public class BusinessException extends Exception {
	private static final long serialVersionUID = 1L;

	public BusinessException(String message) {
		super(message);
	}

	public BusinessException(String message, Throwable cause) {
		super(message, cause);
	}

	public BusinessException(Throwable cause) {
		super(cause);
	}
}
