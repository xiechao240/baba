package cn.daliedu.shiro;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.session.Session;
import org.apache.shiro.util.ThreadContext;
import org.apache.shiro.web.filter.authc.FormAuthenticationFilter;
import org.apache.shiro.web.subject.WebSubject;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import cn.daliedu.enums.ResultCodeEnum;
import cn.daliedu.shiro.redis.MyRedisSessionDAO;
import cn.daliedu.util.Result;
import cn.daliedu.util.SpringUtil;



/**
 * @author xiechao
 * @time 2019年2月12日 下午4:44:59
 * @version 1.0.0
 * @description 这个token其实是在org.apache.shiro.web.filter.authc.FormAuthenticationFilter的createToken创建返回的，
 *              所以，可以写个类继承FormAuthenticationFilter，重写createToken方法，在该方法里面返回自己的创建UsernamePasswordToken
 */
public class MyFormAuthenticationFilter extends FormAuthenticationFilter {

	@Override
	protected MyUsernamePasswordToken createToken(ServletRequest request, ServletResponse response) {
		// TODO: 不知道什么原因, 在 Spring Boot 应用中, 无法初始化 WebSubject ??????????下面代码的作用，暂时还没完全搞清楚
//		WebSubject.Builder builder = new WebSubject.Builder(request, response);
//	    WebSubject webSubject = builder.buildWebSubject();
//	    ThreadContext.bind(webSubject);
		
		String username = getUsername(request);
		String password = getPassword(request);
//		String userType = request.getParameter("userType");

		 MyUsernamePasswordToken token = new MyUsernamePasswordToken(username, password);
//		 token.setUserType(userType);
		
//		 System.out.println("token 获取用户名：" + token1.getUsername());
//		 System.out.println("token 获取密码：" + token1.getPassword());
//		 System.out.println("token 获取userType：" + token1.getUserType());
		 return token;

//		return new MyUsernamePasswordToken(username, password, userType);  //怀疑这个构造方法有问题，可能上面的写法没问题

	}
	
	
	@Override
    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {
        if (isLoginRequest(request, response)) {
            if (isLoginSubmission(request, response)) {
                System.out.println("登录提交检测。尝试执行登录。");
//            	if (logger.isTraceEnabled()) {
//                    logger.trace("Login submission detected.  Attempting to execute login.");
//                }
                return executeLogin(request, response);
            } else {
            	System.out.println("显示登录页面");
//                if (logger.isTraceEnabled()) {
//                    logger.trace("Login page view.");
//                }
                //allow them to see the login page ;)
                return true;
            }
        } else {
            HttpServletRequest req = (HttpServletRequest)request;
            HttpServletResponse resp = (HttpServletResponse) response;
//            System.out.println("请求方法为：" + req.getMethod());
//            System.out.println("options操作的方法为：" + RequestMethod.OPTIONS.name());
            if(req.getMethod().equals(RequestMethod.OPTIONS.name())) {
                resp.setStatus(HttpStatus.OK.value());
                return true;
            }
 
           
            //前端Ajax请求时requestHeader里面带一些参数，用于判断是否是前端的请求
            String cookies= req.getHeader("Cookies"); //这个Cookies是为了支持渠道版跨域访问添加的，因为Cookie是关键字，渠道版跨域无法使用Cookie添加在请求头里面
            String cookie= req.getHeader("Cookie");
//            System.out.println("获取到的cookie:" + cookie);
//            System.out.println("获取到的cookies:" + cookies);
            
            //如果从来没登录过这个系统，则不用执行下面的判断用户是否超时
            if(cookies==null && cookie==null){
            	renderJson(req, resp, Result.error(ResultCodeEnum.USER_NO_LOGIN));
            	return false;
            }
            
            //如果渠道版本前台传了cookies，但cookies的值就是一个null字符串，也要进行处理
            if(cookies!=null && cookies.trim().equals("null")){
//            	resp.addHeader("10010", new String("您还未登录，请登录".getBytes("GBK"),"UTF-8"));
//            	resp.sendError(10010, "not login");
            	renderJson(req, resp, Result.error(ResultCodeEnum.USER_NO_LOGIN));
            	return false;
            }
            
          //如果签友汇前台传了cookie，但cookie的值就是一个null字符串，也要进行处理
            if(cookie!=null && cookie.trim().equals("null")){
            	renderJson(req, resp, Result.error(ResultCodeEnum.USER_NO_LOGIN));
            	return false;
            }
            
            //下面为兼容小程序与渠道版的写法，小程序默认是cookie，渠道版因为不能设置cookie为关键字，所以改为cookie中添加cookies
            String sessionId = "";
            if(cookie!=null && !cookie.equals("") && cookie.indexOf("SHIRO_SESSION_ID")!=-1){//直接加上SHIRO_SESSION_ID的查找，解决前端传了cookie又传了cookies，但只在其中一个中加了SHIRO_SESSION_ID的问题
//            	if(cookie.indexOf("SHIRO_SESSION_ID")!=-1){
            		sessionId = cookie.substring(cookie.indexOf("SHIRO_SESSION_ID")+17, cookie.indexOf("SHIRO_SESSION_ID")+53);
//            	}
            	System.out.println("cookie的sessionId为：" + sessionId);
            }
            
            if(cookies!=null && !cookies.equals("") && cookies.indexOf("SHIRO_SESSION_ID")!=-1){
//            	if(cookies.indexOf("SHIRO_SESSION_ID")!=-1){
            		sessionId = cookies.substring(cookies.indexOf("SHIRO_SESSION_ID")+17, cookies.indexOf("SHIRO_SESSION_ID")+53);
//            	}
//            	System.out.println("cookies带s的sessionId为：" + sessionId);
            }
            
            if(!sessionId.equals("")){
//            	如果redis中拿得到
            	MyRedisSessionDAO  redisSessionDAO= (MyRedisSessionDAO)SpringUtil.getBean("redisSessionDAO");
            	Session session = redisSessionDAO.doReadSession(sessionId);
            	if(session!=null){
//            		System.out.println("redis中查找到了session");
            		return true;
            	}
            	//没拿到session则应该是没登录的提示返回，没拿到，是登录超时的提示好像也可以，先注掉下面的吧
//            	renderJson(resp, new Result(ResultCodeEnum.USER_NO_LOGIN));
            }
//            System.out.println("sessionId为空，没有找到");
        	//前端Ajax请求，则不会重定向
            renderJson(req, resp, Result.error(ResultCodeEnum.USER_SESSION_TIME_OUT));
            //不能就将这个sessionId给保存至redis，有问题
//            else{
//            	saveRequestAndRedirectToLogin(request, response);
//            }

            return false;
        }
    }
	
	
	
	/**
     * 渲染json对象
     */
    protected  void renderJson(HttpServletRequest request, HttpServletResponse response, Result result) {
        try {
        	
        	//在下面设置可以，在全局里面设置也可以
        	String origin = request.getHeader("Origin");
//        	System.out.println("获取到origin的值：" + origin);

        	//千万不能设置为*，经过调试，打印出来的值为：  获取到origin的值：http://192.168.1.102   
        	//一个 http://192.168.1.102 的请求，跟你一个*去匹配，肯定是不对啊
        	//Access-Control-Allow-Origin：指定允许其他域名访问 :http://172.20.0.206'//一般用法（*，指定域，动态设置），3是因为*不允许携带认证头和cookies
        	
//        	response.setHeader("Access-Control-Allow-Origin", "*"); 
//            response.setHeader("Access-Control-Allow-Origin", origin);
//            response.setHeader("Access-Control-Allow-Credentials", "true");//是否允许发送Cookie  //是否允许后续请求携带认证信息（cookies）,该值只能是true,否则不返回
//            response.setHeader("Access-Control-Allow-Methods", "POST, GET, HEAD, OPTIONS, DELETE");//允许的请求类型
//            response.setHeader("Access-Control-Max-Age", "3600"); //预检结果缓存时间,也就是上面说到的缓存啦
//            //对客户端自定义请求头的应答，，//允许的请求头字段
//            response.setHeader("Access-Control-Allow-Headers", "Cookies, Origin, Accept, X-Requested-With, x-auth-token, client_id, uuid, Authorization, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers");

        	
        	
        	response.setContentType("application/json; charset=utf-8");
        	response.setCharacterEncoding("UTF-8");
            PrintWriter out = response.getWriter();
//            JSONObject result = new JSONObject();
//            result.put("message", "登录失效");
//            result.put("resultCode", 1000);
//            out.println(result);
            out.println(JSON.toJSONString(result));  //println()方法打印出来的东西会自动换行
//            out.write(JSON.toJSONString(result));
            out.flush();
            out.close();
            
//            
//            response.setContentType("application/json");
//            response.setCharacterEncoding("UTF-8");
//            PrintWriter writer = response.getWriter();
//            writer.write(JSON.toJSONString(jsonObject));
        } catch (IOException e) {
        	e.printStackTrace();
        }
    }

}
