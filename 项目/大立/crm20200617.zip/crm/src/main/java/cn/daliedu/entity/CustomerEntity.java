package cn.daliedu.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import com.baomidou.mybatisplus.annotation.FieldStrategy;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 客户表
 * </p>
 *
 * @author xiechao
 * @since 2019-09-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_customer")
public class CustomerEntity extends Model<CustomerEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 客户ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;
    
    /**
     * 分校ID，如果此字段为空，则为代理商存入的客户数据（考虑将来代理商自己的客户可能也会转入分校，或者转给分校的销售，所以存入此表）
     */
    private String branchOrgId;
    
    /**
     * 部门ID，如果此字段为空，代表此客户为分校客户，
     */
    private String departmentId;
    
    // 客户标签集合（ 非数据库字段）
    @TableField(exist = false)
    private List<CustomerTagEntity> customerTagList;
    
    // 客户分校名称（ 非数据库字段）
    @TableField(exist = false)
    private String branchOrgName;
    
    /**
     * 推广人名称
     */
    @TableField(exist = false)
    private String promotionUserName;


    /**
     * 姓名
     */
    private String customerName;

    /**
     * 性别，1：男，2：女，3：未知
     */
    private String sex;

    /**
     * 客户来源类型（见数据字典sys_dict_type表id为3的定义，0：非代理商，1：代理商）
     */
    private String customerSourceType;

//    /**
//     * 客户来源名称类型（见数据字典sys_dict表customer_source_name的定义）
//     */
//    private String customerSourceName;
    
    /**
     * 客户来源名称对应的值（见数据字典sys_dict表customer_source_name的定义）
     */
    private String customerSourceNameValue;

    /**
     * 客户分组类型（见数据字典sys_dict表customer_group的定义，1：一般客户，2：意向客户，3：已成交客户，4：无意向客户，5：拉黑客户，6：其他），此字段属于客户，所以在用户与客户表中此字段已经被删除
     */
    private String customerGroupTypeId;

    /**
     * 客户标签中，客户类型（1：个人客户，2：团购客户，3：集团客户）
     */
//    private String customerType; //使用客户标签来做，不是客户的直接属性

    /**
     * 客户阶段，1：新入库，2：初步沟通，3：多次沟通，4：截杀，5：缴费
     */
    private String customerStage;
    
    /**
     * 客户质量，1：优质，2：一般
     */
    private String customerQuality;
    
    /**
     * 客户意向程度（见数据字典sys_dict表customer_intention_level的定义）
     */
    private String customerIntentionLevel;
    
    /**
     * 客户意向内容（见数据字典sys_dict表customer_intention_content的定义）
     */
    private String customerIntentionContent;

    /**
     * 微信号
     */
    private String weixinId;

    /**
     * QQ
     */
    private String qq;

    /**
     * 手机
     */
    private String mobile;

    /**
     * 座机电话
     */
    private String phone;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 客户创建时间
     */

//    @DateTimeFormat(pattern = "yyyy-MM-dd hh:MM:ss")
//    @JsonFormat(pattern = "yyyy-MM-dd hh:MM:ss")
    private LocalDateTime createTime;

    /**
     * 客户资料更新时间（用来统计一周内更新的客户，一月内更新的客户），刚创建也是存储在这列
     */
    private LocalDateTime updateTime;

    /**
     * 地区(省或自治区)ID
     */
    private String provinceId;

    /**
     * 地区(省)名称（冗余）
     */
    private String provinceName;

    /**
     * 地区(市)ID
     */
    private String cityId;

    /**
     * 地区(市)名称（冗余）
     */
    private String cityName;

    /**
     * 地区(区)
     */
    private String areaId;

    /**
     * 地区(区)名称（冗余）
     */
    private String areaName;

    /**
     * 公司名称
     */
    private String companyName;

    /**
     * 地址
     */
    private String address;

    /**
     * 工作年限
     */
    private String jobAge;

    /**
     * 学历
     */
    private String education;

    /**
     * 专业
     */
    private String professional;

    /**
     * 客户活动表单页面网址
     */
    private String customerActivityPage;

    /**
     * 客户活动页面分类
     */
    private String customerActivityTypePage;
    
    /**
     * 创建人（最开始创建此客户的人）
     */
    private String createUserId;

    /**
     * 最新的跟进人（最后的跟进人也存储在这）,如果此字段为空，则无人跟进
     */
    private String followUserId;

    /**
     * 删除人（一般跟进人跟删除人为同一人，但也可能是经理在客户管理里面删除了客户）
     */
    @TableField(value = "delete_user_id", strategy = FieldStrategy.IGNORED)//忽略空值的判断，将客户还原给同事的时候，需要将此列置空
    private String deleteUserId;
    
    /**
     * 推广人（用于记录公司内部推广部的人提供的号码，由内部别的部门人员导入系统进行跟进）
     */
    private String promotionUserId;
    
    /**
     * 删除时间
     */
    @TableField(value = "delete_date_time", strategy = FieldStrategy.IGNORED)//忽略空值的判断，将客户还原给同事的时候，需要将此列置空
    private LocalDateTime deleteDateTime;

    /**
     * 1：分校资源库，2：部门资源库，当被用户持有时，此字段为空,因为被持有，则就不属于资源库，但是还是属于分校,当客户没有被持有，那么seaType上一定会有值
     */
    @TableField(value = "sea_type", strategy = FieldStrategy.IGNORED)//忽略空值的判断，将客户还原给同事的时候，需要将此列置空
    private String seaType;

    /**
     * 1：进入分校回收站，2：进入公司回收站，为空则表示正常状态
     */
    @TableField(value = "state", strategy = FieldStrategy.IGNORED)
    private String state;

    /**
     * 存储单列客户自定义信息：备注2
     */
    private String remark2;


    /**
     * 备注
     */
    private String remark;

    /**
     * 删除原因ID
     */
    private Integer deleteCauseId;

    /**
     * 删除原因
     */
    private String deleteCause;

    /**
     * 转让原因ID
     */
    private Integer transferCauseId;

    /**
     * 转让原因
     */
    private String transferCause;

    /**
     * 放弃原因ID
     */
    private Integer waiveCauseId;

    /**
     * 放弃原因
     */
    private String waiveCause;
    
    /**
     * 最近动态时间
     */
    private LocalDateTime recentDynamicDateTime;
    
    /**
     * 最近动态内容（只保留最近的一条动态）
     */
    private String recentDynamicContent;
    
    /**
     * 导入类型，1：手工录入，2：批量导入
     */
    private Integer importType;
    
    /**
     * 批量导入批次号（给将来运维使用，如果导入的批次客户有问题，则在后台删除客户及客户关联的数据）
     */
    private String importBatchNo;
    
    /**
     * 客户头像url
     */
    private String photoUrl;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }



   
}
