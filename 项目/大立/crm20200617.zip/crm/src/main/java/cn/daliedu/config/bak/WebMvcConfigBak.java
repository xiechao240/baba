package cn.daliedu.config.bak;
//package com.esa2000.config;
//
//import com.alibaba.fastjson.serializer.SerializerFeature;
//import com.alibaba.fastjson.support.config.FastJsonConfig;
//import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;
//import com.google.common.collect.Lists;
//import com.google.common.collect.Maps;
//
//import org.springframework.boot.web.servlet.FilterRegistrationBean;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.http.MediaType;
//import org.springframework.http.converter.HttpMessageConverter;
//import org.springframework.web.servlet.config.annotation.CorsRegistry;
//import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
//import org.thymeleaf.spring5.view.ThymeleafViewResolver;
//
//import java.util.List;
//import java.util.Map;
//
//import javax.annotation.Resource;
//
///**
// * @author 1921494052@qq.com
// * @date 2018/5/21
// */
//@Configuration
//public class WebMvcConfig extends WebMvcConfigurationSupport {
//	@Override
//	public void addCorsMappings(CorsRegistry registry) {
//		registry.addMapping("/**")
//				.allowedHeaders("*")
//				.allowedMethods("*")
//				.allowedOrigins("*")
//				.allowCredentials(true);
//	}
//
////	/**
////	 * 配置静态访问资源, 由于使用了 Shiro 控制, 所以未登入时, 只能访问 Shiro 放开的文件
////	 */
////	@Override
////	public void addResourceHandlers(ResourceHandlerRegistry registry) {
////		// 所有 static 静态文件夹下的文件都可以访问, 访问时不需要 /static/, 如: css/base64.css
////		registry.addResourceHandler("/**").addResourceLocations("classpath:/static/");
////		registry.addResourceHandler("/myResource/**").addResourceLocations("classpath:/myResource/");
////		super.addResourceHandlers(registry);
////	}
//
////	@Override // fastJson 配置
////	protected void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
////		super.configureMessageConverters(converters);
////
////		// 创建 fastJson 消息转换器
////		FastJsonHttpMessageConverter fastConverter = new FastJsonHttpMessageConverter();
////
////		FastJsonConfig fastJsonConfig = new FastJsonConfig();// 创建配置类
////		// 修改配置返回内容的过滤
////		fastJsonConfig.setSerializerFeatures(SerializerFeature.DisableCircularReferenceDetect,
////				SerializerFeature.WriteMapNullValue, SerializerFeature.WriteNullStringAsEmpty,
////				SerializerFeature.PrettyFormat);
////		fastConverter.setFastJsonConfig(fastJsonConfig);
////
////		// 处理中文乱码问题
////		List<MediaType> fastMediaTypes = Lists.newArrayList();
////		fastMediaTypes.add(MediaType.APPLICATION_JSON_UTF8);
////		fastConverter.setSupportedMediaTypes(fastMediaTypes);
////
////		converters.add(fastConverter);
////	}
//
////	@Bean
////	public FilterRegistrationBean someFilterRegistration() {
////		FilterRegistrationBean registration = new FilterRegistrationBean();
////		registration.setFilter(new ParameterRequestFileter());
////		registration.addUrlPatterns("/login");
////		// registration.addInitParameter("paramName", "paramValue");
////		registration.setName("parameterRequestFileter");
////		return registration;
////	}
////
////	@Resource // 模板使用的常量配置
////	private void configureThymeleafStaticVars(ThymeleafViewResolver viewResolver) {
////		if (null != viewResolver) {
////			// 设置全局变量 js 调用需要 th:inline="javascript"
////			Map<String, Object> vars = Maps.newHashMap();
////			vars.put("ctx", "/app/");// 前台调用: [[${ctx}]]
////			vars.put("userEnum", EnumUtil.EnumToMap(UserEnum.class));
////			vars.put("var2", "var2");
////			viewResolver.setStaticVariables(vars);
////		}
////	}
//
//}
