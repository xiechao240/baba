package cn.daliedu.controller.api.console;


import java.util.List;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.UnauthorizedException;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.ParameterEntity;
import cn.daliedu.entity.RoleEntity;
import cn.daliedu.entity.SmsTemplateEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.json.CustomerJson;
import cn.daliedu.entity.json.GlobalJson;
import cn.daliedu.entity.json.RoleJson;
import cn.daliedu.entity.json.SmsTemplateJson;
import cn.daliedu.enums.ParameterEnum;
import cn.daliedu.enums.ResultCodeEnum;
import cn.daliedu.enums.SmsTemplateCodeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.CustomerService;
import cn.daliedu.service.ParameterService;
import cn.daliedu.service.SmsTemplateService;
import cn.daliedu.service.UserSmsRecordService;
import cn.daliedu.util.JsonUtil;
import cn.daliedu.util.Result;
import cn.daliedu.util.SMSUtil;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 短信模板表 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2019-12-26
 */
@Api(description = "sms短信服务相关接口")
@RestController
@RequestMapping("${rest.path}/console/sms")
public class SmsTemplateController {
	
	@Autowired
	SmsTemplateService smsTemplateService;
	
	@Autowired
	UserSmsRecordService userSmsRecordService;
	
	@Autowired
	ParameterService parameterService;
	
	@ApiOperation(value = "【自定义短信发送】，前端发送短信前，先调用此方法，校验是否有发送权限，是否发送短信数量超过数量，如果此接口返回成功，则前端调用websocket接口进行发送短信")
	@RequiresPermissions("sys:customer:sms:self")
	@PostMapping("/sendSmsToCustomerBySelfDefinition")
	public Result sendSmsToCustomerBySelfDefinition(@RequestBody String params){
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity user = (UserEntity) object;
				
				//获取用户今天发送的短信数量
				Integer smsCount = userSmsRecordService.getUserSmsCount(user.getId());
				//获取系统参数表中配置每天短信发送数量阀值
				ParameterEntity parameterEntity = parameterService.getParameterByKey(ParameterEnum.SMS_COUNT.getValue());
				Integer configSmsCount = Integer.parseInt(parameterEntity.getParamValue());
				if(smsCount<configSmsCount){
					return Result.success("可以发送短信");
				}else{
					return Result.error("您今天的短信发送数量已经超过上限，请联系管理员，或选择明天再发送");
				}
			}
			return Result.error("系统运行出错，请联系管理员");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("短信发送失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "向单个客户或多个客户群发【此为模板发短信】短信功能,此接口可在多处使用")
	@ApiJsonObject(name = "sendSmsToCustomer", value = { 
			@ApiJsonProperty(name = CustomerJson.customerIds),
			@ApiJsonProperty(name = SmsTemplateJson.templateCode)})
	@ApiImplicitParam(name = "params", required = true, dataType = "sendSmsToCustomer")
	@RequiresPermissions("sys:customer:sms")
	@PostMapping("/sendSmsToCustomer")
	public Result sendSmsToCustomer(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String customerIds = String.valueOf(jsonObject.get("customerIds"));
			String templateCode = String.valueOf(jsonObject.get("templateCode"));
			
			StringUtil.validateIsNull(customerIds, "请选择客户");
			StringUtil.validateIsNull(templateCode, "请选择短信模板");
			
			
			if(SmsTemplateCodeEnum.isInclude(templateCode)){
				boolean flag = smsTemplateService.sendSmsToCustomer(customerIds, templateCode);
				if(flag){
					return Result.success("发送成功");
				}else{
					return Result.error("短信发送失败");
				}
			}else{
				return Result.error("请选择正确的短信模板");
			}
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取短信模板列表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "获取所有的短信模板列表，带分页")
	@ApiJsonObject(name = "getSmsTemplateList", value = { 
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getSmsTemplateList")
//	@RequiresPermissions("sys:role:list")
	@PostMapping("/getSmsTemplateList")
	public Result getSmsTemplateList(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
			
			
			StringUtil.validateIsNull(pageNum, "请输入页码");
			StringUtil.validateIsNull(pageSize, "请输入每页记录数");
			
			IPage<SmsTemplateEntity> page = smsTemplateService.getSmsTemplateList(Integer.parseInt(pageNum), Integer.parseInt(pageSize));
			
			return Result.success(page);
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取短信模板列表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
	
}
