package cn.daliedu.controller.api.console;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.shiro.authz.UnauthorizedException;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;

import cn.daliedu.service.OrgService;
import cn.daliedu.service.RoleMenuService;
import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.MenuEntity;
import cn.daliedu.entity.RoleEntity;
import cn.daliedu.entity.RoleMenuEntity;
import cn.daliedu.entity.UserRoleEntity;
import cn.daliedu.entity.json.GlobalJson;
import cn.daliedu.entity.json.OrgJson;
import cn.daliedu.entity.json.RoleJson;
import cn.daliedu.entity.json.UserJson;
import cn.daliedu.enums.ResultCodeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.MenuService;
import cn.daliedu.service.RoleService;
import cn.daliedu.service.UserRoleService;
import cn.daliedu.service.UserService;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * 角色操作相关接口控制器
 * @author xiechao
 * @time 2019年5月13日 上午10:33:58
 * @version 1.0.0 
 * @description
 */
@Api(description = "角色操作相关接口")
@RestController
@RequestMapping(value = "${rest.path}/console/role") 
public class RoleController {
	
	@Autowired
	UserService userService;
	
	@Autowired
	RoleService roleService;
	
	@Autowired
	OrgService deptService;
	
	@Autowired
	MenuService menuService;
	
	@Autowired
	RoleMenuService roleMenuService;
	
	@Autowired
	UserRoleService userRoleService;
	

	//其实后台展现角色列表，跟添加用户可选择的角色列表应该要分开
	@ApiOperation(value = "获取所有角色列表，带分页功能(可传入角色名称进行查询,自动屏蔽掉超级管理员角色)")
	@ApiJsonObject(name = "getRoleList", value = { 
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize),
			@ApiJsonProperty(name = RoleJson.roleName)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getRoleList")
//	@RequiresPermissions("sys:role:list")
	@PostMapping("/getRoleList")
	public Result getRoleList(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
			String name = String.valueOf(jsonObject.get("roleName"));
//			String available = jsonObject.get("available").toString();//角色可用状态，做角色启停的时候，再做这个功能，暂时先注掉
			
			
			StringUtil.validateIsNull(pageNum, "请输入页码");
			StringUtil.validateIsNull(pageSize, "请输入每页记录数");
			
			IPage<RoleEntity> page = roleService.getPageRoleList(Integer.parseInt(pageNum), Integer.parseInt(pageSize), name);
			
			return Result.success(page);
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取角色列表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "获取所有角色列表，新增用户时获取角色列表，如果当前登录的用户为超级管理员，则可以添加普通管理员，普通用户，代理商用户，如果是普通管理员，则可以添加普通用户，代理商用户，如果是普通用户，则提示出错")
	@PostMapping("/getRoleListByAddUser")
	public Result getRoleListByAddUser(){
		try{
			List<RoleEntity> list = roleService.getRoleListByAddUser();
			if(list!=null && list.size()>0){
				return Result.success(list);
			}
			return Result.error("暂无数据");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取角色列表失败，失败原因：" + e.getMessage());
		}
	}

	@ApiOperation(value = "根据角色ID获取角色信息")
	@ApiJsonObject(name = "getRoleById", value = { 
			@ApiJsonProperty(name = RoleJson.id)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getRoleById")
//	@RequiresPermissions("sys:role:list")
	@PostMapping("/getRoleById")
	public Result getRoleById(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String id = jsonObject.get("id").toString();
			
			StringUtil.validateIsNull(id, "请输入角色id");
			
			RoleEntity entity = roleService.getById(id);
			
			return Result.success(entity);
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("根据角色ID获取角色信息失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "根据角色ID修改角色")
	@ApiJsonObject(name = "updateRoleById", value = { 
			@ApiJsonProperty(name = RoleJson.id),
			@ApiJsonProperty(name = RoleJson.roleName),
			@ApiJsonProperty(name = RoleJson.remark),
			@ApiJsonProperty(name = RoleJson.available)})
	@ApiImplicitParam(name = "params", required = true, dataType = "updateRoleById")
//	@RequiresPermissions("sys:role:edit")
	@PostMapping("/updateRoleById")
	public Result updateRoleById(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String id = jsonObject.get("id").toString();
			String roleName = jsonObject.get("roleName").toString();
			String remark = jsonObject.get("remark").toString();
//			String available = jsonObject.get("available").toString();
			
			StringUtil.validateIsNull(id, "请输入角色id");
			StringUtil.validateIsNull(roleName, "请输入角色名称");
//			StringUtil.validateIsNull(available, "请输入角色状态");
			
			RoleEntity entity = roleService.getById(id);
			if(entity!=null){
				entity.setName(roleName);
//				entity.setAvailable(available);
				entity.setRemark(remark);
				
				boolean flag = roleService.updateById(entity);
				if(flag){
					return Result.success("更新成功");
				}
			}
			
			return Result.error("更新失败");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("根据角色ID修改角色失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "根据角色ID删除角色")
	@ApiJsonObject(name = "deleteRoleById", value = { 
			@ApiJsonProperty(name = RoleJson.id)})
	@ApiImplicitParam(name = "params", required = true, dataType = "deleteRoleById")
//	@RequiresPermissions("sys:role:delete")
	@PostMapping("/deleteRoleById")
	public Result deleteRoleById(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String id = jsonObject.get("id").toString();
			
			StringUtil.validateIsNull(id, "请输入角色id");
			
			boolean flag = roleService.removeById(id);
			if(flag){
				return Result.success("删除成功");
			}
			
			return Result.error("删除失败");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("根据角色ID获取角色信息失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
	@ApiOperation(value = "根据角色ID查询角色对应的菜单,以树形结构返回结果集")
	@ApiJsonObject(name = "getMenuListByRoleId", value = { 
			@ApiJsonProperty(name = RoleJson.id)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getMenuListByRoleId")
//	@RequiresPermissions("sys:role:view")
	@PostMapping("/getMenuListByRoleId")
	public Result getMenuListByRoleId(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String id = jsonObject.get("id").toString();
			
			StringUtil.validateIsNull(id, "请输入角色id");
			
			List<MenuEntity> list = menuService.getTreeMenuListByRoleId(id);
			
			return Result.success(list);
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("根据角色ID获取角色信息失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
	/** 
	 * 新增角色对应的菜单
	 **/
	@RequestMapping(value = "/saveRoleMenuByRoleId/{roleId}",method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	@ApiOperation(value = "保存角色对应的菜单", notes = "")
	public Result saveRoleMenuByRoleId(@PathVariable String roleId, @RequestBody @ApiParam(required=true)String[] menuIdList)  {
		try {
			StringUtil.validateIsNull(roleId, "请选择操作的角色");
			
			System.out.println("角色ID" + roleId);
			for(String str : menuIdList){
				System.out.println("menuId数据为：" + str);
			}
			
			boolean flag = roleMenuService.saveRoleMenuByRoleId(menuIdList, roleId);
			if(flag){
				return Result.success("新增成功");
			}else{
				return Result.success("新增失败");
			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("新增失败，请稍后再试！");
		}
	}
	
	@ApiOperation(value = "新建角色")
	@ApiJsonObject(name = "saveRole", value = { 
			@ApiJsonProperty(name = RoleJson.roleName)})
	@ApiImplicitParam(name = "params", required = true, dataType = "saveRole")
//	@RequiresPermissions("sys:role:list")
	@PostMapping("/saveRole")
	public Result saveRole(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String roleName = jsonObject.get("roleName").toString();
			
			StringUtil.validateIsNull(roleName, "请输入角色名称");
			
			List<RoleEntity> list = roleService.getRoleListByRoleName(roleName.trim());
			if(list!=null && list.size()>0){
				return Result.error("该角色名称已经存在,请重新输入！");
			}
			
			RoleEntity entity = new RoleEntity();
			entity.setName(roleName);
			entity.setAvailable("1");
			entity.setCreateTime(LocalDateTime.now());
			
//			boolean flag = roleService.save(entity);
			boolean flag = roleService.saveRole(entity);
			if(flag){
				return Result.success("保存成功！");
			}
			return Result.error("保存失败！");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("新建角色失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "根据用户用户ID，获取用户的角色")
	@ApiJsonObject(name = "getRoleByUserId", value = { 
			@ApiJsonProperty(name = UserJson.userId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getRoleByUserId")
//	@RequiresPermissions("sys:role:list")
	@PostMapping("/getRoleByUserId")
	public Result getRoleByUserId(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String userId = jsonObject.get("userId").toString();
			
			StringUtil.validateIsNull(userId, "请选择用户");
			
			UserRoleEntity entity = userRoleService.getRoleByUserId(userId);
			if(entity!=null){
				return Result.success(entity);
			}else{
				return Result.error("此用户暂无角色信息");
			}
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取用户角色信息失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "复制角色")
	@ApiJsonObject(name = "copyRole", value = { 
			@ApiJsonProperty(name = RoleJson.roleName),
			@ApiJsonProperty(name = RoleJson.id)})
	@ApiImplicitParam(name = "params", required = true, dataType = "copyRole")
//	@RequiresPermissions("sys:role:list")
	@PostMapping("/copyRole")
	public Result copyRole(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String id = jsonObject.get("id").toString();
			String roleName = jsonObject.get("roleName").toString();
			
			StringUtil.validateIsNull(id, "请选择需要复制的角色");
			StringUtil.validateIsNull(roleName, "请选择角色名称");
			
			RoleEntity entity = roleService.getById(id);
			if(entity!=null){
				boolean flag = roleService.copyRole(entity, roleName);
				if(flag){
					return Result.success("角色复制成功！");
				}
				return Result.error("角色复制失败，请联系管理员！");
			}else{
				return Result.error("您输入的角色不存在，请检查！");
			}
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("复制角色失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
//	@ApiOperation(value = "根据角色ID启用，停用角色")
//	@ApiJsonObject(name = "stopRoleById", value = { 
//			@ApiJsonProperty(name = RoleJson.id),
//			@ApiJsonProperty(name = RoleJson.available)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "stopRoleById")
//	@RequiresPermissions(value = {"sys:role:start","sys:role:stop"})
//	@PostMapping("/updateRoleStateById")
//	public Result updateRoleStateById(@RequestBody String params){
//		try{
//			JSONObject jsonObject = JSON.parseObject(params);
//			String id = jsonObject.get("id").toString();
//			String available = jsonObject.get("available").toString();
//			
//			StringUtil.validateIsNull(id, "请输入角色id");
//			StringUtil.validateIsNull(available, "请输入角色状态");
//			
//			RoleEntity entity = roleService.getById(id);
//			if(entity!=null){
//				entity.setAvailable(available);
//				
//				boolean flag = roleService.updateById(entity);
//				if(flag){
//					return Result.success("更新成功");
//				}
//			}
//			
//			return Result.error("更新失败");
//		}catch (UnauthorizedException e){
//			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
//		} catch (BusinessException e) {
//			e.printStackTrace();
//			return Result.error(e.getMessage());
//		}catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("根据角色ID获取角色信息失败，失败原因：" + e.getMessage());
//		}
//	}
	
	
}
