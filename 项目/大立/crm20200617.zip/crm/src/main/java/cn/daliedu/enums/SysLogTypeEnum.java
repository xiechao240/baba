package cn.daliedu.enums;

/**
 * 系统用户类型枚举类
 * @author xiechao
 * @time 2019年1月9日 下午5:51:51
 * @version 1.0.0
 * @description 整个系统登录用户的类型，包括会员版本用户，渠道版本用户....等未来版本，目前先做这两个版本
 */
public enum SysLogTypeEnum {
	/**
	 * 登陆
	 */
	LOG_TYPE_1("1", "登陆"), 
	/**
	 * 退出
	 */
	LOG_TYPE_2("2", "退出"),
	/**
	 * 会员申请
	 */
	LOG_TYPE_3("3", "会员申请"),
	/**
	 * 会员审核
	 */
	LOG_TYPE_4("4", "会员审核");

	private String value;
	private String desc;

	SysLogTypeEnum(final String value, final String desc) {
		this.value = value;
		this.desc = desc;
	}


	public String getValue() {
		return value;
	}
	
	public String getDesc() {
		return desc;
	}
	
}