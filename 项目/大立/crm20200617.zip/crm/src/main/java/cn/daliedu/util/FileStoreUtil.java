//package cn.daliedu.util;
//
//import java.awt.image.BufferedImage;
//import java.io.ByteArrayInputStream;
//import java.io.ByteArrayOutputStream;
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.io.InputStream;
//import java.util.Calendar;
//import java.util.Random;
//
//import javax.imageio.IIOException;
//import javax.imageio.ImageIO;
//
//import org.springframework.web.multipart.MultipartFile;
//
//import com.easysign.file.FileStore;
//import com.easysign.file.FileStoreFactory;
//import com.easysign.file.conf.Config;
//import com.easysign.file.conf.FtpConfig;
//import com.easysign.file.conf.OSSConfig;
//import com.easysign.file.utils.FileUtils;
//
//import cn.daliedu.config.param.GlobalParamConfig;
//import cn.daliedu.exception.CrmException;
//import cn.daliedu.exception.ParameterInvalidException;
//
//
//
///**
// * 文件上传与下载的存储工具类，此类实现方式：
// *  1.本地文件上传与下载 
// *  2.ftp文件上传与下载 
// *  3.阿里云文件上传与下载
// * 
// * @author xiechao
// * @time 2019年2月22日 上午11:49:02
// * @version 1.0.0
// * @description
// */
//public class FileStoreUtil {
//
//	/**
//	 * 文件上传方法
//	 * @param file   MultipartFile对象
//	 * @return 返回文件存储的路径id，可将此路径id进行入库处理
//	 * @throws Exception
//	 */
//	public static String uploadFile(MultipartFile file) throws Exception {
//		String fileName = file.getOriginalFilename();
//		String suffixName = fileName.substring(fileName.indexOf(".")+1, fileName.length());
//		return uploadFile(file.getBytes(),suffixName, false);
//	}
//
//	/**
//	 * 文件上传方法
//	 * @param fileContent  byte[]文件字节数组对象
//	 * @param suffixName   文件名后缀名
//	 * @param isTemp   是否加入临时目录标识
//	 * @return 返回文件存储的路径id，可将此路径id进行入库处理
//	 * @throws Exception
//	 */
//	public static String uploadFile(byte[] fileContent, String suffixName, boolean isTemp) throws Exception {
//		BufferedImage bufferedImage;
//		try {
//			bufferedImage = ImageIO.read(new ByteArrayInputStream(fileContent));
//		} catch (IIOException e) {
//			bufferedImage = new BufferedImage(1, 1, 1);
//		}
//		//如果不希望上传的文件只能为图片，则注掉下面的代码
//		if (bufferedImage == null || bufferedImage.getWidth() == 0 || bufferedImage.getHeight() == 0) {
//			throw new ParameterInvalidException("请上传正确图片");
//		}
//		
//		StringBuilder str = new StringBuilder();
//		if(isTemp){
//			str.append("temp").append("/");
//		}
//		str.append(DateUtil.getYear()).append("/")
//			.append(DateUtil.getMonth()).append("/")
//			.append(DateUtil.getDay()).append("/")
//			.append(System.currentTimeMillis())
//			.append(new Random().nextInt(999))
//			.append(".").append(suffixName);
//		String fileName = str.toString();
//
//				
//		if ("local".equals(GlobalParamConfig.FILE_STORY_WAY)) {
//			FileOutputStream fos = new FileOutputStream(new File(GlobalParamConfig.FILE_LOCAL_PATH + fileName));
//			fos.write(fileContent);
//			fos.flush();
//			fos.close();
//		} else {
//			boolean storeFile = getFileStory().storeFile(fileName, new ByteArrayInputStream(fileContent));
//			if (!storeFile) {
//				throw new CrmException("文件上传失败");
//			}
//		}
//
//		return fileName;
//	}
//
//	/**
//	 * 将上传的文件下载下来
//	 * @param fileName 文件名
//	 * @return
//	 * @throws Exception
//	 */
//	public static byte[] downloadFile(String fileName) throws Exception {
//		if ("local".equals(GlobalParamConfig.FILE_STORY_WAY)) {
//			FileInputStream fis = new FileInputStream(new File(GlobalParamConfig.FILE_LOCAL_PATH + fileName));
//			ByteArrayOutputStream bos = new ByteArrayOutputStream();
//			byte[] b = new byte[1024];
//			int len;
//			while ((len = fis.read(b)) > 0) {
//				bos.write(b, 0, len);
//				bos.flush();
//			}
//			byte[] byteArray = bos.toByteArray();
//			bos.close();
//			fis.close();
//			return byteArray;
//		} else {
//			InputStream is = getFileStory().downloadFile(fileName);
//			return FileUtils.transInputstreamToBytes(is);
//		}
//	}
//
//	/**
//	 * 获取文件存储策略
//	 * @return
//	 * @throws Exception
//	 */
//	public static FileStore getFileStory() throws Exception {
//		Config config;
//		if ("ftp".equals(GlobalParamConfig.FILE_STORY_WAY)) {
//			config = new FtpConfig(GlobalParamConfig.FILE_FTP_HOST, 
//					Integer.parseInt(GlobalParamConfig.FILE_FTP_PORT), GlobalParamConfig.FILE_FTP_USERNAME,
//					GlobalParamConfig.FILE_FTP_PASSWORD);
//		} else if ("oss".equals(GlobalParamConfig.FILE_STORY_WAY)) {
//			config = new OSSConfig(GlobalParamConfig.FILE_OSS_URL, GlobalParamConfig.FILE_OSS_ACCESSKEYID, 
//					GlobalParamConfig.FILE_OSS_BUCKET, GlobalParamConfig.FILE_OSS_ACCESSKEYSECRET,
//					Boolean.valueOf(GlobalParamConfig.FILE_OSS_ISENCRYPT));
//		} else {
//			throw new CrmException("文件上传与下载方式，服务配置错误");
//		}
//		FileStore fileStore = FileStoreFactory.createFileStore(config);
//		return fileStore;
//	}
//}
