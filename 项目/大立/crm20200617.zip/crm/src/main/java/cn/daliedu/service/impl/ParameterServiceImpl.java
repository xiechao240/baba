package cn.daliedu.service.impl;

import cn.daliedu.entity.ParameterEntity;
import cn.daliedu.entity.SmsTemplateEntity;
import cn.daliedu.mapper.ParameterMapper;
import cn.daliedu.service.ParameterService;
import cn.daliedu.util.StringUtil;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

/**
 * <p>
 * 系统参数表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-12-31
 */
@Service
public class ParameterServiceImpl extends ServiceImpl<ParameterMapper, ParameterEntity> implements ParameterService {

	@Resource
	ParameterMapper parameterMapper;
	
	
	
	@Override
	public IPage<ParameterEntity> getSysParameterList(Map<Object, Object> map) {
		Integer pageNum = Integer.parseInt(map.get("pageNum").toString());
		Integer pageSize = Integer.parseInt(map.get("pageSize").toString());
		String paramName = StringUtil.nullValueConvert(map.get("paramName"));
		String paramKey = StringUtil.nullValueConvert(map.get("paramKey"));
		if (pageNum <= 0) {
			pageNum = 1;
		}
		IPage<ParameterEntity> page = new Page<ParameterEntity>();
		page.setCurrent(pageNum);
		page.setSize(pageSize);
		
		QueryWrapper<ParameterEntity> queryWrapper = new QueryWrapper<ParameterEntity>();
		if(!paramName.equals("") && !paramName.equals("null")){
			queryWrapper.eq("param_name", paramName);
		}
		if(!paramKey.equals("") && !paramName.equals("null")){
			queryWrapper.eq("param_key", paramKey);
		}

		return parameterMapper.selectPage(page, queryWrapper);
	}



	@Override
	public ParameterEntity getParameterByKey(String paramKey) {
		return parameterMapper.selectOne(new QueryWrapper<ParameterEntity>().eq("param_key", paramKey).last("limit 1"));
	}
	
	
}
