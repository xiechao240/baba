package cn.daliedu.shiro;


import org.apache.shiro.authc.credential.HashedCredentialsMatcher;
import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.session.mgt.ExecutorServiceSessionValidationScheduler;
import org.apache.shiro.spring.LifecycleBeanPostProcessor;
import org.apache.shiro.spring.security.interceptor.AuthorizationAttributeSourceAdvisor;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.filter.authc.FormAuthenticationFilter;
import org.apache.shiro.web.mgt.CookieRememberMeManager;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.apache.shiro.web.servlet.SimpleCookie;
import org.apache.shiro.web.session.mgt.DefaultWebSessionManager;
import org.crazycake.shiro.RedisCacheManager;
import org.crazycake.shiro.RedisManager;
import org.crazycake.shiro.RedisSessionDAO;
import org.springframework.aop.framework.autoproxy.DefaultAdvisorAutoProxyCreator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

import cn.daliedu.config.filter.ShiroUserFilter;
import cn.daliedu.shiro.redis.MyRedisSessionDAO;
import cn.daliedu.shiro.redis.SessionControlFilter;
import cn.daliedu.shiro.redis.SessionManager;
import cn.daliedu.util.Base64Util;
import cn.daliedu.util.Log4jUtil;

import javax.servlet.Filter;
import java.util.LinkedHashMap;
import java.util.Map;
 
@Configuration
public class ShiroConfig {
 
    @Value("${spring.redis.host}")
    private String redisHost;
 
    @Value("${spring.redis.port}")
    private int redisPort;
 
    @Value("${spring.redis.password}")
    private String redisPassword;
    
    @Value("${spring.redis.timeout}")
	private Integer timeout;
    
    @Value("${spring.redis.database}")
    private Integer database;
    
 
    @Bean
    public ShiroFilterFactoryBean shiroFilter(SecurityManager securityManager) {
        ShiroFilterFactoryBean shiroFilterFactoryBean = new ShiroFilterFactoryBean();
        
      //引入下面的自定义MyFormAuthenticationFilter主要是重写createToken方法，返回自定义的MyUsernamePasswordToken，因为我添加了userType参数
        FormAuthenticationFilter filter = new MyFormAuthenticationFilter();
        filter.setUsernameParam("loginName");// 自定义用户登入参数, 默认 username
		filter.setPasswordParam("pwd");
//		filtersMap.put("authc", filter);
		Map<String, Filter> filters = shiroFilterFactoryBean.getFilters();//获取filters
		filters.put("authc", filter);//将自定义 的FormAuthenticationFilter注入shiroFilter中  
		filters.put("custom", new ShiroUserFilter());
		
        
        shiroFilterFactoryBean.setSecurityManager(securityManager);
        // 没有登陆的用户只能访问登陆页面，前后端分离中登录界面跳转应由前端路由控制，后台仅返回json数据
        shiroFilterFactoryBean.setLoginUrl("/admin/login");
        // 登录成功后要跳转的链接
        shiroFilterFactoryBean.setSuccessUrl("/test2");
        // 未授权界面;
        shiroFilterFactoryBean.setUnauthorizedUrl("403");
 
        //自定义拦截器
//        Map<String, Filter> filtersMap = new LinkedHashMap<String, Filter>();
//        //限制同一帐号同时在线的个数,目前kickoutSessionControlFilter限制同一账号同时在线个数，还未做，只实现了登录超时给用户返回提示
//        filtersMap.put("kickout", kickoutSessionControlFilter());
//        
//		shiroFilterFactoryBean.setFilters(filtersMap);
        
        // 权限控制map.
        Map<String, String> filterChainDefinitionMap = new LinkedHashMap<String, String>();
        // 公共请求
//        filterChainDefinitionMap.put("/common/**", "anon");
        // 静态资源
        filterChainDefinitionMap.put("/static/**", "anon");
        filterChainDefinitionMap.put("/image/**", "anon");//image         
        filterChainDefinitionMap.put("/js/**", "anon");//js  
        filterChainDefinitionMap.put("/css/**", "anon");//css  
        
        filterChainDefinitionMap.put("/druid/**", "anon"); //druid 控制台不拦截
        
        //下面设置不对swagger进行拦截，但是因为接口都需要登录的状态才可以调用，所以下面的代码可以注掉了
//        filterChainDefinitionMap.put("/swagger-ui.html", "anon");  //目前注掉这一行，设置只拦截这一个没有登录则不能访问，下面的样式资源文件等不拦截
        filterChainDefinitionMap.put("/swagger-resources/**", "anon");
        filterChainDefinitionMap.put("/v2/api-docs", "anon");
        filterChainDefinitionMap.put("/webjars/springfox-swagger-ui/**", "anon");
        
        
     // 配置退出过滤器,其中的具体的退出代码Shiro已经替我们实现了
//        filterChainDefinitionMap.put("/logout", "logout");
        
        filterChainDefinitionMap.put("/admin/login", "anon");//一定要记得配置登录页面不拦截，本来就不应该拦截啊，未登录什么状态，什么权限都没有的呀
        filterChainDefinitionMap.put("/admin/logout", "anon");
        filterChainDefinitionMap.put("/admin/wxLogin", "anon");//一定要记得配置登录页面不拦截，本来就不应该拦截啊，未登录什么状态，什么权限都没有的呀
        filterChainDefinitionMap.put("/admin/crmLogin", "anon");//渠道版后台登录
        
        
        //?????????下一版本，前台使用新的获取会员类型接口，即上面那个，就把下面的注掉，不安全
        filterChainDefinitionMap.put("/api/dict/getDictValueByType", "anon");//获取数据字典，前台需要根据类型进行翻译
        
        filterChainDefinitionMap.put("/api/console/userCustomerCall/**", "anon");
        filterChainDefinitionMap.put("/api/console/customer/customerTemplateExport", "anon");
        filterChainDefinitionMap.put("/api/common/**", "anon");
        filterChainDefinitionMap.put("/api/console/user/updateUserAccountPassword", "anon");
      
        filterChainDefinitionMap.put("/register/**", "anon"); //注册路径下的不拦截
        filterChainDefinitionMap.put("/test/**", "anon"); //测试路径下的不拦截
        
        filterChainDefinitionMap.put("/swagger-ui.html", "anon"); //开发阶段可以将这个放开
        
     // <!-- 过滤链定义，从上向下顺序执行，一般将 /**放在最为下边 -->:这是一个坑呢，一不小心代码就不好使了;
        // <!-- authc:所有url都必须认证通过才可以访问; anon:所有url都都可以匿名访问-->
        filterChainDefinitionMap.put("/**", "custom"); //添加shiro跨域拦截支持，为了保险起见，custom放到authc前面
        filterChainDefinitionMap.put("/**", "authc");
        
        //此处需要添加一个kickout，上面添加的自定义拦截器才能生效
//        filterChainDefinitionMap.put("/admin/**", "authc,kickout");// 表示需要认证才可以访问
        shiroFilterFactoryBean.setFilterChainDefinitionMap(filterChainDefinitionMap);
        return shiroFilterFactoryBean;
    }
 
    @Bean
	public DefaultWebSecurityManager securityManager() {
		DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
		// 设置realm.
		securityManager.setRealm(myShiroRealm());
		// 自定义session管理 使用redis，防止重复登入问题
		securityManager.setSessionManager(sessionManager());
		
		// 自定义缓存实现 使用redis
		//这是合同系统的写法，在这个securityManager()方法里面加参数securityManager(RedisCacheManager redisCacheManager)，这种写法不统一，有点乱
		securityManager.setCacheManager(redisCacheManager());
		
		// 注入记住我管理器, 目前不起作用
//		 securityManager.setRememberMeManager(rememberMeManager());

		return securityManager;
	}
    

    
    /**
	 * 2. HashedCredentialsMatcher: 这个类是为了对密码进行编码的, 防止密码在数据库里明码保存, 当然在登陆认证的时候,
	 * 这个类也负责对 form 里输入的密码进行编码.
	 */
    //需要的时候再放开
//	@Bean
//	public HashedCredentialsMatcher hashedCredentialsMatcher(RedisCacheManager redisCacheManager) {
//		return new RetryLimitCredentialsMatcher(redisCacheManager);
//	}
    
    /**
     * 密码匹配凭证管理器
     *
     * @return
     */
    @Bean//(name = "myRetryLimitCredentialsMatcher")
    public MyRetryLimitCredentialsMatcher hashedCredentialsMatcher() {
        MyRetryLimitCredentialsMatcher hashedCredentialsMatcher = new MyRetryLimitCredentialsMatcher();
        // 采用MD5方式加密
        hashedCredentialsMatcher.setHashAlgorithmName("MD5");
        // 设置加密次数
//        hashedCredentialsMatcher.setHashIterations(Constant.MEGABYTE);
        return hashedCredentialsMatcher;
    }
 
    /**
     * 身份认证realm; (这个需要自己写，账号密码校验；权限等)
     *
     * @return
     */
    @Bean(name="myShiroRealm")
	public ShiroRealm myShiroRealm() {
		ShiroRealm myShiroRealm = new ShiroRealm();
		// 设置自定义密码比对方式，加盐等可以自己定义
//		myShiroRealm.setCredentialsMatcher(credentialsMatcher());
		myShiroRealm.setCredentialsMatcher(hashedCredentialsMatcher());

		// 启用缓存, 默认 false
		myShiroRealm.setCachingEnabled(true);

		// 启用身份验证缓存, 即缓存 AuthenticationInfo 信息, 默认 false,在修改密码后还要刷新缓存，目前还没有实现刷新缓存的功能，这个比较复杂，先设置为false吧
		//目前存在一个问题就是：用户修改密码后，无法使用新密码登录
		myShiroRealm.setAuthenticationCachingEnabled(true);
//		myShiroRealm.setAuthenticationCacheName(RetryLimitCredentialsMatcher.CACHE_NAME_AUTH);
		myShiroRealm.setAuthenticationCacheName("authenticationCache");

		// 启用授权缓存, 即缓存 AuthorizationInfo 信息, 默认 false
		myShiroRealm.setAuthorizationCachingEnabled(true);
		myShiroRealm.setAuthorizationCacheName("authorizationCache");

		// 放在设置缓存名之后, 因为调用设置管理器时, 会直接取用缓存名称, 所以放在之前则 authorizationCache 无法覆盖
		myShiroRealm.setCacheManager(redisCacheManager());
		return myShiroRealm;
	}
 
    /**
     * 设置自定义密码比对方式，加盐等可以自己定义
     * @return
     */
//    @Bean
//    public CredentialsMatcher credentialsMatcher() {
//        return new CredentialsMatcher();
//    }
 
    /**
	 * RedisCacheManager, 缓存管理, 用户登陆成功后, 把用户信息和权限信息缓存起来, 然后每次用户请求时, 放入用户的
	 * session 中, 如果不设置这个 bean, 每个请求都会查询一次数据库. 使用的是 shiro-redis 开源插件
	 */
    @Bean
    public RedisCacheManager redisCacheManager() {
        RedisCacheManager redisCacheManager = new RedisCacheManager();
        redisCacheManager.setKeyPrefix("crm_cache:");   //设置前缀
        
        redisCacheManager.setRedisManager(redisManager());
        redisCacheManager.setExpire(7200);//设置1天内不过期：1*24*60*60=86400  1天*24小时*60分钟*60秒
//        redisCacheManager.setExpire(100); //可以调试使用设置成100就超时，配合下面的 redisSessionDAO的时间一起设置
//        redisCacheManager.setValueSerializer(valueSerializer); //这个应该是设置值的序列化方式
        return redisCacheManager;
    }
 
    /**
     * RedisSessionDAO shiro sessionDao层的实现 通过redis
     * 使用的是shiro-redis开源插件
     */
    @Bean(name = "redisSessionDAO")
    public RedisSessionDAO redisSessionDAO() {
//        RedisSessionDAO redisSessionDAO = new RedisSessionDAO();
    	RedisSessionDAO redisSessionDAO = new MyRedisSessionDAO();
       
        redisSessionDAO.setExpire(7200);//设置1天内不过期：1*24*60*60=86400  1天*24小时*60分钟*60秒
//        redisSessionDAO.setExpire(100);  //可以调试使用设置成100就超时，配合下面的 redisCacheManager的时间一起设置
        redisSessionDAO.setKeyPrefix("crm_session:");
//        redisSessionDAO.setValueSerializer(valueSerializer); //这个应该是设置值的序列化方式
        
        redisSessionDAO.setRedisManager(redisManager());
        return redisSessionDAO;
    }
    
    @Bean
    public SimpleCookie getSessionIdCookie(){
//    	//在构造方法里面声明名称，下面的simpleCookie.setName("SHIRO_SESSION_ID");就不需要了
//        SimpleCookie simpleCookie = new SimpleCookie("Token");  
//        //默认的名称是下面这个
////        SimpleCookie simpleCookie = new SimpleCookie("SHRIOSESSIONID22222");
//        
//        simpleCookie.setPath("/"); //可在同一应用服务器内共享方法：设置cookie.setPath("/"); 同一台比如tomcat服务器下所有的应用都共享cookie就设置为  "/"
//        //如果您在cookie中设置了HttpOnly属性，那么通过js脚本将无法读取到cookie信息，这样能有效的防止XSS攻击
//        //合同项目是设置为true
//        simpleCookie.setHttpOnly(true);   //设置js不可读取此Cookie  为true则不可读取
////        simpleCookie.setMaxAge(-1);
//        simpleCookie.setMaxAge(259200); //记住我cookie生效时间,默认30天 ,单位秒：60 * 60 * 24 * 30

        
//        simpleCookie.setName("SHIRO_SESSION_ID");
    	
    	
    	
        //这个参数是cookie的名称，对应前端的checkbox的name = rememberMe
        SimpleCookie simpleCookie = new SimpleCookie();
        //如果httyOnly设置为true，则客户端不会暴露给客户端脚本代码，使用HttpOnly cookie有助于减少某些类型的跨站点脚本攻击；
        simpleCookie.setHttpOnly(true);
        //记住我cookie生效时间,默认30天 ,单位秒：60 * 60 * 24 * 30
//        simpleCookie.setMaxAge(259200);
        simpleCookie.setMaxAge(-1);
        simpleCookie.setName("SHIRO_SESSION_ID");

        return simpleCookie;
    }

 
    /**
     * Session Manager
     * 使用的是shiro-redis开源插件
     */
    @Bean
    public DefaultWebSessionManager sessionManager() {
        //shiro api自带的
//      DefaultWebSessionManager sessionManager = new DefaultWebSessionManager();
        
        //使用自定义的SessionManager，可以获取请求头header中的token
        SessionManager sessionManager = new SessionManager();
        sessionManager.setSessionDAO(redisSessionDAO());
        sessionManager.setCacheManager(redisCacheManager());// 加入缓存管理器 加入了这个还是不起作用
    
     // 去掉shiro登录时url里的JSESSIONID  // tomcat的JESSIONID自动生成模块，shiro直接抄的tomcat的，唉！误导我一直在看tomcat源码
        sessionManager.setSessionIdUrlRewritingEnabled(false);  
        sessionManager.setDeleteInvalidSessions(true);// 删除过期的 session
        
        // 设置全局 session 超时时间
     	sessionManager.setSessionValidationSchedulerEnabled(true);// 是否定时检查
//     	sessionManager.setGlobalSessionTimeout(3600000);  //默认1小时不过期,暂时不设置，使用默认的
     	
     	//这个其实可以不设置，因为默认就是开启的，我设置成了false搞了一天整的找问题
     	//默认就是true,即默认浏览器会带上cookie中的内容去请求
        sessionManager.setSessionIdCookieEnabled(true);  
     	sessionManager.setSessionIdCookie(getSessionIdCookie());
     	
        return sessionManager;
    }
    
    /**
     * 结合上面的属性sessionManager.setSessionValidationSchedulerEnabled(true);使用，目前都是注掉的
     */
    @Bean(name = "sessionValidationScheduler")
	public ExecutorServiceSessionValidationScheduler getExecutorServiceSessionValidationScheduler() {
		ExecutorServiceSessionValidationScheduler scheduler = new ExecutorServiceSessionValidationScheduler();
//		scheduler.setInterval(3600000);   //原来的值
		scheduler.setInterval(86400);   //设置session的失效扫描间隔，单位为毫秒
		return scheduler;
	}
 
 
    /**
     * 配置shiro redisManager
     * 使用的是shiro-redis开源插件
     *
     * @return
     */
    @Bean
    public RedisManager redisManager() {
        RedisManager redisManager = new RedisManager();
        redisManager.setHost(redisHost);
        redisManager.setPort(redisPort);
        redisManager.setTimeout(timeout); //设置过期时间
        redisManager.setPassword(redisPassword);
        redisManager.setDatabase(database); //使用redis库的序号
        return redisManager;
    }
 
    /**
     * 限制同一账号登录同时登录人数控制
     *
     * @return
     */
    @Bean
    public SessionControlFilter kickoutSessionControlFilter() {
        SessionControlFilter kickoutSessionControlFilter = new SessionControlFilter();
        kickoutSessionControlFilter.setCache(redisCacheManager());
        kickoutSessionControlFilter.setSessionManager(sessionManager());
        kickoutSessionControlFilter.setKickoutAfter(false);
        kickoutSessionControlFilter.setMaxSession(1);
        kickoutSessionControlFilter.setKickoutUrl("/admin/login");
        return kickoutSessionControlFilter;
    }
 
 
    /***
     * 授权所用配置
     *
     * @return
     */
    @Bean
    public DefaultAdvisorAutoProxyCreator getDefaultAdvisorAutoProxyCreator() {
        DefaultAdvisorAutoProxyCreator defaultAdvisorAutoProxyCreator = new DefaultAdvisorAutoProxyCreator();
        defaultAdvisorAutoProxyCreator.setProxyTargetClass(true);
        return defaultAdvisorAutoProxyCreator;
    }
 
    /**
	 * AuthorizationAttributeSourceAdvisor, shiro 里实现的 Advisor 类, 内部使用
	 * AopAllianceAnnotationsAuthorizingMethodInterceptor 来拦截用以下注解的方法.
	 */
    @Bean
    public AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor(SecurityManager securityManager){
        AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor = new AuthorizationAttributeSourceAdvisor();
        authorizationAttributeSourceAdvisor.setSecurityManager(securityManager);
        return authorizationAttributeSourceAdvisor;
    }
 
  
     

    
    /**
	 * 1. LifecycleBeanPostProcessor: 这是个 DestructionAwareBeanPostProcessor 的子类,
	 * 负责 org.apache.shiro.util.Initializable 类型 bean 的生命周期的, 初始化和销毁. 主要是
	 * AuthorizingRealm 类的子类, 以及 EhCacheManager 类.
	 */
	@Bean
	public static LifecycleBeanPostProcessor lifecycleBeanPostProcessor() {
		return new LifecycleBeanPostProcessor();
	}
	
	/**
     * 2.Shiro生命周期处理器  (上面的第1点与这个第2点一定要配合使用)
     * 此方法需要用static作为修饰词，否则无法通过@Value()注解的方式获取配置文件的值
     *  
     *  DefaultAdvisorAutoProxyCreator是用来扫描上下文，寻找所有的Advistor(通知器），将这些Advisor应用到所有符合切入点的Bean中。
     *  所以必须在lifecycleBeanPostProcessor创建之后创建，所以用了depends-on=”lifecycleBeanPostProcessor”> 
     *  */
    @Bean
	@DependsOn("lifecycleBeanPostProcessor")  //使用这个注解
	public DefaultAdvisorAutoProxyCreator defaultAdvisorAutoProxyCreator() {
		DefaultAdvisorAutoProxyCreator creator = new DefaultAdvisorAutoProxyCreator();
		creator.setProxyTargetClass(true);
		return creator;
	}
    
//	/**
//	 * cookie 管理对象, 记住我功能 这个是合同项目的写法
//	 */
//	private CookieRememberMeManager rememberMeManager() {
//		// 这个参数是 cookie 的名称, 对应前端的 checkbox 的 name=rememberMe
//		SimpleCookie simpleCookie = new SimpleCookie(FormAuthenticationFilter.DEFAULT_REMEMBER_ME_PARAM);
//		// 记住我 cookie 生效时间 30 天, 单位秒
//		simpleCookie.setMaxAge(2592000);
//
//		CookieRememberMeManager cookieRememberMeManager = new CookieRememberMeManager();
//		cookieRememberMeManager.setCookie(simpleCookie);
//
//		try {
//			// rememberMe cookie 加密的密钥, 建议每个项目都不一样, 默认 AES 算法, 密钥长度(128 256 512
//			// 位)
//			cookieRememberMeManager.setCipherKey(Base64.decode(AesUtil.encryptNormal("lds_yqt-contract")));
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		return cookieRememberMeManager;
//	}
	
//	/**
//	* cookie管理器  网上找的
//	* @return
//	*/
//	@Bean
//	public CookieRememberMeManager rememberMeManager(){
//	    Log4jUtil.info("注入Shiro的记住我(CookieRememberMeManager)管理器-->rememberMeManager");
//	    CookieRememberMeManager cookieRememberMeManager = new CookieRememberMeManager();
//	    //rememberme cookie加密的密钥 建议每个项目都不一样 默认AES算法 密钥长度（128 256 512 位），通过以下代码可以获取
//	    //KeyGenerator keygen = KeyGenerator.getInstance("AES");
//	    //SecretKey deskey = keygen.generateKey();
//	    //System.out.println(Base64.encodeToString(deskey.getEncoded()));
//	    byte[] cipherKey = Base64Util.decode("wGiHplamyXlVB11UXWol8g==");
//	    cookieRememberMeManager.setCipherKey(cipherKey);
//	    cookieRememberMeManager.setCookie(getSessionIdCookie());
//	    return cookieRememberMeManager;
//	}


} 
