package cn.daliedu.config.bak;
//package com.esa2000.config.bak;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import io.swagger.annotations.Api;
//import springfox.documentation.builders.ApiInfoBuilder;
//import springfox.documentation.builders.ParameterBuilder;
//import springfox.documentation.builders.PathSelectors;
//import springfox.documentation.builders.RequestHandlerSelectors;
//import springfox.documentation.schema.ModelRef;
//import springfox.documentation.service.ApiInfo;
//import springfox.documentation.service.Parameter;
//import springfox.documentation.spi.DocumentationType;
//import springfox.documentation.spring.web.plugins.Docket;
//
//
///**
// * 
// * @author xiechao
// * @time 2019年1月7日 下午5:08:23
// * @version 1.0.0 
// * @description  如果需要去除发布的接口显示页面上面的swagger顶栏，需要修改引入的swagger.jar包中的css样式文件
// * 参考：https://blog.csdn.net/yanxilou/article/details/82839108
// */
////@Configuration
//public class Swagger2Config {
////	public static final String SWAGGER_SCAN_ADMIN_PACKAGE = "com.esa2000.controller.api.channel";
////    public static final String ADMIN_VERSION = "1.0.0";
////    public static final String SWAGGER_SCAN_WX_PACKAGE = "com.esa2000.controller.api";
////    public static final String WX_VERSION = "1.0.0";
//
//    @Bean
//    public Docket createVipRestApi() {
//        return new Docket(DocumentationType.SWAGGER_2)
//                .groupName("会员版接口")
//                .apiInfo(apiVipInfo())
//                .select()
//                .apis(RequestHandlerSelectors.basePackage("com.esa2000.controller.api.vip"))//api接口包扫描路径
////                .paths(PathSelectors.regex(".*/admin/.*"))//可以根据url路径设置哪些请求加入文档，忽略哪些请求
//                .paths(PathSelectors.any())
//                .build();
////                .globalOperationParameters(setHeaderToken()); //将配置的header参数加上,如果不需要全局配置header参数，则注掉此行,注意.global方法要放在这个方法链的最后
//        
//    }
//    private ApiInfo apiVipInfo() {
//        return new ApiInfoBuilder()
//                .title("会员版接口")//设置文档的标题
////                .description("后台数据管理")//设置文档的描述->1.Overview
//                .version("1.0")//设置文档的版本信息-> 1.1 Version information
//                .build();
//    }
//
//    @Bean
//    public Docket createChannelRestApi() {
//        return new Docket(DocumentationType.SWAGGER_2)
//                .groupName("渠道版接口")
//                .apiInfo(apiChannelInfo())
//                .select()
//                .apis(RequestHandlerSelectors.basePackage("com.esa2000.controller.api.channel"))//api接口包扫描路径
////                .paths(PathSelectors.regex(".*/weixin/.*"))//可以根据url路径设置哪些请求加入文档，忽略哪些请求
//                .paths(PathSelectors.any())
//                .build();
////                .globalOperationParameters(setHeaderToken()); //将配置的header参数加上,如果不需要全局配置header参数，则注掉此行,注意.global方法要放在这个方法链的最后
//    }
//    private ApiInfo apiChannelInfo() {
//        return new ApiInfoBuilder()
//                .title("渠道版接口")//设置文档的标题
////                .description("微信开发接口实现的文档")//设置文档的描述->1.Overview
//                .version("1.0")//设置文档的版本信息-> 1.1 Version information
//                .build();
//    }
//
//	
//
//	/**
//	 * 添加全局token参数，后面如果所有接口不需要默认带上token了，此方法就废掉了
//	 * 目前问题已经解决，带上全局的参数已经不需要了，但是保留，以后万一有带上全局其他什么参数的需求 
//	 * @return
//	 */
//	private List<Parameter> setHeaderToken() {
//	//添加header参数，下面的pars这一段代码注掉，则发布的接口页面将不会出现往header中传值的输入框
//    ParameterBuilder ticketPar = new ParameterBuilder();
//    List<Parameter> pars = new ArrayList<>();
//    ticketPar.name("token")
//    		 .description("user token")
//             .modelRef(new ModelRef("string"))
//             .parameterType("header")
//             .required(false)
//             .build(); //header中的ticket参数非必填，传空也可以
//    pars.add(ticketPar.build());    //根据每个方法名也知道当前方法在设置什么参数
//    return pars;
////    ParameterBuilder tokenPar = new ParameterBuilder();
////    List<Parameter> pars = new ArrayList<>();
////    tokenPar.name("X-Auth-Token").description("token").modelRef(new ModelRef("string")).parameterType("header").required(false).build();
////    pars.add(tokenPar.build());
////    return pars;
//}
//	
//	
//	
//	
//	
//	
////	@Bean
////	public Docket createRestApi() {
////		return new Docket(DocumentationType.SWAGGER_2)
////				.apiInfo(apiInfo())
////				.select()
////				//配置扫描发布接口的类
////				.apis(RequestHandlerSelectors.basePackage("com.esa2000.controller.api"))
////				.paths(PathSelectors.any())
//////	            .paths(PathSelectors.regex(restPath + "/.*"))// 设置拦截路径
//////	             .paths(PathSelectors.regex("/platform/.*"))// 设置拦截路径
////				.build()
////				.globalOperationParameters(setHeaderToken());//将配置的header参数加上,如果不需要全局配置header参数，则注掉此行
////	}
////	
////	
////	
//
////
////
////	/**
////	 * 创建api页面展现首页基础信息
////	 * @return
////	 */
////	private ApiInfo apiInfo() {
////		return new ApiInfoBuilder()
////				.title("接口测试")
////	            .description("测试系统 Restful API")
////				.termsOfServiceUrl("http://blog.csdn.net/saytime")
//////				.contact(new Contact("xiechao", "https://www.cnblogs.com/", "543043491@qq.com"))
////				.version("1.0")
////				.build();
////	}
//
////	//swagger2的配置文件，这里可以配置swagger2的一些基本的内容，比如扫描的包等等
////    @Bean
////    public Docket createRestApi() {
////        return new Docket(DocumentationType.SWAGGER_2)
////                .apiInfo(apiInfo())
////                .select()
////                //为当前包路径
////                .apis(RequestHandlerSelectors.basePackage("com.esa2000.controller")) 
////                .paths(PathSelectors.any())
////                .build();
////    }
////    //构建 api文档的详细信息函数,注意这里的注解引用的是哪个
////    private ApiInfo apiInfo() {
////        return new ApiInfoBuilder()
////                //页面标题
////                .title("Spring Boot 测试使用 Swagger2 构建RESTful API")
////                //创建人
////                .contact(new Contact("cookie", "http://www.baidu.com", "2118119173@qq.com"))
////                //版本号
////                .version("1.0")
////                //描述
////                .description("用户管理")
////                .build();
////    }
//
//    
////	@Bean
////	public Docket createRestApi() {
////		return new Docket(DocumentationType.SWAGGER_2)
////				.apiInfo(apiInfo())
////				.select()
////				.apis(RequestHandlerSelectors.basePackage("cn.saytime.web"))
////				.paths(PathSelectors.any())
////				.build();
////	}
////	
////	private ApiInfo apiInfo() {
////		return new ApiInfoBuilder()
////				.title("springboot利用swagger构建api文档")
////				.description("简单优雅的restfun风格，http://blog.csdn.net/saytime")
////				.termsOfServiceUrl("http://blog.csdn.net/saytime")
////				.version("1.0")
////				.build();
////	}
//
//
//}
