package cn.daliedu.enums;

/**
 * 用户状态枚举类
 * @author xiechao
 * @time 2019年9月20日 下午3:52:34
 * @version 1.0.0 
 * @description
 */
public enum UserStateEnum {
	/**
	 * 禁用状态
	 */
	STATE_0("0", "禁用状态"), 
	/**
	 * 可用状态
	 */
	STATE_1("1", "可用状态"),
	/**
	 * 离职状态
	 */
	STATE_2("2", "离职状态");

	private String value;
	private String desc;

	UserStateEnum(final String value, final String desc) {
		this.value = value;
		this.desc = desc;
	}


	public String getValue() {
		return value;
	}
	
	public String getDesc() {
		return desc;
	}
	
}