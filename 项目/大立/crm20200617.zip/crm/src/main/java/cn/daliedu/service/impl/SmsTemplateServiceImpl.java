package cn.daliedu.service.impl;

import cn.daliedu.entity.ContractEntity;
import cn.daliedu.entity.CustomerEntity;
import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.SmsTemplateEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.UserSmsRecordEntity;
import cn.daliedu.enums.SmsTemplateCodeEnum;
import cn.daliedu.mapper.SmsTemplateMapper;
import cn.daliedu.service.CustomerService;
import cn.daliedu.service.OrgService;
import cn.daliedu.service.SmsTemplateService;
import cn.daliedu.service.UserService;
import cn.daliedu.util.JsonUtil;
import cn.daliedu.util.Result;
import cn.daliedu.util.SMSUtil;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import java.time.LocalDateTime;
import java.util.List;

import javax.annotation.Resource;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 短信模板表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-12-26
 */
@Service
public class SmsTemplateServiceImpl extends ServiceImpl<SmsTemplateMapper, SmsTemplateEntity> implements SmsTemplateService {

	@Resource
	SmsTemplateMapper smsTemplateMapper;
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	OrgService orgService;
	
	
	@Override
	public boolean sendSmsToCustomer(String customerIds, String templateCode) throws Exception{
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity bean = (UserEntity) object;
			UserEntity user = userService.getById(bean.getId());
			OrgEntity orgEntity = orgService.getUserBranchOrgByOrgId(user.getOrgId());
			
			SmsTemplateEntity smsTemplateEntity = this.getSmsTemplateByTemplateCode(templateCode);
			List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
			if(templateCode.equals(SmsTemplateCodeEnum.SMS_177548750.getValue())){
				for(String customerId : customerIdList){
					CustomerEntity customerEntity = customerService.getById(customerId);
					boolean flag = SMSUtil.sendSms(customerEntity.getMobile(), smsTemplateEntity, customerEntity.getMobile(), customerEntity.getMobile());
					if(flag){
						//记录用户发送的短信，用于记录与统计分析每个分校发送的短信数量
						UserSmsRecordEntity userSmsEntity = new UserSmsRecordEntity();
						userSmsEntity.setUserId(user.getId());
						userSmsEntity.setBranchOrgId(orgEntity.getId().toString());
						userSmsEntity.setTemplateCode(templateCode);
						userSmsEntity.setCreateDateTime(LocalDateTime.now());
					}
				}
				return true;
			}
			//现在还用不上
//			if(templateCode.equals(SmsTemplateCodeEnum.SMS_179155048.getValue())){
//				for(String customerId : customerIdList){
//					CustomerEntity customerEntity = customerService.getById(customerId);
//					boolean flag = SMSUtil.sendSms(customerId, smsTemplateEntity, customerEntity.getMobile());
//					if(flag){
//						//记录用户发送的短信，用于记录与统计分析每个分校发送的短信数量
//						UserSmsRecordEntity userSmsEntity = new UserSmsRecordEntity();
//						userSmsEntity.setUserId(user.getId());
//						userSmsEntity.setBranchOrgId(orgEntity.getId().toString());
//						userSmsEntity.setTemplateCode(templateCode);
//						userSmsEntity.setCreateDateTime(LocalDateTime.now());
//					}
//				}
//				return true;
//			}
		}
		return false;
	}


	@Override
	public IPage<SmsTemplateEntity> getSmsTemplateList(Integer pageNum, Integer pageSize) {
		if (pageNum <= 0) {
			pageNum = 1;
		}
		IPage<SmsTemplateEntity> page = new Page<SmsTemplateEntity>();
		page.setCurrent(pageNum);
		page.setSize(pageSize);
		
		QueryWrapper<SmsTemplateEntity> queryWrapper = new QueryWrapper<SmsTemplateEntity>();

		return smsTemplateMapper.selectPage(page, queryWrapper);
	}


	@Override
	public SmsTemplateEntity getSmsTemplateByTemplateCode(String templateCode) {
		return smsTemplateMapper.selectOne(new QueryWrapper<SmsTemplateEntity>().eq("template_code", templateCode).last("limit 1"));
	}
	
	

	
}
