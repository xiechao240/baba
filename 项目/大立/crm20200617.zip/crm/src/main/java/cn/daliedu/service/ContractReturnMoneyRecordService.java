package cn.daliedu.service;

import cn.daliedu.entity.ContractReturnMoneyRecordEntity;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 合同回款记录表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-31
 */
public interface ContractReturnMoneyRecordService extends IService<ContractReturnMoneyRecordEntity> {
	
	
}
