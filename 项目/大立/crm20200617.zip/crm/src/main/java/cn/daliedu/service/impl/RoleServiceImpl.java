package cn.daliedu.service.impl;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.entity.MenuEntity;
import cn.daliedu.entity.RoleEntity;
import cn.daliedu.entity.RoleMenuEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.enums.UserTypeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.mapper.RoleMapper;
import cn.daliedu.mapper.RoleMenuMapper;
import cn.daliedu.service.MenuService;
import cn.daliedu.service.RoleService;
import cn.daliedu.service.UserService;

/**
 * <p>
 * 角色管理 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
@Service
public class RoleServiceImpl extends ServiceImpl<RoleMapper, RoleEntity> implements RoleService {
	
	@Resource
	RoleMapper roleMapper;
	
	@Resource
	RoleMenuMapper roleMenuMapper;
	
	@Autowired
	MenuService menuService;
	
	@Autowired
	UserService userService;
	
	
	@Override
	public List<RoleEntity> getRoleListByAddUser() throws Exception{
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity bean = (UserEntity) object;
			UserEntity user = userService.getById(bean.getId());
			
			List<RoleEntity> roleList;
			List<String> userTypes = new ArrayList<String>();
			userTypes.add(UserTypeEnum.TYPE_1.getValue());
			userTypes.add(UserTypeEnum.TYPE_2.getValue());
			userTypes.add(UserTypeEnum.TYPE_3.getValue());
			userTypes.add(UserTypeEnum.TYPE_4.getValue());
			userTypes.add(UserTypeEnum.TYPE_5.getValue());
			userTypes.add(UserTypeEnum.TYPE_6.getValue());
			userTypes.add(UserTypeEnum.TYPE_7.getValue());
			
			
			if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue())){
				userTypes.remove(UserTypeEnum.TYPE_1.getValue());
				roleList = roleMapper.selectList(new QueryWrapper<RoleEntity>().in("id", userTypes));
			}else if(user.getUserType().equals(UserTypeEnum.TYPE_2.getValue())){
				userTypes.remove(UserTypeEnum.TYPE_1.getValue());
				userTypes.remove(UserTypeEnum.TYPE_2.getValue());
				roleList = roleMapper.selectList(new QueryWrapper<RoleEntity>().in("id", userTypes));
			}else if(user.getUserType().equals(UserTypeEnum.TYPE_3.getValue())){
				userTypes.remove(UserTypeEnum.TYPE_1.getValue());
				userTypes.remove(UserTypeEnum.TYPE_2.getValue());
				userTypes.remove(UserTypeEnum.TYPE_3.getValue());
				roleList = roleMapper.selectList(new QueryWrapper<RoleEntity>().in("id", userTypes));
			}else if(user.getUserType().equals(UserTypeEnum.TYPE_4.getValue())){
				userTypes.remove(UserTypeEnum.TYPE_1.getValue());
				userTypes.remove(UserTypeEnum.TYPE_2.getValue());
				userTypes.remove(UserTypeEnum.TYPE_3.getValue());
				userTypes.remove(UserTypeEnum.TYPE_4.getValue());
				userTypes.remove(UserTypeEnum.TYPE_7.getValue());
				roleList = roleMapper.selectList(new QueryWrapper<RoleEntity>().in("id", userTypes));
			}else{
				throw new BusinessException("当前用户访问异常");
			}
			return roleList;
		}
		return null;
	}


	@Override
	public IPage<RoleEntity> getPageRoleList(int pageNum, int pageSize, String name) {
		////只有当前登录的用户是超级管理员类型，才可以加载超级管理员的角色列表
		//注：最新需求：所有的用户都不能加载超级管理员角色列表出来
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
//			UserEntity bean = (UserEntity) object;
//			UserEntity user = userService.getById(bean.getId());
			
			// 设置分页
			if (pageNum <= 0) {
				pageNum = 1;
			}
			IPage<RoleEntity> page = new Page<RoleEntity>();
			page.setCurrent(pageNum);
			page.setSize(pageSize);

			QueryWrapper<RoleEntity> queryWrapper = new QueryWrapper<RoleEntity>();
			// 判断角色名称是否为空
			if (name != null && !name.trim().equals("") && !name.trim().equals("null")) {
				queryWrapper.like("name", name.trim());
			}
			
			IPage<RoleEntity> iPage = roleMapper.selectPage(page, queryWrapper);
			List<RoleEntity> newList = new ArrayList<RoleEntity>();
			List<RoleEntity> list = iPage.getRecords();
			for(RoleEntity entity : list){
				if(!entity.getIsAdmin().equals("1")){
					newList.add(entity);
				}
				
			}
			iPage.setRecords(newList);
			iPage.setTotal(Long.valueOf(newList.size()));
//			queryWrapper.orderByDesc("create_time");
			return iPage;
			
//			if(user.getUserType().equals(UserTypeEnum.TYPE_1)){
//				IPage<RoleEntity> iPage = roleMapper.selectPage(page, queryWrapper);
//				List<RoleEntity> newList = new ArrayList<RoleEntity>();
//				List<RoleEntity> list = iPage.getRecords();
//				for(RoleEntity entity : list){
//					if(!entity.getIsAdmin().equals("1")){
//						newList.add(entity);
//					}
//				}
//				iPage.setRecords(newList);
////				queryWrapper.orderByDesc("create_time");
//				return iPage;
//			}else{
//				return roleMapper.selectPage(page, queryWrapper);
//			}
		}
		return null;
		
	}
	
	
	@Override
	public List<RoleEntity> getUserRoleList(String userId, Integer pageNum, Integer pageSize) {
		int startRow = 0;
		if(pageNum!=null && pageNum>0){
			startRow = (pageNum-1)*pageSize;
		}
		Map<Object, Object> map = new HashMap<Object, Object>();
		map.put("startRow", startRow);
		map.put("pageSize", pageSize);
		map.put("userId", userId);
		
		return roleMapper.getUserRoleList(map);
	}
	
	@Override
	public List<Integer> getUserRoleIdsByUserId(String userId, Integer pageNum, Integer pageSize) {
		int startRow = 0;
		if(pageNum!=null && pageNum>0){
			startRow = (pageNum-1)*pageSize;
		}
		Map<Object, Object> map = new HashMap<Object, Object>();
		map.put("startRow", startRow);
		map.put("pageSize", pageSize);
		map.put("userId", userId);
		
		return roleMapper.getUserRoleIdsByUserId(map);
	}


	@Override
	public List<RoleEntity> getRoleListByRoleName(String roleName) {
		return roleMapper.selectList(new QueryWrapper<RoleEntity>().eq("name", roleName));
	}


	@Override
	public boolean copyRole(RoleEntity entity, String newRoleName) {
		List<MenuEntity> menuList = menuService.getMenuListByRoleId(entity.getId());
		
		if(menuList!=null && menuList.size()>0){
			//1. 保存新的角色
			RoleEntity newRole = new RoleEntity();
			int num = roleMapper.insert(newRole);
			if(num>0){
				//2.保存新的角色对应的菜单
				for(MenuEntity menu : menuList){
					RoleMenuEntity bean = new RoleMenuEntity();
					bean.setCreateTime(LocalDateTime.now());
					bean.setMenuId(menu.getId());
					bean.setRoleId(newRole.getId());
					roleMenuMapper.insert(bean);
				}
				return true;
			}
		}
		return false;
	}

//	@Transactional(rollbackFor = Exception.class)
	@Override
	public boolean saveRole(RoleEntity roleEntity) throws Exception {
		
		roleMapper.insert(roleEntity);
		int num = 3/0;
		System.out.println(num);
		
		throw new SQLException("发生异常了..");
//		try {
//			roleMapper.insert(roleEntity);
////			this.save(roleEntity);
//			int num = 3/0;
//			System.out.println(num);
//			return true;
//		} catch (Exception e) {
//			e.printStackTrace();
//			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
//		}
//		return false;
	}
}
