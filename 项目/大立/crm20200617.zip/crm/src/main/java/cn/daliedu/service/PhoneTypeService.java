package cn.daliedu.service;

import cn.daliedu.entity.PhoneTypeEntity;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 机型匹配目录表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2020-06-08
 */
public interface PhoneTypeService extends IService<PhoneTypeEntity> {
	
	PhoneTypeEntity queryPhoneDirectory(String phoneType, Integer androidVersion);

}
