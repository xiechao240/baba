package cn.daliedu.mapper;

import cn.daliedu.entity.UserOrgEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.Map;

/**
 * <p>
 * 用户组织表 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-09-23
 */
public interface UserOrgMapper extends BaseMapper<UserOrgEntity> {
    /**
     * 批量增加用户部门
     * @param map
     * @return
     */
    public Integer addUserOrgBatch(Map<String, Object> map);

}
