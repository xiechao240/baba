package cn.daliedu.controller.api.console;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.CustomerSelfDefineItemConfigDetailEntity;
import cn.daliedu.entity.CustomerTagGroupDetailEntity;
import cn.daliedu.entity.json.CustomerSelfDefineItemJson;
import cn.daliedu.entity.json.CustomerTagGroupJson;
import cn.daliedu.entity.json.OrgJson;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.CustomerSelfDefineItemConfigDetailService;
import cn.daliedu.service.CustomerSelfDefineItemConfigService;
import cn.daliedu.service.CustomerSelfDefineItemService;
import cn.daliedu.service.CustomerTagGroupDetailService;
import cn.daliedu.service.CustomerTagService;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 客户标签分组明细表 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2019-10-24
 */
@Api(description = "客户自定义分组明细接口")
@RestController
@RequestMapping("${rest.path}/console/customerSelfDefineItemConfigDetail")
public class CustomerSelfDefineItemConfigDetailController {
	
	@Autowired
	CustomerSelfDefineItemService customerSelfDefineItemService;
	
	@Autowired
	CustomerSelfDefineItemConfigService customerSelfDefineItemConfigService;
	
	@Autowired
	CustomerSelfDefineItemConfigDetailService customerSelfDefineItemConfigDetailService;
	
	@ApiOperation(value = "根据客户自定义分组类型ID，加载客户自定义分组下的标签明细")
	@ApiJsonObject(name = "getCustomerSelfDefineItemConfigDetail", value = {
			@ApiJsonProperty(name = CustomerSelfDefineItemJson.itemId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerSelfDefineItemConfigDetail")
	@PostMapping("/getCustomerSelfDefineItemConfigDetail")
	public Result getCustomerSelfDefineItemConfigDetail(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String itemId = String.valueOf(jsonObject.get("itemId"));
			
			StringUtil.validateIsNull(itemId, "请输入客户自定义分组类型ID");
			
			itemId  = itemId.trim();
			
			List<CustomerSelfDefineItemConfigDetailEntity> list = customerSelfDefineItemConfigDetailService.getCustomerSelfDefineItemConfigDetailByItemId(itemId);
			
			return Result.success(list);
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户自定义分组下的明细失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "新增客户自定义明细接口")
	@ApiJsonObject(name = "saveCustomerSelfDefineItemConfigDetail", value = { 
			@ApiJsonProperty(name = CustomerSelfDefineItemJson.itemId),
			@ApiJsonProperty(name = CustomerSelfDefineItemJson.itemDetailName)})
	@ApiImplicitParam(name = "params", required = true, dataType = "saveCustomerSelfDefineItemConfigDetail")
	@PostMapping("/saveCustomerSelfDefineItemConfigDetail")
	public Result saveCustomerSelfDefineItemConfigDetail(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String itemId = String.valueOf(jsonObject.get("itemId"));
			String itemDetailName = String.valueOf(jsonObject.get("itemDetailName"));
			
			StringUtil.validateIsNull(itemId, "请输入客户自定义类别ID");
			StringUtil.validateIsNull(itemDetailName, "请输入分组标签ID");
			
			itemId = itemId.trim();
			itemDetailName = itemDetailName.trim();
			
			//判断标签名称是否存在
			if(customerSelfDefineItemConfigDetailService.existsCustomerSelfDefineItemConfigDetail(itemId, itemDetailName)){
				return Result.error("此客户标签已经存在，请重新输入");
			}else{
				boolean flag = customerSelfDefineItemConfigDetailService.saveCustomerSelfDefineItemConfigDetail(itemId, itemDetailName);
				if(flag){
					return Result.success("新增成功");
				}else{
					return Result.error("新增失败");
				}
			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("新增客户自定义明细失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "修改客户自定义明细接口")
	@ApiJsonObject(name = "updateCustomerSelfDefineItemConfigDetail", value = {
			@ApiJsonProperty(name = CustomerSelfDefineItemJson.itemId),
			@ApiJsonProperty(name = CustomerSelfDefineItemJson.itemDetailId),
			@ApiJsonProperty(name = CustomerSelfDefineItemJson.itemDetailName),
			@ApiJsonProperty(name = OrgJson.orderNum)})
	@ApiImplicitParam(name = "params", required = true, dataType = "updateCustomerSelfDefineItemConfigDetail")
	@PostMapping("/updateCustomerSelfDefineItemConfigDetail")
	public Result updateCustomerSelfDefineItemConfigDetail(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String itemId = String.valueOf(jsonObject.get("itemId"));
			String itemDetailId = String.valueOf(jsonObject.get("itemDetailId"));
			String itemDetailName = String.valueOf(jsonObject.get("itemDetailName"));
			String orderNum = String.valueOf(jsonObject.get("orderNum"));
			
			StringUtil.validateIsNull(itemId, "请输入分组ID");
			StringUtil.validateIsNull(itemDetailId, "请输入客户自定义明细ID不能为空");
			StringUtil.validateIsNull(itemDetailName, "请输入客户自定义明细名称不能为空");
			StringUtil.validateIsNull(orderNum, "请输入排序号");
			
			//判断标签名称是否存在
//			if(customerSelfDefineItemConfigDetailService.existsCustomerSelfDefineItemConfigDetail(itemId, itemDetailName)){
//				return Result.error("此客户标签已经存在，请重新输入");
//			}else{
				CustomerSelfDefineItemConfigDetailEntity entity = new CustomerSelfDefineItemConfigDetailEntity();
				entity.setItemDetailId(itemDetailId);
				entity.setItemId(itemId);
				entity.setItemDetailName(itemDetailName);
				entity.setOrderNum(Integer.parseInt(orderNum));
				
				if(customerSelfDefineItemConfigDetailService.updateById(entity)){
					return Result.success("修改成功！");
				}
				return Result.error("修改失败！");
//			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("修改客户自定义明细失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "删除客户自定义明细接口(如果已经被客户使用，则不允许删除)")
	@ApiJsonObject(name = "deleteCustomerSelfDefineItemConfigDetail", value = {
			@ApiJsonProperty(name = CustomerSelfDefineItemJson.itemDetailId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "deleteCustomerSelfDefineItemConfigDetail")
	@PostMapping("/deleteCustomerSelfDefineItemConfigDetail")
	public Result deleteCustomerSelfDefineItemConfigDetail(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String itemDetailId = String.valueOf(jsonObject.get("itemDetailId"));
			
			StringUtil.validateIsNull(itemDetailId, "客户自定义明细ID不能为空");
			
			if(customerSelfDefineItemService.existsCustomerSelfDefineItemConfigDetailUse(itemDetailId)){
				return Result.error("此客户自定义明细已经被使用，不能删除");
			}else{
				CustomerSelfDefineItemConfigDetailEntity entity = new CustomerSelfDefineItemConfigDetailEntity();
				entity.setItemDetailId(itemDetailId);
				
				boolean flag = customerSelfDefineItemConfigDetailService.removeById(entity);
				if(flag){
					return Result.success("删除成功！");
				}
				return Result.error("删除客户自定义明细失败！");
			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("删除客户自定义明细失败，失败原因：" + e.getMessage());
		}
	}
}
