package cn.daliedu.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.config.task.QuartzManager;
import cn.daliedu.entity.TaskEntity;
import cn.daliedu.enums.JobStatusEnum;
import cn.daliedu.mapper.TaskMapper;
import cn.daliedu.service.TaskService;
import cn.daliedu.util.ServerUtil;

/**
 * <p>
 * 动态定时任务 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-12-28
 */
@Service
public class TaskServiceImpl extends ServiceImpl<TaskMapper, TaskEntity> implements TaskService {
	@Autowired
    QuartzManager quartzManager;
	
	@Resource
	TaskMapper taskMapper;
	
	@Override
	public void initSchedule() throws SchedulerException {
		 // 这里获取任务信息数据
        List<TaskEntity> jobList = taskMapper.selectList(new QueryWrapper<TaskEntity>());
        for (TaskEntity task : jobList) {
            if (JobStatusEnum.RUNNING.getCode().equals(task.getJobStatus())) {
                quartzManager.addJob(task);
            }
        }
	}

	@Override
	public void changeStatus(Long jobId, String jobStatus) throws SchedulerException {
	}

	@Override
	public void updateCron(Long jobId) throws SchedulerException {
		
	}

	@Override
	public void run(TaskEntity scheduleJob) throws SchedulerException {
		
	}
	
	
}
