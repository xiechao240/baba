package cn.daliedu.enums;

/**
 * 短信模板枚举类
 * @author xiechao
 * @time 2019年9月27日 下午2:44:36
 * @version 1.0.0 
 * @description
 */
public enum  SmsTemplateCodeEnum {
	/**
	 * 短信模板编码：校验码（您的验证码为：${code}，该验证码2分钟内有效，感谢您的支持！）
	 */
	SMS_175582380("SMS_175582380", "SMS_175582380"), 
	/**
	 * 短信模板编码：课程通知(尊敬的用户，您的账号${name}在大立教育平台的${course}课程已开通,请合理安排时间学习哦)
	 */
	SMS_179155048("SMS_179155048", "SMS_179155048"), 
	/**
	 * 短信模板编码：账号创建(尊敬的用户，您在大立教育的登录账号为${name}，密码为${password}，请不要把密码泄露给其他人)
	 */
	SMS_177548750("SMS_177548750", "SMS_177548750");

	private String value;
	private String desc;

	SmsTemplateCodeEnum(final String value, final String desc) {
		this.value = value;
		this.desc = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
	
	 /**
     * 根据枚举值获取枚举描述
     * @param key
     * @return
     */
    public static String getDesc(String value){
    	String returnStr = "";
        for (SmsTemplateCodeEnum e: SmsTemplateCodeEnum.values()){
            if(e.getValue().equals(value)){
            	returnStr = e.getDesc();
            	break;
            }
        }
		return returnStr;
    }
    
    /**
     * 根据枚举描述获取枚举值
     * @param key
     * @return
     */
    public static String getValue(String desc){
    	String returnStr = "";
        for (SmsTemplateCodeEnum e: SmsTemplateCodeEnum.values()){
            if(e.getDesc().equals(desc)){
            	returnStr = e.getValue();
            	break;
            }
        }
		return returnStr;
    }
    
    /**
     * 判断数值是否属于枚举类的值
     * @param key
     * @return
     */
    public static boolean isInclude(String value){
        boolean include = false;
        for (SmsTemplateCodeEnum e: SmsTemplateCodeEnum.values()){
            if(e.getValue().equals(value)){
                include = true;
                break;
            }
        }
        return include;
    }
}