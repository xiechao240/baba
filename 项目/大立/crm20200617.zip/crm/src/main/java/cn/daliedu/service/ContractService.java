package cn.daliedu.service;

import cn.daliedu.entity.ContractEntity;
import cn.daliedu.entity.json.ContractModel;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 客户合同表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-31
 */
public interface ContractService extends IService<ContractEntity> {
	
	/**
	 * 获取用户的回款金额（目前首页有用到）
	 * @param map
	 * @return
	 */
	public BigDecimal getReturnMoneyByUserId(Map<Object, Object> map) throws Exception;
	
	/**
	 * 获取指定分校的每个员工的合同总金额（目前首页使用）
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getContractAmountCountByBranch(Map<Object, Object> map) throws Exception;
	
	/**
	 * 获取用户创建合同的数量（目前首页有用到）
	 * @param map
	 * @return
	 */
	public BigDecimal getCreateContactCountByUserId(Map<Object, Object> map);
	
	/**
	 * 根据用户ID，获取用户的合同列表（带分页）
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getContractListByUserId(Map<Object, Object> map) throws Exception;
	
	
	
	/**
	 * 获取合同的计划期次列表
	 * @param map
	 */
	public List<LinkedHashMap<Object, Object>> getReturnMoneyNumList(Map<Object, Object> map);
	
	/**
	 * 获取客户合同列表
	 * @param map
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getContractListByCustomerId(Map<Object, Object> map);
	
	/**
	 * 获取客户合同列表总数
	 * @param map
	 * @return
	 */
	public Long getContractListByCustomerIdCount(Map<Object, Object> map);
	
	/**
	 * 根据客户ID，获取客户的合同列表
	 * @param pageNum 页码
	 * @param pageSize 每页的数据量
	 * @param customerId 客户ID
	 * @return
	 */
	public IPage<ContractEntity> getContractListByCustomerId(Integer pageNum, Integer pageSize, String customerId);
	
	/**
	 * 保存客户合同
	 * @param params 前端传递的合同json
	 * @return
	 * @throws Exception
	 */
	public boolean saveContract(String params) throws Exception;
	
	/**
	 * 修改客户合同
	 * @param params 前端传递的合同json
	 * @return
	 * @throws Exception
	 */
	public boolean updateContract(String params) throws Exception;
	
	/**
	 * 修改回款计划期次
	 * @param params 前端传递的合同json
	 * @return
	 * @throws Exception
	 */
	public boolean updateContractReturnMoneyPlan(String params) throws Exception;
	
	
	/**
	 * 保存回款计划
	 * @param params 前端传递的json
	 * @return
	 * @throws Exception
	 */
	public boolean saveContractReturnMoneyPlan(ContractModel model) throws Exception;
	
	
	/**
	 * 保存回款记录
	 * @param params 前端传递的json
	 * @return
	 * @throws Exception
	 */
	public boolean saveContractReturnMoneyRecord(String params) throws Exception;
	
}
