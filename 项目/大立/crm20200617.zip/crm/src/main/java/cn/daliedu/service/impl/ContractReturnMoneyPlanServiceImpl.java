package cn.daliedu.service.impl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.entity.ContractReturnMoneyPlanEntity;
import cn.daliedu.mapper.ContractReturnMoneyPlanMapper;
import cn.daliedu.service.ContractReturnMoneyPlanService;

/**
 * <p>
 * 合同回款计划表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-31
 */
@Service
public class ContractReturnMoneyPlanServiceImpl extends ServiceImpl<ContractReturnMoneyPlanMapper, ContractReturnMoneyPlanEntity> implements ContractReturnMoneyPlanService {
	
	@Resource
	ContractReturnMoneyPlanMapper contractReturnMoneyPlanMapper;
	
	
	
	@Override
	public Integer updateReturnMoneyStateByScheduleTask() {
		return contractReturnMoneyPlanMapper.updateReturnMoneyStateByScheduleTask();
	}

	@Override
	public List<LinkedHashMap<Object, Object>> getContractReturnMoneyPlanList(Map<Object, Object> map) {
		return contractReturnMoneyPlanMapper.getContractReturnMoneyPlanList(map);
	}

	@Override
	public Long getContractReturnMoneyPlanListCount(Map<Object, Object> map) {
		return contractReturnMoneyPlanMapper.getContractReturnMoneyPlanListCount(map);
	}

	@Override
	public ContractReturnMoneyPlanEntity getReturnMoneyPlan(String contractId, Integer returnMoneyNum) {
		return contractReturnMoneyPlanMapper.selectOne(new QueryWrapper<ContractReturnMoneyPlanEntity>()
				.eq("contract_id", contractId).eq("return_money_num", returnMoneyNum).last("limit 1"));
	}

	@Override
	public Integer getReturnMoneyNumMax(String contractId) {
		return contractReturnMoneyPlanMapper.getReturnMoneyNumMax(contractId);
	}
	
	
	@Override
	public List<LinkedHashMap<Object, Object>> getContractReturnMoneyPlanByCustomerIdList(Map<Object, Object> map) {
		return contractReturnMoneyPlanMapper.getContractReturnMoneyPlanByCustomerIdList(map);
	}


	@Override
	public Long getContractReturnMoneyPlanByCustomerIdListCount(Map<Object, Object> map) {
		return contractReturnMoneyPlanMapper.getContractReturnMoneyPlanByCustomerIdListCount(map);
	}
	
	
}
