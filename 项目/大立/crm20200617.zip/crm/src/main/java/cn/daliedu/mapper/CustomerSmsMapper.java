package cn.daliedu.mapper;

import cn.daliedu.entity.CustomerSmsEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 客户发送短信表 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2020-06-16
 */
public interface CustomerSmsMapper extends BaseMapper<CustomerSmsEntity> {

}
