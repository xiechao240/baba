package cn.daliedu.service.impl;

import cn.daliedu.entity.CustomerTagGroupDetailEntity;
import cn.daliedu.entity.CustomerTagGroupEntity;
import cn.daliedu.mapper.CustomerTagGroupDetailMapper;
import cn.daliedu.mapper.CustomerTagGroupMapper;
import cn.daliedu.service.CustomerTagGroupService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import java.time.LocalDateTime;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 客户标签分组表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-24
 */
@Service
public class CustomerTagGroupServiceImpl extends ServiceImpl<CustomerTagGroupMapper, CustomerTagGroupEntity> implements CustomerTagGroupService {
	
	@Resource
	CustomerTagGroupMapper customerTagGroupMapper;
	
	@Resource
	CustomerTagGroupDetailMapper customerTagGroupDetailMapper;
	
	
	
	@Override
	public Integer getMaxCustomerTagValue(String branchOrgId){
		if(branchOrgId.equals("null") || branchOrgId.equals("")){
			return customerTagGroupMapper.getMaxCustomerTagValue();
		}
		return customerTagGroupMapper.getMaxCustomerTagValueByBranchOrgId(branchOrgId);
	}


	@Override
	public boolean restoreCustomerTagGroupByBranchOrgId(String branchOrgId) {
		List<CustomerTagGroupEntity> branchGrouplist = customerTagGroupMapper.selectList(new QueryWrapper<CustomerTagGroupEntity>().eq("branch_org_id", branchOrgId));
		
		if(CollectionUtils.isEmpty(branchGrouplist)){
			//加载系统初始化的客户分组
			List<CustomerTagGroupEntity> list = customerTagGroupMapper.selectList(new QueryWrapper<CustomerTagGroupEntity>().eq("is_init", true));
			if(!CollectionUtils.isEmpty(list)){
				list.stream().forEach(entity -> {
					CustomerTagGroupEntity groupEntity = new CustomerTagGroupEntity();
					groupEntity.setBranchOrgId(branchOrgId);
//					groupEntity.setCustomerTagTypeId(entity.getCustomerTagTypeId());
					groupEntity.setCustomerTagTypeName(entity.getCustomerTagTypeName());
					groupEntity.setRemark(entity.getRemark());
					groupEntity.setOrderNum(entity.getOrderNum());
					groupEntity.setCreateBy(entity.getCreateBy());
					groupEntity.setUpdateBy(entity.getUpdateBy());
					groupEntity.setCreateTime(LocalDateTime.now());
					groupEntity.setUpdateTime(LocalDateTime.now());
					groupEntity.setIsInit(false);
					
					customerTagGroupMapper.insert(groupEntity);
					
					List<CustomerTagGroupDetailEntity> detailList = customerTagGroupDetailMapper.selectList(new QueryWrapper<CustomerTagGroupDetailEntity>().eq("customer_tag_type_id", entity.getCustomerTagTypeId()));
					if(!CollectionUtils.isEmpty(detailList)){
						for(CustomerTagGroupDetailEntity detail : detailList){
							CustomerTagGroupDetailEntity detailEntity = new CustomerTagGroupDetailEntity();
							detailEntity.setCustomerTagTypeId(groupEntity.getCustomerTagTypeId());
							detailEntity.setCustomerTagName(detail.getCustomerTagName());
							detailEntity.setRemark(detail.getRemark());
							detailEntity.setOrderNum(detail.getOrderNum());
							detailEntity.setCreateBy(detail.getCreateBy());
							detailEntity.setUpdateBy(detail.getUpdateBy());
							detailEntity.setCreateTime(LocalDateTime.now());
							detailEntity.setUpdateTime(LocalDateTime.now());
							
							customerTagGroupDetailMapper.insert(detailEntity);
						}
					}
				});
			}
		}
		
		return true;
	}


	@Override
	public List<CustomerTagGroupEntity> findCustomerTagGroupAndTagDetailList(String branchOrgId) {
		if(!StringUtils.isBlank(branchOrgId)){
			//不为空，则加载分校的客户分组
			List<CustomerTagGroupEntity> list = customerTagGroupMapper.selectList(new QueryWrapper<CustomerTagGroupEntity>().eq("branch_org_id", branchOrgId).orderByAsc("order_num"));
			if(!CollectionUtils.isEmpty(list)){
				list.stream().forEach(entity -> {
					List<CustomerTagGroupDetailEntity> detailList = customerTagGroupDetailMapper.
							selectList(new QueryWrapper<CustomerTagGroupDetailEntity>().
									eq("customer_tag_type_id", entity.getCustomerTagTypeId()).orderByAsc("order_num"));
					if(!CollectionUtils.isEmpty(detailList)){
						entity.setCustomerTagGroupDetailList(detailList);
					}
				});
				return list;
			}
		}else{
			//加载系统初始化的客户分组
			List<CustomerTagGroupEntity> list = customerTagGroupMapper.selectList(new QueryWrapper<CustomerTagGroupEntity>().eq("is_init", true));
			if(!CollectionUtils.isEmpty(list)){
				list.stream().forEach(entity -> {
					List<CustomerTagGroupDetailEntity> detailList = customerTagGroupDetailMapper.selectList(new QueryWrapper<CustomerTagGroupDetailEntity>().eq("customer_tag_type_id", entity.getCustomerTagTypeId()));
					if(!CollectionUtils.isEmpty(detailList)){
						entity.setCustomerTagGroupDetailList(detailList);
					}
				});
				return list;
			}
		}
		
		return null;
	}


	@Override
	public List<CustomerTagGroupEntity> findCustomerTagGroupList(String branchOrgId) {
		if(!StringUtils.isBlank(branchOrgId)){
			//不为空，则加载分校的客户分组
			return customerTagGroupMapper.selectList(new QueryWrapper<CustomerTagGroupEntity>().eq("branch_org_id", branchOrgId).orderByAsc("order_num"));
		}else{
			//加载系统初始化的客户分组
			return customerTagGroupMapper.selectList(new QueryWrapper<CustomerTagGroupEntity>().eq("is_init", true).orderByAsc("order_num"));
		}
	}


	@Override
	public boolean existsCustomerTagTypeName(String customerTagTypeName) {
		List<CustomerTagGroupEntity> list = customerTagGroupMapper.selectList(new QueryWrapper<CustomerTagGroupEntity>().eq("customer_tag_type_name", customerTagTypeName));
		if(list!=null && list.size()>0){
			return true;
		}
		return false;
	}


	@Override
	public boolean removeCustomerTagGroup(Integer customerTagTypeId) throws Exception{
		customerTagGroupMapper.deleteById(customerTagTypeId);
		customerTagGroupDetailMapper.delete(new QueryWrapper<CustomerTagGroupDetailEntity>().eq("customer_tag_type_id", customerTagTypeId));
		return true;
	}
	
	
	
	
	
}
