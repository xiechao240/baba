package cn.daliedu.mapper;

import cn.daliedu.entity.CustomerFlowCauseConfigEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 客户流转原因配置表 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-10-15
 */
public interface CustomerFlowCauseConfigMapper extends BaseMapper<CustomerFlowCauseConfigEntity> {

}
