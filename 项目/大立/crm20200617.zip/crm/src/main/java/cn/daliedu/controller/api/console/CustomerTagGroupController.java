package cn.daliedu.controller.api.console;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.CustomerTagGroupDetailEntity;
import cn.daliedu.entity.CustomerTagGroupEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.json.CustomerJson;
import cn.daliedu.entity.json.CustomerTagGroupJson;
import cn.daliedu.entity.json.OrgJson;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.mapper.CustomerTagGroupMapper;
import cn.daliedu.service.CustomerTagGroupDetailService;
import cn.daliedu.service.CustomerTagGroupService;
import cn.daliedu.service.CustomerTagService;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 客户标签分组表 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2019-10-24
 */
@Api(description = "客户标签分组接口")
@RestController
@RequestMapping("${rest.path}/console/customerTagGroup")
public class CustomerTagGroupController {
	
	@Autowired
	CustomerTagService customerTagService;
	
	@Autowired
	CustomerTagGroupService customerTagGroupService;
	
	@Autowired
	CustomerTagGroupDetailService customerTagGroupDetailService;
	
	
	@ApiOperation(value = "为指定分校，还原为系统客户分组，如果分校已经存在客户分组，则不还原，否则做还原操作")
	@ApiImplicitParam(paramType = "query", dataType = "String", name = "branchOrgId", value = "分校ID", required = true)
	@PostMapping("/restoreCustomerTagGroupByBranchOrgId")
	public Result restoreCustomerTagGroupByBranchOrgId(@RequestParam(name="branchOrgId",required=true)String branchOrgId) {
		try {
			boolean flag = customerTagGroupService.restoreCustomerTagGroupByBranchOrgId(branchOrgId);
			if(flag){
				return Result.success("");
			}
			return Result.error("暂无数据");
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取标签分组集合接口失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "获取客户标签分组集合接口,如果不传分校ID，则获取的是系统初始化的标签分组")
	@ApiImplicitParam(paramType = "query", dataType = "String", name = "branchOrgId", value = "分校ID", required = false)
	@PostMapping("/findCustomerTagGroupList")
	public Result findCustomerTagGroupList(@RequestParam(name="branchOrgId",defaultValue="")String branchOrgId) {
		try {
			List<CustomerTagGroupEntity> list = customerTagGroupService.findCustomerTagGroupList(branchOrgId);
			if(!CollectionUtils.isEmpty(list)){
				return Result.success(list);
			}
			return Result.error("暂无数据");
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取标签分组集合接口失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "获取客户标签分组及【标签明细】接口,如果不传分校ID，则获取的是系统初始化的标签及明细数据")
	@ApiImplicitParam(paramType = "query", dataType = "String", name = "branchOrgId", value = "分校ID", required = false)
	@PostMapping("/findCustomerTagGroupAndTagDetailList")
	public Result findCustomerTagGroupAndTagDetailList(@RequestParam(name="branchOrgId",defaultValue="")String branchOrgId) {
		try {
			List<CustomerTagGroupEntity> list = customerTagGroupService.findCustomerTagGroupAndTagDetailList(branchOrgId);
			if(!CollectionUtils.isEmpty(list)){
				return Result.success(list);
			}
			return Result.error("当前无客户标签数据");
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户标签分组及【标签明细】失败，失败原因：" + e.getMessage());
		}
	}

	@ApiOperation(value = "新增客户标签分组接口")
	@ApiJsonObject(name = "saveCustomerTagGroup", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerTagGroupJson.customerTagTypeName)})
	@ApiImplicitParam(name = "params", required = true, dataType = "saveCustomerTagGroup")
	@PostMapping("/saveCustomerTagGroup")
	public Result saveCustomerTagGroup(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
			String customerTagTypeName = String.valueOf(jsonObject.get("customerTagTypeName"));
			
			StringUtil.validateIsNull(customerTagTypeName, "请输入客户标签分组名称");
			
			branchOrgId = branchOrgId.trim();
			customerTagTypeName = customerTagTypeName.trim();
			
			if(customerTagGroupService.existsCustomerTagTypeName(customerTagTypeName)){
				return Result.error("此客户标签分组已经存在，请重新输入");
			}else{
				//保存客户标签分组
				CustomerTagGroupEntity entity = new CustomerTagGroupEntity();
				entity.setBranchOrgId(branchOrgId);
				entity.setCreateTime(LocalDateTime.now());
				entity.setCustomerTagTypeName(customerTagTypeName);
				Integer orderNum = customerTagGroupService.getMaxCustomerTagValue(branchOrgId);
				entity.setOrderNum(orderNum==null ? 0 : orderNum+1);
				
				if(branchOrgId.equals("null") || branchOrgId.equals("")){
					entity.setIsInit(true);
				}else{
					entity.setIsInit(false);
				}
				
				Object object = SecurityUtils.getSubject().getPrincipal();
				UserEntity user = null;
				if (object instanceof UserEntity) {
					user = (UserEntity) object;
					entity.setCreateBy(user.getId());
				}
				
				boolean flag = customerTagGroupService.save(entity);
				if(flag){
					return Result.success("新增成功！");
				}
				return Result.error("新增失败");
			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("新增客户标签分组失败，失败原因：" + e.getMessage());
		}
	}

	@ApiOperation(value = "修改客户标签分组接口")
	@ApiJsonObject(name = "updateCustomerTagGroup", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerTagGroupJson.customerTagTypeId),
			@ApiJsonProperty(name = CustomerTagGroupJson.customerTagTypeName),
			@ApiJsonProperty(name = OrgJson.orderNum)})
	@ApiImplicitParam(name = "params", required = true, dataType = "updateCustomerTagGroup")
	@PostMapping("/updateCustomerTagGroup")
	public Result updateCustomerTagGroup(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String customerTagTypeId = String.valueOf(jsonObject.get("customerTagTypeId"));
			String customerTagTypeName = String.valueOf(jsonObject.get("customerTagTypeName"));
			String orderNum = String.valueOf(jsonObject.get("orderNum"));
			
			StringUtil.validateIsNull(customerTagTypeId, "请输入客户标签分组类型ID");
			StringUtil.validateIsNull(customerTagTypeName, "请输入客户标签分组类型名称");
			StringUtil.validateIsNull(orderNum, "请输入排序号");
			
			customerTagTypeId  = customerTagTypeId.trim();
			customerTagTypeName = customerTagTypeName.trim();
			orderNum = orderNum.trim();
			
			//不能存在同名的标签分组
//			if(customerTagGroupService.existsCustomerTagTypeName(customerTagTypeName)){
//				return Result.error("此客户标签分组已经存在，请重新输入");
//			}else{
				//修改客户标签分组
				CustomerTagGroupEntity entity = new CustomerTagGroupEntity();
				entity.setCustomerTagTypeId(Integer.parseInt(customerTagTypeId));
				entity.setUpdateTime(LocalDateTime.now());
				entity.setCustomerTagTypeName(customerTagTypeName);
				entity.setOrderNum(Integer.parseInt(orderNum));
				
				Object object = SecurityUtils.getSubject().getPrincipal();
				UserEntity user = null;
				if (object instanceof UserEntity) {
					user = (UserEntity) object;
					entity.setUpdateBy(user.getId());
				}
				
				boolean flag = customerTagGroupService.updateById(entity);
				if(flag){
					return Result.success("修改成功！");
				}
				return Result.error("修改失败");
//			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("修改客户标签分组失败，失败原因：" + e.getMessage());
		}
	}

	@ApiOperation(value = "删除分组标签接口(如果已经被客户使用，则不允许删除),此标签只能一个一个删除，不能批量删除，因为要判断标签是否被使用")
	@ApiJsonObject(name = "deleteCustomerTagGroupById", value = { 
			@ApiJsonProperty(name = CustomerTagGroupJson.customerTagTypeId) })
	@ApiImplicitParam(name = "params", required = true, dataType = "deleteCustomerTagGroupById")
	@PostMapping("/deleteCustomerTagGroupById")
	public Result deleteCustomerTagGroupById(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String customerTagTypeId = String.valueOf(jsonObject.get("customerTagTypeId"));
			
			StringUtil.validateIsNull(customerTagTypeId, "请输入客户标签分组类型ID");
			
			customerTagTypeId = customerTagTypeId.trim();
			
			if(customerTagService.existsCustomerTagTypeIdUse(customerTagTypeId)){
				return Result.error("此标签已经被使用，不能删除");
			}else{
				boolean flag = customerTagGroupService.removeCustomerTagGroup(Integer.parseInt(customerTagTypeId));
				if(flag){
					return Result.success("删除成功！");
				}
				return Result.error("删除失败");
			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("删除分组标签失败，失败原因：" + e.getMessage());
		}
	}
}
