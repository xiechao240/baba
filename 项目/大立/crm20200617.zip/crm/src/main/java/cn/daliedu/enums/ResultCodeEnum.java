package cn.daliedu.enums;


/**
 * 系统返回结果枚举类
 * @author xiechao
 * @time 2019年2月19日 下午5:14:23
 * @version 1.0.0 
 * @description
 */
public enum ResultCodeEnum {
	/**
	 * 成功
	 */
	SUCCESS(0, "OK"),
	/**
	 * 失败
	 */
	ERROR(99999, "ERROR"), 
	
	
	/**
	 * 请重新登入
	 */
	USER_RE_LOGIN(10001, "请重新登入"),
	/**
	 * 该用户已登录
	 */
	USER_LOGINED_IN(10002, "该用户已登录"),
	/**
	 * 登录异常
	 */
	USER_LOGIN_ERROR(10003, "登录异常"),
	/**
	 * 用户验证失败
	 */
	USER_VERIFY_ERROR(10004, "用户验证失败"),
	/**
	 * 该用户已被锁定
	 */
	USER_FROZEN(10005, "该用户已被禁用"),
	/**
	 * 该用户不存在或密码错误
	 */
	USER_NOT_EXIST_USER_OR_ERROR_PWD(10006, "该用户不存在或密码错误"),
	/**
	 * 您没有该权限
	 */
	USER_NOT_AUTH(10007, "您没有该权限"),
	/**
	 * 请绑定手机号
	 */
	USER_NOT_BIND_PHONE(10008, "请绑定手机号"),
	/**
	 * 登录超时，请重新登录
	 */
	USER_SESSION_TIME_OUT(10009, "登录超时，请重新登录"),
	
	/**
	 * 您还未登录，请登录
	 */
	USER_NO_LOGIN(10010, "您还未登录，请登录"),
	
	
	/**
	 * 上传文件异常
	 */
	FILE_UPLOAD_ERROR(20000, "上传文件异常"),
	/**
	 * 文件数据有误
	 */
	FILE_DATA_ERROR(20001, "文件数据有误,请查看导入错误历史"),
	/**
	 * 校验错误
	 */
	VALID_ERROR(30000, "校验错误"), 
	/**
	 * 无效的验证码
	 */
	INVALID_CAPTCHA(30001, "无效的验证码"),
   
	
    /**
     * 参数解析失败
     */
	NET_WORK_400_BAD_REQUEST(400, "参数解析失败"),
	/**
	 * 无效的授权码
	 */
	NET_WORK_401_INVALID_TOKEN(401, "无效的授权码"),
	/**
	 * 无效的密钥
	 */
	NET_WORK_402_INVALID_CLIENTID(402, "无效的密钥"),
	/**
	 * 不支持当前请求方法
	 */
	NET_WORK_405_METHOD_NOT_ALLOWED(405, "不支持当前请求方法"),
	/**
	 * 服务器运行异常
	 */
	NET_WORK_500_SYSTEM_ERR(500, "服务器运行异常");


    private Integer code;
    private String msg;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    private ResultCodeEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }
}
