package cn.daliedu.config.bak;
//package com.esa2000.config.bak;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import io.swagger.annotations.Api;
//
//import springfox.documentation.builders.ApiInfoBuilder;
//import springfox.documentation.builders.ParameterBuilder;
//import springfox.documentation.builders.PathSelectors;
//import springfox.documentation.builders.RequestHandlerSelectors;
//import springfox.documentation.schema.ModelRef;
//import springfox.documentation.service.ApiInfo;
//import springfox.documentation.service.ApiKey;
//import springfox.documentation.service.AuthorizationScope;
//import springfox.documentation.service.Parameter;
//import springfox.documentation.service.SecurityReference;
//import springfox.documentation.spi.DocumentationType;
//import springfox.documentation.spi.service.contexts.SecurityContext;
//import springfox.documentation.spring.web.plugins.Docket;
//
//
///**
// * 
// * @author xiechao
// * @time 2019年1月7日 下午5:08:23
// * @version 1.0.0 
// * @description  此类为Swagger2Config的备份类，注掉Swagger2Config类，往springboot中注入此类，
// * 则可以在swagger展现接口页面的右上角输入全局token
// */
////@Configuration
//public class Swagger2ConfigBak {
//	
//	@Bean
//	public Docket createRestApi() {
//		return new Docket(DocumentationType.SWAGGER_2)
////				.apiInfo(apiInfo())
////				.select()
////				//配置扫描发布接口的类
////				.apis(RequestHandlerSelectors.basePackage("com.esa2000.controller.api"))
//////				.paths(PathSelectors.any())
////				.paths(PathSelectors.regex("^(?!api).*$"))
//////	            .paths(PathSelectors.regex(restPath + "/.*"))// 设置拦截路径
//////	             .paths(PathSelectors.regex("/platform/.*"))// 设置拦截路径
////				.build()
////				.useDefaultResponseMessages(false);
//				
//				
//				.useDefaultResponseMessages(false)
//                .select()
//                .apis(RequestHandlerSelectors.basePackage("com.esa2000.controller.api"))
//                .paths(PathSelectors.regex("^(?!api).*$"))
//                .build()
//                .securitySchemes(securitySchemes())
//                .securityContexts(securityContexts())
//                ;
//	}
//	
//	private List<ApiKey> securitySchemes() {
//		ApiKey apiKey = new ApiKey("Authorization", "Authorization", "header");
//		List<ApiKey> list = new ArrayList<ApiKey>();
//		list.add(apiKey);
//		return list;
//	}
//
//	private List<SecurityContext> securityContexts() {
//		List<SecurityContext> list = new ArrayList<SecurityContext>();
//		list.add(SecurityContext.builder().securityReferences(defaultAuth())
//				.forPaths(PathSelectors.regex("^(?!api).*$")).build());
//		return list;
//	}
//
//	private List<SecurityReference> defaultAuth() {
//		AuthorizationScope authorizationScope = new AuthorizationScope("global", "accessEverything");
//		AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
//		authorizationScopes[0] = authorizationScope;
//
//		SecurityReference reference = new SecurityReference("Authorization", authorizationScopes);
//
//		List<SecurityReference> list = new ArrayList<SecurityReference>();
//		list.add(reference);
//		return list;
//	}
//	
//	/**
//	 * 创建api页面展现首页基础信息
//	 * @return
//	 */
//	private ApiInfo apiInfo() {
//		return new ApiInfoBuilder()
//				.title("接口测试")
//	            .description("测试系统 Restful API")
//				.termsOfServiceUrl("http://blog.csdn.net/saytime")
////				.contact(new Contact("xiechao", "https://www.cnblogs.com/", "543043491@qq.com"))
//				.version("1.0")
//				.build();
//	}
//
//
//}
