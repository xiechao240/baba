package cn.daliedu.service;

import org.quartz.SchedulerException;

import com.baomidou.mybatisplus.extension.service.IService;

import cn.daliedu.entity.TaskEntity;

/**
 * <p>
 * 动态定时任务 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-12-28
 */
public interface TaskService extends IService<TaskEntity> {
	
	public void initSchedule() throws SchedulerException;

    public void changeStatus(Long jobId, String jobStatus) throws SchedulerException;

    public void updateCron(Long jobId) throws SchedulerException;
    
    public void run(TaskEntity scheduleJob) throws SchedulerException;
    
}
