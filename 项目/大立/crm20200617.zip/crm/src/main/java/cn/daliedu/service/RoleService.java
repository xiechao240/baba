package cn.daliedu.service;

import cn.daliedu.entity.RoleEntity;

import java.util.List;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 角色管理 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
public interface RoleService extends IService<RoleEntity> {
	
	/**
	 * 根据角色ID复制角色
	 * @param entity 需要复制的角色对象
	 * @param newRoleName 新的角色名称
	 * @return
	 */
	public boolean copyRole(RoleEntity entity, String newRoleName);
	
	/**
	 * 根据角色名称查询角色
	 * @param roleName
	 * @return
	 */
	public List<RoleEntity> getRoleListByRoleName(String roleName);
	
	/**
	 * 分页获取所有角色集合
	 * @param pageNum 页码
	 * @param pageSize 每页的记录数
	 * @param name  角色名称
	 * @return
	 */
	public IPage<RoleEntity> getPageRoleList(int pageNum, int pageSize, String name);
	
	/**
	 * 获取所有角色列表，新增用户时获取角色列表，如果当前登录的用户为超级管理员，则可以添加普通管理员，普通用户，代理商用户，如果是普通管理员，则可以添加普通用户，代理商用户，如果是普通用户，则提示出错
	 * @return
	 */
	public List<RoleEntity> getRoleListByAddUser() throws Exception;
	
	
	/**
	 * 根据用户ID获取用户的所有角色集合，如果不需要分布的结果，则后面的两个参数传null即可
	 * @param userId
	 * @return
	 */
	public List<RoleEntity> getUserRoleList(String userId, Integer pageNum, Integer pageSize);
	
	
	/**
	 * 根据用户ID查询用户对应的角色ID集合,如果不需要分页的结果，则后面的两个参数传null即可
	 * @param userId 用户id
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */
	public List<Integer> getUserRoleIdsByUserId(String userId, Integer pageNum, Integer pageSize);
	
	public boolean saveRole(RoleEntity roleEntity) throws Exception;
}
