//package cn.daliedu.util;
//
//import cn.daliedu.exception.BusinessException;
//import jxl.Sheet;
//import jxl.format.Alignment;
//import jxl.format.Border;
//import jxl.format.BorderLineStyle;
//import jxl.format.Colour;
//import jxl.format.UnderlineStyle;
//import jxl.format.VerticalAlignment;
//import jxl.write.Label;
//import jxl.write.NumberFormats;
//import jxl.write.WritableCellFormat;
//import jxl.write.WritableFont;
//import jxl.write.WriteException;
//
///**
// * jxl框架工具类(jxl不支持xlsx格式的文件，所以以后基本要废掉，全部改为poi来解析)
// * @author xiechao
// * @time 2019年10月22日 下午3:15:28
// * @version 1.0.0 
// * @description
// */
//public class JxlUtil {
//	/**
//	 * 表头单元格样式的设定
//	 */
//	public static WritableCellFormat getHeaderCellStyle() {
//		/*
//		 * WritableFont.createFont("宋体")：设置字体为宋体 10：设置字体大小
//		 * WritableFont.BOLD:设置字体加粗（BOLD：加粗 NO_BOLD：不加粗） false：设置非斜体
//		 * UnderlineStyle.NO_UNDERLINE：没有下划线
//		 */
//		WritableFont font = new WritableFont(WritableFont.createFont("宋体"), 12,
//				WritableFont.BOLD, false, UnderlineStyle.NO_UNDERLINE);
//
//		WritableCellFormat headerFormat = new WritableCellFormat(
//				NumberFormats.TEXT);
//		try {
//			// 添加字体设置
//			headerFormat.setFont(font);
//			// 设置单元格背景色：表头为黄色
//			headerFormat.setBackground(Colour.YELLOW);
//			// 设置表头表格边框样式
//			// 整个表格线为粗线、黑色
//			headerFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK); //.THICK
//			// 表头内容水平居中显示
//			headerFormat.setAlignment(Alignment.CENTRE); //设置水平对齐
//			headerFormat.setVerticalAlignment(VerticalAlignment.CENTRE); //设置上下对齐
//		} catch (WriteException e) {
//			System.out.println("表头单元格样式设置失败！");
//		}
//		return headerFormat;
//	}
//
//	/**
//	 * 单元格样式的设定
//	 */
//	public static WritableCellFormat getBodyCellStyle() {
//		/*
//		 * WritableFont.createFont("宋体")：设置字体为宋体 10：设置字体大小
//		 * WritableFont.NO_BOLD:设置字体非加粗（BOLD：加粗 NO_BOLD：不加粗） false：设置非斜体
//		 * UnderlineStyle.NO_UNDERLINE：没有下划线
//		 */
//		WritableFont font = new WritableFont(WritableFont.createFont("宋体"), 10,
//				WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE);
//
//		WritableCellFormat bodyFormat = new WritableCellFormat(font);
//		try {
//			// 设置单元格背景色：表体为白色
//			bodyFormat.setBackground(Colour.WHITE);
//			// 设置表头表格边框样式
//			// 整个表格线为细线、黑色
//			bodyFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
//			bodyFormat.setAlignment(Alignment.CENTRE); //设置水平对齐
//			bodyFormat.setVerticalAlignment(VerticalAlignment.CENTRE); //设置上下对齐
//
//		} catch (WriteException e) {
//			System.out.println("表体单元格样式设置失败！");
//		}
//		return bodyFormat;
//	}
//	
//	public static void validateCell(Sheet customerSheet) throws BusinessException{
//		//需要注意的是这里的getCell方法的参数，第一个是指定第几列，第二个参数才是指定第几行
//		String name = customerSheet.getCell(0, 0).getContents().trim();//姓名
//		if(!name.equals("姓名")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String sex = customerSheet.getCell(1, 0).getContents().trim();//性别
//		if(!sex.equals("性别")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String customerSourceType = customerSheet.getCell(2, 0).getContents().trim();//来源
//		if(!customerSourceType.equals("来源")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String weixinId = customerSheet.getCell(3, 0).getContents().trim();//微信
//		if(!weixinId.equals("微信")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String qq = customerSheet.getCell(4, 0).getContents().trim();//QQ
//		if(!qq.equals("QQ")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String mobile = customerSheet.getCell(5, 0).getContents().trim();//手机	
//		if(!mobile.equals("手机")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String phone = customerSheet.getCell(6, 0).getContents().trim();//座机
//		if(!phone.equals("座机")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String email = customerSheet.getCell(7, 0).getContents().trim();//邮箱	
//		if(!email.equals("邮箱")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String guojia = customerSheet.getCell(8, 0).getContents().trim();//地区：国家	
//		if(!guojia.equals("地区：国家")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String provinceName = customerSheet.getCell(9, 0).getContents().trim();//地区：省/州	
//		if(!provinceName.equals("地区：省/州")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String cityName = customerSheet.getCell(10, 0).getContents().trim();//地区：城市	
//		if(!cityName.equals("地区：城市")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String areaName = customerSheet.getCell(11, 0).getContents().trim();//地区：区/县
//		if(!areaName.equals("地区：区/县")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String companyName = customerSheet.getCell(12, 0).getContents().trim();//公司
//		if(!companyName.equals("公司")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String address = customerSheet.getCell(13, 0).getContents().trim();//地址
//		if(!address.equals("地址")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String remark = customerSheet.getCell(14, 0).getContents().trim();//备注	
//		if(!remark.equals("备注")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String jobAge = customerSheet.getCell(15, 0).getContents().trim();//工作年限(需要判断是否为数字，如果不为数字，就不入库)
//		if(!jobAge.equals("工作年限")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String education =  customerSheet.getCell(16, 0).getContents().trim();//学历	
//		if(!education.equals("姓名")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String customerActivityPage = customerSheet.getCell(17, 0).getContents().trim();//填写表单页面
//		if(!customerActivityPage.equals("填写表单页面")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String professional = customerSheet.getCell(18, 0).getContents().trim();//专业	
//		if(!professional.equals("专业")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String customerActivityTypePage = customerSheet.getCell(19, 0).getContents().trim();//分类
//		if(!customerActivityTypePage.equals("分类")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String danban = customerSheet.getCell(20, 0).getContents().trim();//单班	
//		if(!danban.equals("单班")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String taoban = customerSheet.getCell(21, 0).getContents().trim();//套班	
//		if(!taoban.equals("套班")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String neixun = customerSheet.getCell(22, 0).getContents().trim();//内训	
//		if(!neixun.equals("内训")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String yijiankemu = customerSheet.getCell(23, 0).getContents().trim();//一建科目	
//		if(!yijiankemu.equals("一建科目")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String erjiankemu = customerSheet.getCell(24, 0).getContents().trim();//二建科目	
//		if(!erjiankemu.equals("二建科目")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String zaojiakemu = customerSheet.getCell(25, 0).getContents().trim();//造价科目	
//		if(!zaojiakemu.equals("造价科目")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String jianlikemu = customerSheet.getCell(26, 0).getContents().trim();//监理科目	
//		if(!jianlikemu.equals("监理科目")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String xiaofangkumu = customerSheet.getCell(27, 0).getContents().trim();//消防科目	
//		if(!xiaofangkumu.equals("消防科目")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String zixungongchengshi = customerSheet.getCell(28, 0).getContents().trim();//咨询工程师	
//		if(!zixungongchengshi.equals("咨询工程师")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String yibaotonghang = customerSheet.getCell(29, 0).getContents().trim();//已报同行	
//		if(!yibaotonghang.equals("已报同行")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String remark2 = customerSheet.getCell(30, 0).getContents().trim();//备注2	
//		if(!remark2.equals("备注2")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String yijiankemu2 = customerSheet.getCell(31, 0).getContents().trim();//一建科目2	
//		if(!yijiankemu2.equals("一建科目2")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
//		
//		String banxingmingcheng2 = customerSheet.getCell(32, 0).getContents().trim();//班型名称2	
//		if(!banxingmingcheng2.equals("班型名称2")){
//			throw new BusinessException("上传的客户数据模板有问题，请检查文件");
//		}
////		customerSheet.getCell(33, 0).getContents();//优惠券	
//		
//		
//
//		
//		
//	}
//	
//	
//	
////	/**
////	 * 表头单元格样式的设定
////	 */
////	public static WritableCellFormat getHeaderCellStyle() {
////		/*
////		 * WritableFont.createFont("宋体")：设置字体为宋体 10：设置字体大小
////		 * WritableFont.BOLD:设置字体加粗（BOLD：加粗 NO_BOLD：不加粗） false：设置非斜体
////		 * UnderlineStyle.NO_UNDERLINE：没有下划线
////		 */
////		WritableFont font = new WritableFont(WritableFont.createFont("宋体"), 12,
////				WritableFont.BOLD, false, UnderlineStyle.NO_UNDERLINE);
////
////		WritableCellFormat headerFormat = new WritableCellFormat(
////				NumberFormats.TEXT);
////		try {
////			// 添加字体设置
////			headerFormat.setFont(font);
////			// 设置单元格背景色：表头为黄色
////			headerFormat.setBackground(Colour.YELLOW);
////			// 设置表头表格边框样式
////			// 整个表格线为粗线、黑色
////			headerFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK); //.THICK
////			// 表头内容水平居中显示
////			headerFormat.setAlignment(Alignment.CENTRE); //设置水平对齐
////			headerFormat.setVerticalAlignment(VerticalAlignment.CENTRE); //设置上下对齐
////		} catch (WriteException e) {
////			System.out.println("表头单元格样式设置失败！");
////		}
////		return headerFormat;
////	}
////
////	/**
////	 * 单元格样式的设定
////	 */
////	public static WritableCellFormat getBodyCellStyle() {
////		/*
////		 * WritableFont.createFont("宋体")：设置字体为宋体 10：设置字体大小
////		 * WritableFont.NO_BOLD:设置字体非加粗（BOLD：加粗 NO_BOLD：不加粗） false：设置非斜体
////		 * UnderlineStyle.NO_UNDERLINE：没有下划线
////		 */
////		WritableFont font = new WritableFont(WritableFont.createFont("宋体"), 10,
////				WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE);
////
////		WritableCellFormat bodyFormat = new WritableCellFormat(font);
////		try {
////			// 设置单元格背景色：表体为白色
////			bodyFormat.setBackground(Colour.WHITE);
////			// 设置表头表格边框样式
////			// 整个表格线为细线、黑色
////			bodyFormat.setBorder(Border.ALL, BorderLineStyle.THIN, Colour.BLACK);
////			bodyFormat.setAlignment(Alignment.CENTRE); //设置水平对齐
////			bodyFormat.setVerticalAlignment(VerticalAlignment.CENTRE); //设置上下对齐
////
////		} catch (WriteException e) {
////			System.out.println("表体单元格样式设置失败！");
////		}
////		return bodyFormat;
////	}
//}
