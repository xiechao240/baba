package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import io.swagger.annotations.ApiModelProperty;

import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import java.util.List;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 菜单表
 * </p>
 *
 * @author xiechao
 * @since 2019-09-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("sys_menu")
public class MenuEntity extends Model<MenuEntity> {

    private static final long serialVersionUID = 1L;
    
    // 上级菜单名称（ 非数据库字段）
    @TableField(exist = false)
    private String parentName;
    
    // 下级菜单（ 非数据库字段）
    @TableField(exist = false)
    private List<MenuEntity> children;
    
    // 菜单层级（ 非数据库字段）
    @TableField(exist = false)
    private Integer level;

    /**
     * 菜单ID
     */
    @TableId(value = "id", type = IdType.UUID)
    @ApiModelProperty(value="菜单ID")
    private Integer id;

    /**
     * 上级菜单ID，一级菜单为0
     */
    @ApiModelProperty(value="上级菜单ID，一级菜单为0")
    private Integer parentId;

    /**
     * 菜单ID全路径
     */
    @ApiModelProperty(value="菜单ID全路径")
    private String parentIds;

    /**
     * 菜单名称
     */
    @ApiModelProperty(value="菜单名称")
    private String name;

    /**
     * 访问链接路径
     */
    @ApiModelProperty(value="访问链接路径")
    private String url;

    /**
     * 菜单类型   0：目录   1：菜单   2：按钮
     */
    @ApiModelProperty(value="菜单类型   0：目录   1：菜单   2：按钮")
    private String type;

    /**
     * 菜单权限标识符，授权(多个用逗号分隔，如：sys:user:add,sys:user:edit)
     */
    @ApiModelProperty(value="菜单权限标识符")
    private String permission;

    /**
     * 是否显示此菜单，0：不显示，1：显示
     */
    @ApiModelProperty(value="是否显示此菜单，0：不显示，1：显示")
    private String isShow;

    /**
     * 菜单排序号
     */
    @ApiModelProperty(value="菜单排序号")
    private Integer orderNum;

    /**
     * 菜单图标
     */
    @ApiModelProperty(value="菜单图标")
    private String icon;

    /**
     * 创建人ID
     */
    @ApiModelProperty(value="创建人ID")
    private Integer createrId;

    /**
     * 创建人名称
     */
    @ApiModelProperty(value="创建人名称")
    private String createrName;

    /**
     * 创建时间
     */
    @ApiModelProperty(value="创建时间")
    private LocalDateTime createTime;

    /**
     * 修改人ID
     */
    @ApiModelProperty(value="修改人ID")
    private Integer updaterId;

    /**
     * 修改人名称
     */
    @ApiModelProperty(value="修改人名称")
    private String updaterName;

    /**
     * 修改时间
     */
    @ApiModelProperty(value="修改时间")
    private LocalDateTime updateTime;

    /**
     * 描述
     */
    @ApiModelProperty(value="描述")
    private String remark;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
