package cn.daliedu.entity.json;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 客户流转操作配置表
 * </p>
 *
 * @author xiechao
 * @since 2019-10-15
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class CustomerFlowOperationConfigJson{

    /**
     * 操作类型，1：删除客户，2：转让客户，3：放弃客户
     */
    @ApiModelProperty(value="操作类型，1：删除客户，2：转让客户，3：放弃客户")
    private String[] operationType;

    /**
     * 操作原因ID
     */
    @ApiModelProperty(value="操作原因ID")
    private Integer operationCauseId;

    /**
     * 操作原因标题
     */
    @ApiModelProperty(value="操作原因")
    private String operationCause;


}
