package cn.daliedu.controller.api.console;


import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.DictEntity;
import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.UserOrgEntity;
import cn.daliedu.entity.UserRoleEntity;
import cn.daliedu.entity.json.DictJson;
import cn.daliedu.entity.json.UserJson;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.DictService;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 数据字典表，存储系统中静态的或少量变动的格式化数据 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2019-09-21
 */
@Api(description = "数据字典相关接口")
@RestController
@RequestMapping("${rest.path}/console/dict")
public class DictController {
	@Autowired
	DictService dictService;
	
	@ApiOperation(value = "获取所有的数据字典类型")
	@PostMapping("/getDictTypeList")
	public Result getDictTypeList() throws Exception {
		List<LinkedHashMap<String, String>> dictList = dictService.getDictType();
		return Result.success(dictList);
	}
	
	
	
	@ApiOperation(value = "根据数据字典名称获取数据字典集合")
	@ApiImplicitParam(paramType = "query", dataType = "String", name = "tag", value = "数据标签名称", required = true)
	@PostMapping("/getDictValueByType")
	public Result getDictValueByType(@RequestParam String tag) throws Exception {
		if (tag == null || tag.trim().length()<=0) {
			return Result.error("数据类型为空");
		}
		
		List<DictEntity> dictList = dictService.getDictValueByType(tag);
		return Result.success(dictList);
	}
	
//	@ApiOperation(value = "获取标签分组集合接口")
//	@ApiJsonObject(name = "findDictListByIsCustomerTag", value = { 
//			@ApiJsonProperty(name = DictJson.isCustomerTag)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "findDictListByIsCustomerTag")
//	@PostMapping("/findDictListByIsCustomerTag")
//	public Result findDictListByIsCustomerTag(@RequestBody String params) {
//		try{
//			System.out.println("params参数为：" + params);
//			JSONObject jsonObject = JSON.parseObject(params);
//			String isCustomerTag = String.valueOf(jsonObject.get("isCustomerTag"));
//			StringUtil.validateIsNull(isCustomerTag, "请默认传入分组标签类型，1：客户标签，0:非客户标签");
//			List<DictEntity> list = this.dictService.findDictListByIsCustomerTag(isCustomerTag);
//			return Result.success(list);
//		} catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("获取标签分组集合接口失败，失败原因：" + e.getMessage());
//		}
//	}
//	
//	@ApiOperation(value = "获取标签集合接口")
//	@ApiJsonObject(name = "findDictListByTag", value = { 
//			@ApiJsonProperty(name = DictJson.tag)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "findDictListByTag")
//	@PostMapping("/findDictListByTag")
//	public Result findDictListByTag(@RequestBody String params) {
//		try{
//			System.out.println("params参数为：" + params);
//			JSONObject jsonObject = JSON.parseObject(params);
//			String tag = String.valueOf(jsonObject.get("tag"));
//			StringUtil.validateIsNull(tag, "请输入查询的标签");
//			List<DictEntity> list = this.dictService.findDictListByTag(tag);
//			return Result.success(list);
//		} catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("获取标签集合接口失败，失败原因：" + e.getMessage());
//		}
//	}
	
//	@ApiOperation(value = "新增数据字典接口")
//	@ApiJsonObject(name = "saveDict", value = { 
//			@ApiJsonProperty(name = DictJson.name),
//			@ApiJsonProperty(name = DictJson.remark),
////			@ApiJsonProperty(name = DictJson.isEdit), 
////			@ApiJsonProperty(name = DictJson.level), 
////			@ApiJsonProperty(name = DictJson.isCustomerTag),
//			@ApiJsonProperty(name = DictJson.tag)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "saveDict")
//	@PostMapping("/saveDict")
//	public Result saveDict(@RequestBody String params) {
//		try{
//			System.out.println("params参数为：" + params);
//			JSONObject jsonObject = JSON.parseObject(params);
//			String name = String.valueOf(jsonObject.get("name"));
//			String remark = String.valueOf(jsonObject.get("remark"));
//			String tag = String.valueOf(jsonObject.get("tag"));
////			String isCustomerTag = String.valueOf(jsonObject.get("isCustomerTag"));
////			String level = String.valueOf(jsonObject.get("level"));
////			String isEdit = String.valueOf(jsonObject.get("isEdit"));
//			StringUtil.validateIsNull(name, "请输入标签名称");
//			StringUtil.validateIsNull(tag, "请输入分组英文标签");
////			StringUtil.validateIsNull(isCustomerTag, "请输入是否是客户标签0：不是，1：是");
//			//保存数据字典
//			DictEntity dict = new DictEntity();
//			Object object = SecurityUtils.getSubject().getPrincipal();
//			UserEntity user = null;
//			if (object instanceof UserEntity) {
//				user = (UserEntity) object;
//			}
//			dict.setCreateBy(String.valueOf(user.getId()));
//			dict.setName(name);
//			dict.setRemark(remark);
//			dict.setCreateTime(LocalDateTime.now());
//			dict.setTag(tag);
//			dict.setIsCustomerTag("1");//默认是客户标签
////			dict.setIsEdit(isEdit);
////			dict.setLevel(level);
//			boolean flag = this.dictService.saveDict(dict);
//			if(flag){
//				return Result.success("新增数据字典成功！");
//			}
//			return Result.error("新增数据字典失败，请联系管理员！");
//		} catch (BusinessException e) {
//			e.printStackTrace();
//			return Result.error(e.getMessage());
//		}catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("新增数据字典失败，失败原因：" + e.getMessage());
//		}
//	}
//	
//	@ApiOperation(value = "修改数据字典接口")
//	@ApiJsonObject(name = "updateDict", value = {
//			@ApiJsonProperty(name = DictJson.id),
//			@ApiJsonProperty(name = DictJson.name),
//			@ApiJsonProperty(name = DictJson.remark),
//			@ApiJsonProperty(name = DictJson.tag),
////			@ApiJsonProperty(name = DictJson.defaultSelected),
////			@ApiJsonProperty(name = DictJson.available), 
////			@ApiJsonProperty(name = DictJson.isEdit), 
////			@ApiJsonProperty(name = DictJson.level), 
////			@ApiJsonProperty(name = DictJson.isCustomerTag),
//			@ApiJsonProperty(name = DictJson.value)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "updateDict")
//	@PostMapping("/updateDict")
//	public Result updateDict(@RequestBody String params) {
//		try{
//			System.out.println("params参数为：" + params);
//			JSONObject jsonObject = JSON.parseObject(params);
//			String id = String.valueOf(jsonObject.get("id"));
//			String name = String.valueOf(jsonObject.get("name"));
//			String remark = String.valueOf(jsonObject.get("remark"));
//			String tag = String.valueOf(jsonObject.get("tag"));
//			String value = String.valueOf(jsonObject.get("value"));
////			String isCustomerTag = String.valueOf(jsonObject.get("isCustomerTag"));
////			String level = String.valueOf(jsonObject.get("level"));
////			String defaultSelected = String.valueOf(jsonObject.get("defaultSelected"));
////			String available = String.valueOf(jsonObject.get("available"));
////			String isEdit = String.valueOf(jsonObject.get("isEdit"));
//			StringUtil.validateIsNull(tag, "请输入分组英文标签");
//			StringUtil.validateIsNull(id, "ID不能为空");
////			StringUtil.validateIsNull(isCustomerTag, "请输入是否是客户标签0：不是，1：是");
//			//保存数据字典
//			DictEntity dict = new DictEntity();
//			Object object = SecurityUtils.getSubject().getPrincipal();
//			UserEntity user = null;
//			if (object instanceof UserEntity) {
//				user = (UserEntity) object;
//			}
//			dict.setUpdateBy(String.valueOf(user.getId()));
//			dict.setName(name);
//			dict.setRemark(remark);
//			dict.setValue(value);
//			dict.setTag(tag);
//			dict.setUpdateTime(LocalDateTime.now());
//			dict.setId(Integer.parseInt(id));
////			dict.setIsEdit(isEdit);
////			dict.setLevel(level);
////			dict.setAvailable(available);
////			dict.setDefaultSelected(defaultSelected);
//			boolean flag = this.dictService.updateDict(dict);
//			if(flag){
//				return Result.success("修改数据字典成功！");
//			}
//			return Result.error("修改数据字典失败，请联系管理员！");
//		} catch (BusinessException e) {
//			e.printStackTrace();
//			return Result.error(e.getMessage());
//		}catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("修改数据字典失败，失败原因：" + e.getMessage());
//		}
//	}
//	
//	@ApiOperation(value = "删除标签接口")
//	@ApiJsonObject(name = "deleteDictById", value = {
//			@ApiJsonProperty(name = DictJson.id)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "deleteDictById")
//	@PostMapping("/deleteDictById")
//	public Result deleteDictById(@RequestBody String params) {
//		try{
//			System.out.println("params参数为：" + params);
//			JSONObject jsonObject = JSON.parseObject(params);
//			String id = String.valueOf(jsonObject.get("id"));
//			StringUtil.validateIsNull(id, "ID不能为空");
//			boolean flag = this.dictService.deleteDictById(id);
//			if(flag){
//				return Result.success("删除标签成功！");
//			}
//			return Result.error("删除标签失败，请联系管理员！");
//		} catch (BusinessException e) {
//			e.printStackTrace();
//			return Result.error(e.getMessage());
//		}catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("删除标签失败，失败原因：" + e.getMessage());
//		}
//	}
	
//	@ApiOperation(value = "删除分组接口")
//	@ApiJsonObject(name = "deleteDictByTag", value = {
//			@ApiJsonProperty(name = DictJson.tag)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "deleteDictByTag")
//	@PostMapping("/deleteDictByTag")
//	public Result deleteDictByTag(@RequestBody String params) {
//		try{
//			System.out.println("params参数为：" + params);
//			JSONObject jsonObject = JSON.parseObject(params);
//			String tag = String.valueOf(jsonObject.get("tag"));
//			StringUtil.validateIsNull(tag, "分组标签不能为空");
//			boolean flag = this.dictService.deleteDictByTag(tag);
//			if(flag){
//				return Result.success("删除分组成功！");
//			}
//			return Result.error("删除分组失败，请联系管理员！");
//		} catch (BusinessException e) {
//			e.printStackTrace();
//			return Result.error(e.getMessage());
//		}catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("删除分组失败，失败原因：" + e.getMessage());
//		}
//	}
	
}
