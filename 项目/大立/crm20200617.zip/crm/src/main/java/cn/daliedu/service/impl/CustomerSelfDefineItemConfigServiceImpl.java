package cn.daliedu.service.impl;

import cn.daliedu.entity.CustomerSelfDefineItemConfigDetailEntity;
import cn.daliedu.entity.CustomerSelfDefineItemConfigEntity;
import cn.daliedu.entity.CustomerSelfDefineItemEntity;
import cn.daliedu.entity.CustomerTagEntity;
import cn.daliedu.entity.CustomerTagGroupDetailEntity;
import cn.daliedu.entity.CustomerTagGroupEntity;
import cn.daliedu.mapper.CustomerSelfDefineItemConfigDetailMapper;
import cn.daliedu.mapper.CustomerSelfDefineItemConfigMapper;
import cn.daliedu.mapper.CustomerSelfDefineItemMapper;
import cn.daliedu.service.CustomerSelfDefineItemConfigService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 客户自定义类别配置表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2020-05-20
 */
@Service
public class CustomerSelfDefineItemConfigServiceImpl extends ServiceImpl<CustomerSelfDefineItemConfigMapper, CustomerSelfDefineItemConfigEntity> implements CustomerSelfDefineItemConfigService {
	
	@Resource
	CustomerSelfDefineItemMapper customerSelfDefineItemMapper;
	
	@Resource
	CustomerSelfDefineItemConfigMapper customerSelfDefineItemConfigMapper;
	
	@Resource
	CustomerSelfDefineItemConfigDetailMapper customerSelfDefineItemConfigDetailMapper;
	
	


	@Override
	public Integer getMaxCustomerSelfDefineItemValue(String branchOrgId){
		if(branchOrgId.equals("null") || branchOrgId.equals("")){
			return customerSelfDefineItemConfigMapper.getMaxCustomerSelfDefineItemValue();
		}
		return customerSelfDefineItemConfigMapper.getMaxCustomerSelfDefineItemValueByBranchOrgId(branchOrgId);
	}


	@Override
	public boolean restoreCustomerSelfDefineItemByBranchOrgId(String branchOrgId) {
		List<CustomerSelfDefineItemConfigEntity> branchGrouplist = customerSelfDefineItemConfigMapper.selectList(new QueryWrapper<CustomerSelfDefineItemConfigEntity>().eq("branch_org_id", branchOrgId));
		
		if(CollectionUtils.isEmpty(branchGrouplist)){
			//加载系统初始化的客户分组
			List<CustomerSelfDefineItemConfigEntity> list = customerSelfDefineItemConfigMapper.selectList(new QueryWrapper<CustomerSelfDefineItemConfigEntity>().eq("is_init", true));
			if(!CollectionUtils.isEmpty(list)){
				list.stream().forEach(entity -> {
					CustomerSelfDefineItemConfigEntity groupEntity = new CustomerSelfDefineItemConfigEntity();
					groupEntity.setBranchOrgId(branchOrgId);
//					groupEntity.setCustomerTagTypeId(entity.getCustomerTagTypeId());
					groupEntity.setItemName(entity.getItemName());
					groupEntity.setIsInit(false);
					groupEntity.setOrderNum(entity.getOrderNum());
					groupEntity.setIsEnabled(entity.getIsEnabled());
					groupEntity.setElementType(entity.getElementType());
					
					customerSelfDefineItemConfigMapper.insert(groupEntity);
					
					List<CustomerSelfDefineItemConfigDetailEntity> detailList = customerSelfDefineItemConfigDetailMapper.selectList(new QueryWrapper<CustomerSelfDefineItemConfigDetailEntity>().eq("item_id", entity.getItemId()));
					if(!CollectionUtils.isEmpty(detailList)){
						for(CustomerSelfDefineItemConfigDetailEntity detail : detailList){
							CustomerSelfDefineItemConfigDetailEntity detailEntity = new CustomerSelfDefineItemConfigDetailEntity();
							detailEntity.setItemId(groupEntity.getItemId());
							detailEntity.setItemDetailName(detail.getItemDetailName());
							detailEntity.setOrderNum(detail.getOrderNum());
							
							customerSelfDefineItemConfigDetailMapper.insert(detailEntity);
						}
					}
				});
			}
		}
		
		return true;
	}


	@Override
	public List<CustomerSelfDefineItemConfigEntity> findCustomerSelfDefineItemAndDetailList(String branchOrgId) {
		if(!StringUtils.isBlank(branchOrgId)){
			//不为空，则加载分校的客户分组
			List<CustomerSelfDefineItemConfigEntity> list = customerSelfDefineItemConfigMapper.selectList(new QueryWrapper<CustomerSelfDefineItemConfigEntity>().eq("branch_org_id", branchOrgId).orderByAsc("order_num"));
			if(!CollectionUtils.isEmpty(list)){
				list.stream().forEach(entity -> {
					List<CustomerSelfDefineItemConfigDetailEntity> detailList = customerSelfDefineItemConfigDetailMapper.
							selectList(new QueryWrapper<CustomerSelfDefineItemConfigDetailEntity>().
									eq("item_id", entity.getItemId()).orderByAsc("order_num"));
					if(!CollectionUtils.isEmpty(detailList)){
						detailList.sort((o1, o2)-> o1.getOrderNum().compareTo(o2.getOrderNum()));
						entity.setCustomerSelfDefineItemConfigDetails(detailList);
					}
				});
				list.sort((o1, o2)-> o1.getOrderNum().compareTo(o2.getOrderNum()));
				return list;
			}
		}else{
			//加载系统初始化的客户分组
			List<CustomerSelfDefineItemConfigEntity> list = customerSelfDefineItemConfigMapper.selectList(new QueryWrapper<CustomerSelfDefineItemConfigEntity>().eq("is_init", true).orderByAsc("order_num"));
			if(!CollectionUtils.isEmpty(list)){
				list.stream().forEach(entity -> {
					List<CustomerSelfDefineItemConfigDetailEntity> detailList = customerSelfDefineItemConfigDetailMapper.selectList(new QueryWrapper<CustomerSelfDefineItemConfigDetailEntity>().eq("item_id", entity.getItemId()));
					if(!CollectionUtils.isEmpty(detailList)){
						detailList.sort((o1, o2)-> o1.getOrderNum().compareTo(o2.getOrderNum()));
						entity.setCustomerSelfDefineItemConfigDetails(detailList);
					}
				});
				list.sort((o1, o2)-> o1.getOrderNum().compareTo(o2.getOrderNum()));
				return list;
			}
		}
		
		return null;
	}
	
	

	@Override
	public List<CustomerSelfDefineItemConfigEntity> getCustomerSelfDefineItemByCustomerId(String branchOrgId, String customerId) {
		List<CustomerSelfDefineItemConfigEntity> list = customerSelfDefineItemConfigMapper.selectList(new QueryWrapper<CustomerSelfDefineItemConfigEntity>().eq("branch_org_id", branchOrgId).orderByAsc("order_num"));
		
		
		//如果客户ID为空，则为新增客户时，直接返回全量的客户自定义数据结构
		if(!CollectionUtils.isEmpty(list)){
			list.stream().forEach(entity -> {
				List<CustomerSelfDefineItemConfigDetailEntity> detailList = customerSelfDefineItemConfigDetailMapper.
						selectList(new QueryWrapper<CustomerSelfDefineItemConfigDetailEntity>().
								eq("item_id", entity.getItemId()).orderByAsc("order_num"));
				if(!CollectionUtils.isEmpty(detailList)){
					detailList.sort((o1, o2)-> o1.getOrderNum().compareTo(o2.getOrderNum()));
					entity.setCustomerSelfDefineItemConfigDetails(detailList);
				}
			});
			list.sort((o1, o2)-> o1.getOrderNum().compareTo(o2.getOrderNum()));
			
			if(StringUtils.isBlank(customerId)){
				return list;
			}else{
				//如果客户ID不为空，则循环进行匹配，将默认选中的属性置为true
				List<CustomerSelfDefineItemEntity> customerSelfList = customerSelfDefineItemMapper.selectList(new QueryWrapper<CustomerSelfDefineItemEntity>().eq("customer_id", customerId));
				if(!CollectionUtils.isEmpty(customerSelfList)){
					//循环全量结果集
					for(CustomerSelfDefineItemConfigEntity selfDefineItem : list){
						List<CustomerSelfDefineItemConfigDetailEntity> customerSelfDefineItemConfigDetails = selfDefineItem.getCustomerSelfDefineItemConfigDetails();
						if(!CollectionUtils.isEmpty(customerSelfDefineItemConfigDetails)){
							for(CustomerSelfDefineItemConfigDetailEntity detail : customerSelfDefineItemConfigDetails){
								for(CustomerSelfDefineItemEntity entity : customerSelfList){
									if(entity.getItemDetailId().equals(detail.getItemDetailId())){
										detail.setIsSelected(true);
									}
								}
							}
						}
					}
				}
				return list;
			}
		}
		return null;
	}


	@Override
	public List<CustomerSelfDefineItemConfigEntity> findCustomerSelfDefineItemList(String branchOrgId) {
		if(!StringUtils.isBlank(branchOrgId)){
			//不为空，则加载分校的客户分组
			List<CustomerSelfDefineItemConfigEntity> list = customerSelfDefineItemConfigMapper.selectList(new QueryWrapper<CustomerSelfDefineItemConfigEntity>().eq("branch_org_id", branchOrgId).orderByAsc("order_num"));
			list.sort((o1, o2)-> o1.getOrderNum().compareTo(o2.getOrderNum()));
			return list;
		}else{
			//加载系统初始化的客户分组
			List<CustomerSelfDefineItemConfigEntity> list = customerSelfDefineItemConfigMapper.selectList(new QueryWrapper<CustomerSelfDefineItemConfigEntity>().eq("is_init", true).orderByAsc("order_num"));
			list.sort((o1, o2)-> o1.getOrderNum().compareTo(o2.getOrderNum()));
			return list;
		}
	}


	@Override
	public boolean existsCustomerSelfDefineItemName(String itemName) {
		List<CustomerSelfDefineItemConfigEntity> list = customerSelfDefineItemConfigMapper.selectList(new QueryWrapper<CustomerSelfDefineItemConfigEntity>().eq("item_name", itemName));
		if(list!=null && list.size()>0){
			return true;
		}
		return false;
	}


	@Override
	public boolean removeCustomerSelfDefineItem(Integer itemId) throws Exception{
		customerSelfDefineItemConfigMapper.deleteById(itemId);
		customerSelfDefineItemConfigDetailMapper.delete(new QueryWrapper<CustomerSelfDefineItemConfigDetailEntity>().eq("item_id", itemId));
		return true;
	}
	
}
