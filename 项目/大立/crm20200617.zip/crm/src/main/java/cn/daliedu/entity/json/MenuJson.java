package cn.daliedu.entity.json;

import cn.daliedu.config.swagger.model.ApiSingleParam;

/**
 * <p>
 * swagger注释属性：菜单表
 * </p>
 *
 * @author xiechao
 * @since 2019-05-06
 */
public class MenuJson{

	@ApiSingleParam(value = "菜单类型   0：目录   1：菜单   2：按钮", example = "1")
	public static final String type = "type";
	
	@ApiSingleParam(value = "名称", example = "")
	public static final String name = "name";
	
	@ApiSingleParam(value = "上级parentId", example = "1")
    public static final String parentId = "parentId";
	
	@ApiSingleParam(value = "菜单权限标识符", example = "sys:user:view")
    public static final String permission = "permission";
	
	
	@ApiSingleParam(value = "菜单URL", example = "/sys/user")
    public static final String url = "url";
	
	@ApiSingleParam(value = "排序编号", example = "0")
    public static final String orderNum = "orderNum";
	
	@ApiSingleParam(value = "菜单图标", example = "el-icon-info")
    public static final String icon = "icon";
	
}
