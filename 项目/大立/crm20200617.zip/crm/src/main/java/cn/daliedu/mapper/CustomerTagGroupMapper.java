package cn.daliedu.mapper;

import cn.daliedu.entity.CustomerTagGroupEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 客户标签分组表 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-10-24
 */
public interface CustomerTagGroupMapper extends BaseMapper<CustomerTagGroupEntity> {
	/**
	 * 根据客户标签分组类型ID，获取当前客户标签对应的最大值
	 * @param customerTagTypeId 客户标签分组类型ID
	 */
	public Integer getMaxCustomerTagValueByBranchOrgId(String branchOrgId);
	
	public Integer getMaxCustomerTagValue();
}
