package cn.daliedu.config;

import javax.annotation.Resource;

import org.aspectj.lang.annotation.Aspect;
import org.springframework.aop.Advisor;
import org.springframework.aop.aspectj.AspectJExpressionPointcut;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.interceptor.DefaultTransactionAttribute;
import org.springframework.transaction.interceptor.NameMatchTransactionAttributeSource;
import org.springframework.transaction.interceptor.TransactionInterceptor;

import cn.daliedu.mapper.MenuMapper;
import cn.daliedu.service.UserService;

/**
 * 
 * @author xiechao
 * @time 2019年1月8日 下午4:44:56
 * @version 1.0.0
 * @description 全局事务处理，在service层debug调试代码可以看到，增删改操作，当没有异常的情况下返回结果大于0，但数据库此时并没有改，因为有事务控制是一起提交的
 * 注意：需要控制事务的方法，在serviceImpl层，一定要将方法定义为：throws Exception，你如果异常不抛出，那事务肯定不会回滚了，因为框架都不知道你有抛出异常，因为你自己捕获处理了
 * **注意**：  ShiroRealm这个类，最好不要注入  
 * @Autowired
 * private UserService userService; 这样的服务类，因为service层已经是动态代理了，而shiro框架去使用动态代理对象就会出问题（会引起事务无效），解决办法是直接导入mapper层
 * @Resource
	MenuMapper menuMapper;  doGetAuthenticationInfo()这个里面又可以使用service层的类，为了保险起见，引类不要引入service层的类
	里面的doGetAuthorizationInfo() 方法体内，  
	
	注意：服务层的实现方法中需要事务控制的方法，不能使用别的服务层来来进行增删改操作，，不需要控制事务的可以注入别的服务层来进行查询
 */
@Aspect
@Configuration
public class TransactionAdviceConfig {
	
//	private static final int TX_METHOD_TIMEOUT = 5;
	private static final int TX_METHOD_TIMEOUT = 500;
	
	
	 /*
     * 定义切入点
     * execution()是最常用的切点函数
     * execution (com.coolron.user.service.impl..*.*(..))
     * 1、execution(): 表达式主体。
     * 2、第一个*号：表示返回类型，*号表示所有的类型。
     * 3、包名：表示需要拦截的包名，后面的两个句点表示当前包和当前包的所有子包，com.sample.service.impl包、子孙包下所有类的方法。
     * 4、第二个*号：表示类名，*号表示所有的类。
     * 5、*(..):最后这个星号表示方法名，*号表示所有的方法，后面括弧里面表示方法的参数，两个句点表示任何参数。
     */
	/*定义切点变量：拦截com.***.service包下所有类的所有方法,返回值类型任意的方法*/
	// //匹配com.cjm.model包及其子包中所有类中的所有方法，返回类型任意，方法参数任意  ("execution(* com.cjm.model..*.*(..))")
//	
//	private static final String AOP_POINTCUT_EXPRESSION = "execution(* cn.daliedu.service.impl.*.*(..))";//无用
	
//	private static final String AOP_POINTCUT_EXPRESSION = "execution(* cn.daliedu.service.impl..*.*(..))"; //无用 
//	private static final String AOP_POINTCUT_EXPRESSION = "execution(* cn.daliedu.service.impl.*(..))"; //启不动  
//	private static final String AOP_POINTCUT_EXPRESSION = "execution(* cn.daliedu.service..*.*(..))";//无用
	
//	private static final String AOP_POINTCUT_EXPRESSION = "execution(* cn.daliedu.service.impl..*(..))";  //无用
	
//	private static final String AOP_POINTCUT_EXPRESSION = "execution(* cn.daliedu.service.*.*(..))";//无用
	
//	expression="execution(* com.easysign.authc.subcenters.module..*.service.impl..*Impl.*(..))"//云平台写法
//	private static final String AOP_POINTCUT_EXPRESSION = "execution(* cn.daliedu.service.impl..*Impl.*(..))";//仿云平台的写法，还是无用
	
	private static final String AOP_POINTCUT_EXPRESSION = "execution(* cn.***.service.*.*(..))";//无用
	
//	private static final String AOP_POINTCUT_EXPRESSION="execution(* cn.daliedu.service..*(..))"; //无用
//	private static final String AOP_POINTCUT_EXPRESSION="execution(* cn.daliedu.service..*.*(..))";//无用
	
//	@Autowired
//	private PlatformTransactionManager transactionManager;
	
	@Autowired
    private DataSourceTransactionManager transactionManager;


	@Bean
	public TransactionInterceptor txAdvice() {

		/*写事务，用于增删改*/
		DefaultTransactionAttribute txAttr_REQUIRED = new DefaultTransactionAttribute();
		/*PROPAGATION_REQUIRED:事务隔离性为1，若当前存在事务，则加入该事务；如果当前没有事务，则创建一个新的事务。这是默认值。 */
		txAttr_REQUIRED.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		
		/*设置事务失效时间，如果超过5秒，则回滚事务,开发阶段可以将此时间调长一点*/
        txAttr_REQUIRED.setTimeout(TX_METHOD_TIMEOUT);

		/*只读事物、不做更新删除等*/
		DefaultTransactionAttribute txAttr_REQUIRED_READONLY = new DefaultTransactionAttribute();
		/*
         * transactiondefinition 定义事务的隔离级别；
         * PROPAGATION_NOT_SUPPORTED事务传播级别5，以非事务运行，如果当前存在事务，则把当前事务挂起
         */
		txAttr_REQUIRED_READONLY.setPropagationBehavior(TransactionDefinition.PROPAGATION_NOT_SUPPORTED);
		txAttr_REQUIRED_READONLY.setReadOnly(true);

		/*事务管理规则，声明具备事务管理的方法名*/
		NameMatchTransactionAttributeSource source = new NameMatchTransactionAttributeSource();
		
		
		//写
		source.addTransactionalMethod("add*", txAttr_REQUIRED);
		source.addTransactionalMethod("insert*", txAttr_REQUIRED);
		source.addTransactionalMethod("save*", txAttr_REQUIRED);
		source.addTransactionalMethod("create*", txAttr_REQUIRED);
		source.addTransactionalMethod("delete*", txAttr_REQUIRED);
		source.addTransactionalMethod("remove*", txAttr_REQUIRED);
		source.addTransactionalMethod("update*", txAttr_REQUIRED);
		source.addTransactionalMethod("exec*", txAttr_REQUIRED);
		source.addTransactionalMethod("set*", txAttr_REQUIRED); 
		source.addTransactionalMethod("restore*", txAttr_REQUIRED);//还原类接口
		
		//只读
		source.addTransactionalMethod("get*", txAttr_REQUIRED_READONLY);
		source.addTransactionalMethod("query*", txAttr_REQUIRED_READONLY);
		source.addTransactionalMethod("find*", txAttr_REQUIRED_READONLY);
		source.addTransactionalMethod("list*", txAttr_REQUIRED_READONLY);
		source.addTransactionalMethod("count*", txAttr_REQUIRED_READONLY);
		source.addTransactionalMethod("is*", txAttr_REQUIRED_READONLY);
		return new TransactionInterceptor(transactionManager, source);
	}

	@Bean
	public Advisor txAdviceAdvisor() {
		/*
		 * 声明切点的面
		 * 切面（Aspect）：切面就是通知和切入点的结合。通知和切入点共同定义了关于切面的全部内容——它的功能、在何时和何地完成其功能。
		 */
		AspectJExpressionPointcut pointcut = new AspectJExpressionPointcut();
		/*声明和设置需要拦截的方法,用切点语言描写*/
		pointcut.setExpression(AOP_POINTCUT_EXPRESSION);
		/*设置切面=切点pointcut+通知TxAdvice*/
		return new DefaultPointcutAdvisor(pointcut, txAdvice());
	}
}
