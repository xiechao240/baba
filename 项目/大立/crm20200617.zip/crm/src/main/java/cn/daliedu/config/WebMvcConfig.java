package cn.daliedu.config;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;

import cn.daliedu.config.filter.CorsFilter;
import cn.daliedu.config.i18n.MyLocaleResolver;





@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

	
	@Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
		//如果这样配置，就可以在前台<script src="js/jquery.js"></script>这样导入/resources/static下面的js等静态文件
        registry.addResourceHandler("/**")
                .addResourceLocations("classpath:/static/");
        
        //如果这样配置，就可以在前台<script src="static/js/jquery.js"></script>这样导入/resources/static下面的js等静态文件
        //**区别就是可以写与不写static的区别
      //将所有/static/**访问都映射到classpath:/static/目录下
//        registry.addResourceHandler("/static/**")
//			.addResourceLocations("classpath:/static/");

        registry.addResourceHandler("swagger-ui.html")
                .addResourceLocations("classpath:/META-INF/resources/");

        registry.addResourceHandler("/webjars/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/");
    }
    

    
    /**
	 * 配置自己的国际化语言解析器
	 */
	@Bean
	public LocaleResolver localeResolver() {
		return new MyLocaleResolver();
	}

	/**
	 * 注入跨域访问Filter
	 * @return
	 */
	@Bean
	public FilterRegistrationBean registration() {
		FilterRegistrationBean registration = new FilterRegistrationBean();
		registration.setFilter(new CorsFilter());
		registration.setName("corsFilter");
		registration.addUrlPatterns("/*");
		return registration;
	}
	
//	@Bean
//    public WebMvcConfigurer CORSConfigurer() {
//        return new WebMvcConfigurerAdapter() {
//            @Override
//            public void addCorsMappings(CorsRegistry registry) {
//                registry.addMapping("/**")
//                        .allowedOrigins("*")
//                        .allowedMethods("*")
//                        .allowedHeaders("*")
//                        //设置是否允许跨域传cookie
//                        .allowCredentials(true)
//                        //设置缓存时间，减少重复响应
//                        .maxAge(3600);
//            }
//        };
//    }





}
