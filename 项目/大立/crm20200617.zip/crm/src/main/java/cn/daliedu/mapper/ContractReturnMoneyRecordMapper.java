package cn.daliedu.mapper;

import cn.daliedu.entity.ContractReturnMoneyRecordEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 合同回款记录表 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-10-31
 */
public interface ContractReturnMoneyRecordMapper extends BaseMapper<ContractReturnMoneyRecordEntity> {

}
