package cn.daliedu.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 客户标签表，用户为客户打上的标签，其实就是作为一个筛选条件，一个客户只能从属于一类标签中的一个值
 * </p>
 *
 * @author xiechao
 * @since 2019-10-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_customer_tag")
public class CustomerTagEntity extends Model<CustomerTagEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;


    /**
     * 客户ID
     */
    @ApiModelProperty(value="客户ID")
    private String customerId;

    /**
     * 客户标签类型ID，来源于数据字典
     */
    @ApiModelProperty(value="客户标签类型ID")
    private Integer customerTagTypeId;

    
    /**
     * 客户标签ID
     */
    @ApiModelProperty(value="客户标签ID")
    private Integer customerTagId;


    /**
     * 客户分组标签值，来源于数据字典
     */
    @ApiModelProperty(value="客户分组标签值")
    private String customerTagValue;
    
    
    /**
     * 客户分组标签名
     */
    @ApiModelProperty(value="客户分组标签名")
    @TableField(exist = false)
    private String customerTagName;
    
    /**
     * 创建时间
     */
    private LocalDateTime createDate;
    
	@Override
    protected Serializable pkVal() {
        return this.id;
    }
}
