package cn.daliedu.service.impl;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.Resource;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.entity.CustomerDynamicLogEntity;
import cn.daliedu.entity.CustomerEntity;
import cn.daliedu.entity.CustomerTagEntity;
import cn.daliedu.entity.CustomerTagLogEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.json.CustomerTagJson;
import cn.daliedu.enums.DynamicTypeEnum;
import cn.daliedu.mapper.CustomerDynamicLogMapper;
import cn.daliedu.mapper.CustomerMapper;
import cn.daliedu.mapper.CustomerTagLogMapper;
import cn.daliedu.mapper.CustomerTagMapper;
import cn.daliedu.service.CustomerService;
import cn.daliedu.service.CustomerTagService;

/**
 * <p>
 * 客户标签表，用户为客户打上的标签，其实就是作为一个筛选条件，一个客户只能从属于一类标签中的一个值 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-08
 */
@Service
public class CustomerTagServiceImpl extends ServiceImpl<CustomerTagMapper, CustomerTagEntity> implements CustomerTagService {

	@Autowired
	CustomerService customerService;
	
	@Resource
	CustomerTagMapper customerTagMapper;
	
	@Resource
	CustomerDynamicLogMapper customerDynamicLogMapper;
	
	@Resource
	CustomerMapper customerMapper;
	
	@Resource
	CustomerTagLogMapper customerTagLogMapper;

	@Override
	public List<LinkedHashMap<Object, Object>> getCustomerTagListByCustomerId(String customerId) {
		return customerTagMapper.getCustomerTagListByCustomerId(customerId);
	}

	@Override
	public boolean deleteCustomerTagByCustomerId(String customerId) {
		int num = customerTagMapper.delete(new QueryWrapper<CustomerTagEntity>().eq("customer_id", customerId));
		if(num>0){
			return true;
		}
		return false;
	}

	
	@Override
	public boolean saveCustomerTagByCustomerId(CustomerTagJson customerTagJson) throws Exception{
		String[] customerIds = customerTagJson.getCustomerIds();
		CustomerTagEntity[] customerTags = customerTagJson.getCustomerTagEntity();
		
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity bean = (UserEntity) object;
			
			//先删除客户已经存在的客户标签，再保存
			for(String customerId : customerIds){
				customerTagMapper.delete(new QueryWrapper<CustomerTagEntity>().eq("customer_id", customerId));
			}
			if(customerTags.length==0){
				return true;
			}
			
			//下面的废掉，客户标签属于客户，不直接从属于用户
			//将userId替换为当前登录的userId，防止系统被攻击
//			for(CustomerTagEntity entity : customerTags){
//				entity.setUserId(bean.getId()); //设置为当前用户下的客户标签
//			}
			
			for(String customerId : customerIds){
				// CustomerTagEntity entity 此对象中的customerId前端不必传，因为要支持多个客户
				for(CustomerTagEntity customerTag : customerTags){
					CustomerTagEntity entity = new CustomerTagEntity();
					entity.setCustomerId(customerId);
					entity.setCreateDate(LocalDateTime.now());
					entity.setCustomerTagId(customerTag.getCustomerTagId());
					entity.setCustomerTagTypeId(customerTag.getCustomerTagTypeId());
					entity.setCustomerTagValue(customerTag.getCustomerTagValue());
					customerTagMapper.insert(entity);
				}
				
				CustomerEntity entity = customerService.getById(customerId);
				entity.setRecentDynamicDateTime(LocalDateTime.now());
				entity.setRecentDynamicContent("变更客户标签");
				entity.setUpdateTime(LocalDateTime.now());
				customerMapper.updateById(entity);
			}
			
			//用户打标签记录（用于报表统计）
			for(String customerId : customerIds){
				for(CustomerTagEntity customerTag : customerTags){
					CustomerTagLogEntity entity = new CustomerTagLogEntity();
					entity.setUserId(bean.getId());
					entity.setCustomerId(customerId);
					entity.setCustomerTagTypeId(customerTag.getCustomerTagTypeId());
					entity.setCustomerTagId(customerTag.getCustomerTagId());
					entity.setCustomerTagValue(customerTag.getCustomerTagValue());
					entity.setCreateDate(LocalDateTime.now());
					
					customerTagLogMapper.insert(entity);
				}
			}
			
			//记录客户动态
			for(String customerId : customerIds){
				CustomerDynamicLogEntity dynamicLogEntity = new CustomerDynamicLogEntity();
				dynamicLogEntity.setCustomerId(customerId);
				dynamicLogEntity.setDynamicType(DynamicTypeEnum.TYPE_8.getValue());
				dynamicLogEntity.setDynamicName(DynamicTypeEnum.TYPE_8.getDesc());
				dynamicLogEntity.setDynamicUserId(bean.getId());
				dynamicLogEntity.setCreateDate(LocalDateTime.now());
				
				String oldValue = "";
				String newValue = "";
				for(CustomerTagEntity entity : customerTags){
					newValue = newValue + entity.getCustomerTagName() + "  ";
				}
				List<LinkedHashMap<Object, Object>> list = this.getCustomerTagListByCustomerId(customerId);
				if(list!=null && list.size()>0){
					for(LinkedHashMap<Object, Object> map : list){
						oldValue = oldValue + map.get("customerTagName") + "  ";
					}
				}
				dynamicLogEntity.setOldValue(oldValue);
				dynamicLogEntity.setNewValue(newValue);
				
				if(customerDynamicLogMapper.insert(dynamicLogEntity)>0){
					return true;
				}
			}
			
			return true;
		}
		return false;
	}


	@Override
	public boolean existsCustomerTagTypeIdUse(String customerTagTypeId) {
		List<CustomerTagEntity> list = customerTagMapper.selectList(new QueryWrapper<CustomerTagEntity>().eq("customer_tag_type_id", Integer.parseInt(customerTagTypeId)));
		if(list!=null && list.size()>0){
			return true;
		}
		return false;
	}


	@Override
	public boolean existsCustomerTagIdUse(String customerTagId) {
		List<CustomerTagEntity> list = customerTagMapper.selectList(new QueryWrapper<CustomerTagEntity>().eq("customer_tag_id", Integer.parseInt(customerTagId)));
		if(list!=null && list.size()>0){
			return true;
		}
		return false;
	}
	
	

}
