//package cn.daliedu.websocket.cluster;
//
//
//import java.security.Principal;
//
//import org.springframework.amqp.core.ExchangeTypes;
//import org.springframework.amqp.rabbit.annotation.Exchange;
//import org.springframework.amqp.rabbit.annotation.Queue;
//import org.springframework.amqp.rabbit.annotation.QueueBinding;
//import org.springframework.amqp.rabbit.annotation.RabbitListener;
//
///**
// * Created by huangrongyou@yixin.im on 2018/7/10.
// */
//@RabbitListener(
//  bindings = @QueueBinding(
//             value = @Queue(value = "${rqbbitmq.log.fanout.info}",autoDelete = "true"),
// exchange = @Exchange(value = "${spring.rabbitmq.exchange}",type = ExchangeTypes.FANOUT)
//)
//)
//public class MyPrincipal implements Principal {
//    private String loginName;
//
//    public MyPrincipal(String loginName){
//        this.loginName = loginName;
//    }
//    @Override
//    public String getName() {
//        return loginName;
//    }
//}
