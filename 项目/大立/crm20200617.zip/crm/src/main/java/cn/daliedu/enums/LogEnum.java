package cn.daliedu.enums;

/**
 * 日志记录策略枚举类
 * 
 * @author xiechao
 * @time 2019年2月20日 下午2:10:21
 * @version 1.0.0
 * @description
 */
public enum LogEnum {

	BUSSINESS("bussiness"),

	PLATFORM("platform"),

	DB("db"),

	EXCEPTION("exception"),

	;

	private String category;

	LogEnum(String category) {
		this.category = category;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
}
