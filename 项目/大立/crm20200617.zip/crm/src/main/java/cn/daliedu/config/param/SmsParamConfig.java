package cn.daliedu.config.param;

import org.springframework.beans.factory.annotation.Value;
/**
 * @author xiechao
 * @time 2019年1月9日 上午10:33:55
 * @version 1.0.0 
 * @description 加载yml配置文件中的值
 */
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

/**
 * 短信参数常量配置获取类
 * @author xiechao
 * @time 2019年1月9日 上午10:58:42
 * @version 1.0.0
 * @description spring-boot启动时会加载application.yml文件中内容，这个类指定加载开发人员需要用到的常量，
 *              由于spring @value注解不支持往静态变量上赋值，所以需要在属性的set方法上把这个注解加上，才能正确赋值
 *              【注意：】此类，成员变量可以为静态static的，但get,set方法前面不能有static关键字，spring不支持这样的特性,其实get方法不用写也可以，目前所有get方法已经去掉了
 */
@Configuration
public class SmsParamConfig {
	/**
	 * 短信验证码默认有效时间(秒)  ${sms.active_time}
	 */
	public static Long ACTIVE_TIME;

	/**
	 * 开启多少分钟内不能重复发送验证的的校验。小于等于0表示不限制，大于0-表示具体限制多少分钟内  ${sms.re_send_check}
	 */
	public static int RE_SEND_CHECK;

	/**
	 * 单个验证码重复验证失败次数验证（0表示不限制，大于0表示可失败次数），则当前验证码失效  ${sms.re_check_error}
	 */
	public static int RE_CHECK_ERROR; // 每在配置文件中定义一个变量，则在这里定义一个属性，非常方便开发



	@Value("${sms.active_time}")
	public void setACTIVE_TIME(Long aCTIVE_TIME) {
		ACTIVE_TIME = aCTIVE_TIME;
	}

	@Value("${sms.re_send_check}")
	public void setRE_SEND_CHECK(int rE_SEND_CHECK) {
		RE_SEND_CHECK = rE_SEND_CHECK;
	}

	@Value("${sms.re_check_error}")
	public void setRE_CHECK_ERROR(int rE_CHECK_ERROR) {
		RE_CHECK_ERROR = rE_CHECK_ERROR;
	}

}