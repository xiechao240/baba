package cn.daliedu.enums;

/**
 * 客户类型枚举类
 * @author xiechao
 * @time 2019年9月27日 下午2:44:36
 * @version 1.0.0 
 * @description
 */
public enum  MyCustomerTypeEnum {
	/**
	 * 客户类型：我的客户
	 */
	TYPE_1("1", "我的客户"), 
	/**
	 * 客户类型：共享给我的客户
	 */
	TYPE_2("2", "共享给我的客户"),
	/**
	 * 客户类型：共享给同事的客户
	 */
	TYPE_3("3", "共享给同事的客户");

	private String value;
	private String desc;

	MyCustomerTypeEnum(final String value, final String desc) {
		this.value = value;
		this.desc = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}