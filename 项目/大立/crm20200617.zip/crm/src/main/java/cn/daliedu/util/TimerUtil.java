package cn.daliedu.util;

import java.util.Timer;

/**
 * 将时间秒数，转换成对应的小时，分钟，秒数
 * 目前我们的业务需求，只需要将秒数转化为分钟即可，如果没超过1分钟，就显示0分x秒这种格式，不需要显示小时数
 * @author xiechao
 * @time 2019年11月26日 上午10:25:19
 * @version 1.0.0
 * @description
 */
public class TimerUtil {

	private int seconds = 0;// 定义秒
	private int minutes = 0;// 定义分
	private int hours = 0; // 定义时

	public int getSeconds() {
		return seconds;
	}
	public int getMinutes() {
		return minutes;
	}
	public int getHours() {
		return hours;
	}

	
	//这个秒数只转化为分钟，不会转化到小时里面去
	public void setSeconds(int seconds) {
		this.seconds = seconds;
		if (this.seconds < 60) {
			this.seconds = this.seconds;
		} else if (this.seconds >= 60 && this.seconds % 60 == 0) {
			this.minutes = this.minutes + this.seconds / 60;
			this.seconds = 0;

		} else if (this.seconds >= 60 && this.seconds % 60 != 0) {
			this.minutes = this.minutes + this.seconds / 60;
			this.seconds = this.seconds % 60;
		}
	}

	
	public void setMinutes(int minutes) {
		this.minutes = this.minutes + minutes;
		if (this.minutes < 60) {
			this.minutes = this.minutes;
		} else if (this.minutes >= 60 && this.minutes % 60 == 0) {
			this.hours = this.hours + this.minutes / 60;
			this.minutes = 0;
		} else if (this.minutes >= 60 && this.minutes % 60 != 0) {
			this.hours = this.hours + this.minutes / 60;
			this.minutes = this.minutes % 60;
		}
	}

	

	public void setHours(int hours) {
		this.hours = this.hours + hours;
	}

	public static void main(String[] args) {
		TimerUtil tt = new TimerUtil();
		
		tt.setSeconds(308);//秒数
//		tt.setMinutes(77);//分钟数
//		tt.setHours(34);//小时数
		System.out.println(tt.getHours() + "时" + tt.getMinutes() + "分" + tt.getSeconds() + "秒");
		
		
		//测试非常大的秒数，也只转化为分钟，不会向小时进位
		tt.setSeconds(30800);//秒数
		System.out.println(tt.getMinutes() + "分" + tt.getSeconds() + "秒");
	}
}
