package cn.daliedu.mapper;

import cn.daliedu.entity.UserOrgAreaEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.Map;

/**
 * <p>
 * 用户可查看的业务组公海与部门数据，用户可拥有多个分校的数据查看权限，其实就是存储用户从属于多个分校 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-09-23
 */
public interface UserOrgAreaMapper extends BaseMapper<UserOrgAreaEntity> {

	
	/**
	 * 根据用户ID查询用户所属的业务组分校集合
	 * @param userId
	 * @return
	 */
	public String getUserOrgAreaIdsByUserId(String userId);

    /**
     * 批量增加用户分校范围
     * @param map
     * @return
     */
    public Integer addUserOrgAreaBatch(Map<String, Object> map);

}
