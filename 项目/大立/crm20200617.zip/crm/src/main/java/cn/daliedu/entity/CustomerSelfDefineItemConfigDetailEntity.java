package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 客户自定义类别配置明细表
 * </p>
 *
 * @author xiechao
 * @since 2020-05-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_customer_self_define_item_config_detail")
@ApiModel(value="CustomerSelfDefineItemConfigDetailEntity对象", description="客户自定义类别配置明细表")
public class CustomerSelfDefineItemConfigDetailEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "类别明细ID")
    @TableId(value = "item_detail_id", type = IdType.UUID)
    private String itemDetailId;

    @ApiModelProperty(value = "类别ID")
    private String itemId;

    @ApiModelProperty(value = "类别明细名称")
    private String itemDetailName;

    @ApiModelProperty(value = "排序号")
    private Integer orderNum;
    
    @TableField(exist = false)
    @ApiModelProperty(value = "是否选中")
    private Boolean isSelected = false;


}
