package cn.daliedu.controller.api.console;


import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cn.daliedu.entity.DictEntity;
import cn.daliedu.entity.DictManyDetailEntity;
import cn.daliedu.entity.DictManyEntity;
import cn.daliedu.service.DictManyService;
import cn.daliedu.service.DictService;
import cn.daliedu.util.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 存储2个维度的，一对多的数据字典 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2019-11-07
 */
@Api(description = "一对多关系，数据字典相关接口")
@RestController
@RequestMapping("${rest.path}/console/dict-many")
public class DictManyController {
	
	@Autowired
	DictManyService dictManyService;
	
	@ApiOperation(value = "获取所有的数据字典类型")
	@PostMapping("/getDictTypeList")
	public Result getDictTypeList() throws Exception {
		List<LinkedHashMap<String, String>> dictList = dictManyService.getDictTypeList();
		return Result.success(dictList);
	}
	
	
	
	@ApiOperation(value = "根据数据字典标签获取数据字典集合")
	@ApiImplicitParam(paramType = "query", dataType = "String", name = "tag", value = "数据标签名称", required = true)
	@PostMapping("/getDictValueByTag")
	public Result getDictValueByTag(@RequestParam String tag) throws Exception {
		if (tag == null || tag.trim().length()<=0) {
			return Result.error("数据类型为空");
		}
		
		List<DictManyEntity> list = dictManyService.getDictValueByTag(tag);
		if(list!=null && list.size()>0){
			return Result.success(list);
		}
		return Result.error("暂无数据");
	}
	
	
	@ApiOperation(value = "根据数据字典标签ID获取数据字典明细")
	@ApiImplicitParam(paramType = "query", dataType = "String", name = "tagId", value = "数据标签ID", required = true)
	@PostMapping("/getDictDetailByTagId")
	public Result getDictDetailByTagId(@RequestParam String tagId) throws Exception {
		if (tagId == null || tagId.trim().length()<=0) {
			return Result.error("数据标签ID为空");
		}
		
		List<DictManyDetailEntity> list = dictManyService.getDictDetailByTagId(tagId);
		if(list!=null && list.size()>0){
			return Result.success(list);
		}
		return Result.error("暂无数据");
	}
	
}
