//package cn.daliedu.util;
//
//import java.io.InputStream;
//
//import org.apache.commons.httpclient.HttpClient;
//import org.apache.commons.httpclient.methods.GetMethod;
//import org.apache.http.HttpEntity;
//import org.apache.http.client.methods.CloseableHttpResponse;
//import org.apache.http.client.methods.HttpPost;
//import org.apache.http.entity.StringEntity;
//import org.apache.http.impl.client.CloseableHttpClient;
//import org.apache.http.impl.client.HttpClients;
//import org.apache.http.message.BasicHeader;
//import org.apache.http.protocol.HTTP;
//import org.apache.http.util.EntityUtils;
//
//import com.alibaba.fastjson.JSONObject;
//import cn.daliedu.config.param.GlobalParamConfig;
//
///**
// * 微信操作相关工具类
// * @author xiechao
// * @time 2019年3月29日 下午5:07:20
// * @version 1.0.0 
// * @description
// */
//public class WeiXinUitl {
////	/**
////	 * 获取 openID  公司原来做的签到的demo里面移植过来，目前已经无法获取到openId,因为这个是post调用的
////	 * @param code
////	 * @return
////	 */
////	public static String getOpenId(String code) {
////		String openId = null;
////		try {
////			HttpClient client = new HttpClient();
////			PostMethod method = new PostMethod(GlobalParamConfig.WE_CHART_URL);
////
////			method.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "UTF-8");// 中文编码
////
////			NameValuePair[] parts = { new NameValuePair("appid", GlobalParamConfig.WE_CHART_APP_ID),
////					new NameValuePair("secret", GlobalParamConfig.WE_CHART_APP_SECRET), new NameValuePair("code", code),
////					new NameValuePair("grant_type", "authorization_code"),
////					new NameValuePair("scope", "snsapi_userinfo")};
////
////			method.setRequestBody(parts);
////			client.executeMethod(method);
////
////			String result = method.getResponseBodyAsString();
////
////			JSONObject obj = JSONObject.parseObject(result);
////			System.out.println("获取微信 openId 结果返回: " + obj);
////
////			openId = obj.getString("openid");
////		} catch (Exception e) {
////			e.printStackTrace();
////		}
////		return openId;
////	}
//	
//	
//	/**
//	 * 获取 openID,目前只能使用get方式调用，post方法无法获取到openId
//	 * @param code
//	 * @return 返回微信唯一 openId
//	 */
//	public static String getOpenId(String code) {
//		String openId = null;
//		try {
//			HttpClient client = new HttpClient();
//            
//            String we_chart_url = GlobalParamConfig.WE_CHART_URL;
//            String we_chart_app_id = GlobalParamConfig.WE_CHART_APP_ID;
//            String we_chart_app_secret = GlobalParamConfig.WE_CHART_APP_SECRET;
//            
//            String url = we_chart_url + "?appid=" + we_chart_app_id + "&secret=" +we_chart_app_secret
//                    + "&js_code=" + code + "&grant_type=authorization_code";
//            
//            //https://api.weixin.qq.com/sns/jscode2session?appid=APPID&secret=SECRET&js_code=JSCODE&grant_type=authorization_code
//            
//            //2.构造GetMethod的实例
//            GetMethod method = new GetMethod(url);
//            
//            method.addRequestHeader("Content-Type", "text/html; charset=UTF-8");
//            client.executeMethod(method);
//            
//            String result = method.getResponseBodyAsString();
//
//			JSONObject obj = JSONObject.parseObject(result);
//			System.out.println("获取微信 openId 结果返回: " + obj);
//
//			openId = obj.getString("openid");
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return openId;
//	}
//	
//	
//	
//	/**
//	 * 获取 微信信息，无法通过openId获取到用户信息
//	 * @param openId
//	 * @return 返回JSONObject  
//	 */
//	public static JSONObject getWeiXinInfo(String openId) {
//		JSONObject obj = null;
//		try {
//			HttpClient client = new HttpClient();
//            
//            String access_token = getAccessToken();
//            
//            String url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=" + access_token 
//            					+"&openid=" + openId +"&lang=zh_CN";
//            
//            //https://api.weixin.qq.com/sns/jscode2session?appid=APPID&secret=SECRET&js_code=JSCODE&grant_type=authorization_code
//            
//            //2.构造GetMethod的实例
//            GetMethod method = new GetMethod(url);
//            
//            method.addRequestHeader("Content-Type", "text/html; charset=UTF-8");
//            int i = client.executeMethod(method);
//            
//            String result = method.getResponseBodyAsString();
//
//			obj = JSONObject.parseObject(result);
//			System.out.println("获取微信信息结果返回: " + obj);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return obj;
//	}
//	
//	/**
//	 * 获取微信访问凭证
//	 * @return
//	 */
//	public static String getAccessToken(){
//		String accessToken = "";
//		try{
//			String we_chart_app_id = GlobalParamConfig.WE_CHART_APP_ID;
//			String we_chart_app_secret = GlobalParamConfig.WE_CHART_APP_SECRET;
//			String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" 
//							+ we_chart_app_id +"&secret=" + we_chart_app_secret;
//			
//			HttpClient client = new HttpClient();
//			GetMethod method = new GetMethod(url);
//            
//            method.addRequestHeader("Content-Type", "text/html; charset=UTF-8");
//            int i = client.executeMethod(method);
//            
//            String result = method.getResponseBodyAsString();
//
//			JSONObject obj = JSONObject.parseObject(result);
//			System.out.println("获取微信访问凭证accessToken返回: " + obj);
//
//			accessToken = obj.getString("access_token");
//		
//		}catch (Exception e) {
//			e.printStackTrace();
//		}
//		return accessToken;
//	}
//	
////	/**
////	 * 获取小程序二维码，参数只能为json形式，下面这种写法调不通
////	 */
////	public static String getWXACodeUnlimit(){
////		String imageStr = "";
////		try{
////			String url = "https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token=" + getAccessToken();
////			
////			HttpClient client = new HttpClient();
////			PostMethod method = new PostMethod(url);
////
////			method.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "UTF-8");// 中文编码
////
////			String scene = "vipId=123456";  //必填  
////			String page = "pages/usercenter/account/login";   //主页
//////			int width = ;
//////			boolean auto_color = false;
//////			Object line_color = {"r":0,"g":0,"b":0}; 
//////			boolean is_hyaline = false;
////			NameValuePair[] parts = { new NameValuePair("scene", scene), new NameValuePair("page", page)};
////
////			method.setRequestBody(parts);
////			client.executeMethod(method);
////
////			String result = method.getResponseBodyAsString();
////			System.out.println("获取小程序二维码返回result: " + result);
////			JSONObject obj = JSONObject.parseObject(result);
////			System.out.println("获取小程序二维码返回: " + obj);
////			
////			InputStream inputStream = method.getResponseBodyAsStream();//得到图片二进制内容
////			
////			imageStr = "data:image/jpg;base64," + Base64Util.base64EncodeString(StreamUtil.inputStreamToOutputStream(inputStream).toByteArray());
////			
//////			imageStr = "data:image/jpg;base64," + StreamUtil.parse_String(inputStream);
////		}catch (Exception e) {
////			e.printStackTrace();
////		}
////		return imageStr;
////	}
//	
//	
//	
//	/**
//	 * 获取小程序二维码,返回base64编码的图片，由于微信的img标签不支持base码的图片，所以再重构一个方法，直接返回byte图片上传服务器
//	 * @param vipId  我的会员id
//	 * @return 二维码图片base字符
//	 */
//	public static String getWXACodeUnlimitBase64(int vipId){
//		String imageStr = "";
//		try{
//			String url = "https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token=" + getAccessToken();
////			String scene = "parentId=" + vipId;  //必填 
//			String scene = vipId+"";  //必填   
//			String page = "pages/usercenter/account/loginselect";   //主页
//			int width = 300;
////			boolean auto_color = false;
////			Object line_color = {"r":0,"g":0,"b":0}; 
////			boolean is_hyaline = false;
//			
//			JSONObject jsonObject = new JSONObject();
//			jsonObject.put("scene", scene);
//			jsonObject.put("width", width);
//			//page参数不能乱传
////			返回结果：{"errcode":41030,"errmsg":"invalid page hint: [R.58HA04121523]"}    
////			 41030：B接口所传page页面不存在，或者小程序没有发布，请注意B接口没有path参数，传path参数虽然可以生成小程序码，但是只能跳主页面。
//			jsonObject.put("page", page);
//			
//			 
//	        //创建httpclient对象
//	        CloseableHttpClient client = HttpClients.createDefault();
//	        //创建post方式请求对象
//	        HttpPost httpPost = new HttpPost(url);
//	 
//	        //装填参数
//	        StringEntity stringEntity = new StringEntity(jsonObject.toString(), "utf-8");
//	        stringEntity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
//	        //设置参数到请求对象中
//	        httpPost.setEntity(stringEntity);
//	 
//	        //设置header信息
//	        //指定报文头【Content-type】、【User-Agent】
////	        httpPost.setHeader("Content-type", "application/x-www-form-urlencoded");
//	        httpPost.setHeader("Content-type", "application/json");
//	        httpPost.setHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");
//	 
//	        //执行请求操作，并拿到结果（同步阻塞）
//	        CloseableHttpResponse response = client.execute(httpPost);
//	        //获取结果实体
//	        HttpEntity entity = response.getEntity();
//	        if (entity != null) {
//	        	InputStream inputStream = entity.getContent();
//	        	
////	        	String result = StreamUtil.inputStreamToString(inputStream);
////	        	System.out.println("返回结果：" + result);
//	        	
//	        	imageStr = "data:image/jpg;base64," + Base64Util.base64EncodeString(StreamUtil.inputStreamToOutputStream(inputStream).toByteArray());
//	            //按指定编码转换结果实体为String类型
////	            body = EntityUtils.toString(entity, encoding);
//	        }
//	        EntityUtils.consume(entity);
//	        //释放链接
//	        response.close();
//		}catch (Exception e) {
//			e.printStackTrace();
//		}
//		return imageStr;
//	}
//	
//	
//	/**
//	 * 获取小程序二维码,返回base64编码的图片，由于微信的img标签不支持base码的图片，所以再重构一个方法，直接返回byte图片上传服务器
//	 * @param vipId  我的会员id
//	 * @return  二维码图片二进制数据
//	 */
//	public static byte[] getWXACodeUnlimit(int vipId){
//		byte[] imageByte = null;
//		try{
//			String url = "https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token=" + getAccessToken();
////			String scene = "parentId=" + vipId;  //必填 
//			String scene = vipId+"";  //必填   
//			String page = "pages/usercenter/account/loginselect";   //主页
//			int width = 300;
////			boolean auto_color = false;
////			Object line_color = {"r":0,"g":0,"b":0}; 
////			boolean is_hyaline = false;
//			
//			JSONObject jsonObject = new JSONObject();
//			jsonObject.put("scene", scene);
//			jsonObject.put("width", width);
//		//page参数不能乱传
////			返回结果：{"errcode":41030,"errmsg":"invalid page hint: [R.58HA04121523]"}    
////			 41030：B接口所传page页面不存在，或者小程序没有发布，请注意B接口没有path参数，传path参数虽然可以生成小程序码，但是只能跳主页面。
//			jsonObject.put("page", page);
//			
//			 
//	        //创建httpclient对象
//	        CloseableHttpClient client = HttpClients.createDefault();
//	        //创建post方式请求对象
//	        HttpPost httpPost = new HttpPost(url);
//	 
//	        //装填参数
//	        StringEntity stringEntity = new StringEntity(jsonObject.toString(), "utf-8");
//	        stringEntity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
//	        //设置参数到请求对象中
//	        httpPost.setEntity(stringEntity);
//	 
//	        //设置header信息
//	        //指定报文头【Content-type】、【User-Agent】
////	        httpPost.setHeader("Content-type", "application/x-www-form-urlencoded");
//	        httpPost.setHeader("Content-type", "application/json");
//	        httpPost.setHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");
//	 
//	        //执行请求操作，并拿到结果（同步阻塞）
//	        CloseableHttpResponse response = client.execute(httpPost);
//	        //获取结果实体
//	        HttpEntity entity = response.getEntity();
//	        if (entity != null) {
//	        	InputStream inputStream = entity.getContent();
//	        	
////	        	String result = StreamUtil.inputStreamToString(inputStream);
////	        	System.out.println("返回结果：" + result);
//	        	
//	        	imageByte = StreamUtil.inputStreamToOutputStream(inputStream).toByteArray();
//	            //按指定编码转换结果实体为String类型
////	            body = EntityUtils.toString(entity, encoding);
//	        }
//	        EntityUtils.consume(entity);
//	        //释放链接
//	        response.close();
//		}catch (Exception e) {
//			Log4jUtil.error("获取微信二维码失败，会员ID为：" + vipId);
//			e.printStackTrace();
//		}
//		return imageByte;
//	}
//}
