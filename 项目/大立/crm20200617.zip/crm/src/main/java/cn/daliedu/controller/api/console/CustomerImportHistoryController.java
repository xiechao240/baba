package cn.daliedu.controller.api.console;


import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.UnauthorizedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.CustomerImportHistoryEntity;
import cn.daliedu.entity.DictManyEntity;
import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.json.CustomerJson;
import cn.daliedu.entity.json.GlobalJson;
import cn.daliedu.enums.ResultCodeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.CustomerImportHistoryService;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 客户导入历史表（用于导入时记录有问题的数据，如果有需求，可以开发定时任务清理此表中的数据） 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2020-02-21
 */
@Api(description = "客户导入历史表（用于导入时记录有问题的数据，如果有需求，可以开发定时任务清理此表中的数据） 前端控制器")
@RestController
@RequestMapping(value = "${rest.path}/console/customer") 
public class CustomerImportHistoryController {
	
	@Autowired
	CustomerImportHistoryService customerImportHistoryService;
	
	@ApiOperation(value = "【客户导入结果】查看")
	@ApiJsonObject(name = "getCustomerImportHistoryList", value = { 
			@ApiJsonProperty(name = CustomerJson.mobile),
			@ApiJsonProperty(name = CustomerJson.customerName),
			@ApiJsonProperty(name = CustomerJson.importBatchNo),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerImportHistoryList")
	@PostMapping("/getCustomerImportHistoryList")
	public Result getCustomerImportHistoryList(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String mobile = String.valueOf(jsonObject.get("mobile"));
				String customerName = String.valueOf(jsonObject.get("customerName"));
				String importBatchNo = String.valueOf(jsonObject.get("importBatchNo"));
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				
	            
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("pageNum", pageNum);
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	    		
	            paramMap.put("userId", bean.getId());
	            paramMap.put("mobile", mobile);
	            paramMap.put("customerName", customerName);
	            paramMap.put("importBatchNo", importBatchNo);
	            
	            IPage<CustomerImportHistoryEntity> page = customerImportHistoryService.getCustomerImportList(paramMap);
	            
	            return Result.success(page);
			}
			return Result.error("您当前未登录，请退出，重新登录");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户导入结果列表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【客户导入错误结果】删除，根据结果集ID进行删除，注意，不是根据客户ID")
	@ApiJsonObject(name = "deleteCustomerImportHistoryById", value = { 
			@ApiJsonProperty(name = CustomerJson.ids)})
	@ApiImplicitParam(name = "params", required = true, dataType = "deleteCustomerImportHistoryById")
	@PostMapping("/deleteCustomerImportHistoryById")
	public Result deleteCustomerImportHistoryById(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String ids = String.valueOf(jsonObject.get("ids"));
				
				StringUtil.validateIsNull(ids, "请选择要删除的数据");
				
	            boolean flag = customerImportHistoryService.deleteCustomerImportResultById(ids);
	            if(flag){
	            	return Result.success("删除成功");
	            }
	            return Result.error("删除失败，请联系系统管理员");
			}
			return Result.error("您当前未登录，请退出，重新登录");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (BusinessException e) {
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("删除数据失败，失败原因：" + e.getMessage());
		}
	}
	
	
}
