package cn.daliedu.shiro.redis;

import cn.daliedu.util.SerializeUtil;
import cn.daliedu.util.UUID;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

import org.apache.shiro.session.Session;
import org.apache.shiro.session.UnknownSessionException;
import org.apache.shiro.subject.Subject;
import org.crazycake.shiro.RedisSessionDAO;
import org.crazycake.shiro.SessionInMemory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * 基于 redis 的 sessionDao, 缓存共享 session, 自定义 sessionId 生成器
 */
public class MyRedisSessionDAO extends RedisSessionDAO {
	private static Logger logger = LoggerFactory.getLogger(MyRedisSessionDAO.class);

	private static ThreadLocal<Map<Serializable, SessionInMemory>> sessionsInThread = new ThreadLocal<>();

	// 会话 KEY
	public final static String KEY_PREFIX = "crm_session:";

	public MyRedisSessionDAO() {
		super();
	}

	@Override
	protected Serializable generateSessionId(Session session) {
//		 return UUID.randomUUID();
		return java.util.UUID.randomUUID().toString();
	}

	@Override
	protected Serializable doCreate(Session session) {
		Serializable sessionId = generateSessionId(session);
		assignSessionId(session, sessionId);
		update(session);
		logger.info("自定义创建 sessionId: {}", sessionId);
		return sessionId;
	}

	@Override
	public void delete(Session session) {
		byte[] key = (KEY_PREFIX + session.getId()).getBytes(StandardCharsets.UTF_8);
		getRedisManager().del(key);
	}

	@Override
	public void update(Session session) throws UnknownSessionException {
		byte[] key = (KEY_PREFIX + session.getId()).getBytes(StandardCharsets.UTF_8);
		byte[] value = SerializeUtil.serialize(session);
		getRedisManager().set(key, value, getExpire());
	}

	 // 使用 session 时, 断点执行时间不能超过 10 秒, 不然会报 UnknownSessionException:
				// There is no session with id
	@Override
	public Session doReadSession(Serializable sessionId) {
		Session session = getSessionFromThreadLocal(sessionId);
		if (null == session) {
			byte[] key = (KEY_PREFIX + sessionId).getBytes(StandardCharsets.UTF_8);
			byte[] s = getRedisManager().get(key);
			session = (Session) SerializeUtil.unSerialize(s);
			setSessionToThreadLocal(sessionId, session);
		}
		return session;
	}

	private Session getSessionFromThreadLocal(Serializable sessionId) {
		Session s = null;
		if (sessionsInThread.get() == null) {
			return null;
		} else {
			Map<Serializable, SessionInMemory> sessionMap = sessionsInThread.get();
			SessionInMemory sessionInMemory = sessionMap.get(sessionId);
			if (sessionInMemory == null) {
				return null;
			} else {
				Date now = new Date();
				long duration = now.getTime() - sessionInMemory.getCreateTime().getTime();
				long sessionInMemoryTimeout = 1000L;// 使用断点时, 可以将此值设置大一些, 单位为毫秒
				if (duration < sessionInMemoryTimeout) {
					s = sessionInMemory.getSession();
				} else {
					sessionMap.remove(sessionId);
				}

				return s;
			}
		}
	}

	private void setSessionToThreadLocal(Serializable sessionId, Session s) {
		Map<Serializable, SessionInMemory> sessionMap = sessionsInThread.get();
		if (sessionMap == null) {
			sessionMap = Maps.newHashMap();
			sessionsInThread.set(sessionMap);
		}

		SessionInMemory sessionInMemory = new SessionInMemory();
		sessionInMemory.setCreateTime(new Date());
		sessionInMemory.setSession(s);
		sessionMap.put(sessionId, sessionInMemory);
	}

	@Override
	public Collection<Session> getActiveSessions() {
		HashSet<Session> sessions = Sets.newHashSet();

		Set<byte[]> keys = getRedisManager().keys((KEY_PREFIX + "*").getBytes(StandardCharsets.UTF_8));
		if (keys != null && keys.size() > 0) {
			for (byte[] key : keys) {
				byte[] s = getRedisManager().get(key);
				Session session = (Session) SerializeUtil.unSerialize(s);
				Subject sub = new Subject.Builder().session(session).buildSubject();
				if (sub.isAuthenticated()) {
					sessions.add(session);
				} else {
					delete(session);
				}
			}
		}

		return sessions;
	}
}
