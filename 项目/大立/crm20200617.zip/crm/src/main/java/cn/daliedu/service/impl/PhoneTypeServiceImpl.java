package cn.daliedu.service.impl;

import cn.daliedu.entity.PhoneTypeEntity;
import cn.daliedu.mapper.PhoneTypeMapper;
import cn.daliedu.service.PhoneTypeService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

/**
 * <p>
 * 机型匹配目录表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2020-06-08
 */
@Service
public class PhoneTypeServiceImpl extends ServiceImpl<PhoneTypeMapper, PhoneTypeEntity> implements PhoneTypeService {
	
	@Resource
	PhoneTypeMapper phoneTypeMapper;
	
	@Override
	public PhoneTypeEntity queryPhoneDirectory(String phoneType, Integer androidVersion) {
		return phoneTypeMapper.selectOne(new QueryWrapper<PhoneTypeEntity>().eq("phone_type", phoneType).eq("android_version", androidVersion).last("limit 1"));
	}
	
	
}
