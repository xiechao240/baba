package cn.daliedu.controller.api.console;


import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.ContractEntity;
import cn.daliedu.entity.CustomerDynamicFileEntity;
import cn.daliedu.entity.CustomerEntity;
import cn.daliedu.entity.CustomerTagEntity;
import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.json.ContractJson;
import cn.daliedu.entity.json.ContractModel;
import cn.daliedu.entity.json.CustomerJson;
import cn.daliedu.entity.json.CustomerModel;
import cn.daliedu.entity.json.GlobalJson;
import cn.daliedu.entity.json.OrgJson;
import cn.daliedu.entity.json.UserJson;
import cn.daliedu.entity.web.CustomerContactVO;
import cn.daliedu.entity.web.CustomerTagAndCountVO;
import cn.daliedu.enums.CallTypeEnum;
import cn.daliedu.enums.ContractStateEnum;
import cn.daliedu.enums.CustomerStageEnum;
import cn.daliedu.enums.DynamicTypeEnum;
import cn.daliedu.enums.ReturnMoneyStateEnum;
import cn.daliedu.enums.SexEnum;
import cn.daliedu.enums.UserTypeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.exception.OtherException;
import cn.daliedu.service.ContractReturnMoneyPlanService;
import cn.daliedu.service.ContractService;
import cn.daliedu.service.CustomerCountService;
import cn.daliedu.service.CustomerService;
import cn.daliedu.service.CustomerTagService;
import cn.daliedu.service.OrgService;
import cn.daliedu.service.ReportService;
import cn.daliedu.service.UserCustomerCallService;
import cn.daliedu.service.UserService;
import cn.daliedu.util.BigDecimalUtil;
import cn.daliedu.util.DateUtil;
import cn.daliedu.util.JsonUtil;
import cn.daliedu.util.LocalDateTimeUtil;
import cn.daliedu.util.PageUtil;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import cn.daliedu.util.TimerUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * <p>
 * 报表导出 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2019-10-31
 */
@Api(description = "报表导出所有接口")
@RestController
@RequestMapping("${rest.path}/report")
public class ReportExportController {
	@Autowired
	ReportService reportService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	OrgService orgService;
	
	@Autowired
	ContractService contractService;
	
	@Autowired
	CustomerCountService customerCountService;
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	CustomerTagService customerTagService;
	
	@Autowired
	ContractReturnMoneyPlanService contractReturnMoneyPlanService;
	
	@Autowired
	UserCustomerCallService userCustomerCallService;
	
//	@ApiOperation(value = "导出【客户管理】综合查询获取客户列表")
//	@ApiJsonObject(name = "exportCustomerListByCustomerManage", value = { 
//			@ApiJsonProperty(name = CustomerJson.customerStage),
//			@ApiJsonProperty(name = CustomerJson.customerTagIdList),
//			@ApiJsonProperty(name = OrgJson.branchOrgId),
//			@ApiJsonProperty(name = CustomerJson.followUserId),
//			@ApiJsonProperty(name = CustomerJson.updateStartDate),
//			@ApiJsonProperty(name = CustomerJson.updateEndDate),
//			@ApiJsonProperty(name = GlobalJson.pageNum),
//			@ApiJsonProperty(name = GlobalJson.pageSize)})
//	@ApiImplicitParam(name = "params", required = true, dataType = "exportCustomerListByCustomerManage")
//	@RequiresPermissions("sys:report:customerListByCustomerManage:export")
//	@PostMapping("/exportCustomerListByCustomerManage")
//	public void exportCustomerListByCustomerManage(@RequestBody String params, HttpServletResponse response) {
//		OutputStream os = null;
//		Workbook workbook = null;
//		try {
//			Object object = SecurityUtils.getSubject().getPrincipal();
//			if (object instanceof UserEntity) {
//				UserEntity bean = (UserEntity) object;
//	            
//				System.out.println("params参数为：" + params);
//				
//				JSONObject jsonObject = JSON.parseObject(params);
//				String pageNum = String.valueOf(jsonObject.get("pageNum"));
//				String pageSize = String.valueOf(jsonObject.get("pageSize"));
//				String customerStage = String.valueOf(jsonObject.get("customerStage"));//客户阶段
//				String customerTagIdList = String.valueOf(jsonObject.get("customerTagIdList"));//客户标签集合
//				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));//分校ID
//				String followUserId = String.valueOf(jsonObject.get("followUserId"));
//				String updateStartDate = String.valueOf(jsonObject.get("updateStartDate"));
//				String updateEndDate = String.valueOf(jsonObject.get("updateEndDate"));
//				
//				
//				StringUtil.validateIsNull(pageNum, "请输入页码");
//				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
//				
//	            
//	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
//	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
//	            paramMap.put("pageSize", Integer.parseInt(pageSize));
//	    		
//	            paramMap.put("userId", bean.getId());
//	            paramMap.put("customerStage", customerStage);
//	            paramMap.put("customerTagIdList", customerTagIdList);
//	            paramMap.put("userId", bean.getId());//用来查自己权限范围内的业务组的客户
//	            paramMap.put("followUserId", followUserId);//前端传入的跟进人ID
//	            paramMap.put("updateStartDate", updateStartDate);
//	            paramMap.put("updateEndDate", updateEndDate);
//	            
//	            if(branchOrgId!=null && !branchOrgId.equals("") && !branchOrgId.equals("null")){
//	            	paramMap.put("branchOrgId", branchOrgId);
//	            }else{
//	            	//加载用户当前能访问的分校范围
//	            	paramMap.put("branchOrgId", branchOrgId);
//	            	List<OrgEntity> orgList = orgService.getBranchOrgByUserId(bean.getId());
//	            	if(orgList!=null && orgList.size()>0){
//	            		String orgId = "";
//	    				for(OrgEntity entity : orgList){
//	    					orgId = orgId + "'" + entity.getId() + "'" + ",";
//	    				}
//	    				paramMap.put("branchOrgId", orgId.substring(0, orgId.length()-1));
//	            	}
//	            }
//	            
//	            
//	            List<LinkedHashMap<Object, Object>> list = customerService.getCustomerListByCustomerManage(paramMap);
//	            if(list!=null && list.size()>0){
//	            	//将每个客户的标签添加进去，与创建人加进去
//					for(LinkedHashMap<Object, Object> map : list){
//						//添加客户标签
//						String customerId = map.get("id").toString();
//						List<LinkedHashMap<Object, Object>> customerTagList = customerTagService.getCustomerTagListByCustomerId(customerId);
//	            		if(customerTagList!=null && customerTagList.size()>0){
//	            			map.put("customerTagList", customerTagList);
//	            		}else{
//	            			map.put("customerTagList", "");
//	            		}
//	            		
//	            		//添加 创建人
//						String createUserId = map.get("create_user_id").toString();
//						UserEntity createUser = userService.getById(createUserId);
//						if(createUser!=null){
//							map.put("create_user_name", createUser.getUserName());
//						}
//	            		
//	            		//添加客户所属分校名称，将每个客户的分校加进去，因为有时候客户是没有分校的，不在sql语句里面进行处理
//	            		OrgEntity orgEntity = orgService.getBranchOrgByCustomerId(customerId);
//	            		if(orgEntity!=null){
//	            			map.put("branch_org_name", orgEntity.getOrgName());
//	            		}else{
//	            			map.put("branch_org_name", "");
//	            		}
//	            		
//	            		//添加跟进人所在的部门
//	            		LinkedHashMap<Object, Object> tempMap = userService.getUserNameAndOrgNameByUserId(map.get("follow_user_id").toString());
//	            		map.put("orgName", tempMap.get("orgName").toString());
//	            	}
//				}
//			
//			String fileName = "customer.xls";
//			
//			response.reset();
//			// 设置文件MIME类型
//			response.setContentType("multipart/form-data");
//			// 设置Content-Disposition,下面的为导出xls格式的
//			response.setContentType("application/vnd.ms-excel");//其他自定义的文件如ofd文件采用：application/x-download
//			response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
//			
//			
//			os = response.getOutputStream();
//			
//			// 1、创建工作簿(WritableWorkbook)对象
//			workbook = new XSSFWorkbook();
//		 
//		    // 2、新建工作表(sheet)对象，并声明其属于第几页
//			Sheet customerSheet = workbook.createSheet("客户数据"); // 创建Sheet
//			
//			// 3、创建单元格(Label)对象，
//			//设置列的宽度,注意（POI框架设置宽度需要*256，否则会挤到一列里面去）
//			customerSheet.setColumnWidth(0, 20*256);//客户姓名
//			customerSheet.setColumnWidth(1, 6*256);//性别
//			customerSheet.setColumnWidth(2, 10*256);//来源
//			customerSheet.setColumnWidth(3, 15*256);//微信
//			customerSheet.setColumnWidth(4, 15*256);//QQ
//			customerSheet.setColumnWidth(5, 15*256);//手机
//			customerSheet.setColumnWidth(6, 15*256);//座机（电话）
//			customerSheet.setColumnWidth(7, 20*256);//邮箱
//			customerSheet.setColumnWidth(8, 15*256);//地区：国家
//			customerSheet.setColumnWidth(9, 15*256);//地区：省/州
//			customerSheet.setColumnWidth(10, 15*256);//地区：城市	
//			customerSheet.setColumnWidth(11, 15*256);//地区：区/县
//			customerSheet.setColumnWidth(12, 20*256);//公司
//			customerSheet.setColumnWidth(13, 20*256);//地址
//			customerSheet.setColumnWidth(14, 20*256);//备注	
//			customerSheet.setColumnWidth(15, 10*256);//工作年限
//			customerSheet.setColumnWidth(16, 15*256);//学历	
//			customerSheet.setColumnWidth(17, 20*256);//填写表单页面
//			customerSheet.setColumnWidth(18, 20*256);//专业
//			customerSheet.setColumnWidth(19, 25*256);//分类	
//			customerSheet.setColumnWidth(20, 26*256);//单班	
//			customerSheet.setColumnWidth(21, 26*256);//套班	
//			customerSheet.setColumnWidth(22, 26*256);//内训	
//			customerSheet.setColumnWidth(23, 26*256);//一建科目	
//			customerSheet.setColumnWidth(24, 26*256);//二建科目
//			customerSheet.setColumnWidth(25, 26*256);//造价科目
//			customerSheet.setColumnWidth(26, 26*256);//监理科目	
//			customerSheet.setColumnWidth(27, 26*256);//消防科目	
//			customerSheet.setColumnWidth(28, 26*256);//咨询工程师	
//			customerSheet.setColumnWidth(29, 26*256);//已报同行	
//			customerSheet.setColumnWidth(30, 26*256);//备注2	
//			customerSheet.setColumnWidth(31, 26*256);//一建科目2	
//			customerSheet.setColumnWidth(32, 26*256);//班型名称2	
//			customerSheet.setColumnWidth(33, 26*256);//优惠券
//			customerSheet.setColumnWidth(34, 22*256);//创建时间
//			customerSheet.setColumnWidth(35, 15*256);//客户阶段
//			customerSheet.setColumnWidth(36, 26*256);//标签
//			customerSheet.setColumnWidth(37, 20*256);//跟进人
//			customerSheet.setColumnWidth(38, 20*256);//部门
//			
//			//设置表头列的高度
////			customerSheet.setColumnHidden(0, true);
//
//			Row header = customerSheet.createRow(0);
//			// 创建表头行
//			header.createCell(0).setCellValue("姓名");//姓名	
//			header.createCell(1).setCellValue("性别");//性别
//			header.createCell(2).setCellValue("来源");	//来源	
//			header.createCell(3).setCellValue("微信");//微信
//			header.createCell(4).setCellValue("QQ");//QQ
//			header.createCell(5).setCellValue("手机");//手机	
//			header.createCell(6).setCellValue("座机");//座机（电话）
//			header.createCell(7).setCellValue("邮箱");//邮箱	
//			header.createCell(8).setCellValue("地区：国家");//地区：国家	
//			header.createCell(9).setCellValue("地区：省/州");//地区：省/州	
//			header.createCell(10).setCellValue("地区：城市");//地区：城市	
//			header.createCell(11).setCellValue("地区：区/县");//地区：区/县
//			header.createCell(12).setCellValue("公司");//公司	
//			header.createCell(13).setCellValue("地址");//地址	
//			header.createCell(14).setCellValue("备注");//备注	
//			header.createCell(15).setCellValue("工作年限");//工作年限	
//			header.createCell(16).setCellValue("学历");//学历	
//			header.createCell(17).setCellValue("填写表单页面");//填写表单页面	
//			header.createCell(18).setCellValue("专业");//专业	
//			header.createCell(19).setCellValue("分类");//分类	
//			header.createCell(20).setCellValue("单班");//单班	
//			header.createCell(21).setCellValue("套班");//套班	
//			header.createCell(22).setCellValue("内训");//内训	
//			header.createCell(23).setCellValue("一建科目");//一建科目	
//			header.createCell(24).setCellValue("二建科目");//二建科目	
//			header.createCell(25).setCellValue("造价科目");//造价科目	
//			header.createCell(26).setCellValue("监理科目");//监理科目	
//			header.createCell(27).setCellValue("消防科目");//消防科目	
//			header.createCell(28).setCellValue("咨询工程师");//咨询工程师	
//			header.createCell(29).setCellValue("已报同行");//已报同行	
//			header.createCell(30).setCellValue("备注2");//备注2	
//			header.createCell(31).setCellValue("一建科目2");//一建科目2	
//			header.createCell(32).setCellValue("班型名称2");//班型名称2	
//			header.createCell(33).setCellValue("优惠券");//优惠券	
//			header.createCell(34).setCellValue("创建时间");//创建时间	
//			header.createCell(35).setCellValue("客户阶段");//客户阶段	
//			header.createCell(36).setCellValue("标签");//标签	
//			header.createCell(37).setCellValue("跟进人");//跟进人	
//			header.createCell(38).setCellValue("部门");//部门
//
//		
//			for(int i=0; i<list.size(); i++){
//				LinkedHashMap<Object, Object> map = list.get(i);
//				
//				Row row = customerSheet.createRow(i+1);
//				
//				row.createCell(0).setCellValue(StringUtil.nullValueConvert(map.get("customer_name")));//姓名
//				row.createCell(1).setCellValue(SexEnum.getDesc(StringUtil.nullValueConvert(map.get("sex"))));//性别
////				row.createCell(2).setCellValue(CustomerSourceTypeEnum.getDesc(bean.getCustomerSourceType()));//来源,是指的来源于竞价表单，在线咨询这样的来源，不是代理商与非代理商
//				row.createCell(2).setCellValue(bean.getCustomerSourceName());
//				row.createCell(3).setCellValue(bean.getWeixinId());//微信
//				row.createCell(4).setCellValue(bean.getQq());//QQ
//				row.createCell(5).setCellValue(bean.getMobile());//手机
//				row.createCell(6).setCellValue(bean.getPhone());//座机
//				row.createCell(7).setCellValue(bean.getEmail());//邮箱
//				row.createCell(8).setCellValue("中国");//地区：国家
//				row.createCell(9).setCellValue(bean.getProvinceName());//地区：省/州	
//				row.createCell(10).setCellValue(bean.getCityName());//地区：城市
//				row.createCell(11).setCellValue(bean.getAreaName());//地区：区/县	
//				row.createCell(12).setCellValue(bean.getCompanyName());//公司
//				row.createCell(13).setCellValue(bean.getAddress());//地址
//				row.createCell(14).setCellValue(bean.getRemark());//备注
//				row.createCell(15).setCellValue(bean.getJobAge());//工作年限
//				row.createCell(16).setCellValue(bean.getEducation());//学历
//				row.createCell(17).setCellValue(bean.getCustomerActivityPage());//填写表单页面	
//				row.createCell(18).setCellValue(bean.getProfessional());//专业
//				row.createCell(19).setCellValue(bean.getCustomerActivityTypePage());//分类
//				row.createCell(20).setCellValue("");//单班
//				row.createCell(21).setCellValue("");//套班
//				row.createCell(22).setCellValue("");//内训
//				row.createCell(23).setCellValue("");//一建科目
//				row.createCell(24).setCellValue("");//二建科目
//				row.createCell(25).setCellValue("");//造价科目
//				row.createCell(26).setCellValue("");//监理科目
//				row.createCell(27).setCellValue("");//消防科目	
//				row.createCell(28).setCellValue("");//咨询工程师
//				row.createCell(29).setCellValue("");//已报同行
//				row.createCell(30).setCellValue("");//备注2	
//				row.createCell(31).setCellValue("");//一建科目2
//				row.createCell(32).setCellValue("");//班型名称2	
//				row.createCell(33).setCellValue("");//优惠券	
//				row.createCell(34).setCellValue(LocalDateTimeUtil.getDateTime(bean.getCreateTime(), "yyyy-MM-dd HH:mm:ss"));//创建时间
//				row.createCell(35).setCellValue(CustomerStageEnum.getDesc(bean.getCustomerStage()));//客户阶段	
//				row.createCell(36).setCellValue("");//标签	
//				//获取跟进人及跟进人所在的部门
//				LinkedHashMap<Object, Object> map = userService.getUserNameAndOrgNameByUserId(bean.getFollowUserId());
//				if(map!=null && map.size()>0){
//					row.createCell(37).setCellValue(map.get("userName").toString());//跟进人
//					row.createCell(38).setCellValue(map.get("orgName").toString());//部门
//				}else{
//					row.createCell(37).setCellValue("");//跟进人
//					row.createCell(38).setCellValue("");//部门
//				}
//			}
//
//			// 4、打开流，开始写文件
//			workbook.write(os);
//			os.flush();
//			workbook.close();
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			if (os != null){
//				try {
//					os.close();
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
//			}
//		}
//	}
	
	@ApiOperation(value = "导出【客户标签变化统计】（动态导出未完成）")
	@ApiJsonObject(name = "exportCustomerTagUpdateCount", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.customerTagIds),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "exportCustomerTagUpdateCount")
	@RequiresPermissions("sys:report:customerTagUpdateCount:export")
	@PostMapping("/exportCustomerTagUpdateCount")
	public Result exportCustomerTagUpdateCount(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
				String customerTagIds = String.valueOf(jsonObject.get("customerTagIds"));
				
				StringUtil.validateIsNull(customerTagIds, "请选择客户标签");
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				
				
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            
	            if(branchOrgId!=null && !branchOrgId.equals("") && !branchOrgId.equals("null")){
	            	paramMap.put("branchOrgId", branchOrgId);
	            }else{
	            	//加载用户当前能访问的分校范围
	            	paramMap.put("branchOrgId", branchOrgId);
	            	List<OrgEntity> list = orgService.getBranchOrgByUserId(bean.getId());
	            	if(list!=null && list.size()>0){
	            		String orgId = "";
	    				for(OrgEntity entity : list){
	    					orgId = orgId + "'" + entity.getId() + "'" + ",";
	    				}
	    				paramMap.put("branchOrgId", orgId.substring(0, orgId.length()-1));
	            	}
	            }
	            
	            //客户选择的标签集合
	            List<String> customerTagIdList = JsonUtil.getJsonToList(customerTagIds, String.class);
	           
	            if(customerTagIdList!=null && customerTagIdList.size()>0){
	            	String customerTag = "";
    				for(String str : customerTagIdList){
    					customerTag = customerTag + "'" + str + "'" + ",";
    				}
    				paramMap.put("customerTagIds", customerTag.substring(0, customerTag.length()-1));
	            	
	            	//获取客户标签变化的用户
		            List<LinkedHashMap<Object, Object>> list = userService.getCustomerTagUpdateByUser(paramMap);
		            if(list!=null && list.size()>0){
		            	for(LinkedHashMap<Object, Object> map : list){
		            		List<CustomerTagAndCountVO> tempList = new ArrayList<CustomerTagAndCountVO>();
		            		for(String customerTagId : customerTagIdList){
		            			paramMap.put("userId", map.get("user_id"));
		            			paramMap.put("customerTagId", customerTagId);
		            			Integer customerTagIdCount = userService.getCustomerTagUpdateByCustomerTag(paramMap);
		            			
		            			CustomerTagAndCountVO vo = new CustomerTagAndCountVO();
		            			vo.setCustomerTagId(customerTagId);
		            			vo.setCustomerTagIdCount(customerTagIdCount);
		            			tempList.add(vo);
							}
		            		map.put("tagIdList", tempList);
			            }
		            	
		            	//添加合计这一项
		            	LinkedHashMap<Object, Object> dataCountMap = new LinkedHashMap<Object, Object>();
		            	dataCountMap.put("user_id", "");
		            	dataCountMap.put("user_name", "合计");
		            	
		            	List<CustomerTagAndCountVO> tempList = new ArrayList<CustomerTagAndCountVO>();
		            	for(String customerTagId : customerTagIdList){
	            			paramMap.put("customerTagId", customerTagId);
	            			Integer customerTagIdCount = userService.getCustomerTagUpdateByCustomerTagAllCount(paramMap);
	            			
	            			CustomerTagAndCountVO vo = new CustomerTagAndCountVO();
	            			vo.setCustomerTagId(customerTagId);
	            			vo.setCustomerTagIdCount(customerTagIdCount);
	            			tempList.add(vo);
						}
		            	dataCountMap.put("tagIdList", tempList);
		            	
		            	list.add(dataCountMap);
		            	
		            	return Result.success(list);
		            }else{
		            	return Result.error("当前分校下没有标签变化统计");
		            }
				}else{
					return Result.error("当前分校下没有标签变化统计");
				}
			}
			return Result.error("无法获取分校下的客户标签变化统计列表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("无法获取分校下的客户标签变化统计列表，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "导出【客户活跃度统计报表】")
	@ApiJsonObject(name = "exportCustomerActivenessReport", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime)})
	@ApiImplicitParam(name = "params", required = true, dataType = "exportCustomerActivenessReport")
	@RequiresPermissions("sys:report:customerActiveness:export")
	@PostMapping("/exportCustomerActivenessReport")
	public void exportCustomerActivenessReport(@RequestBody String params, HttpServletResponse response) {
		OutputStream os = null;
		Workbook workbook = null;
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				UserEntity user = userService.getById(bean.getId());
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
				
	            
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            
	            if(branchOrgId!=null && !branchOrgId.equals("") && !branchOrgId.equals("null")){
	            	paramMap.put("branchOrgId", branchOrgId);
	            }else{
	            	//加载用户当前能访问的分校范围
	            	paramMap.put("branchOrgId", branchOrgId);
	            	List<OrgEntity> list = orgService.getBranchOrgByUserId(bean.getId());
	            	if(list!=null && list.size()>0){
	            		String orgId = "";
	    				for(OrgEntity entity : list){
	    					orgId = orgId + "'" + entity.getId() + "'" + ",";
	    				}
	    				paramMap.put("branchOrgId", orgId.substring(0, orgId.length()-1));
	            	}
	            }
	            
	            //如果是admin超级管理员账号，则统计整个公司的客户数，如果是普通管理员，则统计用户能查看的分校范围的客户或指定的某一个分校的客户
	            //这个表格，客户联系次数，需要带上客户的创建时间去统计，所以下面这个参数要改为map,不仅要统计分校，还要统计创建时间
//	            BigDecimal customerAllCount = customerService.getBranchCustomerCount(branchOrgId);
	            BigDecimal customerAllCount = customerService.getBranchCustomerCount(paramMap);
	            
	            //客户联系次数统计list
	            List<CustomerContactVO> contactNumList = new ArrayList<CustomerContactVO>();
	            
	            //1.统计联系1次的客户数
	            paramMap.put("contactNum", 1);
	            BigDecimal num1 = customerService.getCustomerContactCount(paramMap);
	            
	            CustomerContactVO contactNum1 = new CustomerContactVO();
	            contactNum1.setContactName("1次");
	            contactNum1.setCustomerCount(num1);
	            contactNum1.setPercentage(BigDecimalUtil.divide(num1, customerAllCount));
	            
	            //2.统计联系2次的客户数
	            paramMap.put("contactNum", 2);
	            BigDecimal num2 = customerService.getCustomerContactCount(paramMap);
	            
	            CustomerContactVO contactNum2 = new CustomerContactVO();
	            contactNum2.setContactName("2次");
	            contactNum2.setCustomerCount(num2);
	            contactNum2.setPercentage(BigDecimalUtil.divide(num2, customerAllCount));
	            
	            //3.统计联系3次的客户数
	            paramMap.put("contactNum", 3);
	            BigDecimal num3 = customerService.getCustomerContactCount(paramMap);
	            
	            CustomerContactVO contactNum3 = new CustomerContactVO();
	            contactNum3.setContactName("3次");
	            contactNum3.setCustomerCount(num3);
	            contactNum3.setPercentage(BigDecimalUtil.divide(num3, customerAllCount));
	            
	            //4.统计联系4次及以上的客户数
	            paramMap.put("contactNum", 4);
	            BigDecimal num4 = customerService.getCustomerContactCount(paramMap);
	            
	            CustomerContactVO contactNum4 = new CustomerContactVO();
	            contactNum4.setContactName("4次及以上");
	            contactNum4.setCustomerCount(num4);
	            contactNum4.setPercentage(BigDecimalUtil.divide(num4, customerAllCount));
	            
	            //5.统计未联系的客户数
	            BigDecimal num0 = BigDecimalUtil.subtract(customerAllCount, num1, num2, num3, num4);
	            
	            CustomerContactVO contactNum0 = new CustomerContactVO();
	            contactNum0.setContactName("未联系");
	            contactNum0.setCustomerCount(BigDecimalUtil.divide(num0, customerAllCount));
	            contactNum0.setPercentage(BigDecimalUtil.divide(num0, customerAllCount));
	            
	            
	            //6.统计合计的客户数
	            CustomerContactVO contactNumAll = new CustomerContactVO();
	            contactNumAll.setContactName("合计");
	            contactNumAll.setCustomerCount(customerAllCount);
	            contactNumAll.setPercentage(new BigDecimal(1));
	            
	            
	            contactNumList.add(contactNum0);
	            contactNumList.add(contactNum1);
	            contactNumList.add(contactNum2);
	            contactNumList.add(contactNum3);
	            contactNumList.add(contactNum4);
	            contactNumList.add(contactNumAll);
	            
	            
	            //客户最近联系时间统计list
	            List<CustomerContactVO> latelyContactList = new ArrayList<CustomerContactVO>();
	            //去除日期，重新统计客户总数,因为上面的是统计一段时间范围内创建的客户数，再去做统计报表，下面的表格为：统计全分校或全公司的客户
	            paramMap.remove("startDateTime");
	            paramMap.remove("endDateTime");
	            customerAllCount = customerService.getBranchCustomerCount(paramMap);
	           
	            //1.统计7天内联系的客户
	    		paramMap.put("startDateTime", DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-7), "yyyy-MM-dd"));
		        paramMap.put("endDateTime", DateUtil.getCurrentDateString("yyyy-MM-dd"));
		        BigDecimal lately1 = customerService.getLatelyContactCustomerCount(paramMap);
		        
		        CustomerContactVO latelyNum1 = new CustomerContactVO();
		        latelyNum1.setContactName("7天内");
		        latelyNum1.setCustomerCount(lately1);
		        latelyNum1.setPercentage(BigDecimalUtil.divide(lately1, customerAllCount));
		        
	            //2.统计8-30天内联系的客户
		        paramMap.put("startDateTime", DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-30), "yyyy-MM-dd"));
		        paramMap.put("endDateTime", DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-8), "yyyy-MM-dd"));
		        BigDecimal lately2 = customerService.getLatelyContactCustomerCount(paramMap);
		        
		        CustomerContactVO latelyNum2 = new CustomerContactVO();
		        latelyNum2.setContactName("8-30天内");
		        latelyNum2.setCustomerCount(lately2);
		        latelyNum2.setPercentage(BigDecimalUtil.divide(lately2, customerAllCount));
		        
	            //3.统计31-60天内联系的客户
		        paramMap.put("startDateTime", DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-60), "yyyy-MM-dd"));
		        paramMap.put("endDateTime", DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-31), "yyyy-MM-dd"));
		        BigDecimal lately3 = customerService.getLatelyContactCustomerCount(paramMap);
		        
		        CustomerContactVO latelyNum3 = new CustomerContactVO();
		        latelyNum3.setContactName("31-60天内");
		        latelyNum3.setCustomerCount(lately3);
		        latelyNum3.setPercentage(BigDecimalUtil.divide(lately3, customerAllCount));
		        
	            //4.统计60天以上联系的客户
		        paramMap.put("startDateTime", DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-5000), "yyyy-MM-dd"));//开始时间设置一个超大的值，少写一个方法，通用性更强
		        paramMap.put("endDateTime", DateUtil.getDateString(DateUtil.getBeforOrAfterDate(-61), "yyyy-MM-dd"));
		        BigDecimal lately4 = customerService.getLatelyContactCustomerCount(paramMap);
		        
		        CustomerContactVO latelyNum4 = new CustomerContactVO();
		        latelyNum4.setContactName("60天以上");
		        latelyNum4.setCustomerCount(lately4);
		        latelyNum4.setPercentage(BigDecimalUtil.divide(lately4, customerAllCount));
		        
	            //5.统计未联系的客户
		        BigDecimal lately0 = BigDecimalUtil.subtract(customerAllCount, lately1, lately2, lately3, lately4);
		        
		        CustomerContactVO latelyNum0 = new CustomerContactVO();
		        latelyNum0.setContactName("未联系");
		        latelyNum0.setCustomerCount(BigDecimalUtil.divide(lately0, customerAllCount));
		        latelyNum0.setPercentage(BigDecimalUtil.divide(lately0, customerAllCount));
		        
	            //6.统计合计的客户数
		        CustomerContactVO latelyNumAll = new CustomerContactVO();
		        latelyNumAll.setContactName("合计");
		        latelyNumAll.setCustomerCount(customerAllCount);
		        latelyNumAll.setPercentage(new BigDecimal(1));
		        
	            
		        latelyContactList.add(latelyNum1);
		        latelyContactList.add(latelyNum2);
		        latelyContactList.add(latelyNum3);
		        latelyContactList.add(latelyNum4);
		        latelyContactList.add(latelyNum0);
		        latelyContactList.add(latelyNumAll);
	            
	            Map<String, List<CustomerContactVO>> allDataMap = new HashMap<String, List<CustomerContactVO>>();
	            allDataMap.put("contactNumList", contactNumList);
	            allDataMap.put("latelyContactList", latelyContactList);
	            
	            //待写完，这个要把两个导入至一个文件里面去，还需要添加空白的行，隔开
	            
	            String fileName = "customer_activeness_report.xls"; 
				
				response.reset();
				// 设置文件MIME类型
				response.setContentType("multipart/form-data");
				// 设置Content-Disposition,下面的为导出xls格式的
				response.setContentType("application/vnd.ms-excel");//其他自定义的文件如ofd文件采用：application/x-download
				response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
				
				
				os = response.getOutputStream();
				
				
				// 1、创建工作簿(WritableWorkbook)对象
				workbook = new XSSFWorkbook();
			 
			    // 2、新建工作表(sheet)对象，并声明其属于第几页
				Sheet customerSheet = workbook.createSheet("客户活跃度统计"); // 创建Sheet
				
				// 3、创建单元格(Label)对象，
				//设置列的宽度,注意（POI框架设置宽度需要*256，否则会挤到一列里面去）
				
				customerSheet.setColumnWidth(0, 25*256);
				customerSheet.setColumnWidth(1, 25*256);//
				customerSheet.setColumnWidth(2, 20*256);//
				
				//设置表头列的高度
//				customerSheet.setColumnHidden(0, true);

				Row header = customerSheet.createRow(0);
				// 创建表头行
				header.createCell(0).setCellValue("联系次数");
				header.createCell(1).setCellValue("客户数");
				header.createCell(2).setCellValue("百分比");		
				
				for(int i=0; i<contactNumList.size(); i++){
					CustomerContactVO vo = contactNumList.get(i);
					
					Row row = customerSheet.createRow(i+1);
					
					row.createCell(0).setCellValue(StringUtil.nullValueConvert(vo.getContactName()));
					row.createCell(1).setCellValue(StringUtil.nullValueConvert(vo.getCustomerCount()));
					row.createCell(2).setCellValue(StringUtil.nullValueConvert(vo.getPercentage()));
				}
				//???添加一行   客户最近联系时间，然后再循环latelyContactList这个集合，
				//???

				// 4、打开流，开始写文件
				workbook.write(os);
				os.flush();
				workbook.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null){
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	@ApiOperation(value = "导出【工作效率统计】")
	@ApiJsonObject(name = "exportWorkEfficiencyReport", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime),
			@ApiJsonProperty(name = GlobalJson.pageNum), 
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "exportWorkEfficiencyReport")
	@RequiresPermissions("sys:report:workEfficiency:export")
	@PostMapping("/exportWorkEfficiencyReport")
	public void exportWorkEfficiencyReport(@RequestBody String params, HttpServletResponse response) {
		OutputStream os = null;
		Workbook workbook = null;
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				UserEntity user = userService.getById(bean.getId());
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            
	            if(branchOrgId!=null && !branchOrgId.equals("") && !branchOrgId.equals("null")){
	            	paramMap.put("branchOrgId", branchOrgId);
	            }else{
	            	//加载用户当前能访问的分校范围
	            	paramMap.put("branchOrgId", branchOrgId);
	            	List<OrgEntity> list = orgService.getBranchOrgByUserId(bean.getId());
	            	if(list!=null && list.size()>0){
	            		String orgId = "";
	    				for(OrgEntity entity : list){
	    					orgId = orgId + "'" + entity.getId() + "'" + ",";
	    				}
	    				paramMap.put("branchOrgId", orgId.substring(0, orgId.length()-1));
	            	}
	            }
	            
	            List<LinkedHashMap<Object, Object>> list = userService.getAddCustomerCountTopList(paramMap);
	            for(LinkedHashMap<Object, Object> map : list){
	            	//1.把联系客户数添加进来
	            	paramMap.put("userId", map.get("user_id"));
	            	BigDecimal contactCustomerCount = reportService.getContactCustomerCount(paramMap);
	            	map.put("contact_customer_count", contactCustomerCount);
	            	//2.把电话次数添加进来
	            	BigDecimal callCount = reportService.getCallCount(paramMap);
	            	map.put("call_count", callCount);
	            	//3.跟进记录数添加进来(新建客户，修改客户资料不算跟进记录)
	            	BigDecimal followRecoreCount = reportService.getFollowRecoreCount(paramMap);
	            	map.put("follow_recore_count", followRecoreCount);
	            	//4.把总联系次数添加进来
	            	map.put("all_contact_count", BigDecimalUtil.add(callCount, followRecoreCount));
	            }
	            
	            String fileName = "work_efficiency_report.xls"; 
				
				response.reset();
				// 设置文件MIME类型
				response.setContentType("multipart/form-data");
				// 设置Content-Disposition,下面的为导出xls格式的
				response.setContentType("application/vnd.ms-excel");//其他自定义的文件如ofd文件采用：application/x-download
				response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
				
				
				os = response.getOutputStream();
				
				
				// 1、创建工作簿(WritableWorkbook)对象
				workbook = new XSSFWorkbook();
			 
			    // 2、新建工作表(sheet)对象，并声明其属于第几页
				Sheet customerSheet = workbook.createSheet("工作效率统计"); // 创建Sheet
				
				// 3、创建单元格(Label)对象，
				//设置列的宽度,注意（POI框架设置宽度需要*256，否则会挤到一列里面去）
				
				customerSheet.setColumnWidth(0, 25*256);
				customerSheet.setColumnWidth(1, 25*256);//
				customerSheet.setColumnWidth(2, 20*256);//
				customerSheet.setColumnWidth(3, 20*256);//
				customerSheet.setColumnWidth(4, 20*256);//
				customerSheet.setColumnWidth(5, 20*256);//
				
				//设置表头列的高度
//				customerSheet.setColumnHidden(0, true);

				Row header = customerSheet.createRow(0);
				// 创建表头行
				header.createCell(0).setCellValue("姓名");
				header.createCell(1).setCellValue("新增客户");
				header.createCell(2).setCellValue("联系客户");		
				header.createCell(3).setCellValue("电话");
				header.createCell(4).setCellValue("跟进记录数");
				header.createCell(5).setCellValue("总联系次数");
				
				for(int i=0; i<list.size(); i++){
					LinkedHashMap<Object, Object> map = list.get(i);
					
					Row row = customerSheet.createRow(i+1);
					
					row.createCell(0).setCellValue(StringUtil.nullValueConvert(map.get("user_name")));
					row.createCell(1).setCellValue(StringUtil.nullValueConvert(map.get("add_customer_count")));
					row.createCell(2).setCellValue(StringUtil.nullValueConvert(map.get("contact_customer_count")));
					row.createCell(3).setCellValue(StringUtil.nullValueConvert(map.get("call_count")));
					row.createCell(4).setCellValue(StringUtil.nullValueConvert(map.get("follow_recore_count")));
					row.createCell(5).setCellValue(StringUtil.nullValueConvert(map.get("all_contact_count")));
				}

				// 4、打开流，开始写文件
				workbook.write(os);
				os.flush();
				workbook.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null){
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	@ApiOperation(value = "导出【电话联系统计】")
	@ApiJsonObject(name = "exportCallContactDetailCount", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime)})
	@ApiImplicitParam(name = "params", required = true, dataType = "exportCallContactDetailCount")
	@RequiresPermissions("sys:report:callContactDetailCount:export")
	@PostMapping("/exportCallContactDetailCount")
	public void exportCallContactDetailCount(@RequestBody String params, HttpServletResponse response) {
		OutputStream os = null;
		Workbook workbook = null;
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				UserEntity user = userService.getById(bean.getId());
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
				
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            
	            if(branchOrgId!=null && !branchOrgId.equals("") && !branchOrgId.equals("null")){
	            	paramMap.put("branchOrgId", branchOrgId);
	            }else{
	            	//加载用户当前能访问的分校范围
	            	paramMap.put("branchOrgId", branchOrgId);
	            	List<OrgEntity> list = orgService.getBranchOrgByUserId(bean.getId());
	            	if(list!=null && list.size()>0){
	            		String orgId = "";
	    				for(OrgEntity entity : list){
	    					orgId = orgId + "'" + entity.getId() + "'" + ",";
	    				}
	    				paramMap.put("branchOrgId", orgId.substring(0, orgId.length()-1));
	            	}
	            }
	            
	            List<LinkedHashMap<Object, Object>> dataList = new ArrayList<LinkedHashMap<Object, Object>>();
	            
	            if(startDateTime.equals(endDateTime)){
	            	List<LinkedHashMap<Object, Object>> list = userService.getCallContactDetailCount(paramMap);
		            if(list!=null && list.size()>0){
		            	for(LinkedHashMap<Object, Object> map : list){
			            	//添加联系人数属性
			            	Integer contactCustomerCount = userService.getCallContactCustomerCount(paramMap);
			            	map.put("contact_customer_count", contactCustomerCount);
			            	map.put("date", startDateTime);
			            	
			            	TimerUtil tt = new TimerUtil();	
		            		tt.setSeconds(Integer.valueOf(map.get("call_time").toString()));//秒数
		            		String callTime = tt.getMinutes() + "分" + tt.getSeconds() + "秒";
		            		map.put("call_time", callTime);
			            }
		            	
		            	//添加合计这一项
		            	LinkedHashMap<Object, Object> dataCountMap = new LinkedHashMap<Object, Object>();
		            	
		            	List<LinkedHashMap<Object, Object>> dataCountList = userService.getCallContactDetailCount(paramMap);
		            	for(LinkedHashMap<Object, Object> map : dataCountList){
		            		TimerUtil tt = new TimerUtil();	
		            		tt.setSeconds(Integer.valueOf(map.get("call_time").toString()));//秒数
		            		String callTime = tt.getMinutes() + "分" + tt.getSeconds() + "秒";
		            		
		            		dataCountMap.put("success_rate", map.get("success_rate"));
		            		dataCountMap.put("call_time", callTime);
		            		dataCountMap.put("call_count", map.get("call_count"));
		            		dataCountMap.put("call_count_success", map.get("call_count_success"));
		            		dataCountMap.put("call_avg_time", map.get("call_avg_time"));
		            	}
		            	Integer contactCustomerCount = userService.getCallContactCustomerCount(paramMap);
		            	dataCountMap.put("contact_customer_count", contactCustomerCount);
		            	dataCountMap.put("date", "合计");
		            	
		            	list.add(dataCountMap);
		            	
		            	dataList = list;
		            }
	            }else{
	            	List<String> dateList = DateUtil.getDatesBetweenTwoDate(startDateTime, endDateTime);
		            for(String date : dateList){
		            	paramMap.put("startDateTime", date);
			            paramMap.put("endDateTime", date);
		            	List<LinkedHashMap<Object, Object>> list = userService.getCallContactDetailCount(paramMap);
		            	
			            if(list!=null && list.size()>0){
			            	for(LinkedHashMap<Object, Object> map : list){
				            	//添加联系人数属性
				            	Integer contactCustomerCount = userService.getCallContactCustomerCount(paramMap);
				            	map.put("contact_customer_count", contactCustomerCount);
				            	map.put("date", date);
				            	dataList.add(map);
				            	
				            	TimerUtil tt = new TimerUtil();	
			            		tt.setSeconds(Integer.valueOf(map.get("call_time").toString()));//秒数
			            		String callTime = tt.getMinutes() + "分" + tt.getSeconds() + "秒";
			            		map.put("call_time", callTime);
				            }
			            }
		            }
		            
		            paramMap.put("startDateTime", startDateTime);
		            paramMap.put("endDateTime", endDateTime);
	            	//添加合计这一项
	            	LinkedHashMap<Object, Object> dataCountMap = new LinkedHashMap<Object, Object>();
	            	
	            	List<LinkedHashMap<Object, Object>> list = userService.getCallContactDetailCount(paramMap);
	            	for(LinkedHashMap<Object, Object> map : list){
	            		TimerUtil tt = new TimerUtil();	
	            		tt.setSeconds(Integer.valueOf(map.get("call_time").toString()));//秒数
	            		String callTime = tt.getMinutes() + "分" + tt.getSeconds() + "秒";
	            		
	            		dataCountMap.put("success_rate", map.get("success_rate"));
	            		dataCountMap.put("call_time", callTime);
	            		dataCountMap.put("call_count", map.get("call_count"));
	            		dataCountMap.put("call_count_success", map.get("call_count_success"));
	            		dataCountMap.put("call_avg_time", map.get("call_avg_time"));
	            	}
	            	Integer contactCustomerCount = userService.getCallContactCustomerCount(paramMap);
	            	dataCountMap.put("contact_customer_count", contactCustomerCount);
	            	dataCountMap.put("date", "合计");
	            	
	            	dataList.add(dataCountMap);
	            }
	            
	            String fileName = "call_contact_detail_count.xls"; 
				
				response.reset();
				// 设置文件MIME类型
				response.setContentType("multipart/form-data");
				// 设置Content-Disposition,下面的为导出xls格式的
				response.setContentType("application/vnd.ms-excel");//其他自定义的文件如ofd文件采用：application/x-download
				response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
				
				
				os = response.getOutputStream();
				
				
				// 1、创建工作簿(WritableWorkbook)对象
				workbook = new XSSFWorkbook();
			 
			    // 2、新建工作表(sheet)对象，并声明其属于第几页
				Sheet customerSheet = workbook.createSheet("电话联系统计"); // 创建Sheet
				
				// 3、创建单元格(Label)对象，
				//设置列的宽度,注意（POI框架设置宽度需要*256，否则会挤到一列里面去）
				
				customerSheet.setColumnWidth(0, 25*256);
				customerSheet.setColumnWidth(1, 25*256);//
				customerSheet.setColumnWidth(2, 20*256);//
				customerSheet.setColumnWidth(3, 20*256);//
				customerSheet.setColumnWidth(4, 20*256);//
				customerSheet.setColumnWidth(5, 20*256);//
				
				//设置表头列的高度
//				customerSheet.setColumnHidden(0, true);

				Row header = customerSheet.createRow(0);
				// 创建表头行
				header.createCell(0).setCellValue("时间");
				header.createCell(1).setCellValue("接通率");
				header.createCell(2).setCellValue("通话时长");		
				header.createCell(3).setCellValue("拨打次数");
				header.createCell(4).setCellValue("平均通话时长");
				header.createCell(5).setCellValue("联系人数");
				
				for(int i=0; i<dataList.size(); i++){
					LinkedHashMap<Object, Object> map = dataList.get(i);
					
					Row row = customerSheet.createRow(i+1);
					
					row.createCell(0).setCellValue(StringUtil.nullValueConvert(map.get("date")));
					row.createCell(1).setCellValue(StringUtil.nullValueConvert(map.get("success_rate")));
					row.createCell(2).setCellValue(StringUtil.nullValueConvert(map.get("call_time")));
					row.createCell(3).setCellValue(StringUtil.nullValueConvert(map.get("call_count")));
					row.createCell(4).setCellValue(StringUtil.nullValueConvert(map.get("call_avg_time")));
					row.createCell(5).setCellValue(StringUtil.nullValueConvert(map.get("contact_customer_count")));
				}

				// 4、打开流，开始写文件
				workbook.write(os);
				os.flush();
				workbook.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null){
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	
	@ApiOperation(value = "导出【客户数量统计报表】,原型上暂时没有导出功能，此接口暂不调用")
	@ApiJsonObject(name = "exportCustomerCountList", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = UserJson.userId),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime)})
	@ApiImplicitParam(name = "params", required = true, dataType = "exportCustomerCountList")
	@RequiresPermissions("sys:report:customerCount:export")
	@PostMapping("/exportCustomerCountList")
	public void exportCustomerCountList(@RequestBody String params, HttpServletResponse response) {
		OutputStream os = null;
		Workbook workbook = null;
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
				UserEntity user = userService.getById(bean.getId());
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
				String userId = String.valueOf(jsonObject.get("userId"));
				
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            paramMap.put("userId", userId);
	            
	            if(branchOrgId!=null && !branchOrgId.equals("") && !branchOrgId.equals("null")){
	            	paramMap.put("branchOrgId", branchOrgId);
	            }else{
	            	//加载用户当前所在的分校
	            	OrgEntity orgEntity = orgService.getUserBranchOrgByOrgId(user.getOrgId());
	            	paramMap.put("branchOrgId", orgEntity.getId());
	            }
	            
	            
	            List<LinkedHashMap<Object, Object>> list = new ArrayList<LinkedHashMap<Object, Object>>();
	            List<String> dateList = DateUtil.getDatesBetweenTwoDate(startDateTime, endDateTime); //使用这种方式来统计
	            if(userId!=null && !userId.equals("") && !userId.equals("null")){
	            	paramMap.put("userId", userId);
	            	paramMap.put("dataType", "2");
	            	for(String date : dateList){
		            	LinkedHashMap<Object, Object> map = new LinkedHashMap<Object, Object>();
		            	
		            	paramMap.put("startDateTime", date);
			            paramMap.put("endDateTime", date);
			            paramMap.put("date", date);
			            
		            	//1.统计新增的客户数量
		            	BigDecimal createCustomerCount = customerService.getCreateCustomerCountByUser(paramMap);
		            	//2.统计流失的客户数量
		            	BigDecimal lossCustomerCount = customerService.getLossCustomerCountByUser(paramMap);
		            	//3.统计客户总数(分为统计用户的，统计分校的)
		            	Integer customerCount = customerCountService.getCustomerCountByScheduled(paramMap);
		            	if(customerCount==null){
		            		customerCount = 0;
		            	}
		            	map.put("date", date);
		            	map.put("createCustomerCount", createCustomerCount);
		            	map.put("lossCustomerCount", lossCustomerCount);
		            	map.put("customerCount", customerCount);
		            	
		            	list.add(map);
		            }
	        	}else{
	        		for(String date : dateList){
		            	LinkedHashMap<Object, Object> map = new LinkedHashMap<Object, Object>();
		            	
		            	paramMap.put("startDateTime", date);
			            paramMap.put("endDateTime", date);
			            paramMap.put("date", date);
		            	paramMap.put("dataType", "1");
		            	
		            	//1.统计新增的客户数量
		            	BigDecimal createCustomerCount = customerService.getCreateCustomerCountByBranch(paramMap);
		            	//2.统计流失的客户数量
		            	BigDecimal lossCustomerCount = customerService.getLossCustomerCountByBranch(paramMap);
		            	//3.统计客户总数(分为统计用户的，统计分校的)
		            	Integer customerCount = customerCountService.getCustomerCountByScheduled(paramMap);
		            	if(customerCount==null){
		            		customerCount = 0;
		            	}
		            	map.put("date", date);
		            	map.put("createCustomerCount", createCustomerCount);
		            	map.put("lossCustomerCount", lossCustomerCount);
		            	map.put("customerCount", customerCount);
		            	
		            	list.add(map);
		            }
	        	}
	            
	            String fileName = "customer_count_list.xls"; 
				
				response.reset();
				// 设置文件MIME类型
				response.setContentType("multipart/form-data");
				// 设置Content-Disposition,下面的为导出xls格式的
				response.setContentType("application/vnd.ms-excel");//其他自定义的文件如ofd文件采用：application/x-download
				response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
				
				
				os = response.getOutputStream();
				
				
				// 1、创建工作簿(WritableWorkbook)对象
				workbook = new XSSFWorkbook();
			 
			    // 2、新建工作表(sheet)对象，并声明其属于第几页
				Sheet customerSheet = workbook.createSheet("客户数量统计"); // 创建Sheet
				
				// 3、创建单元格(Label)对象，
				//设置列的宽度,注意（POI框架设置宽度需要*256，否则会挤到一列里面去）
				
				customerSheet.setColumnWidth(0, 25*256);
				customerSheet.setColumnWidth(1, 25*256);//
				customerSheet.setColumnWidth(2, 20*256);//
				customerSheet.setColumnWidth(3, 20*256);//
				customerSheet.setColumnWidth(4, 20*256);//
				
				//设置表头列的高度
//				customerSheet.setColumnHidden(0, true);

				Row header = customerSheet.createRow(0);
				// 创建表头行
				header.createCell(0).setCellValue("日期");
				header.createCell(1).setCellValue("新增客户数");
				header.createCell(2).setCellValue("流失客户数");		
				header.createCell(3).setCellValue("客户总数");
				
				for(int i=0; i<list.size(); i++){
					LinkedHashMap<Object, Object> map = list.get(i);
					
					Row row = customerSheet.createRow(i+1);
					
					row.createCell(0).setCellValue(StringUtil.nullValueConvert(map.get("date")));
					row.createCell(1).setCellValue(StringUtil.nullValueConvert(map.get("createCustomerCount")));
					row.createCell(2).setCellValue(StringUtil.nullValueConvert(map.get("lossCustomerCount")));
					row.createCell(3).setCellValue(StringUtil.nullValueConvert(map.get("customerCount")));
				}

				// 4、打开流，开始写文件
				workbook.write(os);
				os.flush();
				workbook.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null){
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	@ApiOperation(value = "导出【员工联系记录】")
	@ApiJsonObject(name = "exportCallContactRecord", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.customerNameOrMobile),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "exportCallContactRecord")
	@RequiresPermissions("sys:report:callContactRecord:export")
	@PostMapping("/exportCallContactRecord")
	public void exportCallContactRecord(@RequestBody String params, HttpServletResponse response) {
		OutputStream os = null;
		Workbook workbook = null;
		try {
			UserEntity bean = (UserEntity) SecurityUtils.getSubject().getPrincipal();
			
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
			String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
			String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
			String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
			String customerNameOrMobile = String.valueOf(jsonObject.get("customerNameOrMobile"));
			
//			pageNum = "1";  还是前端传比较好，可以动态控制导出多少条
//			pageSize = "100000"; //共用后端的方法，所以将此参数设置为10万条，以后数据量达到万级，再来优化此导出接口
			
			Map<Object, Object> paramMap = new HashMap<Object, Object>();
            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
            paramMap.put("pageSize", Integer.parseInt(pageSize));
            paramMap.put("startDateTime", startDateTime);
            paramMap.put("endDateTime", endDateTime);
            paramMap.put("customerNameOrMobile", customerNameOrMobile);
            
            if(branchOrgId!=null && !branchOrgId.equals("") && !branchOrgId.equals("null")){
            	paramMap.put("branchOrgId", branchOrgId);
            }else{
            	//加载用户当前能访问的分校范围
            	paramMap.put("branchOrgId", branchOrgId);
            	List<OrgEntity> list = orgService.getBranchOrgByUserId(bean.getId());
            	if(list!=null && list.size()>0){
            		String orgId = "";
    				for(OrgEntity entity : list){
    					orgId = orgId + "'" + entity.getId() + "'" + ",";
    				}
    				paramMap.put("branchOrgId", orgId.substring(0, orgId.length()-1));
            	}
            }
            
            
            List<LinkedHashMap<Object, Object>> list = userCustomerCallService.getCallContactRecordList(paramMap);
            if(list!=null && list.size()>0){
            	for(LinkedHashMap<Object, Object> map : list){
            		String startTime = map.get("start_time").toString();
            		map.put("start_time", LocalDateTimeUtil.getDateTime(startTime));
            	}
			}
            
            String fileName = "call_contact_record.xls"; 
			
			response.reset();
			// 设置文件MIME类型
			response.setContentType("multipart/form-data");
			// 设置Content-Disposition,下面的为导出xls格式的
			response.setContentType("application/vnd.ms-excel");//其他自定义的文件如ofd文件采用：application/x-download
			response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
			
			
			os = response.getOutputStream();
			
			
			// 1、创建工作簿(WritableWorkbook)对象
			workbook = new XSSFWorkbook();
		 
		    // 2、新建工作表(sheet)对象，并声明其属于第几页
			Sheet customerSheet = workbook.createSheet("员工联系记录"); // 创建Sheet
			
			// 3、创建单元格(Label)对象，
			//设置列的宽度,注意（POI框架设置宽度需要*256，否则会挤到一列里面去）
			
			customerSheet.setColumnWidth(0, 25*256);
			customerSheet.setColumnWidth(1, 25*256);//
			customerSheet.setColumnWidth(2, 20*256);//
			customerSheet.setColumnWidth(3, 20*256);//
			customerSheet.setColumnWidth(4, 20*256);//
			customerSheet.setColumnWidth(5, 20*256);//
			
			//设置表头列的高度
//			customerSheet.setColumnHidden(0, true);

			Row header = customerSheet.createRow(0);
			// 创建表头行
			header.createCell(0).setCellValue("联系时间");
			header.createCell(1).setCellValue("电话号码");
			header.createCell(2).setCellValue("联系人");		
			header.createCell(3).setCellValue("通话时长");
			header.createCell(4).setCellValue("通话方式");
			header.createCell(5).setCellValue("员工");
			
			for(int i=0; i<list.size(); i++){
				LinkedHashMap<Object, Object> map = list.get(i);
				
				Row row = customerSheet.createRow(i+1);
				
				row.createCell(0).setCellValue(StringUtil.nullValueConvert(map.get("start_time")));
				row.createCell(1).setCellValue(StringUtil.nullValueConvert(map.get("call_number")));
				row.createCell(2).setCellValue(StringUtil.nullValueConvert(map.get("customer_name")));
				row.createCell(3).setCellValue(StringUtil.nullValueConvert(map.get("call_time")));
				row.createCell(4).setCellValue(CallTypeEnum.getDesc(StringUtil.nullValueConvert(map.get("call_type"))));
				row.createCell(5).setCellValue(StringUtil.nullValueConvert(map.get("user_name")));
			}

			// 4、打开流，开始写文件
			workbook.write(os);
			os.flush();
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null){
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	
	@ApiOperation(value = "导出【电话排名】电话联系统计表")
	@ApiJsonObject(name = "exportCallRankingByContact", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "exportCallRankingByContact")
	@RequiresPermissions("sys:report:callRanking:export")
	@PostMapping("/exportCallRankingByContact")
	public void exportCallRankingByContact(@RequestBody String params, HttpServletResponse response) {
		OutputStream os = null;
		Workbook workbook = null;
		try {
			Object object = SecurityUtils.getSubject().getPrincipal();
			UserEntity bean = (UserEntity) object;
			
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
			String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
			String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
			String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
			
			StringUtil.validateIsNull(pageNum, "请输入页码");
			StringUtil.validateIsNull(pageSize, "请输入每页记录数");
			
            
            Map<Object, Object> paramMap = new HashMap<Object, Object>();
            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
            paramMap.put("pageSize", Integer.parseInt(pageSize));
    		
            paramMap.put("userId", bean.getId());
            paramMap.put("startDateTime", startDateTime);
            paramMap.put("endDateTime", endDateTime);
            paramMap.put("oderbyParam", "call_time");
            
            if(branchOrgId!=null && !branchOrgId.equals("") && !branchOrgId.equals("null")){
            	paramMap.put("branchOrgId", branchOrgId);
            }else{
            	//加载用户当前能访问的分校范围
            	paramMap.put("branchOrgId", branchOrgId);
            	List<OrgEntity> list = orgService.getBranchOrgByUserId(bean.getId());
            	if(list!=null && list.size()>0){
            		String orgId = "";
    				for(OrgEntity entity : list){
    					orgId = orgId + "'" + entity.getId() + "'" + ",";
    				}
    				paramMap.put("branchOrgId", orgId.substring(0, orgId.length()-1));
            	}
            }
            
            
            List<LinkedHashMap<Object, Object>> list = userService.getCallRankingByContactList(paramMap);
            
            String fileName = "contract_return_money.xls"; 
			
			response.reset();
			// 设置文件MIME类型
			response.setContentType("multipart/form-data");
			// 设置Content-Disposition,下面的为导出xls格式的
			response.setContentType("application/vnd.ms-excel");//其他自定义的文件如ofd文件采用：application/x-download
			response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
			
			
			os = response.getOutputStream();
			
			
			// 1、创建工作簿(WritableWorkbook)对象
			workbook = new XSSFWorkbook();
		 
		    // 2、新建工作表(sheet)对象，并声明其属于第几页
			Sheet customerSheet = workbook.createSheet("电话联系统计"); // 创建Sheet
			
			// 3、创建单元格(Label)对象，
			//设置列的宽度,注意（POI框架设置宽度需要*256，否则会挤到一列里面去）
			
			customerSheet.setColumnWidth(0, 25*256);
			customerSheet.setColumnWidth(1, 25*256);//
			customerSheet.setColumnWidth(2, 20*256);//
			customerSheet.setColumnWidth(3, 20*256);//
			customerSheet.setColumnWidth(4, 20*256);//
			
			//设置表头列的高度
//			customerSheet.setColumnHidden(0, true);

			Row header = customerSheet.createRow(0);
			// 创建表头行
			header.createCell(0).setCellValue("名称");
			header.createCell(1).setCellValue("接通率");
			header.createCell(2).setCellValue("通话时长");		
			header.createCell(3).setCellValue("拨打次数");
			header.createCell(4).setCellValue("平均通话时长");
			
			for(int i=0; i<list.size(); i++){
				LinkedHashMap<Object, Object> map = list.get(i);
				
				Row row = customerSheet.createRow(i+1);
				
				TimerUtil tt = new TimerUtil();	
        		tt.setSeconds(Integer.valueOf(map.get("call_time").toString()));//秒数
        		String callTime = tt.getMinutes() + "分" + tt.getSeconds() + "秒";
				
				row.createCell(0).setCellValue(StringUtil.nullValueConvert(map.get("user_name")));
				row.createCell(1).setCellValue(StringUtil.nullValueConvert(map.get("success_rate")));
				row.createCell(2).setCellValue(callTime);//通话时长
				row.createCell(3).setCellValue(StringUtil.nullValueConvert(map.get("call_count")));
				row.createCell(4).setCellValue(StringUtil.nullValueConvert(map.get("call_avg_time")));
			}

			// 4、打开流，开始写文件
			workbook.write(os);
			os.flush();
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null){
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	
	@ApiOperation(value = "导出【合同回款金额统计】，用户下的销售统计（当getContractReturnMoneyListBybranchOrgId接口返回的returnType为2时调用此接口）")
	@ApiJsonObject(name = "exportContractReturnMoneyListByUserId", value = { 
			@ApiJsonProperty(name = UserJson.userId),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "exportContractReturnMoneyListByUserId")
	@RequiresPermissions("sys:report:contractReturnMoneyList:export")
	@PostMapping("/exportContractReturnMoneyListByUserId")
	public void exportContractReturnMoneyListByUserId(@RequestBody String params, HttpServletResponse response) {
		OutputStream os = null;
		Workbook workbook = null;
		try {
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
			String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
			String userId = String.valueOf(jsonObject.get("userId"));
			
			StringUtil.validateIsNull(userId, "请输入用户ID");
			
//			pageNum = "1";  还是前端传比较好，可以动态控制导出多少条
//			pageSize = "100000"; //共用后端的方法，所以将此参数设置为10万条，以后数据量达到万级，再来优化此导出接口
			
			Map<Object, Object> paramMap = new HashMap<Object, Object>();
            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
            paramMap.put("pageSize", Integer.parseInt(pageSize));
            paramMap.put("startDateTime", startDateTime);
            paramMap.put("endDateTime", endDateTime);
            paramMap.put("userId", userId);
            
            
            List<LinkedHashMap<Object, Object>> list =  contractService.getContractListByUserId(paramMap);
            for(LinkedHashMap<Object, Object> map : list){
            	String contractId = map.get("id").toString();
            	HashMap<Object, Object> contractReturnMoneyMap = reportService.findContractReturnMoneyCount(contractId);
				map.put("returnType", "5");//返回返回用户下的所有合同统计结果
				if(contractReturnMoneyMap!=null && contractReturnMoneyMap.size()>0){
					String str = StringUtil.nullValueConvert(contractReturnMoneyMap.get("already_return_money"));
					map.put("alreadyReturnMoney", str.equals("") ? 0 : str);
					map.put("noReturnMoney", contractReturnMoneyMap.get("no_return_money"));
				}else{
					map.put("alreadyReturnMoney", "0");
					map.put("noReturnMoney", "0");
				}
            }
            
            String fileName = "contract_return_money.xls"; 
			
			response.reset();
			// 设置文件MIME类型
			response.setContentType("multipart/form-data");
			// 设置Content-Disposition,下面的为导出xls格式的
			response.setContentType("application/vnd.ms-excel");//其他自定义的文件如ofd文件采用：application/x-download
			response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
			
			
			os = response.getOutputStream();
			
			
			// 1、创建工作簿(WritableWorkbook)对象
			workbook = new XSSFWorkbook();
		 
		    // 2、新建工作表(sheet)对象，并声明其属于第几页
			Sheet customerSheet = workbook.createSheet("回款统计"); // 创建Sheet
			
			// 3、创建单元格(Label)对象，
			//设置列的宽度,注意（POI框架设置宽度需要*256，否则会挤到一列里面去）
			
			customerSheet.setColumnWidth(0, 25*256);
			customerSheet.setColumnWidth(1, 25*256);//
			customerSheet.setColumnWidth(2, 20*256);//
			customerSheet.setColumnWidth(3, 20*256);//
			customerSheet.setColumnWidth(4, 20*256);//
			
			//设置表头列的高度
//			customerSheet.setColumnHidden(0, true);

			Row header = customerSheet.createRow(0);
			// 创建表头行
			header.createCell(0).setCellValue("合同标题");
			header.createCell(1).setCellValue("客户名");
			header.createCell(2).setCellValue("合同总金额");		
			header.createCell(3).setCellValue("已回款金额");
			header.createCell(4).setCellValue("未回款金额");
			
			for(int i=0; i<list.size(); i++){
				LinkedHashMap<Object, Object> map = list.get(i);
				
				Row row = customerSheet.createRow(i+1);
				
				row.createCell(0).setCellValue(StringUtil.nullValueConvert(map.get("title")));
				row.createCell(1).setCellValue(StringUtil.nullValueConvert(map.get("customerName")));
				row.createCell(2).setCellValue(StringUtil.nullValueConvert(map.get("amount")));
				row.createCell(3).setCellValue(StringUtil.nullValueConvert(map.get("alreadyReturnMoney")));
				row.createCell(4).setCellValue(StringUtil.nullValueConvert(map.get("noReturnMoney")));
			}

			// 4、打开流，开始写文件
			workbook.write(os);
			os.flush();
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null){
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	
	@ApiOperation(value = "导出【合同回款金额统计】，部门下的用户销售统计（当getContractReturnMoneyListBybranchOrgId接口返回的returnType为2时调用此接口）")
	@ApiJsonObject(name = "exportContractReturnMoneyListByOrgId", value = { 
			@ApiJsonProperty(name = OrgJson.orgId),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime)})
	@ApiImplicitParam(name = "params", required = true, dataType = "exportContractReturnMoneyListByOrgId")
	@RequiresPermissions("sys:report:contractReturnMoneyList:export")
	@PostMapping("/exportContractReturnMoneyListByOrgId")
	public void exportContractReturnMoneyListByOrgId(@RequestBody String params, HttpServletResponse response) {
		OutputStream os = null;
		Workbook workbook = null;
		try {
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
			String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
			String orgId = String.valueOf(jsonObject.get("orgId"));
			
			StringUtil.validateIsNull(orgId, "请输入部门ID");
			

			Map<Object, Object> paramMap = new HashMap<Object, Object>();
            paramMap.put("startDateTime", startDateTime);
            paramMap.put("endDateTime", endDateTime);
            paramMap.put("orgId", orgId);
            
            OrgEntity orgEntity = orgService.getById(orgId);
            OrgEntity branchEntity =  orgService.getUserBranchOrgByOrgId(orgId);
            List<LinkedHashMap<Object, Object>> list = new ArrayList<LinkedHashMap<Object, Object>>();
            
            List<UserEntity> userList = userService.getUserListByOrgId(orgId);
        	//按用户统计每个用户的销售情况
        	for(UserEntity entity : userList){
        		LinkedHashMap<Object, Object> map = new LinkedHashMap<Object, Object>();
				map.put("userId", entity.getId());
				map.put("userName", entity.getUserName());
				map.put("returnType", "4");//返回部门下的用户合同统计结果
				
				//统计合同数，合同总金额
				HashMap<Object, Object> contractCountMap = reportService.findUserIdContractCount(paramMap);
				if(contractCountMap!=null && contractCountMap.size()>0 && Integer.parseInt(contractCountMap.get("contract_count").toString())>0){
					map.put("contractCount", contractCountMap.get("contract_count"));
					map.put("amount", contractCountMap.get("amount"));
				}else{
					map.put("contractCount", "0");
					map.put("amount", "0");
				}
				
				//已回款金额，未回款金额
				HashMap<Object, Object> contractReturnMoneyMap = reportService.findUserIdContractReturnMoneyCount(paramMap);
				if(contractReturnMoneyMap!=null && contractReturnMoneyMap.size()>0){
					String str = StringUtil.nullValueConvert(contractReturnMoneyMap.get("already_return_money"));
					map.put("alreadyReturnMoney", str.equals("") ? 0 : str);
					map.put("noReturnMoney", contractReturnMoneyMap.get("no_return_money"));
				}else{
					map.put("alreadyReturnMoney", "0");
					map.put("noReturnMoney", "0");
				}
				
				list.add(map);
        	}
            
            String fileName = "contract_return_money.xls"; 
			
			response.reset();
			// 设置文件MIME类型
			response.setContentType("multipart/form-data");
			// 设置Content-Disposition,下面的为导出xls格式的
			response.setContentType("application/vnd.ms-excel");//其他自定义的文件如ofd文件采用：application/x-download
			response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
			
			
			os = response.getOutputStream();
			
			
			// 1、创建工作簿(WritableWorkbook)对象
			workbook = new XSSFWorkbook();
		 
		    // 2、新建工作表(sheet)对象，并声明其属于第几页
			Sheet customerSheet = workbook.createSheet("回款统计"); // 创建Sheet
			
			// 3、创建单元格(Label)对象，
			//设置列的宽度,注意（POI框架设置宽度需要*256，否则会挤到一列里面去）
			
			customerSheet.setColumnWidth(0, 25*256);
			customerSheet.setColumnWidth(1, 25*256);//
			customerSheet.setColumnWidth(2, 20*256);//合同数
			customerSheet.setColumnWidth(3, 20*256);//合同总金额
			customerSheet.setColumnWidth(4, 20*256);//已回款金额
			customerSheet.setColumnWidth(5, 20*256);//未回款金额
			customerSheet.setColumnWidth(6, 25*256);
			
			//设置表头列的高度
//			customerSheet.setColumnHidden(0, true);

			Row header = customerSheet.createRow(0);
			// 创建表头行
			header.createCell(0).setCellValue("分校");
			header.createCell(1).setCellValue("部门");
			header.createCell(2).setCellValue("员工");
			header.createCell(3).setCellValue("合同数");
			header.createCell(4).setCellValue("合同总金额");		
			header.createCell(5).setCellValue("已回款金额");
			header.createCell(6).setCellValue("未回款金额");
			
			for(int i=0; i<list.size(); i++){
				LinkedHashMap<Object, Object> map = list.get(i);
				
				Row row = customerSheet.createRow(i+1);
				
				row.createCell(0).setCellValue(StringUtil.nullValueConvert(branchEntity.getOrgName()));
				row.createCell(1).setCellValue(StringUtil.nullValueConvert(orgEntity.getOrgName()));
				row.createCell(2).setCellValue(StringUtil.nullValueConvert(map.get("userName")));
				row.createCell(3).setCellValue(StringUtil.nullValueConvert(map.get("contractCount")));
				row.createCell(4).setCellValue(StringUtil.nullValueConvert(map.get("amount")));
				row.createCell(5).setCellValue(StringUtil.nullValueConvert(map.get("alreadyReturnMoney")));
				row.createCell(6).setCellValue(StringUtil.nullValueConvert(map.get("noReturnMoney")));
			}

			// 4、打开流，开始写文件
			workbook.write(os);
			os.flush();
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null){
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	
	@ApiOperation(value = "导出【合同回款金额统计】，分校下的部门统计（当getContractReturnMoneyListBybranchOrgId接口返回的returnType为2时调用此接口）")
	@ApiJsonObject(name = "getContractReturnMoneyListBybranchOrgId", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getContractReturnMoneyListBybranchOrgId")
	@RequiresPermissions("sys:report:contractReturnMoneyList:export")
	@PostMapping("/exportContractReturnMoneyListBybranchOrgId")
	public void exportContractReturnMoneyListBybranchOrgId(@RequestBody String params, HttpServletResponse response) {
		OutputStream os = null;
		Workbook workbook = null;
		try {
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
			String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
			String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
			
			StringUtil.validateIsNull(branchOrgId, "请输入分校ID");
			

			Map<Object, Object> paramMap = new HashMap<Object, Object>();
            paramMap.put("startDateTime", startDateTime);
            paramMap.put("endDateTime", endDateTime);
            
            List<LinkedHashMap<Object, Object>> list = new ArrayList<LinkedHashMap<Object, Object>>();
            
            //将分校查出来，后面导出的时候，带上分校名
            OrgEntity branchEntity =  orgService.getById(branchOrgId);
            
            //校验此分校下面是否存在部门，如果无部门，则直接返回这个部门下面的每个员工的合同统计结果集
            List<OrgEntity> orgList = orgService.getNextLevelOrgByOrgId(branchOrgId);
            if(orgList!=null && orgList.size()>0){
            	//按部门统计每个部门的销售情况
            	for(OrgEntity entity : orgList){
					LinkedHashMap<Object, Object> map = new LinkedHashMap<Object, Object>();
					map.put("orgId", entity.getId());
					map.put("orgName", entity.getOrgName());
					map.put("returnType", "2");//给前端做判断使用，返回类型为2：返回分校下的部门合同统计结果集
					paramMap.put("orgId", entity.getId());//添加部门参数去按部门查询
					
					//统计合同数，合同总金额
					HashMap<Object, Object> contractCountMap = reportService.findOrgIdContractCount(paramMap);
					if(contractCountMap!=null && contractCountMap.size()>0 && Integer.parseInt(contractCountMap.get("contract_count").toString())>0){
						map.put("contractCount", contractCountMap.get("contract_count"));
						map.put("amount", contractCountMap.get("amount"));
					}else{
						map.put("contractCount", "0");
						map.put("amount", "0");
					}
					
					//已回款金额，未回款金额
					HashMap<Object, Object> contractReturnMoneyMap = reportService.findOrgIdContractReturnMoneyCount(paramMap);
					if(contractReturnMoneyMap!=null && contractReturnMoneyMap.size()>0){
						String str = StringUtil.nullValueConvert(contractReturnMoneyMap.get("already_return_money"));
						map.put("alreadyReturnMoney", str.equals("") ? 0 : str);
						map.put("noReturnMoney", contractReturnMoneyMap.get("no_return_money"));
					}else{
						map.put("alreadyReturnMoney", "0");
						map.put("noReturnMoney", "0");
					}
					
					list.add(map);
				}
            }
            
            String fileName = "contract_return_money.xls"; 
			
			response.reset();
			// 设置文件MIME类型
			response.setContentType("multipart/form-data");
			// 设置Content-Disposition,下面的为导出xls格式的
			response.setContentType("application/vnd.ms-excel");//其他自定义的文件如ofd文件采用：application/x-download
			response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
			
			
			os = response.getOutputStream();
			
			
			// 1、创建工作簿(WritableWorkbook)对象
			workbook = new XSSFWorkbook();
		 
		    // 2、新建工作表(sheet)对象，并声明其属于第几页
			Sheet customerSheet = workbook.createSheet("回款统计"); // 创建Sheet
			
			// 3、创建单元格(Label)对象，
			//设置列的宽度,注意（POI框架设置宽度需要*256，否则会挤到一列里面去）
			
			customerSheet.setColumnWidth(0, 25*256);
			customerSheet.setColumnWidth(1, 25*256);//
			customerSheet.setColumnWidth(2, 20*256);//合同数
			customerSheet.setColumnWidth(3, 20*256);//合同总金额
			customerSheet.setColumnWidth(4, 20*256);//已回款金额
			customerSheet.setColumnWidth(5, 20*256);//未回款金额
			
			
			//设置表头列的高度
//			customerSheet.setColumnHidden(0, true);

			Row header = customerSheet.createRow(0);
			// 创建表头行
			header.createCell(0).setCellValue("分校");
			header.createCell(1).setCellValue("员工/部门");
			header.createCell(2).setCellValue("合同数");
			header.createCell(3).setCellValue("合同总金额");		
			header.createCell(4).setCellValue("已回款金额");
			header.createCell(5).setCellValue("未回款金额");
			
			for(int i=0; i<list.size(); i++){
				LinkedHashMap<Object, Object> map = list.get(i);
				
				Row row = customerSheet.createRow(i+1);
				
				row.createCell(0).setCellValue(StringUtil.nullValueConvert(branchEntity.getOrgName()));
				row.createCell(1).setCellValue(StringUtil.nullValueConvert(map.get("orgName")));
				row.createCell(2).setCellValue(StringUtil.nullValueConvert(map.get("contractCount")));
				row.createCell(3).setCellValue(StringUtil.nullValueConvert(map.get("amount")));
				row.createCell(4).setCellValue(StringUtil.nullValueConvert(map.get("alreadyReturnMoney")));
				row.createCell(5).setCellValue(StringUtil.nullValueConvert(map.get("noReturnMoney")));
			}

			// 4、打开流，开始写文件
			workbook.write(os);
			os.flush();
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null){
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	
	
	@ApiOperation(value = "导出【合同回款金额统计】，分校统计（当getContractReturnMoneyList接口返回的returnType为1时调用此接口）")
	@ApiJsonObject(name = "exportContractReturnMoneyList", value = { 
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime)})
	@ApiImplicitParam(name = "params", required = true, dataType = "exportContractReturnMoneyList")
	@RequiresPermissions("sys:report:contractReturnMoneyList:export")
	@PostMapping("/exportContractReturnMoneyList")
	public void exportContractReturnMoneyList(@RequestBody String params, HttpServletResponse response) {
		OutputStream os = null;
		Workbook workbook = null;
		try {
			UserEntity bean = (UserEntity) SecurityUtils.getSubject().getPrincipal();
			UserEntity user = userService.getById(bean.getId());
            
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
			String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
			

			Map<Object, Object> paramMap = new HashMap<Object, Object>();
			paramMap.put("startDateTime", startDateTime);
			paramMap.put("endDateTime", endDateTime);
            
            //如果前端传入了分校id，则执行如下的逻辑
//            if(orgIds!=null && !orgIds.equals("null") && !orgIds.equals("")){
//				List<String> orgIdList = JsonHelper.getJsonToList(orgIds, String.class);
//				String orgId = "";
//				for(String str : orgIdList){
//					orgId = orgId + "'" + str + "'" + ",";
//				}
//				paramMap.put("orgIds", orgId.substring(0, orgId.length()-1));
//			}else{
//				//如果前端没传分校id，则判断用户能查看到的分校范围进行判断
//				List<OrgEntity> list = orgService.getBranchOrgByUserId(user.getId());
//				String orgId = "";
//				for(OrgEntity entity : list){
//					orgId = orgId + "'" + entity.getId() + "'" + ",";
//				}
//				paramMap.put("orgIds", orgId.substring(0, orgId.length()-1));
//			}
			
			List<OrgEntity> list = orgService.getBranchOrgByUserId(user.getId());
			String orgId = "";
			for (OrgEntity entity : list) {
				orgId = orgId + "'" + entity.getId() + "'" + ",";
			}
			paramMap.put("branchOrgId", orgId.substring(0, orgId.length() - 1));

            
			List<LinkedHashMap<Object, Object>> tempList = new ArrayList<LinkedHashMap<Object, Object>>();
			//分别统计每个分校的，合同数，合同总金额，已回款金额，未回款金额
			for(OrgEntity entity : list){
				LinkedHashMap<Object, Object> map = new LinkedHashMap<Object, Object>();
				map.put("orgId", entity.getId());
				map.put("orgName", entity.getOrgName());
				
				//统计合同数，合同总金额
				HashMap<Object, Object> contractCountMap = reportService.findbranchOrgIdContractCount(paramMap);
				if(contractCountMap!=null && contractCountMap.size()>0){
					map.put("contractCount", contractCountMap.get("contract_count"));
					map.put("amount", contractCountMap.get("amount"));
				}else{
					map.put("contractCount", "0");
					map.put("amount", "0");
				}
				
				//已回款金额，未回款金额
				HashMap<Object, Object> contractReturnMoneyMap = reportService.findbranchOrgIdContractReturnMoneyCount(paramMap);
				if(contractReturnMoneyMap!=null && contractReturnMoneyMap.size()>0){
					map.put("alreadyReturnMoney", contractReturnMoneyMap.get("already_return_money"));
					map.put("noReturnMoney", contractReturnMoneyMap.get("no_return_money"));
				}else{
					map.put("alreadyReturnMoney", "0");
					map.put("noReturnMoney", "0");
				}
				
				tempList.add(map);
			}
            
            String fileName = "contract_return_money.xls"; 
			
			response.reset();
			// 设置文件MIME类型
			response.setContentType("multipart/form-data");
			// 设置Content-Disposition,下面的为导出xls格式的
			response.setContentType("application/vnd.ms-excel");//其他自定义的文件如ofd文件采用：application/x-download
			response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
			
			
			os = response.getOutputStream();
			
			
			// 1、创建工作簿(WritableWorkbook)对象
			workbook = new XSSFWorkbook();
		 
		    // 2、新建工作表(sheet)对象，并声明其属于第几页
			Sheet customerSheet = workbook.createSheet("回款统计"); // 创建Sheet
			
			// 3、创建单元格(Label)对象，
			//设置列的宽度,注意（POI框架设置宽度需要*256，否则会挤到一列里面去）
			customerSheet.setColumnWidth(0, 25*256);//分校
			customerSheet.setColumnWidth(1, 20*256);//合同数
			customerSheet.setColumnWidth(2, 20*256);//合同总金额
			customerSheet.setColumnWidth(3, 20*256);//已回款金额
			customerSheet.setColumnWidth(4, 20*256);//未回款金额
			
			
			//设置表头列的高度
//			customerSheet.setColumnHidden(0, true);

			Row header = customerSheet.createRow(0);
			// 创建表头行
			header.createCell(0).setCellValue("员工/部门");
			header.createCell(1).setCellValue("合同数");
			header.createCell(2).setCellValue("合同总金额");		
			header.createCell(3).setCellValue("已回款金额");
			header.createCell(4).setCellValue("未回款金额");
			
			for(int i=0; i<tempList.size(); i++){
				LinkedHashMap<Object, Object> map = tempList.get(i);
				
				Row row = customerSheet.createRow(i+1);
				
				row.createCell(0).setCellValue(StringUtil.nullValueConvert(map.get("orgName")));
				row.createCell(1).setCellValue(StringUtil.nullValueConvert(map.get("contractCount")));
				row.createCell(2).setCellValue(StringUtil.nullValueConvert(map.get("amount")));
				row.createCell(3).setCellValue(StringUtil.nullValueConvert(map.get("alreadyReturnMoney")));
				row.createCell(4).setCellValue(StringUtil.nullValueConvert(map.get("noReturnMoney")));
			}

			// 4、打开流，开始写文件
			workbook.write(os);
			os.flush();
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null){
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	
	
	@ApiOperation(value = "导出【回款管理报表】（导出的数据为条件查询出来的全部数据,如果没有数据，将导出一个空的文件，如果要不返回一个空的文件，再开发新的校验接口即可）")
	@ApiJsonObject(name = "exportContractReturnMoneyPlanList", value = { 
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime),
			@ApiJsonProperty(name = UserJson.orgIds),
			@ApiJsonProperty(name = ContractJson.createUserId),
			@ApiJsonProperty(name = ContractJson.returnMoneyState),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "exportContractReturnMoneyPlanList")
	@RequiresPermissions("sys:report:contractReturnMoneyPlanList:export")
	@PostMapping("/exportContractReturnMoneyPlanList")
	public void exportContractReturnMoneyPlanList(@RequestBody String params, HttpServletResponse response) {
		OutputStream os = null;
		Workbook workbook = null;
		try {
			UserEntity bean = (UserEntity) SecurityUtils.getSubject().getPrincipal();
			UserEntity user = userService.getById(bean.getId());
            
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
			String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
			String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
			String createUserId = String.valueOf(jsonObject.get("createUserId"));
			String orgIds = String.valueOf(jsonObject.get("orgIds"));
			String returnMoneyState = String.valueOf(jsonObject.get("returnMoneyState"));
			
//			pageNum = "1";  还是前端传比较好，可以动态控制导出多少条
//			pageSize = "100000"; //共用后端的方法，所以将此参数设置为10万条，以后数据量达到万级，再来优化此导出接口
			

			Map<Object, Object> paramMap = new HashMap<Object, Object>();
			paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
			paramMap.put("pageSize", Integer.parseInt(pageSize));
			paramMap.put("startDateTime", startDateTime);
			paramMap.put("endDateTime", endDateTime);
			paramMap.put("createUserId", createUserId);
			paramMap.put("returnMoneyState", returnMoneyState);
            
            //如果前端传入了分校id，则执行如下的逻辑
            if(orgIds!=null && !orgIds.equals("null") && !orgIds.equals("")){
				List<String> orgIdList = JsonUtil.getJsonToList(orgIds, String.class);
				String orgId = "";
				for(String str : orgIdList){
					orgId = orgId + "'" + str + "'" + ",";
				}
				paramMap.put("orgIds", orgId.substring(0, orgId.length()-1));
			}else{
				//如果前端没传分校id，则判断用户能查看到的分校范围进行判断
				List<OrgEntity> list = orgService.getBranchOrgByUserId(user.getId());
				String orgId = "";
				for(OrgEntity entity : list){
					orgId = orgId + "'" + entity.getId() + "'" + ",";
				}
				paramMap.put("orgIds", orgId.substring(0, orgId.length()-1));
			}

            
            List<LinkedHashMap<Object, Object>> list = contractReturnMoneyPlanService.getContractReturnMoneyPlanList(paramMap);
            
            String fileName = "contract_return_money_detail.xls"; 
			
			response.reset();
			// 设置文件MIME类型
			response.setContentType("multipart/form-data");
			// 设置Content-Disposition,下面的为导出xls格式的
			response.setContentType("application/vnd.ms-excel");//其他自定义的文件如ofd文件采用：application/x-download
			response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
			
			
			os = response.getOutputStream();
			
			
			// 1、创建工作簿(WritableWorkbook)对象
			workbook = new XSSFWorkbook();
		 
		    // 2、新建工作表(sheet)对象，并声明其属于第几页
			Sheet customerSheet = workbook.createSheet("回款明细"); // 创建Sheet
			
			// 3、创建单元格(Label)对象，
			//设置列的宽度,注意（POI框架设置宽度需要*256，否则会挤到一列里面去）
			customerSheet.setColumnWidth(0, 20*256);//计划回款日期
			customerSheet.setColumnWidth(1, 20*256);//回款期次
			customerSheet.setColumnWidth(2, 30*256);//合同标题
			customerSheet.setColumnWidth(3, 15*256);//计划回款金额
			customerSheet.setColumnWidth(4, 15*256);//已回款金额
			customerSheet.setColumnWidth(5, 15*256);//未回款金额
			customerSheet.setColumnWidth(6, 15*256);//回款状态
			customerSheet.setColumnWidth(7, 15*256);//跟进人
			
			//设置表头列的高度
//			customerSheet.setColumnHidden(0, true);

			Row header = customerSheet.createRow(0);
			// 创建表头行
			header.createCell(0).setCellValue("计划回款日期");
			header.createCell(1).setCellValue("回款期次");
			header.createCell(2).setCellValue("合同标题");		
			header.createCell(3).setCellValue("计划回款金额");
			header.createCell(4).setCellValue("已回款金额");
			header.createCell(5).setCellValue("未回款金额");
			header.createCell(6).setCellValue("回款状态");
			header.createCell(7).setCellValue("跟进人");
			
			for(int i=0; i<list.size(); i++){
				LinkedHashMap<Object, Object> map = list.get(i);
				
				Row row = customerSheet.createRow(i+1);
				
				row.createCell(0).setCellValue(StringUtil.nullValueConvert(map.get("plan_return_money_date")));
				row.createCell(1).setCellValue(StringUtil.nullValueConvert(map.get("return_money_num")));
				row.createCell(2).setCellValue(StringUtil.nullValueConvert(map.get("title")));
				row.createCell(3).setCellValue(StringUtil.nullValueConvert(map.get("plan_return_money")));
				row.createCell(4).setCellValue(StringUtil.nullValueConvert(map.get("already_return_money")));
				row.createCell(5).setCellValue(StringUtil.nullValueConvert(map.get("no_return_money")));
				row.createCell(6).setCellValue(ReturnMoneyStateEnum.getDesc(StringUtil.nullValueConvert(map.get("return_money_state"))));
				row.createCell(7).setCellValue(StringUtil.nullValueConvert(map.get("create_user_name")));
			}

			// 4、打开流，开始写文件
			workbook.write(os);
			os.flush();
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null){
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	
	@ApiOperation(value = "导出【合同管理报表】（导出的数据为条件查询出来的全部数据,如果没有数据，将导出一个空的文件，如果要不返回一个空的文件，再开发新的校验接口即可）")
	@ApiJsonObject(name = "exportContractList", value = { 
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime),
			@ApiJsonProperty(name = UserJson.orgIds),
			@ApiJsonProperty(name = ContractJson.createUserId),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "exportContractList")
	@RequiresPermissions("sys:report:contractListReport:export")
	@PostMapping("/exportContractList")
	public void exportContractList(@RequestBody String params, HttpServletResponse response) {
		OutputStream os = null;
		Workbook workbook = null;
		try {
			UserEntity bean = (UserEntity) SecurityUtils.getSubject().getPrincipal();
			UserEntity user = userService.getById(bean.getId());
            
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
			String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
			String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
			String createUserId = String.valueOf(jsonObject.get("createUserId"));
			String orgIds = String.valueOf(jsonObject.get("orgIds"));
			
//			pageNum = "1";
//			pageSize = "100000"; //共用后端的方法，所以将此参数设置为10万条，以后数据量达到万级，再来优化此导出接口
			
			Map<Object, Object> paramMap = new HashMap<Object, Object>();
			paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
            paramMap.put("pageSize", Integer.parseInt(pageSize));
            paramMap.put("startDateTime", startDateTime);
            paramMap.put("endDateTime", endDateTime);
            paramMap.put("createUserId", createUserId);
            
            //如果前端传入了分校id，则执行如下的逻辑
            if(orgIds!=null && !orgIds.equals("null") && !orgIds.equals("")){
				List<String> orgIdList = JsonUtil.getJsonToList(orgIds, String.class);
				String orgId = "";
				for(String str : orgIdList){
					orgId = orgId + "'" + str + "'" + ",";
				}
				paramMap.put("orgIds", orgId.substring(0, orgId.length()-1));
			}else{
				//如果前端没传分校id，则判断用户能查看到的分校范围进行判断
				List<OrgEntity> list = orgService.getBranchOrgByUserId(user.getId());
				String orgId = "";
				for(OrgEntity entity : list){
					orgId = orgId + "'" + entity.getId() + "'" + ",";
				}
				paramMap.put("orgIds", orgId.substring(0, orgId.length()-1));
			}

            
            List<LinkedHashMap<Object, Object>> list = reportService.getContractList(paramMap);
            
            String fileName = "contract_list.xls";
			
			response.reset();
			// 设置文件MIME类型
			response.setContentType("multipart/form-data");
			// 设置Content-Disposition,下面的为导出xls格式的
			response.setContentType("application/vnd.ms-excel");//其他自定义的文件如ofd文件采用：application/x-download
			response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
			
			
			os = response.getOutputStream();
			
			
			// 1、创建工作簿(WritableWorkbook)对象
			workbook = new XSSFWorkbook();
		 
		    // 2、新建工作表(sheet)对象，并声明其属于第几页
			Sheet customerSheet = workbook.createSheet("合同列表"); // 创建Sheet
			
			// 3、创建单元格(Label)对象，
			//设置列的宽度,注意（POI框架设置宽度需要*256，否则会挤到一列里面去）
			customerSheet.setColumnWidth(0, 25*256);//合同标题
			customerSheet.setColumnWidth(1, 30*256);//对应客户
			customerSheet.setColumnWidth(2, 25*256);//合同总金额
			customerSheet.setColumnWidth(3, 15*256);//合同状态
			customerSheet.setColumnWidth(4, 15*256);//签约日期
			customerSheet.setColumnWidth(5, 15*256);//负责人
			customerSheet.setColumnWidth(6, 15*256);//备注
			
			//设置表头列的高度
//			customerSheet.setColumnHidden(0, true);

			Row header = customerSheet.createRow(0);
			// 创建表头行
			header.createCell(0).setCellValue("合同标题");
			header.createCell(1).setCellValue("对应客户");
			header.createCell(2).setCellValue("合同总金额");		
			header.createCell(3).setCellValue("合同状态");
			header.createCell(4).setCellValue("签约日期");
			header.createCell(5).setCellValue("负责人");
			header.createCell(6).setCellValue("备注");
		
			
			for(int i=0; i<list.size(); i++){
				LinkedHashMap<Object, Object> map = list.get(i);
				
				Row row = customerSheet.createRow(i+1);
				
				row.createCell(0).setCellValue(StringUtil.nullValueConvert(map.get("title")));
				row.createCell(1).setCellValue(StringUtil.nullValueConvert(map.get("customer_name")));
				row.createCell(2).setCellValue(StringUtil.nullValueConvert(map.get("amount")));
				row.createCell(3).setCellValue(ContractStateEnum.getDesc(StringUtil.nullValueConvert(map.get("contract_state"))));
				row.createCell(4).setCellValue(StringUtil.nullValueConvert(map.get("contract_date")));
				row.createCell(5).setCellValue(StringUtil.nullValueConvert(map.get("create_user_name")));
				row.createCell(6).setCellValue(StringUtil.nullValueConvert(map.get("remark")));
			}

			// 4、打开流，开始写文件
			workbook.write(os);
			os.flush();
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null){
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	
	@ApiOperation(value = "导出客户创建记录（导出的数据为条件查询出来的全部数据,如果没有数据，将导出一个空的文件，如果要不返回一个空的文件，再开发新的校验接口即可）")
	@ApiJsonObject(name = "exportCustomerCreateRecord", value = { 
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime),
			@ApiJsonProperty(name = CustomerJson.customerNameOrCompanyName),
			@ApiJsonProperty(name = UserJson.orgIds)})
	@ApiImplicitParam(name = "params", required = true, dataType = "exportCustomerCreateRecord")
	@RequiresPermissions("sys:report:CustomerCreateRecordList:export")
	@PostMapping("/exportCustomerCreateRecord")
	public void exportCustomerCreateRecord(@RequestBody String params, HttpServletResponse response) {
		OutputStream os = null;
		Workbook workbook = null;
		try {
			UserEntity bean = (UserEntity) SecurityUtils.getSubject().getPrincipal();
			UserEntity user = userService.getById(bean.getId());
            
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
			String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
			String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
			String customerNameOrCompanyName = String.valueOf(jsonObject.get("customerNameOrCompanyName"));
			String orgIds = String.valueOf(jsonObject.get("orgIds"));
			
//			pageNum = "1";  还是前端传比较好，可以动态控制导出多少条
//			pageSize = "100000"; //共用后端的方法，所以将此参数设置为10万条，以后数据量达到万级，再来优化此导出接口
			
			Map<Object, Object> paramMap = new HashMap<Object, Object>();
            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
            paramMap.put("pageSize", Integer.parseInt(pageSize));
            paramMap.put("startDateTime", startDateTime);
            paramMap.put("endDateTime", endDateTime);
            paramMap.put("customerNameOrCompanyName", customerNameOrCompanyName);
            
            //如果前端传入了分校id，则执行如下的逻辑
            if(orgIds!=null && !orgIds.equals("null") && !orgIds.equals("")){
				List<String> orgIdList = JsonUtil.getJsonToList(orgIds, String.class);
				String orgId = "";
				for(String str : orgIdList){
					orgId = orgId + "'" + str + "'" + ",";
				}
				paramMap.put("orgIds", orgId.substring(0, orgId.length()-1));
			}else{
				//如果前端没传分校id，则判断用户能查看到的分校范围进行判断
				List<OrgEntity> list = orgService.getBranchOrgByUserId(user.getId());
				String orgId = "";
				for(OrgEntity entity : list){
					orgId = orgId + "'" + entity.getId() + "'" + ",";
				}
				paramMap.put("orgIds", orgId.substring(0, orgId.length()-1));
			}

            
            List<LinkedHashMap<Object, Object>> list = reportService.getCustomerCreateRecordList(paramMap);
            
            String fileName = "customer_create_record.xls";
			
			response.reset();
			// 设置文件MIME类型
			response.setContentType("multipart/form-data");
			// 设置Content-Disposition,下面的为导出xls格式的
			response.setContentType("application/vnd.ms-excel");//其他自定义的文件如ofd文件采用：application/x-download
			response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
			
			
			os = response.getOutputStream();
			
			
			// 1、创建工作簿(WritableWorkbook)对象
			workbook = new XSSFWorkbook();
		 
		    // 2、新建工作表(sheet)对象，并声明其属于第几页
			Sheet customerSheet = workbook.createSheet("客户创建记录"); // 创建Sheet
			
			// 3、创建单元格(Label)对象，
			//设置列的宽度,注意（POI框架设置宽度需要*256，否则会挤到一列里面去）
			customerSheet.setColumnWidth(0, 25*256);//创建时间
			customerSheet.setColumnWidth(1, 30*256);//客户
			customerSheet.setColumnWidth(2, 25*256);//手机
			customerSheet.setColumnWidth(3, 15*256);//创建人
			
			//设置表头列的高度
//			customerSheet.setColumnHidden(0, true);

			Row header = customerSheet.createRow(0);
			// 创建表头行
			header.createCell(0).setCellValue("创建时间");//创建时间	
			header.createCell(1).setCellValue("客户");//客户
			header.createCell(2).setCellValue("手机");	//来源	
			header.createCell(3).setCellValue("创建人");//创建人
		
			
			for(int i=0; i<list.size(); i++){
				LinkedHashMap<Object, Object> map = list.get(i);
				
				Row row = customerSheet.createRow(i+1);
				
				row.createCell(0).setCellValue(StringUtil.nullValueConvert(map.get("create_time")));
				row.createCell(1).setCellValue(StringUtil.nullValueConvert(map.get("customer_name")));
				row.createCell(2).setCellValue(StringUtil.nullValueConvert(map.get("mobile")));
				row.createCell(3).setCellValue(StringUtil.nullValueConvert(map.get("user_name")));
				
			}

			// 4、打开流，开始写文件
			workbook.write(os);
			os.flush();
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null){
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	
	
}
