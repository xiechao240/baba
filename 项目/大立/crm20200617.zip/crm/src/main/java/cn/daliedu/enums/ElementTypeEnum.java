package cn.daliedu.enums;

/**
 * 组件类型枚举类
 * @author xiechao
 * @time 2019年9月27日 下午2:44:36
 * @version 1.0.0 
 * @description
 */
public enum  ElementTypeEnum {
	//	组件类型，复选框：checkbox，下拉框：select，单选：radio，文本框的为单值且由用户输入的，不能存储在此
	/**
	 * 组件类型：复选框
	 */
	CHECKBOX("checkbox", "复选框"), 
	/**
	 * 组件类型：下拉框
	 */
	SELECT("select", "下拉框"), 
	/**
	 * 组件类型：单选
	 */
	RADIO("radio", "单选");

	private String value;
	private String desc;

	ElementTypeEnum(final String value, final String desc) {
		this.value = value;
		this.desc = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
	
	 /**
     * 根据枚举值获取枚举描述
     * @param key
     * @return
     */
    public static String getDesc(String value){
    	String returnStr = "";
        for (ElementTypeEnum e: ElementTypeEnum.values()){
            if(e.getValue().equals(value)){
            	returnStr = e.getDesc();
            	break;
            }
        }
		return returnStr;
    }
    
    /**
     * 根据枚举描述获取枚举值
     * @param key
     * @return
     */
    public static String getValue(String desc){
    	String returnStr = "";
        for (ElementTypeEnum e: ElementTypeEnum.values()){
            if(e.getDesc().equals(desc)){
            	returnStr = e.getValue();
            	break;
            }
        }
		return returnStr;
    }
    
    /**
     * 判断数值是否属于枚举类的值
     * @param key
     * @return
     */
    public static boolean isInclude(String value){
        boolean include = false;
        for (ElementTypeEnum e: ElementTypeEnum.values()){
            if(e.getValue().equals(value)){
                include = true;
                break;
            }
        }
        return include;
    }
}