package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 客户流转原因配置表
 * </p>
 *
 * @author xiechao
 * @since 2019-10-15
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_customer_flow_cause_config")
public class CustomerFlowCauseConfigEntity extends Model<CustomerFlowCauseConfigEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private Integer id;

    /**
     * 原因
     */
    private String cause;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
