package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 客户自定义类别配置表
 * </p>
 *
 * @author xiechao
 * @since 2020-05-22
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_customer_self_define_item_config")
@ApiModel(value="CustomerSelfDefineItemConfigEntity对象", description="客户自定义类别配置表")
public class CustomerSelfDefineItemConfigEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "类别ID")
    @TableId(value = "item_id", type = IdType.UUID)
    private String itemId;

    @ApiModelProperty(value = "分校ID，如果此字段为空，则为全局自定义类别属性")
    private String branchOrgId;

    @ApiModelProperty(value = "类别名称")
    private String itemName;

    @ApiModelProperty(value = "是否是初始数据模板,1:是true, 0：不是false")
    private Boolean isInit;

    @ApiModelProperty(value = "类别排序值")
    private Integer orderNum;


    @ApiModelProperty(value = "是否启用")
    private Boolean isEnabled;
    
    @ApiModelProperty(value = "组件类型，复选框：checkbox，下拉框：select，单选：radio，文本框的为单值且由用户输入的，不能存储在此")
    private String elementType;
    
    @TableField(exist = false)
    @ApiModelProperty(value = "自定义信息明细")
    private List<CustomerSelfDefineItemConfigDetailEntity> customerSelfDefineItemConfigDetails;
    
    
//    @TableField(exist = false)
//    @ApiModelProperty(value = "前端用于勾选选中项使用")
//    private String[] defaultValue;

}
