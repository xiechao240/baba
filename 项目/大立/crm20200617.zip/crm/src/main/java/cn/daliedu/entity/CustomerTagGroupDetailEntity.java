package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 客户标签分组明细表
 * </p>
 *
 * @author xiechao
 * @since 2019-10-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_customer_tag_group_detail")
public class CustomerTagGroupDetailEntity extends Model<CustomerTagGroupDetailEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 客户标签ID，主键ID
     */
    @TableId(value = "customer_tag_id", type = IdType.AUTO)
    private Integer customerTagId;

    /**
     * 客户标签分组类型ID（来自于客户标签分组表）
     */
    private Integer customerTagTypeId;

    /**
     * 客户标签名称
     */
    private String customerTagName;


    /**
     * 描述此数据标签值的含义
     */
    private String remark;

    /**
     * 排序值
     */
    private Integer orderNum;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;


    @Override
    protected Serializable pkVal() {
        return this.customerTagId;
    }

}
