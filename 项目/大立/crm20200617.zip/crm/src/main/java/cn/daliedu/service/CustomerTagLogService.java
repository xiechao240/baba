package cn.daliedu.service;

import cn.daliedu.entity.CustomerTagLogEntity;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户打标签记录表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-12-12
 */
public interface CustomerTagLogService extends IService<CustomerTagLogEntity> {

}
