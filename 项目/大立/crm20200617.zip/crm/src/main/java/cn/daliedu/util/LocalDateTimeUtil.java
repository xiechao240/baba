package cn.daliedu.util;

import org.apache.commons.lang3.time.DateFormatUtils;

import java.sql.Timestamp;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

/**
 * 日期工具类
 * @author xiechao
 * @time 2019年11月1日 上午9:11:01
 * @version 1.0.0 
 * @description
 */
public class LocalDateTimeUtil{
	
	/**
	 * 将字符串日期，转化为LocalDateTime日期
	 * @param date 字符串格式日期
	 * @param pattern 时间格式，传null则默认返回yyyy-MM-dd格式
	 */
	public static LocalDateTime getLocalDateTime(String date, String pattern){
		if(pattern==null){
			DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			return LocalDateTime.parse(date, df);
		}else{
			DateTimeFormatter df = DateTimeFormatter.ofPattern(pattern);
			return LocalDateTime.parse(date, df);
		}
	}
	

	/**
	 * 将字符串日期，转化为LocalDateTime日期
	 * @param date 字符串格式日期,如：2019-10-28T08:26:01.000+0000
	 * @return 返回yyyy-MM-dd HH:mm:ss格式
	 */
	public static LocalDateTime getLocalDateTime(String date){
		DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		return LocalDateTime.parse(date, df);
	}
	
	
	/**
	 * 将localDateTime时间格式转化为 pattern格式的时间
	 * @param localDateTime  localDateTime时间对象
	 * @param pattern 时间格式，如：yyyy-MM-dd HH:mm:ss
	 * @return
	 */
	public static String getDateTime(LocalDateTime localDateTime, String pattern){
		return localDateTime.format(DateTimeFormatter.ofPattern(pattern));
	}
	
	/**
	 * 将localDateTime时间格式转化为yyyy-MM-dd hh:mm:ss格式的时间
	 * @param dateTime  dateTime时间字符串，如：2019-10-28T08:26:01.000+0000
	 * @return  yyyy-MM-dd hh:mm:ss时间
	 */
	public static String getDateTime(String dateTime){
		Date date = DateUtil.strToDate(dateTime);
		return DateUtil.getDateString(date, "yyyy-MM-dd HH:mm:ss");
	}
	
	
	public static void main(String[] args) {
		String str = "2019-10-28T08:26:01.000+0000";
		System.out.println(str.substring(0, str.length()-9).replace("T", " "));
	}
}
