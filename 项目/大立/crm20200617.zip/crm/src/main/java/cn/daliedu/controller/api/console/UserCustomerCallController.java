package cn.daliedu.controller.api.console;


import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.shiro.authz.UnauthorizedException;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.CustomerDynamicFileEntity;
import cn.daliedu.entity.json.CallJson;
import cn.daliedu.entity.json.CustomerJson;
import cn.daliedu.enums.ResultCodeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.CustomerDynamicFileService;
import cn.daliedu.service.UserCustomerCallService;
import cn.daliedu.util.FileUtil;
import cn.daliedu.util.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * <p>
 * 用户客户通话表 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2019-11-23
 */
@Api(description = "用户客户通话相关接口")
@RestController
@RequestMapping(value = "${rest.path}/console/userCustomerCall") 
public class UserCustomerCallController {
	
	@Autowired
	UserCustomerCallService userCustomerCallService;
	
	@Autowired
	CustomerDynamicFileService customerDynamicFileService;
	
   
	
//	@ApiOperation(value = "测试多文件上传【经测试，多文件上传，无论怎么调整files在swagger页面上，都是传递为空值,knife4j框架应该解决了】")
//	@PostMapping(value = "/testSaveCallRecordingFile", consumes = "multipart/*", headers = "content-type=multipart/form-data")//注意consumes = "multipart/*"这个我没加，也可以在swagger上上传成功
//	public Result testSaveCallRecordingFile(
//			@ApiParam(value="用户客户通话唯一ID",required=true)@RequestParam(required=true) String userCustomerCallId, 
//			@ApiParam(value="上传的文件",required=true)@RequestPart(required=true, value = "files") MultipartFile[] files) {
//		try{
//			for(MultipartFile file : files){
//				System.out.println(file.getName());
//			}
//			return Result.success("保存成功");
//		}catch (Exception e) {
//			e.printStackTrace();
//			return Result.error("上传录音文件失败，失败原因：" + e.getMessage());
//		}
//	}
	
	
	@ApiOperation(value = "单独保存客户通话录音文件，给移动端app使用")
//	@ApiImplicitParams({
//			@ApiImplicitParam(paramType = "query", dataType = "String", name = "userCustomerCallId", value = "用户客户通话唯一ID", required = true),
//			@ApiImplicitParam(paramType = "query", dataType = "__file", name = "file", value = "需要导入的客户数据的excel文件", required = true)
//			})
	@PostMapping(value = "/saveCallRecordingFile", consumes = "multipart/*", headers = "content-type=multipart/form-data") 
	//@PostMapping(value = "/saveCallRecordingFile", consumes = "multipart/*", headers = "content-type=multipart/form-data")//注意consumes = "multipart/*"这个我没加，也可以在swagger上上传成功
	public Result saveCallRecordingFile(
			@ApiParam(value="用户客户通话唯一ID",required=true)@RequestParam(required=true) String userCustomerCallId, 
			@ApiParam(value="上传的文件",required=true)@RequestParam(required=true, value = "file") MultipartFile file) {
		try{
			userCustomerCallService.saveCallRecordingFile(userCustomerCallId, file);
			return Result.success("保存成功");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("上传录音文件失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "保存通话记录（不需要保存通话录音文件则调用此接口）,此接口调用为前端直接发起的请求，所以不需要传入userId")
	@ApiJsonObject(name = "saveCallRecord", value = { 
			@ApiJsonProperty(name = CustomerJson.customerId),
			@ApiJsonProperty(name = CallJson.callType),
			@ApiJsonProperty(name = CallJson.startTime),
			@ApiJsonProperty(name = CallJson.endTime),
			@ApiJsonProperty(name = CallJson.answerTime),
			@ApiJsonProperty(name = CallJson.callNumber),
			@ApiJsonProperty(name = CallJson.callState)})
	@ApiImplicitParam(name = "params", required = true, dataType = "saveCallRecord")
	@PostMapping("/saveCallRecord")
	public Result saveCallRecord(@RequestBody String params) {
		try{
			String result = userCustomerCallService.saveCallRecord(params);
			if(!StringUtils.isBlank(result)){
				return Result.success(result, result);
			}
			
			return Result.error("保存通话记录失败，请联系管理员");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("保存通话记录失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
	@ApiOperation(value = "保存通话记录（同时保存通话录音文件）,此接口调用为客户端发起，所以需要由前端将userId传给客户端，客户端再带上userId发起请求")
	@ApiImplicitParams({
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "userId", value = "用户ID", required = true),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "customerId", value = "客户ID", required = true),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "callType", value = "呼出方式,1：座机，2：手机", required = true),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "startTime", value = "开始时间", required = true),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "endTime", value = "结束时间", required = true),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "answerTime", value = "接听时间", required = true),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "callNumber", value = "呼出号码", required = true),
			@ApiImplicitParam(paramType = "query", dataType = "String", name = "callState", value = "应答状态", required = true)})
//	@RequiresPermissions("sys:role:list")
	@PostMapping("/saveCallRecordAndRecording")
	public Result saveCallRecordAndRecording(@RequestParam(required=true) String userId,
			@RequestParam(required=true) String customerId, 
			@RequestParam(required=true) String callType, 
			@RequestParam(required=true) String callNumber, @RequestParam(required=true) String callState, 
			@RequestParam(required=true) String startTime, @RequestParam(required=true) String endTime, 
			@RequestParam(required=true) String answerTime, 
			@RequestParam(required=true, value = "file") MultipartFile file) {
		try{
			boolean flag = userCustomerCallService.saveCallRecordAndRecording(userId, customerId, callType, callNumber, callState, startTime, endTime, answerTime, file);
			if(flag){
				return Result.success("保存成功");
			}
			return Result.error("保存通话记录失败，请联系管理员");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("保存通话记录失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "下载录音文件")
	@ApiJsonObject(name = "downloadRecordingFile", value = { 
			@ApiJsonProperty(name = CustomerJson.customerDynamicId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "downloadRecordingFile")
	@RequiresPermissions("sys:customer:export")
	@PostMapping("/downloadRecordingFile")
	public void downloadRecordingFile(@RequestBody String params, HttpServletResponse response) {
		OutputStream os = null;
		Workbook workbook = null;
		try {
			JSONObject jsonObject = JSON.parseObject(params);
			String customerDynamicId = String.valueOf(jsonObject.get("customerDynamicId"));
			
			if (customerDynamicId == null || customerDynamicId.trim().equals("") || customerDynamicId.equals("null")) {
				return ;
			}
			
			List<CustomerDynamicFileEntity> list = customerDynamicFileService.getCustomerDynamicFileById(customerDynamicId);
			if(list!=null && list.size()>0){
				if(list.size()>1){
					return ;
				}else{
					CustomerDynamicFileEntity dynamicFileEntity = list.get(0);
					String fileName = dynamicFileEntity.getFileName() +".wav";
					
					response.reset();
					// 设置文件MIME类型
					response.setContentType("multipart/form-data");
					// 设置Content-Disposition,下面的为导出xls格式的
					response.setContentType("audio/x-wav");//其他自定义的文件如ofd文件采用：application/x-download
					response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
					
					os = response.getOutputStream();
					
					os.write(FileUtil.getContent(dynamicFileEntity.getFilePath()));
					
					os.flush();
				}
			}else{
				return ;
			}
		}catch (UnauthorizedException e){
			Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (os != null){
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	
	
}
