package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 数据字典（二维数据字典明细）
 * </p>
 *
 * @author xiechao
 * @since 2019-11-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("sys_dict_many_detail")
public class DictManyDetailEntity extends Model<DictManyDetailEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 数据字典明细ID
     */
    @TableId(value = "detail_id", type = IdType.UUID)
    private Integer detailId;

    /**
     * 数据标签表ID
     */
    private Integer tagId;

    /**
     * 数据类型名称，存储数据如，客户类型，用户类型，用来解释type对应的名称
     */
    private String detailName;

    /**
     * 排序值
     */
    private Integer orderNum;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;


    @Override
    protected Serializable pkVal() {
        return this.detailId;
    }

}
