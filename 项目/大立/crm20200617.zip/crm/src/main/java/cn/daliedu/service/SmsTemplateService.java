package cn.daliedu.service;

import cn.daliedu.entity.SmsTemplateEntity;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 短信模板表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-12-26
 */
public interface SmsTemplateService extends IService<SmsTemplateEntity> {
	
	/**
	 * 向客户发送自定义短信
	 * @param customerIds  json数组形式客户ID集合
	 * @param templateCode 短信模板编码
	 * @return
	 */
	public boolean sendSmsToCustomer(String customerIds, String templateCode) throws Exception;
	
	/**
	 * 获取所有的模板列表
	 * @return
	 */
	public IPage<SmsTemplateEntity> getSmsTemplateList(Integer pageNum, Integer pageSize);
	
	/**
	 * 通过模板code获取短信模板
	 * @param templateCode 短信模板code
	 * @return
	 */
	public SmsTemplateEntity getSmsTemplateByTemplateCode(String templateCode);
	
	
}
