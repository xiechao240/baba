package cn.daliedu.service;

import cn.daliedu.entity.AreaDataEntity;

import java.util.List;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 区域数据表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-11-05
 */
public interface AreaDataService extends IService<AreaDataEntity> {
	
	/**
	 * 获取省市区三级联动，树形数据
	 * @return
	 */
	public List<AreaDataEntity> findTreeAreaList();
	
//	/**
//	 * 根据区域ID，找到区域数据
//	 * @param id
//	 * @return
//	 */
//	public AreaDataEntity getAreaDataById(Integer id);
}
