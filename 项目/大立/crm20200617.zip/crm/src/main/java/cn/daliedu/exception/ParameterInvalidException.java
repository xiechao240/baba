package cn.daliedu.exception;

/**
 * 自定义参数异常
 * @author xiechao
 * @time 2019年2月18日 上午10:13:15
 * @version 1.0.0 
 * @description
 */
public class ParameterInvalidException extends Exception
{
    private static final long serialVersionUID = 1L;

    public ParameterInvalidException(String message)
    {
        super(message);
    }

    public ParameterInvalidException(String message, Throwable cause)
    {
        super(message, cause);
    }

    public ParameterInvalidException(Throwable cause)
    {
        super(cause);
    }
}
