package cn.daliedu.mapper;

import cn.daliedu.entity.CustomerTagLogEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 用户打标签记录表 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-12-12
 */
public interface CustomerTagLogMapper extends BaseMapper<CustomerTagLogEntity> {

}
