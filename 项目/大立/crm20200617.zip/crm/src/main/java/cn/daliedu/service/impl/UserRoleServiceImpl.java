package cn.daliedu.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.entity.UserRoleEntity;
import cn.daliedu.mapper.UserRoleMapper;
import cn.daliedu.service.UserRoleService;

/**
 * <p>
 * 用户角色 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
@Service
public class UserRoleServiceImpl extends ServiceImpl<UserRoleMapper, UserRoleEntity> implements UserRoleService {

	@Resource
	UserRoleMapper userRoleMapper;

	@Override
	public UserRoleEntity getRoleByUserId(String userId) {
		return userRoleMapper.selectOne(new QueryWrapper<UserRoleEntity>().eq("user_id", userId).last("limit 1"));
	}
	
	
	
	

}
