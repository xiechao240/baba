package cn.daliedu.entity.json;

import cn.daliedu.config.swagger.model.ApiSingleParam;

/**
 * <p>
 * swagger注释属性：用户表
 * </p>
 *
 * @author xiechao
 * @since 2019-05-06
 */
public class UserJson{
	
	@ApiSingleParam(value = "用户ID", example = "2")
    public static final String userId = "userId";
	
	@ApiSingleParam(value = "交接后的用户ID", example = "2")
    public static final String receiveUserId = "receiveUserId";
	
	@ApiSingleParam(value = "用户ID集合", example = "[1,2,3]")
    public static final String userIds = "userIds";

	@ApiSingleParam(value = "登录名或用户名", example = "admin")
    public static final String loginNameOrUserName = "loginNameOrUserName";
	
	@ApiSingleParam(value = "姓名", example = "张三")
    public static final String userName = "userName";
	
	
	@ApiSingleParam(value = "性别，1：男，2：女", example = "1")
    public static final String sex = "sex";

	@ApiSingleParam(value = "手机号码作为登录账号", example = "1839098692")
    public static final String mobile = "mobile";
	
	@ApiSingleParam(value = "密码", example = "123456")
    public static final String password = "password";

	@ApiSingleParam(value = "部门ID", example = "1")
    public static final String orgId = "orgId";
	
	@ApiSingleParam(value = "部门名称", example = "1")
    public static final String orgName = "orgName";
	
	@ApiSingleParam(value = "用户类型，1：超级管理员，2：普通管理员，3：普通用户，4：代理商用户,5：其他类型", example = "1")
    public static final String userType = "userType";
	
	@ApiSingleParam(value = "角色ID", example = "1")
    public static final String roleId = "roleId";
	
	@ApiSingleParam(value = "邮箱", example = "1")
    public static final String email = "email";
	
	@ApiSingleParam(value = "查看业务组公海与部门数据", example = "[1,2,3]")
    public static final String orgIds = "orgIds";
	
	@ApiSingleParam(value = "员工状态，0：禁用，1：启用，2：离职", example = "1")
	public static final String state = "state";
	
	@ApiSingleParam(value = "新密码", example = "123456")
    public static final String newPassword = "newPassword";

	@ApiSingleParam(value = "旧密码", example = "123456")
	public static final String oldPassword = "oldPassword";
	
	@ApiSingleParam(value = "验证码", example = "123456")
	public static final String validateCode = "validateCode";
	
}
