package cn.daliedu.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.entity.RoleMenuEntity;
import cn.daliedu.mapper.RoleMenuMapper;
import cn.daliedu.service.RoleMenuService;

/**
 * <p>
 * 角色菜单 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
@Service
public class RoleMenuServiceImpl extends ServiceImpl<RoleMenuMapper, RoleMenuEntity> implements RoleMenuService {
	
	@Resource
	RoleMenuMapper roleMenuMapper;


	@Override
	public boolean saveRoleMenuByRoleId(String[] menuIdList, String roleId) throws Exception {
		//先删除此角色配置的菜单
		roleMenuMapper.delete(new QueryWrapper<RoleMenuEntity>().eq("role_id", roleId.trim()));
	
		if(menuIdList!=null && menuIdList.length>0){
			for (int i = 0; i < menuIdList.length; i++) {
				RoleMenuEntity roleMenuEntity = new RoleMenuEntity();
				roleMenuEntity.setMenuId(Integer.parseInt(menuIdList[i]));
				roleMenuEntity.setRoleId(roleId);
				roleMenuMapper.insert(roleMenuEntity);
			}
		}
		return true;
	}
}
