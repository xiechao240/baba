package cn.daliedu.service;

import cn.daliedu.entity.CustomerCountEntity;

import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 每天统计分校的客户总数与用户的客户总数 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-12-06
 */
public interface CustomerCountService extends IService<CustomerCountEntity> {
	/**
	 * 【客户数量统计报表】获取客户数量
	 * @param map
	 * @return
	 */
	public Integer getCustomerCountByScheduled(Map<Object, Object> map);
	
	/**
	 * 判断分校下的客户数量是否已经统计过
	 * @param branchOrgId 分校ID
	 * @param date 日期
	 * @return
	 */
	public boolean existBranchCustomerCountData(String branchOrgId, String date);
	
	/**
	 * 判断用户下的客户数量是否已经统计过
	 * @param userId 用户ID
	 * @param date 日期
	 * @return
	 */
	public boolean existUserCustomerCountData(String userId, String date);
}
