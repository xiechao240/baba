package cn.daliedu.service.impl;

import cn.daliedu.entity.DictManyDetailEntity;
import cn.daliedu.mapper.DictManyDetailMapper;
import cn.daliedu.service.DictManyDetailService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

/**
 * <p>
 * 数据字典（二维数据字典明细） 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-11-07
 */
@Service
public class DictManyDetailServiceImpl extends ServiceImpl<DictManyDetailMapper, DictManyDetailEntity> implements DictManyDetailService {
	
	@Resource
	DictManyDetailMapper dictManyDetailMapper;
	
	@Override
	public List<DictManyDetailEntity> getDictDetailList() throws Exception {
		return dictManyDetailMapper.selectList(new QueryWrapper<DictManyDetailEntity>());
	}
}
