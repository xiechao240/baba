package cn.daliedu.service;

import cn.daliedu.entity.CustomerImportHistoryEntity;

import java.util.Map;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 客户导入历史表（用于导入时记录有问题的数据，如果有需求，可以开发定时任务清理此表中的数据） 服务类
 * </p>
 *
 * @author xiechao
 * @since 2020-02-18
 */
public interface CustomerImportHistoryService extends IService<CustomerImportHistoryEntity> {
	
	/**
	 * 获取用户导入的客户结果（只有导入客户时出错的客户数据才会被记录在此结果集中）
	 * @param map
	 * @return
	 */
	public IPage<CustomerImportHistoryEntity> getCustomerImportList(Map<Object, Object> map);
	
	/**
	 * 根据用户导入的客户结果集ID，删除导入的客户数据
	 * @param ids
	 * @return
	 */
	public boolean deleteCustomerImportResultById(String ids);
}
