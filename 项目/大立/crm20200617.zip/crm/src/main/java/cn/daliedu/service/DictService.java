package cn.daliedu.service;

import java.util.LinkedHashMap;
import java.util.List;

import com.baomidou.mybatisplus.extension.service.IService;

import cn.daliedu.entity.DictEntity;

/**
 * <p>
 * 数据字典表，存储系统中静态的或少量变动的格式化数据 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-21
 */
public interface DictService extends IService<DictEntity> {
	
	/**
	 * 获取数据库中所有的数据字典类别
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<String, String>> getDictType() throws Exception;
	
	/**
	 * 根据字典类别获取所有的数据字典
	 * @param tag 标签标识符
	 * @return
	 * @throws Exception
	 */
	public List<DictEntity> getDictValueByType(String tag) throws Exception;
	
	/**
	 * 根据字典类别及描述获取相应的字典
	 * @param tag 标签标识符
	 * @return
	 * @throws Exception
	 */
	public DictEntity getDictValueByTagAndRemark(String tag, String remark) throws Exception;
	
	
	/**
	 * 根据是否属于客户标签查询标签分组
	 * @param isCustomerTag 分组标签类型，1：客户标签，0:非客户标签
	 * @return
	 */
	public List<DictEntity> findDictListByIsCustomerTag(String isCustomerTag);
	
	/**
	 * 根据标签查询数据字典
	 * @param tag 标签
	 * @return
	 */
	public List<DictEntity> findDictListByTag(String tag);
	
	/**
	 * 创建数据字典
	 * @param dict  数据字典
	 * @throws Exception
	 */
	public boolean saveDict(DictEntity dict) throws Exception;
	
	/**
	 * 修改数据字典
	 * @param dict  数据字典
	 * @throws Exception
	 */
	public boolean updateDict(DictEntity dict) throws Exception;
	
	/**
	 * 根据分组删除数据字典
	 * @param id  
	 * @throws Exception
	 */
	public boolean deleteDictById(String id) throws Exception;
	
	/**
	 * 根据分组tag删除数据字典
	 * @param id  
	 * @throws Exception
	 */
	public boolean deleteDictByTag(String tag) throws Exception;
	
}
