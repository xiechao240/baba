package cn.daliedu.entity.json;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * swagger注释属性：合同属性json
 * </p>
 *
 * @author xiechao
 * @since 2019-05-06
 */
@ApiModel(value = "回款计划", description = "回款计划所有属性")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ContractModel {
	
	/**
	 * 回款期次集合
	 */
	@ApiModelProperty(value="回款期次集合")
	private ReturnMoneyPlanModel[] returnMoneyPlanList;
	
	/**
	 * 客户ID，新增客户此，此属性可不填，修改客户时此属性必填
	 */
	@ApiModelProperty(value="客户ID")
	private String customerId;
	
	@ApiModelProperty(value="合同ID")
	private String contractId;
	
	
	
	
	

	
}
