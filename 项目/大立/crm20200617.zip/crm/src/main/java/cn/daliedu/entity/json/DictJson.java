package cn.daliedu.entity.json;

import cn.daliedu.config.swagger.model.ApiSingleParam;

/**
 * <p>
 * swagger注释属性：数据字典属性json
 * </p>
 *
 * @author xiechao
 * @since 2019-05-06
 */
public class DictJson{
	@ApiSingleParam(value = "ID", example = "1")
    public static final String id = "id";
	
	@ApiSingleParam(value = "标签名称", example = "客户来源")
    public static final String name = "name";
	
	@ApiSingleParam(value = "描述", example = "非代理商")
    public static final String remark = "remark";
	
	@ApiSingleParam(value = "标签值", example = "1")
    public static final String value = "value";

	@ApiSingleParam(value = "分组英文标签", example = "customer_source")
    public static final String tag = "tag";
	
	@ApiSingleParam(value = "是否是客户标签0：不是，1：是", example = "1")
    public static final String isCustomerTag = "isCustomerTag";
	
	@ApiSingleParam(value = "是否是默认选中0：不是，1：是", example = "1")
	public static final String defaultSelected = "defaultSelected";
	
	@ApiSingleParam(value = "是否是可编辑0：不是，1：是", example = "1")
	public static final String isEdit = "isEdit";
	
	@ApiSingleParam(value = "是否是可用0：不是，1：是", example = "1")
	public static final String available = "available";
	
	@ApiSingleParam(value = "字典级别,0表示系统级别;1表示用户创建", example = "1")
	public static final String level = "level";
}
