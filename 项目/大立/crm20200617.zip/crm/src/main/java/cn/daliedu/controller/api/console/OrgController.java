package cn.daliedu.controller.api.console;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.UserOrgAreaEntity;
import cn.daliedu.entity.json.CustomerTagGroupJson;
import cn.daliedu.entity.json.GlobalJson;
import cn.daliedu.entity.json.MenuJson;
import cn.daliedu.entity.json.OrgJson;
import cn.daliedu.entity.json.UserJson;
import cn.daliedu.enums.OrgTypeEnum;
import cn.daliedu.enums.UserTypeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.OrgService;
import cn.daliedu.service.UserOrgAreaService;
import cn.daliedu.service.UserService;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * <p>
 * 部门管理 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
@RestController
@Api(description = "部门操作相关接口")
@RequestMapping(value = "${rest.path}/console/org") 
public class OrgController {
	
	@Autowired
	OrgService orgService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	UserOrgAreaService userOrgAreaService;
	
	/** 
	 * 新增部门
	 **/
	@ApiOperation(value = "根据组织机构ID获取组织机构类别", notes = "根据组织机构ID获取组织机构类别")
	@ApiJsonObject(name = "getOrgTypeByOrgId", value = { 
			@ApiJsonProperty(name = OrgJson.orgId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getOrgTypeByOrgId")
	@PostMapping("/getOrgTypeByOrgId")
	public Result getOrgTypeByOrgId(@RequestBody String params)  {
		try {
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String orgId = jsonObject.get("orgId").toString();
			
			StringUtil.validateIsNull(orgId, "请输入组织机构ID");
			
			OrgEntity orgEntity = orgService.getById(orgId);
			if(orgEntity!=null){
				return Result.success(orgEntity);
			}else{
				return Result.error("查询出错");
			}
		} catch(BusinessException e){
			e.printStackTrace();
			return Result.error("获取组织机构类型失败，请稍后再试！");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取组织机构类型失败，请稍后再试！");
		}
	}
	
	/** 
	 * 新增部门
	 **/
	@ApiOperation(value = "新增部门", notes = "新增部门")
	@ApiJsonObject(name = "saveOrg", value = { 
			@ApiJsonProperty(name = OrgJson.orgName),
			@ApiJsonProperty(name = OrgJson.parentId),
			@ApiJsonProperty(name = OrgJson.orderNum),
			@ApiJsonProperty(name = OrgJson.orgType)})
	@ApiImplicitParam(name = "params", required = true, dataType = "saveOrg")
	@PostMapping("/saveOrg")
	public Result saveOrg(@RequestBody String params)  {
		try {
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String orgName = jsonObject.get("orgName").toString();
			String parentId = jsonObject.get("parentId").toString();
			String orderNum = jsonObject.get("orderNum").toString();
			String orgType = jsonObject.get("orgType").toString();
			
			StringUtil.validateIsNull(orgName, "请输入名称");
			StringUtil.validateIsNull(parentId, "请输入上级部门ID");
//			StringUtil.validateIsNull(orderNum, "请输入部门排序号");
			StringUtil.validateIsNull(orgType, "请输入部门类型");
			
			OrgEntity orgEntity = orgService.getById(parentId);
			if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_3.getValue())){
				//顶级机构下只能创建省份，目前已经由前端进行控制了，后端目前只做部门下不能再创建部门的判断吧
				if(orgType.equals(OrgTypeEnum.ORG_TYPE_3.getValue())){
					return Result.error("目前系统，部门下面不允许再添加部门");
				}
			}
			
			if(orderNum==null || orderNum.equals("") || orderNum.equals("null")){
				orderNum = "0";
			}
			
			OrgEntity entity = new OrgEntity();
			entity.setOrgName(orgName);
			entity.setOrgType(orgType);
			entity.setParentId(parentId);
			entity.setOrderNum(Integer.parseInt(orderNum));
			entity.setState("1");
			entity.setCreateTime(LocalDateTime.now());
			
			boolean flag = orgService.saveOrg(entity);
			if(flag){
				return Result.success("新增成功！");
			}
			return Result.success("新增成功！");
		} catch(BusinessException e){
			e.printStackTrace();
			return Result.error("新增失败，请稍后再试！");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("新增失败，请稍后再试！");
		}
	}
	
	
	
	
	
//	/**
//	 *  删除部门（支持批量删除）
//	 * @return 
//	 **/
//	@ApiOperation(value = "删除部门（支持批量删除）", notes = "删除部门（支持批量删除）")
//	@RequestMapping(value = "/delete",method = RequestMethod.DELETE,produces = "application/json;charset=UTF-8")
//	public Result deleteBatch(String[] ids) {
//		for (int i = 0; i < ids.length; i++) {
//			orgService.removeById(ids[i]);
//		}
//		return Result.success("删除成功！");
//	}
	
	
	@ApiOperation(value = "获取部门树形菜单集合接口")
	@PostMapping("/findTreeOrgList")
	public Result findTreeOrgList(){
		try{
			List<OrgEntity> list = orgService.findTreeOrgList();
			
			return Result.success(list);
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取部门树形菜单集合接口失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "获取所有的分校节点树形结构数据")
	@PostMapping("/getBranchOrg")
	public Result getBranchOrg(){
		try{
			List<OrgEntity> list = orgService.getBranchOrgTree();
			
			return Result.success(list);
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取所有的分校节点树形结构数据失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "删除部门接口")
	@ApiJsonObject(name = "deleteOrg", value = {
			@ApiJsonProperty(name = OrgJson.orgId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "deleteOrg")
	@PostMapping("/deleteOrg")
	public Result deleteOrg(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String orgId = String.valueOf(jsonObject.get("orgId"));
			
			StringUtil.validateIsNull(orgId, "部门ID不能为空");
			
			if(orgId.equals("1")){
				return Result.error("顶级节点不允许删除，请谨慎操作");
			}
			
			this.orgService.deleteOrg(orgId);
			
			return Result.success("删除部门成功！");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("删除部门失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "获取分校下的部门")
	@ApiJsonObject(name = "getDepartmentByBranchOrgId", value = {
			@ApiJsonProperty(name = OrgJson.branchOrgId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getDepartmentByBranchOrgId")
	@PostMapping("/getDepartmentByBranchOrgId")
	public Result getDepartmentByBranchOrgId(@RequestBody String params) {
		try {
			Object object = SecurityUtils.getSubject().getPrincipal();
			UserEntity user = (UserEntity) object;
			
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
			
			StringUtil.validateIsNull(branchOrgId, "分校ID不能为空");
			
			//如果用户所在的组织为部门，那么就直接返回部门即可
			OrgEntity orgEntity = orgService.getById(user.getOrgId());
			if(orgEntity!=null && orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_3.getValue())){
				List<OrgEntity> list = new ArrayList<>();
				list.add(orgEntity);
				return Result.success(list);
			}else{
				List<OrgEntity> list = orgService.getDepartmentListByBranchOrgId(branchOrgId);
				return Result.success(list);
			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取部门失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "修改部门名称接口")
	@ApiJsonObject(name = "updateOrg", value = {
			@ApiJsonProperty(name = OrgJson.orgId),
			@ApiJsonProperty(name = OrgJson.orgName),
			@ApiJsonProperty(name = OrgJson.orderNum)})
	@ApiImplicitParam(name = "params", required = true, dataType = "updateOrg")
	@PostMapping("/updateOrg")
	public Result updateOrg(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String orgId = String.valueOf(jsonObject.get("orgId"));
			String orgName = String.valueOf(jsonObject.get("orgName"));
			String orderNum = String.valueOf(jsonObject.get("orderNum"));
			
			StringUtil.validateIsNull(orgId, "部门ID不能为空");
			StringUtil.validateIsNull(orgId, "部门名称不能为空");
			StringUtil.validateIsNull(orderNum, "排序值不能为空");
			
			OrgEntity entity = orgService.getById(orgId);
			entity.setOrgName(orgName);
			entity.setOrderNum(Integer.parseInt(orderNum));
			
			this.orgService.saveOrUpdate(entity);
			
			return Result.success("修改部门成功！");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("修改部门失败，失败原因：" + e.getMessage());
		}
	}
	

}
