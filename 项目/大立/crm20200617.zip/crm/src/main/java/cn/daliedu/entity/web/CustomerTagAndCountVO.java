package cn.daliedu.entity.web;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * 客户标签及数量
 * @author xiechao
 * @time 2019年12月5日 下午1:57:35
 * @version 1.0.0 
 * @description 
 */
@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class CustomerTagAndCountVO {
	private String customerTagId;
	
	private Integer customerTagIdCount;
}
