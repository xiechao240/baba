package cn.daliedu.mapper;

import cn.daliedu.entity.ContractEntity;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 客户合同表 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-10-31
 */
public interface ContractMapper extends BaseMapper<ContractEntity> {
	
	/**
	 * 获取用户的回款金额（目前首页有用到）
	 * @param map
	 * @return
	 */
	public BigDecimal getReturnMoneyByUserId(Map<Object, Object> map) throws Exception;
	
	/**
	 * 获取指定分校的每个员工的合同总金额（目前首页使用）
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getContractAmountCountByBranch(Map<Object, Object> map) throws Exception;
	
	/**
	 * 获取用户创建合同的数量（目前首页有用到）
	 * @param map
	 * @return
	 */
	public BigDecimal getCreateContactCountByUserId(Map<Object, Object> map);
	
	/**
	 * 根据用户ID，获取用户的合同列表（带分页）
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getContractListByUserId(Map<Object, Object> map) throws Exception;
	
	/**
	 * 合同管理报表列表
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getContractList(Map<Object, Object> map) throws Exception;
	
	/**
	 * 合同管理报表列表总数
	 * @param map 查询组合参数集合
	 */
	public Long getContractListCount(Map<Object, Object> map);
	
	
	
	
	
	/**
	 * 获取客户合同列表
	 * @param map
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getContractListByCustomerId(Map<Object, Object> map);
	
	/**
	 * 获取客户合同列表总数
	 * @param map
	 * @return
	 */
	public Long getContractListByCustomerIdCount(Map<Object, Object> map);
}
