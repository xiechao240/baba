package cn.daliedu.mapper;

import cn.daliedu.entity.TaskEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 动态定时任务 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-12-28
 */
public interface TaskMapper extends BaseMapper<TaskEntity> {

}
