package cn.daliedu.entity.json;

import cn.daliedu.config.swagger.model.ApiSingleParam;

/**
 * <p>
 * swagger注释属性：通话属性json
 * </p>
 *
 * @author xiechao
 * @since 2019-05-06
 */
public class CallJson{
	
	@ApiSingleParam(value = "呼叫号码", example = "18312346952")
	public static final String callNumber = "callNumber";
	
	@ApiSingleParam(value = "应答状态（0：呼出，对方未振铃，可能是空号  1：呼出，对方未接听  2：接通  3：呼入，未接来电）", example = "2")
	public static final String callState = "callState";
	
	@ApiSingleParam(value = "开始时间", example = "2019-11-23 11:40:00")
	public static final String startTime = "startTime";
	
	@ApiSingleParam(value = "结束时间", example = "2019-11-23 11:50:00")
	public static final String endTime = "endTime";
	
	@ApiSingleParam(value = "接听时间", example = "2019-11-23 11:41:00")
	public static final String answerTime = "answerTime";
	
	@ApiSingleParam(value = "呼出方式,1：座机，2：手机，目前传1即可，因为只接入座机方案，手机拨号还未接入", example = "1")
	public static final String callType = "callType";
	
	
	
}
