package cn.daliedu.shiro;

import org.apache.shiro.authc.UsernamePasswordToken;

import cn.daliedu.enums.LoginType;
import cn.daliedu.enums.OrgTypeEnum;

/**
 * @author 1921494052@qq.com
 * @date 2018/7/26
 */
public class MyUsernamePasswordToken extends UsernamePasswordToken {
	private static final long serialVersionUID = 8824863415145938949L;
	
	/**
	 * 用户类型(预留，暂时未启用此字段)
	 */
//	private String userType;
	
	/**
	 * 登录类型，密码登录，免密登录
	 */
	private LoginType loginType;

	public MyUsernamePasswordToken(final String username, final String password) {
		super(username, password);
		this.loginType = LoginType.PASSWORD;
	}

	public MyUsernamePasswordToken(final String username, final String password, String userType) {
		super(username, password);
//		this.userType = userType;
		this.loginType = LoginType.PASSWORD;
	}
	
	/**免密登录*/
    public MyUsernamePasswordToken(final String username, LoginType loginType) {
        super(username, "", false, null);
//        this.userType = SysUserTypeEnum.VIP_TYPE.getValue();//免密登录的，都是会员版本
        this.loginType = loginType;  //目前增加了一个一签通登录类型，所以在调用这个构造方法后，需要再
    }


	public LoginType getLoginType() {
		return loginType;
	}

	public void setLoginType(LoginType loginType) {
		this.loginType = loginType;
	}

//	public String getUserType() {
//		return userType;
//	}
//
//	public void setUserType(String userType) {
//		this.userType = userType;
//	}

}
