package cn.daliedu.service.impl;

import cn.daliedu.entity.CustomerCountEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.mapper.CustomerCountMapper;
import cn.daliedu.service.CustomerCountService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

/**
 * <p>
 * 每天统计分校的客户总数与用户的客户总数 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-12-06
 */
@Service
public class CustomerCountServiceImpl extends ServiceImpl<CustomerCountMapper, CustomerCountEntity> implements CustomerCountService {

	@Resource
	CustomerCountMapper customerCountMapper;
	
	
	
	@Override
	public boolean existBranchCustomerCountData(String branchOrgId, String date) {
		CustomerCountEntity entity = customerCountMapper.selectOne(
				new QueryWrapper<CustomerCountEntity>().eq("data_type", "1")
				.eq("branch_org_id", branchOrgId).eq("create_date", date).last("limit 1"));
		if(entity!=null){
			return true;
		}
		return false;
	}



	@Override
	public boolean existUserCustomerCountData(String userId, String date) {
		CustomerCountEntity entity = customerCountMapper.selectOne(
				new QueryWrapper<CustomerCountEntity>().eq("data_type", "2")
				.eq("user_id", userId).eq("create_date", date).last("limit 1"));
		if(entity!=null){
			return true;
		}
		return false;
	}


	@Override
	public Integer getCustomerCountByScheduled(Map<Object, Object> map) {
		return customerCountMapper.getCustomerCountByScheduled(map);
	}
	
	
}
