package cn.daliedu.util;

import java.security.MessageDigest;

/**
 * Created on 2018/7/19
 *
 * @author
 */
public class MD5Util {

	public static String encrypt(String encryptStr) {
		MessageDigest md5;
		try {
			md5 = MessageDigest.getInstance("MD5");
			byte[] md5Bytes = md5.digest(encryptStr.getBytes());
			StringBuffer hexValue = new StringBuffer();
			for (int i = 0; i < md5Bytes.length; i++) {
				int val = ((int) md5Bytes[i]) & 0xff;
				if (val < 16)
					hexValue.append("0");
				hexValue.append(Integer.toHexString(val));
			}
			encryptStr = hexValue.toString();
		}
		catch (Exception e) {
			throw new RuntimeException(e);
		}
		return encryptStr;
	}

	public static String encrypt16(String encryptStr) {
		return encrypt(encryptStr).substring(8, 24);
	}
	
	public static void main(String[] args) {
		System.out.println(MD5Util.encrypt("123456"));//e10adc3949ba59abbe56e057f20f883e
		System.out.println(MD5Util.encrypt("12345678"));//25d55ad283aa400af464c76d713c07ad
		System.out.println(MD5Util.encrypt("aa123456"));//8a6f2805b4515ac12058e79e66539be9
		System.out.println(MD5Util.encrypt("aa12345678"));//d4f2a60315eef2b600cf0240ac0c37ad
		System.out.println(MD5Util.encrypt("dali@123"));
		System.out.println(MD5Util.encrypt("******"));
//		if("e10adc3949ba59abbe56e057f20f883e".equals(MD5Util.encrypt("123456"))){
//			Log4jUtil.info("相等。。");
//		}
	}

}
