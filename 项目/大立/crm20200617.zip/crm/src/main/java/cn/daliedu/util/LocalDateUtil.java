package cn.daliedu.util;

import org.apache.commons.lang3.time.DateFormatUtils;

import java.sql.Timestamp;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

/**
 * 日期工具类
 * @author xiechao
 * @time 2019年11月1日 上午9:10:53
 * @version 1.0.0 
 * @description
 */
public class LocalDateUtil{
	
	/**
	 * 将字符串日期，转化为LocalDate日期
	 * @param date 字符串格式日期
	 * @param pattern 时间格式，传null则默认返回yyyy-MM-dd格式
	 */
	public static LocalDate getLocalDate(String date, String pattern){
		if(pattern==null){
			DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			return LocalDate.parse(date, df);
		}else{
			DateTimeFormatter df = DateTimeFormatter.ofPattern(pattern);
			return LocalDate.parse(date, df);
		}
	}
	
	
}
