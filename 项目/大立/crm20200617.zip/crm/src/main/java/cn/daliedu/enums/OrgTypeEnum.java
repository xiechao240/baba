package cn.daliedu.enums;


/**
 * 组织结构类型枚举类
 * @author xiechao
 * @time 2019年9月20日 下午3:52:34
 * @version 1.0.0 
 * @description
 */
public enum OrgTypeEnum {
	/**
	 * 顶级机构
	 */
	ORG_TYPE_0("0", "顶级机构"), 
	/**
	 * 省份
	 */
	ORG_TYPE_1("1", "省份"), 
	/**
	 * 分校
	 */
	ORG_TYPE_2("2", "分校"),
	/**
	 * 部门
	 */
	ORG_TYPE_3("3", "部门"),
	/**
	 * 代理商
	 */
	ORG_TYPE_4("4", "代理商"),
	/**
	 * 代理商下的节点
	 */
	ORG_TYPE_5("5", "代理商下的节点"),
	/**
	 * 代理商下的子节点
	 */
	ORG_TYPE_6("6", "代理商下的子节点");

	private String value;
	private String desc;

	OrgTypeEnum(final String value, final String desc) {
		this.value = value;
		this.desc = desc;
	}


	public String getValue() {
		return value;
	}
	
	public String getDesc() {
		return desc;
	}
	
}