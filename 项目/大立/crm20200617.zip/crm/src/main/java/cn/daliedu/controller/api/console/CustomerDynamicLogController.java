package cn.daliedu.controller.api.console;


import java.io.File;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import cn.daliedu.config.param.SysParamConfig;
import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.CustomerDynamicFileEntity;
import cn.daliedu.entity.CustomerTagEntity;
import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.json.CustomerJson;
import cn.daliedu.entity.json.GlobalJson;
import cn.daliedu.enums.DynamicTypeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.CustomerDynamicFileService;
import cn.daliedu.service.CustomerDynamicLogService;
import cn.daliedu.util.LocalDateTimeUtil;
import cn.daliedu.util.PageUtil;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 客户动态记录表，如新建客户，客户资料变更等操作记录 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2019-10-29
 */
@RestController
@Api(description = "客户动态记录相关接口")
@RequestMapping(value = "${rest.path}/console/customerdDynamicLog") 
public class CustomerDynamicLogController {
	
	@Autowired
	CustomerDynamicLogService customerDynamicLogService;
	
	@Autowired
	CustomerDynamicFileService customerDynamicFileService;
	
	@ApiOperation(value = "根据客户动态ID，获取客户上传的内容图片（当动态类型为：10，添加跟进记录，此类型需要调用这个接口）")
	@ApiJsonObject(name = "getCustomerDynamicImage", value = { 
			@ApiJsonProperty(name = CustomerJson.customerDynamicId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerDynamicImage")
	@PostMapping("/getCustomerDynamicImage")
	public Result getCustomerDynamicImage(@RequestBody String params) {
		try{
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String customerDynamicId = String.valueOf(jsonObject.get("customerDynamicId"));
			
			List<CustomerDynamicFileEntity> list = customerDynamicFileService.getCustomerDynamicFileById(customerDynamicId);
			if(list!=null && list.size()>0){
				for(CustomerDynamicFileEntity entity : list){
					entity.setFilePath(SysParamConfig.UPLOAD_FILE_DOMAIN_NAME_PATH + File.separatorChar + entity.getFilePath());
				}
				return Result.success(list);
			}
			return Result.error("当前客户无动态");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户动态列表失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "获取客户动态列表(带分页)")
	@ApiJsonObject(name = "getCustomerDynamicList", value = { 
			@ApiJsonProperty(name = CustomerJson.customerId),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerDynamicList")
	@PostMapping("/getCustomerDynamicList")
	public Result getCustomerDynamicList(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String pageNum = String.valueOf(jsonObject.get("pageNum"));
				String pageSize = String.valueOf(jsonObject.get("pageSize"));
				String customerId = String.valueOf(jsonObject.get("customerId"));
				
				StringUtil.validateIsNull(pageNum, "请输入页码");
				StringUtil.validateIsNull(pageSize, "请输入每页记录数");
				
	            
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
	            paramMap.put("pageSize", Integer.parseInt(pageSize));
	            paramMap.put("customerId", customerId);
	    		

	            List<LinkedHashMap<Object, Object>> list = customerDynamicLogService.getCustomerDynamicList(paramMap);
	            if(list!=null && list.size()>0){
					for(LinkedHashMap<Object, Object> map : list){
						//map.put("create_date", LocalDateTimeUtil.getDateTime(map.get("create_date").toString()));
						//如果不需要转换，下面的page.setRecords(tempList);设置为tempList即可
						if(map.get("dynamic_type").toString().equals(DynamicTypeEnum.TYPE_10.getValue()) ||
								//如果通话没有接通，则不会有录音，前台根据dynamic_type_sub判断通话是否成功，如果成功了就会有录音，那么customerDynamicFileList就会返回内容
								map.get("dynamic_type").toString().equals(DynamicTypeEnum.TYPE_4.getValue())){
							List<CustomerDynamicFileEntity> dynamicFileList = customerDynamicFileService.getCustomerDynamicFileById(map.get("dynamic_id").toString());
							if(dynamicFileList!=null && dynamicFileList.size()>0){
								for(CustomerDynamicFileEntity entity : dynamicFileList){
									entity.setFilePath(SysParamConfig.UPLOAD_FILE_DOMAIN_NAME_PATH + File.separatorChar + entity.getFilePath());
								}
								map.put("customerDynamicFileList", dynamicFileList);
							}
						}else{
							map.put("customerDynamicFileList", "");
						}
	            	}
	            	
					Long total = customerDynamicLogService.getCustomerDynamicListCount(paramMap);
					
					IPage page  = new Page();
					page.setTotal(total.longValue());
					page.setSize(Long.parseLong(pageSize));
					page.setRecords(list);
					return Result.success(page);
				}
	            return Result.error("当前客户无动态");
			}
			return Result.error("无法获取客户动态列表");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户动态列表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "添加跟进记录,不支持文件上传", notes="")
	@ApiImplicitParams({
	        @ApiImplicitParam(paramType = "query", dataType = "String", name = "dynamicContent", value = "用户填写的跟进日志,动态内容", required = true),
	        @ApiImplicitParam(paramType = "query", dataType = "String", name = "customerId", value = "客户ID", required = true)})
	@PostMapping(value = "/insertFollowLog")
	public Result insertFollowLog(HttpServletRequest request, @RequestParam(required = true) String dynamicContent, @RequestParam(required = true) String customerId) {
	    try {
	    	StringUtil.validateIsNull(dynamicContent, "请添加动态内容");
	    	StringUtil.validateIsNull(customerId, "请输入客户ID");
	    	
	    	boolean flag = customerDynamicLogService.insertFollowLog(customerId, dynamicContent);
	    	if(flag){
	    		return Result.success("添加成功");
	    	}
	    	
	    	return Result.error("添加失败");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("添加跟进记录失败，失败原因：" + e.getMessage());
		}
	}
	

	@ApiOperation(value = "添加跟进记录,支持多文件上传(只支持上传*.jpg,*.bmp,*.png格式文件)，注：多文件上传，不支持swagger页面上测试", notes="注：多文件上传，不支持swagger页面上测试")
	@ApiImplicitParams({
	        @ApiImplicitParam(name = "files",value = "多个文件，",paramType = "formData",allowMultiple=true,required = false,dataType = "file"),
	        @ApiImplicitParam(paramType = "query", dataType = "String", name = "dynamicContent", value = "用户填写的跟进日志,动态内容", required = true),
	        @ApiImplicitParam(paramType = "query", dataType = "String", name = "customerId", value = "客户ID", required = true)})
	@PostMapping(value = "/insertFollowLogFile", headers = "content-type=multipart/form-data")
	public Result insertFollowLogFile(HttpServletRequest request, @RequestParam(required = true) String dynamicContent, @RequestParam(required = true) String customerId,
			@RequestParam(value = "files", required = false) MultipartFile[] files) {
	    try {
	    	//目前没有文件服务器，只上传至当前部署的服务器上，就做不了集群，或者使用ftp服务器，就可以做集群了，先上传至当前部署的服务器上吧
	    	//开发测试阶段使用的是： ln -sv /home/dali/fileupload/crm/image /home/dali/tomcat-cluster/tomcat-8081/webapps/crm/upload
	    	//创建软链的方式实现的，问题就是问题新包的时候，这个upload文件夹会删除掉
	    	//http://upload.daliedu.cn/image/1/20140321103225_.jpg 可直接访问到1.51机器上的/home/dali/fileupload/crm/image/1/目录下的文件
	    	if(files!=null){
	    		if(files.length>9){
		    		return Result.error("文件一次性最大支持9个，请检查");
		    	}
	    	}
	    	
	    	
	    	StringUtil.validateIsNull(dynamicContent, "请添加动态内容");
	    	StringUtil.validateIsNull(customerId, "请输入客户ID");
	    	
	    	boolean flag = customerDynamicLogService.insertFollowLog(request, customerId, dynamicContent, files);
	    	if(flag){
	    		return Result.success("添加成功");
	    	}
	    	
	    	return Result.error("添加失败");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("添加跟进记录失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
}
