package cn.daliedu.controller.api.console;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.daliedu.entity.AreaDataEntity;
import cn.daliedu.service.AreaDataService;
import cn.daliedu.util.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 区域数据表 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2019-11-05
 */
@RestController
@Api(description = "地理区域相关接口")
@RequestMapping(value = "${rest.path}/console/area") 
public class AreaDataController {
	
	@Autowired
	AreaDataService areaDataService;
	
	@ApiOperation(value = "获取省市区三级联动，树形数据")
	@PostMapping("/findTreeAreaList")
	public Result findTreeAreaList(){
		try{
			List<AreaDataEntity> list = areaDataService.findTreeAreaList();
			
			return Result.success(list);
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取部门树形菜单集合接口失败，失败原因：" + e.getMessage());
		}
	}

}
