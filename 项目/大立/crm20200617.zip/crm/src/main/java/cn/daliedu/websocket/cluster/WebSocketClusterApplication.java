package cn.daliedu.websocket.cluster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
 public class WebSocketClusterApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebSocketClusterApplication.class, args);
		System.out.println();
		System.out.println("-----------WebSocket版本，启动成功-------------");
	}

}
