package cn.daliedu.service.impl;

import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.entity.CustomerFlowOperationConfigEntity;
import cn.daliedu.entity.json.CustomerFlowOperationConfigJson;
import cn.daliedu.mapper.CustomerFlowOperationConfigMapper;
import cn.daliedu.service.CustomerFlowOperationConfigService;

/**
 * <p>
 * 客户流转操作配置表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-15
 */
@Service
public class CustomerFlowOperationConfigServiceImpl extends ServiceImpl<CustomerFlowOperationConfigMapper, CustomerFlowOperationConfigEntity> implements CustomerFlowOperationConfigService {

	@Resource
	CustomerFlowOperationConfigMapper customerFlowOperationConfigMapper;
	
	@Override
	public List<CustomerFlowOperationConfigEntity> getCustomerFlowOperationConfigByType(String operationType) {
		return customerFlowOperationConfigMapper.selectList(new QueryWrapper<CustomerFlowOperationConfigEntity>().eq("operation_type", operationType));
	}

	@Override
	public boolean saveCustomerFlowOperationConfig(CustomerFlowOperationConfigJson[] arrList) {
		// 逻辑为： 先删除已经存在的所有配置数据，再新增
		customerFlowOperationConfigMapper.deleteAllData();
		
		for(CustomerFlowOperationConfigJson json : arrList){
			for(String operationType : json.getOperationType()){
				CustomerFlowOperationConfigEntity entity = new CustomerFlowOperationConfigEntity();
				entity.setOperationCause(json.getOperationCause());
				entity.setOperationCauseId(json.getOperationCauseId());
				entity.setOperationType(operationType);
				
				customerFlowOperationConfigMapper.insert(entity);
			}
		}
		
		return true;
	}


	@Override
	public List<LinkedHashMap<Object, Object>> getAllCustomerFlowOperation() {
		return customerFlowOperationConfigMapper.getAllCustomerFlowOperation();
	}
	
	

}
