package cn.daliedu.service.impl;

import java.io.InputStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.entity.CustomerDynamicLogEntity;
import cn.daliedu.entity.CustomerEntity;
import cn.daliedu.entity.CustomerImportHistoryEntity;
import cn.daliedu.entity.CustomerSelfDefineItemConfigDetailEntity;
import cn.daliedu.entity.CustomerSelfDefineItemConfigEntity;
import cn.daliedu.entity.CustomerSelfDefineItemEntity;
import cn.daliedu.entity.CustomerTagEntity;
import cn.daliedu.entity.DictEntity;
import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.UserCustomerEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.json.CustomerModel;
import cn.daliedu.enums.CustomerGroupTypeIdEnum;
import cn.daliedu.enums.CustomerSourceTypeEnum;
import cn.daliedu.enums.CustomerStageEnum;
import cn.daliedu.enums.DynamicTypeEnum;
import cn.daliedu.enums.MyCustomerTypeEnum;
import cn.daliedu.enums.OrgTypeEnum;
import cn.daliedu.enums.ParameterEnum;
import cn.daliedu.enums.ResultCodeEnum;
import cn.daliedu.enums.SeaTypeEnum;
import cn.daliedu.enums.SexEnum;
import cn.daliedu.enums.UserTypeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.mapper.CustomerDynamicLogMapper;
import cn.daliedu.mapper.CustomerImportHistoryMapper;
import cn.daliedu.mapper.CustomerMapper;
import cn.daliedu.mapper.CustomerSelfDefineItemConfigMapper;
import cn.daliedu.mapper.CustomerSelfDefineItemMapper;
import cn.daliedu.mapper.CustomerTagMapper;
import cn.daliedu.mapper.UserCustomerMapper;
import cn.daliedu.service.CustomerSelfDefineItemConfigService;
import cn.daliedu.service.CustomerService;
import cn.daliedu.service.CustomerTagService;
import cn.daliedu.service.DictService;
import cn.daliedu.service.OrgService;
import cn.daliedu.service.ParameterService;
import cn.daliedu.service.UserCustomerService;
import cn.daliedu.service.UserService;
import cn.daliedu.util.DateUtil;
import cn.daliedu.util.HttpClientUtil;
import cn.daliedu.util.JsonUtil;
import cn.daliedu.util.PoiUtil;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;

/**
 * <p>
 * 客户表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-26
 */
@Service
public class CustomerServiceImpl extends ServiceImpl<CustomerMapper, CustomerEntity> implements CustomerService {
	@Autowired
	CustomerSelfDefineItemConfigService customerSelfDefineItemConfigService;
	
	@Autowired
	CustomerTagService customerTagService;
	
	@Autowired
	UserCustomerService userCustomerService;
	
	@Autowired
	OrgService orgService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	DictService dictService;
	
	@Autowired
	ParameterService parameterService;
	
	
	@Resource
	UserCustomerMapper userCustomerMapper;
	
	@Resource
	CustomerSelfDefineItemConfigMapper customerSelfDefineItemConfigMapper;
	
	@Resource
	CustomerSelfDefineItemMapper customerSelfDefineItemMapper;
	
	@Resource
	CustomerMapper customerMapper;
	
	@Resource
	CustomerDynamicLogMapper customerDynamicLogMapper;
	
	@Resource
	CustomerTagMapper customerTagMapper;
	
	@Resource
	CustomerImportHistoryMapper customerImportHistoryMapper;
	
	
	
	@Override
	public List<LinkedHashMap<Object, Object>> getCustomerListByRepetition(Map<Object, Object> map) throws Exception {
		return customerMapper.getCustomerListByRepetition(map);
	}


	@Override
	public Long getCustomerListByRepetitionCount(Map<Object, Object> map) throws Exception {
		return customerMapper.getCustomerListByRepetitionCount(map);
	}


	@Override
	public List<LinkedHashMap<Object, Object>> getCustomerListByPromotionManage(Map<Object, Object> map)
			throws Exception {
		return customerMapper.getCustomerListByPromotionManage(map);
	}


	@Override
	public Long getCustomerListByPromotionManageCount(Map<Object, Object> map) {
		return customerMapper.getCustomerListByPromotionManageCount(map);
	}


	@Override
	public List<LinkedHashMap<Object, Object>> getCustomerListByImport(Map<Object, Object> map) {
		return customerMapper.getCustomerListByImport(map);
	}


	@Override
	public List<LinkedHashMap<Object, Object>> getCustomerListByGeneralize(Map<Object, Object> map) {
		return customerMapper.getCustomerListByGeneralize(map);
	}


	@Override
	public List<LinkedHashMap<Object, Object>> getCustomerListByRepository(Map<Object, Object> map) {
		return customerMapper.getCustomerListByRepository(map);
	}


	@Override
	public Long getCustomerListByImportCount(Map<Object, Object> map) {
		return customerMapper.getCustomerListByImportCount(map);
	}


	@Override
	public Long getCustomerListByGeneralizeCount(Map<Object, Object> map) {
		return customerMapper.getCustomerListByGeneralizeCount(map);
	}


	@Override
	public Long getCustomerListByRepositoryCount(Map<Object, Object> map) {
		return customerMapper.getCustomerListByRepositoryCount(map);
	}


	@Override
	public boolean existsCustomerByMobile(String mobile) {
		List<CustomerEntity> list = this.getCustomerListByMobile(mobile);
		if(list.size()>0){
			return true;
		}
		return false;
	}


	@Override
	public boolean existsCustomerByMobileAndBranchOrgId(String mobile, String branchOrgId) {
		List<CustomerEntity> list = this.getCustomerListByMobileAndBranchOrgId(mobile, branchOrgId);
		if(list.size()>0){
			return true;
		}
		return false;
	}


	@Override
	public BigDecimal getCustomerContactCountByUserId(Map<Object, Object> map) {
		return customerMapper.getCustomerContactCountByUserId(map);
	}


	@Override
	public boolean updateCancelShareToUserCustomer(List<String> customerIdList) throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity bean = (UserEntity) object;
			
			//1.移除我共享给同事的客户 
			userCustomerMapper.delete(new QueryWrapper<UserCustomerEntity>()
					.eq("user_id", bean.getId()).eq("my_customer_type", MyCustomerTypeEnum.TYPE_3.getValue())
					.in("customer_id", customerIdList));
			//2.移除共享给我的客户
			userCustomerMapper.delete(new QueryWrapper<UserCustomerEntity>()
					.eq("my_customer_type", MyCustomerTypeEnum.TYPE_2.getValue())
					.in("customer_id", customerIdList));
			return true;
		}
		return false;
	}


	@Override
	public boolean removeShareToMyCustomer(List<String> customerIdList) throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity bean = (UserEntity) object;
			
			//1.移除共享给我的客户
			userCustomerMapper.delete(new QueryWrapper<UserCustomerEntity>()
					.eq("user_id", bean.getId()).eq("my_customer_type", MyCustomerTypeEnum.TYPE_2.getValue())
					.in("customer_id", customerIdList));
			//2.移除我共享给同事的客户
			userCustomerMapper.delete(new QueryWrapper<UserCustomerEntity>()
					.eq("my_customer_type", MyCustomerTypeEnum.TYPE_3.getValue())
					.in("customer_id", customerIdList));
			return true;
		}
		return false;
	}


	@Override
	public boolean updateGetCustomerByRepository(String customerGroupTypeId, List<String> customerIdList) throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity bean = (UserEntity) object;
			
			for(String customerId : customerIdList){
				UserCustomerEntity entity = new UserCustomerEntity();
				entity.setUserId(bean.getId());
				entity.setCustomerId(customerId);
				entity.setMyCustomerType(MyCustomerTypeEnum.TYPE_1.getValue());
				entity.setCreateTime(LocalDateTime.now());
				userCustomerMapper.insert(entity);
			}
			
			//将客户的公海类别置空，此时客户不再待在公海里面（包括业务组公海与公司大公海）
			for(String customerId : customerIdList){
				CustomerEntity entity = this.getById(customerId);
				if(entity!=null){
					entity.setSeaType("");
					entity.setCustomerGroupTypeId(customerGroupTypeId);
					customerMapper.updateById(entity);
				}
			}
			
			return true;
		}
		return false;
	}
	
	

	@Override
	public boolean updateGetCustomerByBusinessGroupSea(String customerGroupTypeId, List<String> customerIdList)
			throws Exception {
		boolean exist = false;
		for(String customerId : customerIdList){
			CustomerEntity entity = this.getById(customerId);
			//判断state为空的客户是否存在
			exist = existsCustomerByMobileAndBranchOrgId(entity.getMobile(), entity.getBranchOrgId());
			if(exist){
				throw new BusinessException(entity.getCustomerName()+"已经在你所在的分校中存在，不能领取");
			}
		}
		
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity bean = (UserEntity) object;
			
			for(String customerId : customerIdList){
				UserCustomerEntity entity = new UserCustomerEntity();
				entity.setUserId(bean.getId());
				entity.setCustomerId(customerId);
				entity.setMyCustomerType(MyCustomerTypeEnum.TYPE_1.getValue());
				entity.setCreateTime(LocalDateTime.now());
				userCustomerMapper.insert(entity);
			}
			
			//将客户的公海类别置空，此时客户不再待在公海里面（包括业务组公海与公司大公海）
			for(String customerId : customerIdList){
				CustomerEntity entity = this.getById(customerId);
				if(entity!=null){
					entity.setState("");
					entity.setCustomerGroupTypeId(customerGroupTypeId);
					customerMapper.updateById(entity);
				}
			}
			
			return true;
		}
		return false;
	}


	@Override
	public boolean updateGetCustomerByCompanySea(String branchOrgId, String customerGroupTypeId, List<String> customerIdList)
			throws Exception {
		//对customerIdList增加判断，如果有客户已经在分校中存在，则不能从公司回收站领取回去
		boolean exist = false;
		for(String customerId : customerIdList){
			CustomerEntity entity = this.getById(customerId);
			exist = existsCustomerByMobileAndBranchOrgId(entity.getMobile(), branchOrgId);
			if(exist){
				throw new BusinessException(entity.getCustomerName()+"已经在你所在的分校中存在，不能领取");
			}
		}
		
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity bean = (UserEntity) object;
			
			for(String customerId : customerIdList){
				UserCustomerEntity entity = new UserCustomerEntity();
				entity.setUserId(bean.getId());
				entity.setCustomerId(customerId);
				entity.setMyCustomerType(MyCustomerTypeEnum.TYPE_1.getValue());
				entity.setCreateTime(LocalDateTime.now());
				userCustomerMapper.insert(entity);
			}
			
			//将客户的公海类别置空，此时客户不再待在公海里面（包括业务组公海与公司大公海）
			for(String customerId : customerIdList){
				CustomerEntity entity = this.getById(customerId);
				if(entity!=null){
					entity.setBranchOrgId(branchOrgId);
					entity.setState("");
					entity.setCustomerGroupTypeId(customerGroupTypeId);
					customerMapper.updateById(entity);
				}
			}
			
			return true;
		}
		return false;
	}


	@Override
	public boolean updateAllocationCustomerByCustomerIdBusinessGroupSea(String userId, List<String> customerIdList) throws Exception{
		boolean exist = false;
		for(String customerId : customerIdList){
			CustomerEntity entity = this.getById(customerId);
			//判断state为空的客户是否存在
			exist = existsCustomerByMobileAndBranchOrgId(entity.getMobile(), entity.getBranchOrgId());
			if(exist){
				throw new BusinessException(entity.getCustomerName()+"已经在你所在的分校中存在，不能领取");
			}
		}
		//分配客户，即在用户客户表添加一条关联的数据即可
		for(String customerId : customerIdList){
			UserCustomerEntity entity = new UserCustomerEntity();
			entity.setUserId(userId);
			entity.setCustomerId(customerId);
			entity.setMyCustomerType(MyCustomerTypeEnum.TYPE_1.getValue());
			entity.setCreateTime(LocalDateTime.now());
			userCustomerMapper.insert(entity);
		}
		
		//将客户的公海类别置为""
		for(String customerId : customerIdList){
			CustomerEntity entity = this.getById(customerId);
			if(entity!=null){
				entity.setState("");
				entity.setCustomerGroupTypeId(CustomerGroupTypeIdEnum.TYPE_6.getValue());
				customerMapper.updateById(entity);
			}
		}
		return true;
	}
	
	
	
	
	@Override
	public boolean updateAllocationCustomerByCustomerIdRepository(String userId, List<String> customerIdList)
			throws Exception {
		//分配客户，即在用户客户表添加一条关联的数据即可
		for(String customerId : customerIdList){
			UserCustomerEntity entity = new UserCustomerEntity();
			entity.setUserId(userId);
			entity.setCustomerId(customerId);
			entity.setMyCustomerType(MyCustomerTypeEnum.TYPE_1.getValue());
			entity.setCreateTime(LocalDateTime.now());
			userCustomerMapper.insert(entity);
		}
		
		//将客户的公海类别置为""
		for(String customerId : customerIdList){
			CustomerEntity entity = this.getById(customerId);
			if(entity!=null){
				entity.setSeaType("");
//				entity.setState("");
				entity.setCustomerGroupTypeId(CustomerGroupTypeIdEnum.TYPE_6.getValue());
				customerMapper.updateById(entity);
			}
		}
		return true;
	}


	@Override
	public boolean updateAllocationCustomerByCustomerIdCompanySea(String branchOrgId, String userId, List<String> customerIdList) throws Exception{
		boolean exist = false;
		for(String customerId : customerIdList){
			CustomerEntity entity = this.getById(customerId);
			//判断state为空的客户是否存在
			exist = existsCustomerByMobileAndBranchOrgId(entity.getMobile(), branchOrgId);
			if(exist){
				throw new BusinessException(entity.getCustomerName()+"已经在你所在的分校中存在，不能领取");
			}
		}
		//分配客户，即在用户客户表添加一条关联的数据即可
		for(String customerId : customerIdList){
			UserCustomerEntity entity = new UserCustomerEntity();
			entity.setUserId(userId);
			entity.setCustomerId(customerId);
			entity.setMyCustomerType(MyCustomerTypeEnum.TYPE_1.getValue());
			entity.setCreateTime(LocalDateTime.now());
			userCustomerMapper.insert(entity);
		}
		
		//将客户的公海类别置为""
		for(String customerId : customerIdList){
			CustomerEntity entity = this.getById(customerId);
			if(entity!=null){
				entity.setBranchOrgId(branchOrgId);
				entity.setState("");
				entity.setCustomerGroupTypeId(CustomerGroupTypeIdEnum.TYPE_6.getValue());
				customerMapper.updateById(entity);
			}
		}
		return true;
	}


	@Override
	public Integer getCustomerCountByUserId(String userId) {
		return customerMapper.getCustomerCountByUserId(userId);
	}


	@Override
	public Integer getCustomerCountByBranchOrgId(String branchOrgId) {
		return customerMapper.getCustomerCountByBranchOrgId(branchOrgId);
	}


	@Override
	public BigDecimal getLossCustomerCountByUser(Map<Object, Object> map) {
		return customerMapper.getLossCustomerCountByUser(map);
	}


	@Override
	public BigDecimal getLossCustomerCountByBranch(Map<Object, Object> map) {
		return customerMapper.getLossCustomerCountByBranch(map);
	}


	@Override
	public BigDecimal getCreateCustomerCountByUser(Map<Object, Object> map) {
		return customerMapper.getCreateCustomerCountByUser(map);
	}


	@Override
	public BigDecimal getCreateCustomerCountByBranch(Map<Object, Object> map) {
		return customerMapper.getCreateCustomerCountByBranch(map);
	}


	@Override
	public BigDecimal getLatelyContactCustomerCount(Map<Object, Object> map) {
		return customerMapper.getLatelyContactCustomerCount(map);
	}


	@Override
	public BigDecimal getCustomerContactCount(Map<Object, Object> map) {
		return customerMapper.getCustomerContactCount(map);
	}


	@Override
	public BigDecimal getBranchCustomerCount(Map<Object, Object> map) {
		return customerMapper.getBranchCustomerCount(map);
	}
	
	
	@Override
	public Integer getAllCustomerCount() {
		return null;
	}
	
	
	@Override
	public List<LinkedHashMap<Object, Object>> getCustomerListByCustomerManage(Map<Object, Object> map)
			throws Exception {
		return customerMapper.getCustomerListByCustomerManage(map);
	}



	@Override
	public Long getCustomerListByCustomerManageCount(Map<Object, Object> map) {
		return customerMapper.getCustomerListByCustomerManageCount(map);
	}



	@Override
	public List<LinkedHashMap<Object, Object>>  getShareRelation(String customerId) {
		LinkedHashMap<Object, Object> linkMap = new LinkedHashMap<Object, Object>();
		
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity bean = (UserEntity) object;
			UserEntity user = userService.getById(bean.getId());
			
			CustomerEntity entity = this.getById(customerId);
			//如果当前操作的用户，与客户的跟进人为同一人，则显示已经共享给的用户列表，前端显示一个加号，可以让用户将客户共享给更多的客户
			if(entity.getFollowUserId().equals(user.getId())){
				//根据客户ID查询共享给我的客户的所有用户
				List<LinkedHashMap<Object, Object>> list = userService.getShareRelationUsers(customerId);
				linkMap.put("type", "1");
				list.add(linkMap);
				return list;
			}else{
				//如果不是同一个人，则直接显示，原跟进人：xxx  即可
				List<LinkedHashMap<Object, Object>>  list = new ArrayList<LinkedHashMap<Object, Object>>();
				UserEntity formUser = userService.getById(entity.getFollowUserId());
				linkMap.put("type", "2");
				linkMap.put("info", "原跟进人：" + userService.getById(formUser.getId()).getUserName());
				list.add(linkMap);
				return list;
			}
			
		}
		return null;
		
	}



	@Override
	public boolean saveCustomer(CustomerModel model, MultipartFile file, UserEntity user) throws Exception {
		//目前改为：超级管理员，区域管理员，分校管理员，部门管理员，普通用户，代理商用户，都可以新建客户，导入客户时有一点点区别
		//客户基础信息
		String customerName = model.getCustomerName();
		String sex = model.getSex();
		String customerSourceType = model.getCustomerSourceType();
		String customerSourceNameValue = model.getCustomerSourceNameValue();
		String customerGroupTypeId = model.getCustomerGroupTypeId();
		String customerQuality = model.getCustomerQuality();
		String customerIntentionLevel = model.getCustomerIntentionLevel();
		String customerIntentionContent = model.getCustomerIntentionContent();
		String promotionUserId = model.getPromotionUserId();
		String weixinId = model.getWeixinId();
		String qq = model.getQq();
		String mobile = model.getMobile();
		String phone = model.getPhone();
		String email = model.getEmail();
		String provinceId = model.getProvinceId();
		String provinceName = model.getProvinceName();
		String cityId = model.getCityId();
		String cityName = model.getCityName();
		String areaId = model.getAreaId();
		String areaName = model.getAreaName();
		String companyName = model.getCompanyName();
		String address = model.getAddress();
		String remark = model.getRemark();
		String jobAge = model.getJobAge();
		String education = model.getEducation();
		String professional = model.getProfessional();
		String customerActivityPage = model.getCustomerActivityPage();
		String customerActivityTypePage = model.getCustomerActivityTypePage();
		
		String branchOrgId = model.getBranchOrgId();//分校ID，当超级管理员，区域管理员，修改客户时，此属性为必填
		
		//客户标签
//		CustomerTagEntity[] customerTagList = model.getCustomerTagList();
		
		//客户自定义信息
//		CustomerSelfDefineItemEntity[] danbanList = model.getDanbanList();
//		CustomerSelfDefineItemEntity[] taobanList = model.getTaobanList();
//		CustomerSelfDefineItemEntity[] neixunList = model.getNeixunList();
//		CustomerSelfDefineItemEntity[] yijiankemuList = model.getYijiankemuList();
//		CustomerSelfDefineItemEntity[] erjiankemuList = model.getErjiankemuList();
//		CustomerSelfDefineItemEntity[] zaojiakemuList = model.getZaojiakemuList();
//		CustomerSelfDefineItemEntity[] jianlikemuList = model.getJianlikemuList();
//		CustomerSelfDefineItemEntity[] xiaofangkemuList = model.getXiaofangkemuList();
//		CustomerSelfDefineItemEntity[] zixungongchengshiList = model.getZixungongchengshiList();
//		CustomerSelfDefineItemEntity yibaotonghangEntity = model.getYibaotonghang();
		String remark2 = String.valueOf(model.getRemark2());
//		String yijiankemu2 = String.valueOf(model.getYijiankemu2());
//		String banjimingcheng2 = String.valueOf(model.getBanjimingcheng2());
		CustomerSelfDefineItemConfigEntity[] selfDefineItemConfigList = model.getSelfDefineItemConfigList();
		
		
//		StringUtil.validateIsNull(customerName, "请输入姓名");
//		StringUtil.validateIsNull(weixinId, "请输入微信号");
//		StringUtil.validateIsNull(qq, "请输入QQ");
		StringUtil.validateIsNull(mobile, "请输入手机");
		StringUtil.validateIsNull(branchOrgId, "请输入分校ID");
//		StringUtil.validateIsNull(phone, "请输入座机");
//		StringUtil.validateIsNull(email, "请输入邮箱");
		String departmentId = "";
		
		if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue())||user.getUserType().equals(UserTypeEnum.TYPE_2.getValue())){
				//||user.getUserType().equals(UserTypeEnum.TYPE_7.getValue()) //代理商不需要传入分校ID了，手动新建的客户属于自己，不过在客户的界面上的右键中可以加入转入分校的功能
			//如果是以上3种类型的用户，则必需传入分校ID
			if(branchOrgId==null || branchOrgId.equals("") || branchOrgId.equals("null")){
				throw new BusinessException("新建客户，请选择录入的分校");
			}
		}
		if(user.getUserType().equals(UserTypeEnum.TYPE_3.getValue()) || user.getUserType().equals(UserTypeEnum.TYPE_4.getValue())
		|| user.getUserType().equals(UserTypeEnum.TYPE_5.getValue()) || user.getUserType().equals(UserTypeEnum.TYPE_6.getValue())){
			OrgEntity branchEntity = orgService.getUserBranchOrgByOrgId(user.getOrgId());
			branchOrgId = branchEntity.getId().toString();
			
			OrgEntity orgEntity = orgService.getById(user.getOrgId());
			if(orgEntity!=null && orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_3.getValue())){
				departmentId = orgEntity.getId();
			}
		}
		
		//如果是部门下的用户，则计算出部门ID
		
		
		//以下用户不可以新建客户，这样的逻辑不符合系统发展
//		if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue())){
//			throw new BusinessException("超级管理员暂不支持手动添加客户，请使用批量导入客户");//除非页面上手工录入客户时，指定分校，即业务组，那么此方法再接收一个分校ID
//		}
//		if(user.getUserType().equals(UserTypeEnum.TYPE_2.getValue())){
//			throw new BusinessException("区域管理员暂不支持手动添加客户，请使用批量导入客户");//除非页面上手工录入客户时，指定分校，即业务组，那么此方法再接收一个分校ID
//		}
//		if(user.getUserType().equals(UserTypeEnum.TYPE_6.getValue())){
//			throw new BusinessException("代理商用户暂不支持手动添加客户，请使用批量导入客户");//除非页面上手工录入客户时，指定分校，即业务组，那么此方法再接收一个分校ID
//		}
		
		//客户查重，以手机号码作为客户是否重复的唯一判断标准----此功能暂时废除
		//客户查重，判断系统参数是否允许重复，如果为1：可以重复，则只判断当前分校下是否已经存在此号码，如果存在，则不允许创建，如果不存在，则可以创建
		//如果为0：不允许重复，则判断整个系统是否存在此号码，如果存在，则不允许创建，如果不存在，则可以创建
//		if(user.getUserType().equals(UserTypeEnum.TYPE_7.getValue())){
//			//如果是代理商用户，则只需要校验代理商是否已经导入此号码的客户即可
//			if(this.getCustomerListByAgentImportMobile(user.getId(), mobile).size()>0){
//				throw new BusinessException("此手机号码的客户，已在您的客户列表中存在，请勿重复创建");
//			}
//		}else{
//			if(parameterService.getParameterByKey(ParameterEnum.IS_REPETITION.getValue()).equals("1")){
//				boolean flag = existsCustomerByMobileAndBranchOrgId(mobile, branchOrgId);
//				if(flag){
//					OrgEntity orgEntity = orgService.getById(branchOrgId);
//					throw new BusinessException("此手机号码的客户已在  "+ orgEntity.getOrgName() +"  中存在，请勿重复创建");
//				}
//			}else{
//				if(existsCustomerByMobile(mobile)){
//					throw new BusinessException("此手机号码的客户已在系统中存在，请勿重复创建");
//				}
//			}
//		}
		if(parameterService.getParameterByKey(ParameterEnum.IS_REPETITION.getValue()).getParamValue().equals("1")){
			boolean flag = existsCustomerByMobileAndBranchOrgId(mobile, branchOrgId);
			if(flag){
				OrgEntity orgEntity = orgService.getById(branchOrgId);
				throw new BusinessException("此手机号码的客户已在  "+ orgEntity.getOrgName() +"  中存在，请勿重复创建");
			}
		}else{
			if(existsCustomerByMobile(mobile)){
				throw new BusinessException("此手机号码的客户已在系统中存在，请勿重复创建");
			}
		}
		
		

		
		//1.保存客户信息
		CustomerEntity customerEntity = new CustomerEntity();
		//现在改为代理商创建的，跟区域管理员一样，自己创建的也属于分校
//		if(user.getUserType().equals(UserTypeEnum.TYPE_7.getValue())){
//			customerEntity.setBranchOrgId("");
//		}else{
//			customerEntity.setBranchOrgId(branchOrgId);//设置客户分校ID
//		}
		customerEntity.setBranchOrgId(branchOrgId);//设置客户分校ID
		customerEntity.setCustomerName(customerName);
		customerEntity.setSex(sex);
		if(customerSourceType!=null && !customerSourceType.equals("") && !customerSourceType.equals("null")){
			customerEntity.setCustomerSourceType(customerSourceType);
		}else{
			customerEntity.setCustomerSourceType(CustomerSourceTypeEnum.TYPE_1.getValue());
		}
		customerEntity.setCustomerSourceNameValue(customerSourceNameValue);
		if(customerGroupTypeId!=null && !customerGroupTypeId.equals("") && !customerGroupTypeId.equals("null")){
			customerEntity.setCustomerGroupTypeId(customerGroupTypeId);
		}else{
			customerEntity.setCustomerGroupTypeId(CustomerGroupTypeIdEnum.TYPE_6.getValue());
		}
//		customerEntity.setCustomerType(customerType);  //给客户打标签的时候，才会标上客户类型
		customerEntity.setWeixinId(weixinId == null ? "" : weixinId);
		customerEntity.setQq(qq == null ? "" : qq);
		customerEntity.setMobile(mobile == null ? "" : mobile);
		customerEntity.setPhone(phone == null ? "" : phone);
		customerEntity.setEmail(email == null ? "" : email);
		customerEntity.setProvinceId(provinceId == null ? "" : provinceId);
		customerEntity.setProvinceName(provinceName == null ? "" : provinceName);
		customerEntity.setCityId(cityId == null ? "" : cityId);
		customerEntity.setCityName(cityName == null ? "" : cityName);
		customerEntity.setAreaId(areaId == null ? "" : areaId);
		customerEntity.setAreaName(areaName == null ? "" : areaName);
		customerEntity.setCompanyName(companyName == null ? "" : companyName);
		customerEntity.setAddress(address == null ? "" : address);
		customerEntity.setRemark(remark == null ? "" : remark);
		customerEntity.setJobAge(jobAge == null ? "" : jobAge);
		customerEntity.setEducation(education == null ? "" : education);
		customerEntity.setProfessional(professional == null ? "" : professional);
		customerEntity.setCustomerActivityPage(customerActivityPage == null ? "" : customerActivityPage);
		customerEntity.setCustomerActivityTypePage(customerActivityTypePage == null ? "" : customerActivityTypePage);
		customerEntity.setCreateTime(LocalDateTime.now());//创建时间
		customerEntity.setUpdateTime(LocalDateTime.now());//更新时间
		customerEntity.setRecentDynamicDateTime(LocalDateTime.now());//最近动态时间
		customerEntity.setRecentDynamicContent("新增客户资料，备注：" + StringUtil.nullValueConvert(remark));//最近动态内容
		customerEntity.setRemark2(StringUtil.nullValueConvert(remark2));
		customerEntity.setCreateUserId(user.getId());//创建人，如果是代理商，那创建人就是代理商
		customerEntity.setCustomerStage(CustomerStageEnum.TYPE_1.getValue());//客户阶段，新入库
		
		customerEntity.setCustomerQuality(customerQuality == null ? "" : customerQuality);
		customerEntity.setCustomerIntentionLevel(customerIntentionLevel == null ? "" : customerIntentionLevel);
		customerEntity.setCustomerIntentionContent(customerIntentionContent == null ? "" : customerIntentionContent);
		customerEntity.setPromotionUserId(promotionUserId == null ? "" : promotionUserId);
		customerEntity.setState("");//为空表示正常状态
		customerEntity.setDepartmentId(departmentId); 
		customerEntity.setImportType(1);
		
		
		if(user.getUserType().equals(UserTypeEnum.TYPE_7.getValue())){
			//代理商创建的应该在公海里面，所以是没有跟进人的
//			customerEntity.setCustomerSourceType(CustomerSourceTypeEnum.TYPE_2.getValue());//如果是代理商用户导入的，则来源为代理商
			customerEntity.setFollowUserId(user.getId());//代理商录入的也是自己跟进
//			customerEntity.setSeaType("1");//代理商录入的，属于分校资源库，目前不属于分校资源库，他手工导入，或者导入给自己，是他要自己去开发的
			customerEntity.setSeaType("");
		}else{
			customerEntity.setFollowUserId(user.getId());//跟进人
			customerEntity.setSeaType("");//资源库类别，被用户持有时，此字段为空，为什么要这样设计呢？因为被持有，则就不属于公海
//			customerEntity.setCustomerSourceType(CustomerSourceTypeEnum.TYPE_1.getValue());
		}
		
		if(customerMapper.insert(customerEntity)>0){
			//保存客户后先保存客户头像
			if(file!=null){
				String photoUrl = HttpClientUtil.uploadCustomerFile(file, customerEntity.getId());
				System.out.println("客户头像上传后地址：" + photoUrl);
//				CustomerEntity entity = new CustomerEntity();
//				entity.setId(customerEntity.getId());
//				entity.setPhotoUrl(photoUrl);
//				customerMapper.updateById(entity);//只修改一个参数即可，提升程序速度,mybatis plus此版本有个bug，空值更新的问题
				customerEntity.setPhotoUrl(photoUrl);
				customerMapper.updateById(customerEntity);
			}
			
			//2.保存用户客户表数据
			UserCustomerEntity userCustomerEntity = new UserCustomerEntity();
			userCustomerEntity.setUserId(user.getId());
			userCustomerEntity.setMyCustomerType(MyCustomerTypeEnum.TYPE_1.getValue());
//			userCustomerEntity.setCustomerGroupTypeId(CustomerGroupTypeIdEnum.TYPE_1.getValue());
			userCustomerEntity.setCustomerId(customerEntity.getId());
			userCustomerEntity.setCreateTime(LocalDateTime.now());
			
			if(userCustomerMapper.insert(userCustomerEntity)>0){
				if(selfDefineItemConfigList!=null && selfDefineItemConfigList.length>0){
					for(CustomerSelfDefineItemConfigEntity config : selfDefineItemConfigList){
						List<CustomerSelfDefineItemConfigDetailEntity> details = config.getCustomerSelfDefineItemConfigDetails();
						for(CustomerSelfDefineItemConfigDetailEntity detail : details){
							if(detail.getIsSelected()){
								CustomerSelfDefineItemEntity pojo = new CustomerSelfDefineItemEntity();
								pojo.setCustomerId(customerEntity.getId());
								pojo.setItemId(config.getItemId());
								pojo.setItemDetailId(detail.getItemDetailId());
								
								customerSelfDefineItemMapper.insert(pojo);
							}
						}
					}
				}
				
				
				
				//6.保存客户动态记录
				CustomerDynamicLogEntity dynamicLogEntity = new CustomerDynamicLogEntity();
				dynamicLogEntity.setCustomerId(customerEntity.getId());
				dynamicLogEntity.setDynamicType(DynamicTypeEnum.TYPE_1.getValue());
				dynamicLogEntity.setDynamicName(DynamicTypeEnum.TYPE_1.getDesc());
				dynamicLogEntity.setDynamicContent(remark);//如果新增客户的时候，没有写备注，此项将为空
				dynamicLogEntity.setDynamicUserId(user.getId());
				dynamicLogEntity.setCreateDate(LocalDateTime.now());
				
				if(customerDynamicLogMapper.insert(dynamicLogEntity)>0){
					return true;
				}
			}
		}
		return false;
	}
	
	
	
	@Override
	public boolean updateCustomerByCustomerId(CustomerModel model, MultipartFile file, UserEntity user) throws Exception {
		//客户基础信息
		String id = model.getId();
		String customerName = model.getCustomerName();
		String sex = model.getSex();
		String customerSourceType = model.getCustomerSourceType();
		String customerSourceNameValue = model.getCustomerSourceNameValue();
		String customerGroupTypeId = model.getCustomerGroupTypeId();
		String customerQuality = model.getCustomerQuality();
		String customerIntentionLevel = model.getCustomerIntentionLevel();
		String customerIntentionContent = model.getCustomerIntentionContent();
		String weixinId = model.getWeixinId();
		String qq = model.getQq();
		String mobile = model.getMobile();
		String phone = model.getPhone();
		String email = model.getEmail();
		String provinceId = model.getProvinceId();
		String provinceName = model.getProvinceName();
		String cityId = model.getCityId();
		String cityName = model.getCityName();
		String areaId = model.getAreaId();
		String areaName = model.getAreaName();
		String companyName = model.getCompanyName();
		String address = model.getAddress();
		String remark = model.getRemark();
		String jobAge = model.getJobAge();
		String education = model.getEducation();
		String professional = model.getProfessional();
		String customerActivityPage = model.getCustomerActivityPage();
		String customerActivityTypePage = model.getCustomerActivityTypePage();
		
		//客户标签
//		CustomerTagEntity[] customerTagList = model.getCustomerTagList(); //待确定，如果前端做成在此接口传，那么放开此行代码
		
		//客户自定义信息
//		CustomerSelfDefineItemEntity[] danbanList = model.getDanbanList();
//		CustomerSelfDefineItemEntity[] taobanList = model.getTaobanList();
//		CustomerSelfDefineItemEntity[] neixunList = model.getNeixunList();
//		CustomerSelfDefineItemEntity[] yijiankemuList = model.getYijiankemuList();
//		CustomerSelfDefineItemEntity[] erjiankemuList = model.getErjiankemuList();
//		CustomerSelfDefineItemEntity[] zaojiakemuList = model.getZaojiakemuList();
//		CustomerSelfDefineItemEntity[] jianlikemuList = model.getJianlikemuList();
//		CustomerSelfDefineItemEntity[] xiaofangkemuList = model.getXiaofangkemuList();
//		CustomerSelfDefineItemEntity[] zixungongchengshiList = model.getZixungongchengshiList();
//		CustomerSelfDefineItemEntity yibaotonghangEntity = model.getYibaotonghang();
		String remark2 = String.valueOf(model.getRemark2());
//		String yijiankemu2 = String.valueOf(model.getYijiankemu2());
//		String banjimingcheng2 = String.valueOf(model.getBanjimingcheng2());
		CustomerSelfDefineItemConfigEntity[] selfDefineItemConfigList = model.getSelfDefineItemConfigList();
		
		String branchOrgId = String.valueOf(model.getBranchOrgId());//分校ID，当超级管理员，区域管理员，代理商用户，新增客户时，此属性为必填
		
//		StringUtil.validateIsNull(customerName, "请输入姓名");
//		StringUtil.validateIsNull(weixinId, "请输入微信号");
//		StringUtil.validateIsNull(qq, "请输入QQ");
		StringUtil.validateIsNull(mobile, "请输入手机");
//		StringUtil.validateIsNull(phone, "请输入座机");
//		StringUtil.validateIsNull(email, "请输入邮箱");
		
		
		if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue())||user.getUserType().equals(UserTypeEnum.TYPE_2.getValue())){
			//||user.getUserType().equals(UserTypeEnum.TYPE_7.getValue()) //代理商不需要传入分校ID了，手动新建的客户属于自己，不过在客户的界面上的右键中可以加入转入分校的功能
		//如果是以上3种类型的用户，则必需传入分校ID
		if(branchOrgId==null || branchOrgId.equals("") || branchOrgId.equals("null")){
			throw new BusinessException("修改客户，请选择录入的分校");
			}
		}
		
//		if(user.getUserType().equals(UserTypeEnum.TYPE_7.getValue())){
//			//如果是代理商用户，则只需要校验代理商是否已经导入此号码的客户即可
//			if(this.getCustomerListByAgentImportMobile(user.getId(), mobile).size()>0){
//				throw new BusinessException("此手机号码的客户，已在您的客户列表中存在，请勿重复创建");
//			}
//		}else{
//			if(parameterService.getParameterByKey(ParameterEnum.IS_REPETITION.getValue()).equals("1")){
//				boolean flag = existsCustomerByMobileAndBranchOrgId(mobile, branchOrgId);
//				if(flag){
//					OrgEntity orgEntity = orgService.getById(branchOrgId);
//					throw new BusinessException("此手机号码的客户已在  "+ orgEntity.getOrgName() +"  中存在，请勿重复创建");
//				}
//			}else{
//				if(existsCustomerByMobile(mobile)){
//					throw new BusinessException("此手机号码的客户已在系统中存在，请勿重复创建");
//				}
//			}
//		}
		
		
		
		//1.修改客户信息
		CustomerEntity customerEntity = this.getById(id);
		if(customerEntity!=null){
//			customerEntity.setId(id);
//			if(user.getUserType().equals(UserTypeEnum.TYPE_7.getValue())){
//				customerEntity.setBranchOrgId("");
//			}else{
//				customerEntity.setBranchOrgId(branchOrgId);//设置客户分校ID
//			}
			
			//如果传入的手机号码与系统中已经存在的客户手机号不相同，则为用户在修改客户的手机号码，需要判断是否重复
			if(!customerEntity.getMobile().equals(mobile)){
				if(parameterService.getParameterByKey(ParameterEnum.IS_REPETITION.getValue()).equals("1")){
					boolean flag = existsCustomerByMobileAndBranchOrgId(mobile, branchOrgId);
					if(flag){
						OrgEntity orgEntity = orgService.getById(branchOrgId);
						throw new BusinessException("此手机号码的客户已在  "+ orgEntity.getOrgName() +"  中存在，请勿重复创建");
					}
				}else{
					if(existsCustomerByMobile(mobile)){
						throw new BusinessException("此手机号码的客户已在系统中存在，请勿重复创建");
					}
				}
			}
			
			
			customerEntity.setBranchOrgId(branchOrgId);
			customerEntity.setCustomerName(customerName == null ? "" : customerName);
			customerEntity.setSex(sex == null ? "" : sex);
			customerEntity.setCustomerSourceType(customerSourceType == null ? "" : customerSourceType);
			customerEntity.setCustomerSourceNameValue(customerSourceNameValue == null ? "" : customerSourceNameValue);
			customerEntity.setCustomerGroupTypeId(customerGroupTypeId == null ? "" : customerGroupTypeId);
//			customerEntity.setCustomerType(customerType);  //给客户打标签的时候，才会标上客户类型
			customerEntity.setCustomerQuality(customerQuality == null ? "" : customerQuality);
			customerEntity.setCustomerIntentionLevel(customerIntentionLevel == null ? "" : customerIntentionLevel);
			customerEntity.setCustomerIntentionContent(customerIntentionContent == null ? "" : customerIntentionContent);
			customerEntity.setWeixinId(weixinId == null ? "" : weixinId);
			customerEntity.setQq(qq == null ? "" : qq);
			customerEntity.setMobile(mobile == null ? "" : mobile);
			customerEntity.setPhone(phone == null ? "" : phone);
			customerEntity.setEmail(email == null ? "" : email);
			customerEntity.setProvinceId(provinceId == null ? "" : provinceId);
			customerEntity.setProvinceName(provinceName == null ? "" : provinceName);
			customerEntity.setCityId(cityId == null ? "" : cityId);
			customerEntity.setCityName(cityName == null ? "" : cityName);
			customerEntity.setAreaId(areaId == null ? "" : areaId);
			customerEntity.setAreaName(areaName == null ? "" : areaName);
			customerEntity.setCompanyName(companyName == null ? "" : companyName);
			customerEntity.setAddress(address == null ? "" : address);
			customerEntity.setRemark(remark == null ? "" : remark);
			customerEntity.setJobAge(jobAge == null ? "" : jobAge);
			customerEntity.setEducation(education == null ? "" : education);
			customerEntity.setProfessional(professional == null ? "" : professional);
			customerEntity.setCustomerActivityPage(customerActivityPage == null ? "" : customerActivityPage);
			customerEntity.setCustomerActivityTypePage(customerActivityTypePage == null ? "" : customerActivityTypePage);
			customerEntity.setUpdateTime(LocalDateTime.now());
			customerEntity.setRemark2(StringUtil.nullValueConvert(remark2));
//			customerEntity.setCreateUserId(user.getId());//创建人
			customerEntity.setFollowUserId(user.getId());//跟进人
//			customerEntity.setCustomerStage(CustomerStageEnum.TYPE_1.getValue());//客户阶段，新入库
			customerEntity.setRecentDynamicDateTime(LocalDateTime.now());//最近动态时间
			customerEntity.setRecentDynamicContent("修改客户资料，备注：" + remark);//最近动态内容
			
		}else{
			throw new BusinessException("需要修改的客户不存在，请检查");
		}
		
		if(file!=null){
			String photoUrl = HttpClientUtil.uploadCustomerFile(file, customerEntity.getId());
			customerEntity.setPhotoUrl(photoUrl);
		}
		customerMapper.updateById(customerEntity);
		
		
		//2.先删除客户自定义信息，再保存客户自定义信息
		if(selfDefineItemConfigList!=null && selfDefineItemConfigList.length>0){
			customerSelfDefineItemMapper.delete(new QueryWrapper<CustomerSelfDefineItemEntity>().eq("customer_id", customerEntity.getId()));
			
			for(CustomerSelfDefineItemConfigEntity config : selfDefineItemConfigList){
				List<CustomerSelfDefineItemConfigDetailEntity> details = config.getCustomerSelfDefineItemConfigDetails();
				for(CustomerSelfDefineItemConfigDetailEntity detail : details){
					if(detail.getIsSelected()){
						CustomerSelfDefineItemEntity pojo = new CustomerSelfDefineItemEntity();
						pojo.setCustomerId(customerEntity.getId());
						pojo.setItemId(config.getItemId());
						pojo.setItemDetailId(detail.getItemDetailId());
						
						customerSelfDefineItemMapper.insert(pojo);
					}
				}
			}
		}

			
		//4.保存客户动态记录
		CustomerDynamicLogEntity dynamicLogEntity = new CustomerDynamicLogEntity();
		dynamicLogEntity.setCustomerId(customerEntity.getId());
		dynamicLogEntity.setDynamicType(DynamicTypeEnum.TYPE_2.getValue());
		dynamicLogEntity.setDynamicName(DynamicTypeEnum.TYPE_2.getDesc());
		dynamicLogEntity.setDynamicContent(remark);
		dynamicLogEntity.setDynamicUserId(user.getId());
		dynamicLogEntity.setCreateDate(LocalDateTime.now());
			
		if(customerDynamicLogMapper.insert(dynamicLogEntity)>0){
			return true;
		}
		return false;
	}





	@Override
	public boolean deleteCustomerByCustomerId(String customerIds, String causeId, String cause) throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity bean = (UserEntity) object;
			
			//1.先删除用户客户表中的数据，切断引用关系
//			String arr[] = customerIds.split(",");
			List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
			for(String customerId : customerIdList){
				userCustomerMapper.delete(new QueryWrapper<UserCustomerEntity>().eq("user_id", bean.getId()).eq("customer_id", customerId));
			}
			
			//如果是代理商删除自己的客户，则直接删除
			if(bean.getUserType().equals(UserTypeEnum.TYPE_7.getValue())){
				customerMapper.deleteBatchIds(customerIdList);
			}else{
				//2.更新客户表中的客户数据为进入回收站状态，同时增加删除人，删除时间属性
				for(String customerId : customerIdList){
					CustomerEntity entity = this.getById(customerId);
					if(entity!=null){
						entity.setId(customerId);
						entity.setBranchOrgId("");
						entity.setDeleteUserId(bean.getId());
						entity.setDeleteDateTime(LocalDateTime.now());
						entity.setState("2");//状态	state	1：进入分校回收站，2：进入公司回收站，为空则表示正常状态
						entity.setDeleteCauseId(Integer.parseInt(causeId));
						entity.setDeleteCause(cause);
						
						customerMapper.updateById(entity);
					}
				}
			}
			return true;
		}
		return false;
	}
	
	
	@Override
	public boolean deleteCustomerFromRepositoryByCustomerId(String customerIds) throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity bean = (UserEntity) object;
			
//			String arr[] = customerIds.split(",");
			List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
//			customerMapper.deleteBatchIds(customerIdList);
			for(String customerId : customerIdList){
				CustomerEntity entity = this.getById(customerId);
				if(entity!=null){
					entity.setSeaType("");//不在资源库中时，此字段清空
					entity.setState("1");
					customerMapper.updateById(entity);
				}
			}
			
			return true;
		}
		return false;
	}
	
	
	
	
	@Override
	public boolean deleteCustomerBeFromBusinessGroupSeaByCustomerId(String customerIds, String causeId, String cause)
			throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
//			UserEntity bean = (UserEntity) object;
			//从分校回收站删除，则进入公司回收站
			List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
			for(String customerId : customerIdList){
				CustomerEntity entity = this.getById(customerId);
				if(entity!=null){
					entity.setBranchOrgId("");
					entity.setDepartmentId("");
					entity.setState("2");//分校回收站中删除，则进入公司回收站
					entity.setWaiveCause(cause);
					entity.setWaiveCauseId(Integer.parseInt(causeId));
					
					customerMapper.updateById(entity);
				}
			}
//			for(String customerId : customerIdList){
//				customerMapper.delete(new QueryWrapper<CustomerEntity>().eq("id", customerId));
//			}
			
			return true;
		}
		return false;
	}
	
	@Override
	public boolean deleteCustomerBeFromCompanySeaByCustomerId(String customerIds, String causeId, String cause)
			throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
//			UserEntity bean = (UserEntity) object;
			
			//1.公司回收站中删除客户，则真正删除客户
			List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
//			for(String customerId : customerIdList){
//				customerMapper.delete(new QueryWrapper<CustomerEntity>().eq("id", customerId));
//			}
			customerMapper.deleteBatchIds(customerIdList);
			
			return true;
		}
		return false;
	}



	@Override
	public boolean updateWaiveCustomerToCompanySea(String customerIds, String causeId, String cause) throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity bean = (UserEntity) object;
			
			//1.先删除用户客户表中的数据，切断引用关系
//			String arr[] = customerIds.split(",");
			List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
			for(String customerId : customerIdList){
				userCustomerMapper.delete(new QueryWrapper<UserCustomerEntity>().eq("user_id", bean.getId()).eq("customer_id", customerId));
			}
			
			//2.将客户表的公海类别sea_type设置为2，统计公司大公海客户，直接统计此表即可
			for(String customerId : customerIdList){
				CustomerEntity entity = this.getById(customerId);
				if(entity!=null){
					entity.setBranchOrgId("");
					entity.setDepartmentId("");
					entity.setState("2");
					entity.setWaiveCause(cause);
					entity.setWaiveCauseId(Integer.parseInt(causeId));
					
					customerMapper.updateById(entity);
				}
			}
			return true;
		}
		return false;
	}
	
	
	@Override
	public boolean updateWaiveCustomerToBusinessGroupSea(String customerIds, String causeId, String cause) throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity user = (UserEntity) object;
			
			//先测试找用户的分校，看正不正常
//			OrgEntity orgTest = orgService.getUserBranchOrgByOrgId(user.getOrgId());
//			System.out.println("找用户所在的分校：" + orgTest);
			
			//1.获取当前用户所在的机构，并判断机构类型，0：顶级机构， 1：省份或直辖市，2：分校，3：部门， 4：代理商  如果为2或者3即是正常操作，否则不允许操作，不然数据会搞乱， 
//			OrgEntity orgEntity = orgService.getById(user.getOrgId());
//			if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_0.getValue()) || orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_1.getValue()) || orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_4.getValue())){
//				throw new BusinessException("您当前所在的组织机构有问题，您无权限操作，请联系管理员");
//			}
			
			//2.删除用户客户表中的数据，切断引用关系  
			List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
			for(String customerId : customerIdList){
				userCustomerMapper.delete(new QueryWrapper<UserCustomerEntity>().eq("user_id", user.getId()).eq("customer_id", customerId));
			}
			
			//3.将客户表的公海类别sea_type设置为1
			for(String customerId : customerIdList){
				CustomerEntity entity = this.getById(customerId);
				if(entity!=null){
					entity.setId(customerId);
					entity.setState("1");
					entity.setWaiveCause(cause);
					entity.setWaiveCauseId(Integer.parseInt(causeId));
					
					customerMapper.updateById(entity);
				}
			}
			
			return true;
			//4.在 分校与客户关联表（即公海与客户关联表）中增加一条,此处不需要了，因为在新建客户的时候，就已经添加了客户所属的分校中，即业务组
			//先找到用户所在的分校
//			OrgEntity entity = orgService.getBranchOrg(user.getOrgId());
//			for(String customerId : customerIdList){
//				BranchOrgCustomerEntity branchCustomer = new BranchOrgCustomerEntity();
//				branchCustomer.setCustomerId(customerId);
//				branchCustomer.setbranchOrgId(entity.getId());
//				branchCustomer.setCreateDate(LocalDateTime.now());
//				
//				branchCustomerList.add(branchCustomer);
//				
//				branchOrgCustomerMapper.insert(branchCustomer);
//			}
		}
		return false;
	}
	
	

	@Override
	public boolean updateCustomerToRepository(String customerIds) throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity user = (UserEntity) object;
			
			//2.删除用户客户表中的数据，切断引用关系  
			List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
			for(String customerId : customerIdList){
				userCustomerMapper.delete(new QueryWrapper<UserCustomerEntity>().eq("user_id", user.getId()).eq("customer_id", customerId));
			}
			
			String seaType = "1";//默认为分校资源库，如果此时为部门下面的员工操作，则返回部门资源库
			String departmentId = "";
			OrgEntity orgEntity = orgService.getById(user.getOrgId());
			if(orgEntity!=null && orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_3.getValue())){
				departmentId = orgEntity.getId();
				seaType = "2";
			}
			
			//3.将客户表的公海类别sea_type设置为1
			for(String customerId : customerIdList){
				CustomerEntity entity = this.getById(customerId);
				if(entity!=null){
					entity.setId(customerId);
					if(seaType.equals("2")){
						entity.setSeaType(seaType);
						entity.setDepartmentId(departmentId);//如果是部门的人操作，才设置部门，否则不执行，如果也强行执行，那么会存在清空部门的可能
					}else{
						entity.setSeaType(seaType);
					}
					entity.setFollowUserId("");//资源库里面的客户，都是无人跟过进的
					customerMapper.updateById(entity);
				}
			}
			
			return true;
		}
		return false;
	}


	@Override
	public List<LinkedHashMap<Object, Object>> findCustomerRecycledList(Map<Object, Object> map) {
		return customerMapper.findCustomerRecycledList(map);
	}


	@Override
	public Long findCustomerRecycledListCount(Map<Object, Object> map) {
		return customerMapper.findCustomerRecycledListCount(map);
	}


	@Override
	public boolean updateRestoreCustomerByCustomerId(String customerId, String userId) {
		//1. 添加用户客户表，增加用户与客户的关联关系
		UserCustomerEntity userCustomerEntity = new UserCustomerEntity();
		userCustomerEntity.setCreateTime(LocalDateTime.now());
		userCustomerEntity.setMyCustomerType(MyCustomerTypeEnum.TYPE_1.getValue());
//		userCustomerEntity.setCustomerGroupTypeId(CustomerGroupTypeIdEnum.TYPE_6.getValue());
		userCustomerEntity.setCustomerId(customerId);
		userCustomerEntity.setUserId(userId);
		
		int num = userCustomerMapper.insert(userCustomerEntity);
		if(num>0){
			//2.更新客户的状态为正常状态，将删除人和删除时间属性上的数据置空，添加跟进人ID
			CustomerEntity entity = this.getById(customerId);
			if(entity!=null){
				entity.setId(customerId);
				entity.setFollowUserId(userId.toString());
				entity.setDeleteDateTime(null);
				entity.setDeleteUserId(null);
				//将客户的分组属性设置为其他
				entity.setCustomerGroupTypeId(CustomerGroupTypeIdEnum.TYPE_6.getValue());
				
				int num2 = customerMapper.updateById(entity);
				if(num2>0){
					return true;
				}
			}
		}
		return false;
	}


	@Override
	public boolean updateRestoreCustomerToCompanySea(String customerId) throws Exception{
		CustomerEntity entity = this.getById(customerId);
		if(entity!=null){
			//如果还原回去的时候，在公司公海存在，则提示此客户只能删除处理了
			if(this.existsCustomerByMobile(entity.getMobile())){
				throw new BusinessException("此手机号码的客户已在系统中存在，无法再还原回去，请删除处理");
			}
			
			entity.setId(customerId);
			entity.setSeaType("2");
			entity.setState(""); //设置为正常状态
			return this.updateById(entity);
		}
		
		return false;
	}


	@Override
	public boolean updateRestoreCustomerToBusinessGroupSea(String customerId, String branchOrgId) throws Exception{
		//实现逻辑为：
		//1. 将客户表中的公海类别设置为1，即客户目前属于业务组公海
		//--------2. 在分校与客户关联表（即公海与客户关联表）中增加一条数据，记录此客户目前已经挂在此业务组公海下面
		//注意：当客户在业务组公海中被领走的时候，实现逻辑则是上面两步的逆向工程
		//1. 将客户表中的公海类别置空
		//2-------. 将分校与客户关联表（即公海与客户关联表）中的此客户数据删除
		
		CustomerEntity entity = this.getById(customerId);
		if(entity!=null){
			if(this.existsCustomerByMobileAndBranchOrgId(entity.getMobile(), branchOrgId)){
				throw new BusinessException("此客户已经在此业务组中存在，请不要重复往业务组中创建客户");
			}
			//这种设计是允许跨分校转业务组的
			entity.setBranchOrgId(branchOrgId);
			entity.setId(customerId);
			entity.setSeaType("1");
			entity.setState("");//设置为正常状态
			return this.updateById(entity);
		}
		
		return false;
		
		//因为客户本身就是属于业务组的，有可能将此客户还原至别的分校（业务级里面去了）
		//先查询此客户是否在此分校存在，如果存在则更新一下日期即可，如果不存在，则新增
//		BranchOrgCustomerEntity bean = branchOrgCustomerService.getBranchCustomerByCustomerId(customerId);
//		if(bean!=null){
//			bean.setBranchOrgId(branchOrgId);
//			bean.setCustomerId(customerId);
//			bean.setCreateDate(LocalDateTime.now());
//			branchOrgCustomerMapper.updateById(bean);
//		}else{
//			//适用于不属于分校的客户，如果被删除了，还原至分校的情况，例如：代理商导入客户，导入的公司大公海
//			bean = new BranchOrgCustomerEntity();
//			bean.setBranchOrgId(branchOrgId);
//			bean.setCustomerId(customerId);
//			bean.setCreateDate(LocalDateTime.now());
//			branchOrgCustomerMapper.insert(bean);
//		}
		
//		return true;
	}


	@Override
	public boolean updateTransferCustomerToUser(String customerIds, Integer causeId, String cause, String userId)
			throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity user = (UserEntity) object;
			
			
			//转让客户给同事核心逻辑：
			//1.先删除用户客户表中的数据，切断现有用户与客户的引用关系 2.用户客户表中增加新的用户与客户的引用关系，并且设置客户分组类型为：其他
			//不用使用上述逻辑，直接将用户客户表中的用户id替换即可，更简单清晰
			List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
//			List<String> userIdList= JsonUtil.getJsonToList(userIds, String.class);
			
			//不允许自己转给自己(如果可以自己转给自己，那么就转到自己的其他下面去了)
//			for(String userId : userIdList){
//				if(user.getId().equals(userId)){
//					throw new BusinessException("请确认转让的用户，不允许自己转给自己");
//				}
//			}
			
			//如果有已成交的客户，不能进行转让
			for(String customerId : customerIdList){
				CustomerEntity entity = this.getById(customerId);
				if(entity.getCustomerStage().equals(CustomerStageEnum.TYPE_5.getValue())){
					throw new BusinessException("已缴费成交的客户，不能进行转让");
				}
			}
			
			for(String customerId : customerIdList){
				UserCustomerEntity bean = new UserCustomerEntity();
				bean.setUserId(userId);
				bean.setCustomerId(customerId);
				bean.setMyCustomerType(MyCustomerTypeEnum.TYPE_1.getValue());
//				bean.setCustomerGroupTypeId(CustomerGroupTypeIdEnum.TYPE_6.getValue());
				bean.setCreateTime(LocalDateTime.now());
//				bean.setCustomerStage(customerStage); //转让后的客户，客户阶段保持不变，只是持有的用户变了而已
				
//				userCustomerMapper.updateById(bean);
				userCustomerMapper.update(bean, new UpdateWrapper<UserCustomerEntity>().eq("my_customer_type", "1").eq("customer_id", customerId));
				
				//记录转让动态
				UserEntity entity = userService.getById(userId);
				CustomerDynamicLogEntity dynamicLogEntity = new CustomerDynamicLogEntity();
				dynamicLogEntity.setCustomerId(customerId);
				dynamicLogEntity.setDynamicUserId(user.getId());
				dynamicLogEntity.setDynamicType(DynamicTypeEnum.TYPE_9.getValue());
				dynamicLogEntity.setDynamicName(DynamicTypeEnum.TYPE_9.getDesc());
				String dynamicContent = "将此客户转让给了  " + entity.getUserName() + "," + "转让原因：" + cause;
				dynamicLogEntity.setDynamicContent(dynamicContent); 
				dynamicLogEntity.setCreateDate(LocalDateTime.now());
				
				customerDynamicLogMapper.insert(dynamicLogEntity);
			}
			//转让后更新客户分组为其他,转让后，跟进人变了
			for(String customerId : customerIdList){
				CustomerEntity entity = this.getById(customerId);
				entity.setId(customerId);
				entity.setCustomerGroupTypeId(CustomerGroupTypeIdEnum.TYPE_6.getValue());
				entity.setRecentDynamicDateTime(LocalDateTime.now());
				entity.setRecentDynamicContent("转让客户");
				entity.setUpdateTime(LocalDateTime.now());
				entity.setFollowUserId(userId);
				customerMapper.updateById(entity);
			}
			
			return true;
		}
		return false;
	}


	@Override
	public boolean updateShareCustomerToUser(String customerIds, String userIds, String shareType) throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity user = (UserEntity) object;
			
			List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
			List<String> userIdList = JsonUtil.getJsonToList(userIds, String.class);
			
			//1：保留原有共享关系，新增共享同事,需要判断客户是否已经共享过给别人了，防止重复共享
			if(shareType.trim().equals("1")){
				for(String customerId : customerIdList){
					for(String userId : userIdList){
						//查询这个客户是否已经共享给这个用户了，如果没有共享则新增，如果已经共享则跳出此次循环
						List<UserCustomerEntity> userCustomerList = userCustomerMapper.selectList(new QueryWrapper<UserCustomerEntity>()
								.eq("my_customer_type", MyCustomerTypeEnum.TYPE_2.getValue())
								.eq("customer_id", customerId).eq("user_id", userId));
						if(userCustomerList.size()==0){
							//用户客户表，增加2条记录，1条为：我共享给别人的数据，1条为：别人共享给我的数据
							//增加我共享给别人的数据
							UserCustomerEntity entity = new UserCustomerEntity();
							entity.setMyCustomerType(MyCustomerTypeEnum.TYPE_3.getValue());
							entity.setCreateTime(LocalDateTime.now());
							entity.setUserId(user.getId());
							entity.setCustomerId(customerId);
							entity.setShareId(user.getId());//添加共享人ID
							
							userCustomerMapper.insert(entity);
							
							//增加别人共享给我的数据
							UserCustomerEntity entity2 = new UserCustomerEntity();
							entity2.setCreateTime(LocalDateTime.now());
							entity2.setMyCustomerType(MyCustomerTypeEnum.TYPE_2.getValue());
							entity2.setUserId(userId);
							entity2.setCustomerId(customerId);
							entity2.setShareId(user.getId());//添加共享人ID
							userCustomerMapper.insert(entity2);
						}else{
							continue;
						}
					}
				}
			}
			
			//2：用新的共享同事覆盖原有共享关系,需要将此客户原来共享给的用户关系全部删除
			if(shareType.trim().equals("2")){
				for(String customerId : customerIdList){
					userCustomerMapper.delete(new QueryWrapper<UserCustomerEntity>()
							.eq("my_customer_type", MyCustomerTypeEnum.TYPE_2.getValue())
							.eq("customer_id", customerId));
				}
				
				for(String customerId : customerIdList){
					for(String userId : userIdList){
						UserCustomerEntity entity = new UserCustomerEntity();
						entity.setMyCustomerType(MyCustomerTypeEnum.TYPE_2.getValue());
						entity.setUserId(userId);
						entity.setCreateTime(LocalDateTime.now());
						entity.setCustomerId(customerId);
//						entity.setCustomerGroupTypeId(CustomerGroupTypeIdEnum.TYPE_6); //共享给我的客户，无客户分组
						entity.setShareId(user.getId());//添加共享人ID
						
						userCustomerMapper.insert(entity);
					}
				}
			}
			return true;
		}
		
		return false;
	}
	
	

	@Override
	public boolean moveCustomerGroupByCustomerId(String customerIds, String customerGroupTypeId) {
		List<String> customerIdList = JsonUtil.getJsonToList(customerIds, String.class);
		for(String customerId : customerIdList){
			CustomerEntity entity = this.getById(customerId);
			entity.setId(customerId);
			entity.setCustomerGroupTypeId(customerGroupTypeId);
			
			customerMapper.updateById(entity);
		}
		return true;
	}


	@Override
	public List<LinkedHashMap<Object, Object>> getCustomerList(Map<Object, Object> map) {
		return customerMapper.getCustomerList(map);
	}


	@Override
	public List<LinkedHashMap<Object, Object>> getCustomerListByBusinessGroupSea(Map<Object, Object> map) {
		return customerMapper.getCustomerListByBusinessGroupSea(map);
	}
	
	

	@Override
	public List<LinkedHashMap<Object, Object>> getCustomerListByAgentsSearch(Map<Object, Object> map) {
		return customerMapper.getCustomerListByAgentsSearch(map);
	}


	@Override
	public Long getCustomerListByAgentsSearchCount(Map<Object, Object> map) {
		return customerMapper.getCustomerListByAgentsSearchCount(map);
	}


	@Override
	public List<LinkedHashMap<Object, Object>> getCustomerListByCompanySea(Map<Object, Object> map) {
		return customerMapper.getCustomerListByCompanySea(map);
	}


	@Override
	public Long getCustomerListCount(Map<Object, Object> map) {
		return customerMapper.getCustomerListCount(map);
	}


	@Override
	public Long getCustomerListByBusinessGroupSeaCount(Map<Object, Object> map) {
		return customerMapper.getCustomerListByBusinessGroupSeaCount(map);
	}


	@Override
	public Long getCustomerListByCompanySeaCount(Map<Object, Object> map) {
		return customerMapper.getCustomerListByCompanySeaCount(map);
	}
	
	
	@Override
	public List<CustomerEntity> getCustomerListByMobile(String mobile) {
		return customerMapper.selectList(new QueryWrapper<CustomerEntity>().eq("mobile", mobile).eq("state", ""));
	}
	
	@Override
	public List<CustomerEntity> getCustomerListByAgentImportMobile(String userId, String mobile) {
		Map<Object, Object> map = new HashMap<Object, Object>();
		map.put("userId", userId);
		map.put("mobile", mobile);
		return customerMapper.getCustomerListByAgentImportMobile(map);
	}
	
	@Override
	public List<CustomerEntity> getCustomerListByMobileAndBranchOrgId(String mobile, String branchOrgId) {
		return customerMapper.selectList(new QueryWrapper<CustomerEntity>().eq("mobile", mobile).eq("branch_org_id", branchOrgId).eq("state", ""));
	}
	
	

	@Override
	public boolean updateCustomerStage(String customerId, String customerStage) throws Exception {
		UserEntity user = (UserEntity)SecurityUtils.getSubject().getPrincipal();
		//业务需求为：
		if(CustomerStageEnum.isInclude(customerStage)){
			CustomerEntity entity = this.getById(customerId);
			String oldCustomerStage = entity.getCustomerStage();//原来的客户阶段
			
			if(!entity.getCustomerStage().equals(customerStage)){
				//如果不相等，才更新客户阶段，如果相等，则相当于用户没操作
				entity.setCustomerStage(customerStage);
				entity.setUpdateTime(LocalDateTime.now());
				entity.setRecentDynamicContent("更新客户阶段");
				entity.setRecentDynamicDateTime(LocalDateTime.now());
				
				int num = customerMapper.updateById(entity);
				if(num>0){
					CustomerDynamicLogEntity dynamicLogEntity = new CustomerDynamicLogEntity();
					dynamicLogEntity.setCustomerId(customerId);
					dynamicLogEntity.setDynamicUserId(user.getId());
					dynamicLogEntity.setDynamicType(DynamicTypeEnum.TYPE_7.getValue());
					dynamicLogEntity.setDynamicName(DynamicTypeEnum.TYPE_7.getDesc());
					dynamicLogEntity.setOldValue(CustomerStageEnum.getDesc(oldCustomerStage));
					dynamicLogEntity.setNewValue(CustomerStageEnum.getDesc(customerStage));
					dynamicLogEntity.setCreateDate(LocalDateTime.now());
					
					customerDynamicLogMapper.insert(dynamicLogEntity);
					return true;
				}
				return false;
			}else{
				throw new BusinessException("请选择客户阶段");
			}
		}else{
			 throw new BusinessException("请选择正确的客户阶段");
		}
	}
	
	
	@Override
	public boolean updateReturnCustomerStage(String customerId, String customerStage) throws Exception {
		
		//业务需求为：
		//判断用户类型，如果用户类型为1或者2，则可以操作阶段回退，否则不允许操作回退
		if(CustomerStageEnum.isInclude(customerStage)){
			CustomerEntity entity = this.getById(customerId);
			String oldCustomerStage = entity.getCustomerStage();//原来的客户阶段
			
			UserEntity user = (UserEntity)SecurityUtils.getSubject().getPrincipal();
			//其他的用户类型不允许操作回退
			if(!entity.getCustomerStage().equals(customerStage)){
//				Integer entityCustomerStage = Integer.parseInt(entity.getCustomerStage());
//				Integer paramCustomerStage = Integer.parseInt(customerStage);
				entity.setCustomerStage(customerStage);
				entity.setUpdateTime(LocalDateTime.now());
				entity.setRecentDynamicContent("更新客户阶段");
				entity.setRecentDynamicDateTime(LocalDateTime.now());
				
				int num = customerMapper.updateById(entity);
				if(num>0){
					CustomerDynamicLogEntity dynamicLogEntity = new CustomerDynamicLogEntity();
					dynamicLogEntity.setDynamicUserId(user.getId());
					dynamicLogEntity.setCustomerId(customerId);
					dynamicLogEntity.setDynamicType(DynamicTypeEnum.TYPE_7.getValue());
					dynamicLogEntity.setDynamicName(DynamicTypeEnum.TYPE_7.getDesc());
					dynamicLogEntity.setOldValue(CustomerStageEnum.getDesc(oldCustomerStage));
					dynamicLogEntity.setNewValue(CustomerStageEnum.getDesc(customerStage));
					dynamicLogEntity.setCreateDate(LocalDateTime.now());
					
					customerDynamicLogMapper.insert(dynamicLogEntity);
					return true;
				}
			}else{
				throw new BusinessException("请选择客户阶段");
			}
		}else{
			 throw new BusinessException("请选择正确的客户阶段");
		}
		return false;
	}


	@Override
	public Result saveCustomerImport(String customerGroupTypeId, String branchOrgId, String departmentId, String importType, 
			String isSupplementCustomerInfo, String userId, String customerQuality, String customerIntentionLevel,
			String customerIntentionContent, String promotionUserId, MultipartFile file) throws Exception{
		Result result = new Result(ResultCodeEnum.SUCCESS);//默认返回为成功状态
//		文件名称：客户资料test.xls
//		文件类型：application/vnd.ms-excel
//		文件名称：CRM项目开发计划.xlsx
//		文件类型：application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
//		System.out.println("上传的文件名称：" + file.getOriginalFilename());
//		System.out.println("上传的文件类型：" + file.getContentType());
		
		UserEntity bean = (UserEntity)SecurityUtils.getSubject().getPrincipal();
		UserEntity user = userService.getById(bean.getId());
		
		String xlsType = "application/vnd.ms-excel";
		String xlsxType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
		if(file.getContentType().equals(xlsType) || file.getContentType().equals(xlsxType)){
			StringUtil.validateIsNull(importType, "请选择导入类型");
			if(importType.equals("1")){ //1：导入给自己
//				StringUtil.validateIsNull(customerGroupTypeId, "请选择导入的分组");
				if(customerGroupTypeId!=null && !customerGroupTypeId.equals("")){
					
				}else{
					customerGroupTypeId = CustomerGroupTypeIdEnum.TYPE_6.getValue();
				}
				
				//导入给自己，如果是以下的用户类型，则必需选择分校
				if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue())||user.getUserType().equals(UserTypeEnum.TYPE_2.getValue())
						||user.getUserType().equals(UserTypeEnum.TYPE_7.getValue())){
						 //代理商用户目前还是设计不让导入给自己，选择导入至公海吧,由于要区分代理商自己去发展，所以也需要有导入给自己
					//如果是以上3种类型的用户，则必需传入分校ID
					StringUtil.validateIsNull(branchOrgId, "导入客户，请选择导入的分校");
				}
				if(user.getUserType().equals(UserTypeEnum.TYPE_3.getValue()) || user.getUserType().equals(UserTypeEnum.TYPE_4.getValue())
						|| user.getUserType().equals(UserTypeEnum.TYPE_5.getValue()) || user.getUserType().equals(UserTypeEnum.TYPE_6.getValue())){
					//加载到用户所属的分校
					OrgEntity orgEntity = orgService.getUserBranchOrgByOrgId(user.getOrgId());
					branchOrgId = orgEntity.getId().toString();
				}
//				if(user.getUserType().equals(UserTypeEnum.TYPE_6.getValue())){
//					throw new BusinessException("代理商用户不能导入给自己，请选择导入公海列表");
//				}
			}
			if(importType.equals("2")){//2：导入至公海
				StringUtil.validateIsNull(branchOrgId, "请选择导入分校");
				//其实还要加上，导入的公海是否正确，防止攻击的校验，当前用户只能导入自己的公海
				//?????????????
			}
			
			if(importType.equals("3")){
				if(user.getUserType().equals(UserTypeEnum.TYPE_7.getValue())){
					throw new BusinessException("代理商用户不能导入给同事");
				}
			}
			
			//加载用户所属的分校
			OrgEntity branchOrgEntity = orgService.getById(branchOrgId);
			
			//提高性能，减少重复执行如下的校验系统是否重复
			boolean isRepetition = false;
			if(parameterService.getParameterByKey(ParameterEnum.IS_REPETITION.getValue()).equals("1")){
				isRepetition = true;
			}
			
			InputStream is = file.getInputStream();
//			Workbook workBook=null;
			Workbook workBook = new XSSFWorkbook(is);//网上的教程有问题，  .xls  .xlsx都使用XSSFWorkbook解析即可，有可能是我使用poi4.0的版本的原因，就不用分开处理了
//			if(file.getContentType().equals(xlsType)){
//				workBook = new XSSFWorkbook(is); //workBook = new HSSFWorkbook(is); //处理以.xls结尾的excel
//			}else{
//				workBook = new HSSFWorkbook(is); //workBook = new XSSFWorkbook(is);//处理以.xlsx结尾的excel
//			}
			
			Sheet customerSheet = workBook.getSheetAt(0);//获取第一个sheet
			//增加校验，这个excel文件的表头列 是否是按我们的模板来填充数据的
			try {
				PoiUtil.validateCell(customerSheet);
			} catch (Exception e) {
				throw new BusinessException("无法解析此文件，文件内容有误，请确认是否采用下载的模板文件？");
			}
			
			
			int countRow = customerSheet.getLastRowNum()+1;
//			System.out.println("总行数：" + countRow);
			
			String importBatchNo = DateUtil.getCurrentDateString("yyyyMMddHHmmss");
			if(importType.equals("1")){ //1：导入给自己
				//计算当前登录的用户是否在部门下面
				OrgEntity orgEntity = orgService.getById(user.getOrgId());
				if(orgEntity!=null && orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_3.getValue())){
					departmentId = orgEntity.getId();
				}
				for (int i = 11; i < countRow; i++) {
					Row row = customerSheet.getRow(i);// 获取第i行
					String customerName = PoiUtil.getCellValue(row.getCell(0));//姓名
					String sex = PoiUtil.getCellValue(row.getCell(1));//性别
					String customerSourceName = PoiUtil.getCellValue(row.getCell(2));//来源
					String mobile = PoiUtil.getCellValue(row.getCell(3));//手机
					String qq = PoiUtil.getCellValue(row.getCell(4));//QQ
					String weixinId = PoiUtil.getCellValue(row.getCell(5));//微信
					String phone = PoiUtil.getCellValue(row.getCell(6));//座机
					String email = PoiUtil.getCellValue(row.getCell(7));//邮箱
//					String guojia = PoiUtil.getCellValue(row.getCell(8));//地区：国家
					String provinceName = PoiUtil.getCellValue(row.getCell(9));//地区：省/州
					String cityName = PoiUtil.getCellValue(row.getCell(10));//区：城市
					String areaName = PoiUtil.getCellValue(row.getCell(11));//地区：区/县
					String companyName = PoiUtil.getCellValue(row.getCell(12));//公司
					String address = PoiUtil.getCellValue(row.getCell(13));//地址
					String remark = PoiUtil.getCellValue(row.getCell(14));//备注
					String jobAge = PoiUtil.getCellValue(row.getCell(15));//工作年限
					String education = PoiUtil.getCellValue(row.getCell(16));//学历
					String customerActivityPage = PoiUtil.getCellValue(row.getCell(17));//填写表单页面
					String professional = PoiUtil.getCellValue(row.getCell(18));//专业
					String customerActivityTypePage = PoiUtil.getCellValue(row.getCell(19));//分类
//					String danban = PoiUtil.getCellValue(row.getCell(20));//单班
//					String taoban = PoiUtil.getCellValue(row.getCell(21));//套班
//					String neixun = PoiUtil.getCellValue(row.getCell(22));//内训
//					String yijiankemu = PoiUtil.getCellValue(row.getCell(23));//一建科目
//					String erjiankemu = PoiUtil.getCellValue(row.getCell(24));//二建科目
//					String zaojiakemu = PoiUtil.getCellValue(row.getCell(25));//造价科目
//					String jianlikemu = PoiUtil.getCellValue(row.getCell(26));//监理科目
//					String xiaofangkemu = PoiUtil.getCellValue(row.getCell(27));//消防科目
//					String zixungongchengshi = PoiUtil.getCellValue(row.getCell(28));//咨询工程师
//					String yibaotonghang = PoiUtil.getCellValue(row.getCell(29));//已报同行
					String remark2 = PoiUtil.getCellValue(row.getCell(30));//备注2
//					String yijiankemu2 = PoiUtil.getCellValue(row.getCell(31));//一建科目2
//					String banxingmingcheng2 = PoiUtil.getCellValue(row.getCell(32));//班型名称2
//					String youhuiquan = PoiUtil.getCellValue(row.getCell(33));//优惠券
					
					//如果手机号码为空，则此行的数据不处理
					if(StringUtils.isBlank(mobile)){
						continue;
					}
					
					//先看整个系统配置是否允许重复，如果允许重复，则再进行分校的判断
					if(isRepetition){
						boolean flag = existsCustomerByMobileAndBranchOrgId(mobile, branchOrgId);
						if(flag){
							//如果此客户存在，则记录导入的此客户在xxx分校中已经存在
							result.setCode(ResultCodeEnum.FILE_DATA_ERROR.getCode());
							result.setMsg(ResultCodeEnum.FILE_DATA_ERROR.getMsg());
							
							CustomerImportHistoryEntity historyEntity = new CustomerImportHistoryEntity();
							historyEntity.setUserId(user.getId());
							historyEntity.setCustomerName(customerName);
							historyEntity.setSex(SexEnum.getValue(sex));
							historyEntity.setWeixinId(weixinId);
							historyEntity.setQq(qq);
							historyEntity.setMobile(mobile);
							historyEntity.setPhone(phone);
							historyEntity.setEmail(email);
							historyEntity.setImportBatchNo(importBatchNo);
							historyEntity.setImportDate(LocalDate.now());
							historyEntity.setRemark("导入的客户已经存在于: " + branchOrgEntity.getOrgName());
							customerImportHistoryMapper.insert(historyEntity);
							
							continue;
						}
					}else{
						boolean flag = existsCustomerByMobile(mobile);
						if(flag){
							//如果整个系统中存在此客户，则记录导入的此客户在xxx分校中已经存在
							result.setCode(ResultCodeEnum.FILE_DATA_ERROR.getCode());
							result.setMsg(ResultCodeEnum.FILE_DATA_ERROR.getMsg());
							
							CustomerImportHistoryEntity historyEntity = new CustomerImportHistoryEntity();
							historyEntity.setUserId(user.getId());
							historyEntity.setCustomerName(customerName);
							historyEntity.setSex(SexEnum.getValue(sex));
							historyEntity.setWeixinId(weixinId);
							historyEntity.setQq(qq);
							historyEntity.setMobile(mobile);
							historyEntity.setPhone(phone);
							historyEntity.setEmail(email);
							historyEntity.setImportBatchNo(importBatchNo);
							historyEntity.setImportDate(LocalDate.now());
							historyEntity.setRemark("导入的客户已经存在于: " + branchOrgEntity.getOrgName());
							customerImportHistoryMapper.insert(historyEntity);
							continue;
						}
					}
					
					
					CustomerEntity entity = new CustomerEntity();
					if(user.getUserType().equals(UserTypeEnum.TYPE_7.getValue())){
						entity.setBranchOrgId(branchOrgId);
						entity.setDepartmentId("");
					}else{
						entity.setBranchOrgId(branchOrgId);
						entity.setDepartmentId(departmentId);
					}
					entity.setCustomerName(customerName);
					entity.setSex(SexEnum.getValue(sex));
					
					DictEntity dictEntity = dictService.getDictValueByTagAndRemark("customer_source_name", customerSourceName);
					if(dictEntity!=null){
//						entity.setCustomerSourceName(dictEntity.getRemark());
						entity.setCustomerSourceNameValue(dictEntity.getValue());
					}else{
//						entity.setCustomerSourceName("");
						entity.setCustomerSourceNameValue("");
					}
					
					entity.setWeixinId(weixinId);
					entity.setQq(qq);
					entity.setMobile(mobile);
					entity.setPhone(phone);
					entity.setEmail(email);
					entity.setProvinceName(provinceName);
					entity.setCityName(cityName);
					entity.setAreaName(areaName);
					entity.setCompanyName(companyName);
					entity.setAddress(address);
					entity.setRemark(remark);
					entity.setRemark2(remark2);
					entity.setJobAge(jobAge);
					entity.setEducation(education);
					entity.setCustomerActivityPage(customerActivityPage);
					entity.setProfessional(professional);
					entity.setCustomerActivityTypePage(customerActivityTypePage);
					entity.setCreateUserId(user.getId());
					entity.setCreateTime(LocalDateTime.now());//创建时间
					entity.setUpdateTime(LocalDateTime.now());//更新时间
					entity.setRecentDynamicDateTime(LocalDateTime.now());
					entity.setRecentDynamicContent("新增客户资料");
					entity.setCustomerQuality(customerQuality);
					entity.setCustomerIntentionLevel(customerIntentionLevel);
					entity.setCustomerIntentionContent(customerIntentionContent);
					entity.setPromotionUserId(promotionUserId);
					
					if(user.getUserType().equals(UserTypeEnum.TYPE_7.getValue())){
						entity.setCustomerSourceType(CustomerSourceTypeEnum.TYPE_2.getValue());//如果是代理商用户导入的，则来源为代理商
						entity.setFollowUserId(user.getId());//代理商导入的,谁导入的，谁就是跟进人
						entity.setSeaType("");//代理商录入给自己的，
					}else{
						entity.setFollowUserId(user.getId());
						entity.setCustomerSourceType(CustomerSourceTypeEnum.TYPE_1.getValue());
						entity.setSeaType("");//公海类别，被用户持有时，此字段为空，为什么要这样设计呢？因为被持有，则就不属于公海
					}
					entity.setState("");
					entity.setCustomerStage(CustomerStageEnum.TYPE_1.getValue());
					
					entity.setImportBatchNo(importBatchNo);//设置导入批次号，将来运维查错用
					entity.setCustomerGroupTypeId(customerGroupTypeId);
					entity.setImportType(2);
					customerMapper.insert(entity);
					
					//增加用户客户表数据，代理商导入给自己也是增加用户客户表数据
					UserCustomerEntity userCustomer = new UserCustomerEntity();
					userCustomer.setCreateTime(LocalDateTime.now());
					userCustomer.setUserId(user.getId());
					userCustomer.setCustomerId(entity.getId());
					userCustomer.setMyCustomerType(MyCustomerTypeEnum.TYPE_1.getValue());
					
					userCustomerMapper.insert(userCustomer);
					
//					//如果是代理商录入的，增加：代理商用户客户表数据
//					if(user.getUserType().equals(UserTypeEnum.TYPE_6.getValue())){
//						UserCustomerAgentEntity agentsEntity = new UserCustomerAgentEntity();
//						agentsEntity.setCustomerId(entity.getId());
//						agentsEntity.setUserId(user.getId());
//						agentsEntity.setCreateDateTime(LocalDateTime.now());
//						userCustomerAgentsMapper.insert(agentsEntity);
//					}
				}
			}
			if(importType.equals("2")){//2：导入至资源库(代码分开写，跟导入到自己混到一起，到时候业务变更的时候，代码极难维护)
				for (int i = 11; i < countRow; i++) {
					Row row = customerSheet.getRow(i);// 获取第i行
					String customerName = PoiUtil.getCellValue(row.getCell(0));//姓名
					String sex = PoiUtil.getCellValue(row.getCell(1));//性别
					String customerSourceName = PoiUtil.getCellValue(row.getCell(2));//来源
					String mobile = PoiUtil.getCellValue(row.getCell(3));//手机
					String qq = PoiUtil.getCellValue(row.getCell(4));//QQ
					String weixinId = PoiUtil.getCellValue(row.getCell(5));//微信
					String phone = PoiUtil.getCellValue(row.getCell(6));//座机
					String email = PoiUtil.getCellValue(row.getCell(7));//邮箱
//					String guojia = PoiUtil.getCellValue(row.getCell(8));//地区：国家
					String provinceName = PoiUtil.getCellValue(row.getCell(9));//地区：省/州
					String cityName = PoiUtil.getCellValue(row.getCell(10));//区：城市
					String areaName = PoiUtil.getCellValue(row.getCell(11));//地区：区/县
					String companyName = PoiUtil.getCellValue(row.getCell(12));//公司
					String address = PoiUtil.getCellValue(row.getCell(13));//地址
					String remark = PoiUtil.getCellValue(row.getCell(14));//备注
					String jobAge = PoiUtil.getCellValue(row.getCell(15));//工作年限
					String education = PoiUtil.getCellValue(row.getCell(16));//学历
					String customerActivityPage = PoiUtil.getCellValue(row.getCell(17));//填写表单页面
					String professional = PoiUtil.getCellValue(row.getCell(18));//专业
					String customerActivityTypePage = PoiUtil.getCellValue(row.getCell(19));//分类
//					String danban = PoiUtil.getCellValue(row.getCell(20));//单班
//					String taoban = PoiUtil.getCellValue(row.getCell(21));//套班
//					String neixun = PoiUtil.getCellValue(row.getCell(22));//内训
//					String yijiankemu = PoiUtil.getCellValue(row.getCell(23));//一建科目
//					String erjiankemu = PoiUtil.getCellValue(row.getCell(24));//二建科目
//					String zaojiakemu = PoiUtil.getCellValue(row.getCell(25));//造价科目
//					String jianlikemu = PoiUtil.getCellValue(row.getCell(26));//监理科目
//					String xiaofangkemu = PoiUtil.getCellValue(row.getCell(27));//消防科目
//					String zixungongchengshi = PoiUtil.getCellValue(row.getCell(28));//咨询工程师
//					String yibaotonghang = PoiUtil.getCellValue(row.getCell(29));//已报同行
					String remark2 = PoiUtil.getCellValue(row.getCell(30));//备注2
//					String yijiankemu2 = PoiUtil.getCellValue(row.getCell(31));//一建科目2
//					String banxingmingcheng2 = PoiUtil.getCellValue(row.getCell(32));//班型名称2
//					String youhuiquan = PoiUtil.getCellValue(row.getCell(33));//优惠券
					
					//如果手机号码为空，则此行的数据不处理
					if(StringUtils.isBlank(mobile)){
						continue;
					}
					//先看整个系统配置是否允许重复，如果允许重复，则再进行分校的判断
					if(isRepetition){
						boolean flag = existsCustomerByMobileAndBranchOrgId(mobile, branchOrgId);
						if(flag){
							//如果此客户存在，则记录导入的此客户在xxx分校中已经存在
							result.setCode(ResultCodeEnum.FILE_DATA_ERROR.getCode());
							result.setMsg(ResultCodeEnum.FILE_DATA_ERROR.getMsg());
							
							CustomerImportHistoryEntity historyEntity = new CustomerImportHistoryEntity();
							historyEntity.setUserId(user.getId());
							historyEntity.setCustomerName(customerName);
							historyEntity.setSex(SexEnum.getValue(sex));
							historyEntity.setWeixinId(weixinId);
							historyEntity.setQq(qq);
							historyEntity.setMobile(mobile);
							historyEntity.setPhone(phone);
							historyEntity.setEmail(email);
							historyEntity.setImportBatchNo(importBatchNo);
							historyEntity.setImportDate(LocalDate.now());
							historyEntity.setRemark("导入的客户已经存在于: " + branchOrgEntity.getOrgName());
							customerImportHistoryMapper.insert(historyEntity);
							
							continue;
						}
					}else{
						boolean flag = existsCustomerByMobile(mobile);
						if(flag){
							//如果整个系统中存在此客户，则记录导入的此客户在xxx分校中已经存在
							result.setCode(ResultCodeEnum.FILE_DATA_ERROR.getCode());
							result.setMsg(ResultCodeEnum.FILE_DATA_ERROR.getMsg());
							
							CustomerImportHistoryEntity historyEntity = new CustomerImportHistoryEntity();
							historyEntity.setUserId(user.getId());
							historyEntity.setCustomerName(customerName);
							historyEntity.setSex(SexEnum.getValue(sex));
							historyEntity.setWeixinId(weixinId);
							historyEntity.setQq(qq);
							historyEntity.setMobile(mobile);
							historyEntity.setPhone(phone);
							historyEntity.setEmail(email);
							historyEntity.setImportBatchNo(importBatchNo);
							historyEntity.setImportDate(LocalDate.now());
							historyEntity.setRemark("导入的客户已经存在于: " + branchOrgEntity.getOrgName());
							customerImportHistoryMapper.insert(historyEntity);
							continue;
						}
					}
					
					CustomerEntity entity = new CustomerEntity();
					entity.setBranchOrgId(branchOrgId);
					if(departmentId!=null && !departmentId.equals("") && !departmentId.equals("null")){
						if(!user.getUserType().equals(UserTypeEnum.TYPE_7.getValue())){
							entity.setSeaType(SeaTypeEnum.TYPE_2.getValue());
							entity.setDepartmentId(departmentId);
						}else{
							entity.setSeaType(SeaTypeEnum.TYPE_1.getValue());
							entity.setDepartmentId("");
						}
					}else{
						entity.setSeaType(SeaTypeEnum.TYPE_1.getValue());
						entity.setDepartmentId("");
					}
					
					entity.setCustomerName(customerName);
					entity.setSex(SexEnum.getValue(sex));
					
					DictEntity dictEntity = dictService.getDictValueByTagAndRemark("customer_source_name", customerSourceName);
					if(dictEntity!=null){
//						entity.setCustomerSourceName(dictEntity.getRemark());
						entity.setCustomerSourceNameValue(dictEntity.getValue());
					}else{
//						entity.setCustomerSourceName("");
						entity.setCustomerSourceNameValue("");
					}
					
					entity.setWeixinId(weixinId);
					entity.setQq(qq);
					entity.setMobile(mobile);
					entity.setPhone(phone);
					entity.setEmail(email);
					entity.setProvinceName(provinceName);
					entity.setCityName(cityName);
					entity.setAreaName(areaName);
					entity.setCompanyName(companyName);
					entity.setAddress(address);
					entity.setRemark(remark);
					entity.setRemark2(remark2);
					entity.setJobAge(jobAge);
					entity.setEducation(education);
					entity.setCustomerActivityPage(customerActivityPage);
					entity.setProfessional(professional);
					entity.setCustomerActivityTypePage(customerActivityTypePage);
					entity.setCreateUserId(user.getId());
					entity.setCreateTime(LocalDateTime.now());//创建时间
					entity.setUpdateTime(LocalDateTime.now());//更新时间
					entity.setRecentDynamicDateTime(LocalDateTime.now());
					entity.setRecentDynamicContent("新增客户资料");
					entity.setCustomerQuality(customerQuality);
					entity.setCustomerIntentionLevel(customerIntentionLevel);
					entity.setCustomerIntentionContent(customerIntentionContent);
					entity.setPromotionUserId(promotionUserId);
					
					
					if(user.getUserType().equals(UserTypeEnum.TYPE_7.getValue())){
						entity.setCustomerSourceType(CustomerSourceTypeEnum.TYPE_2.getValue());//如果是代理商用户导入的，则来源为代理商
						//代理商导入的没有跟进人
					}else{
						entity.setCustomerSourceType(CustomerSourceTypeEnum.TYPE_1.getValue());
					}
					entity.setFollowUserId("");//任何人导入至资源库，应该都是没有跟进人的
					entity.setCustomerStage(CustomerStageEnum.TYPE_1.getValue());
					
					entity.setImportBatchNo(importBatchNo);//设置导入批次号，将来运维查错用
					entity.setCustomerGroupTypeId(CustomerGroupTypeIdEnum.TYPE_6.getValue()); //导入至公海，默认将客户分组设置为其他
					entity.setState("");
					entity.setImportType(2);
					customerMapper.insert(entity);
				}
			}
			if(importType.equals("3")){
				StringUtil.validateIsNull(userId, "请选择同事");
				
				//计算同事是否在部门下面
				OrgEntity orgEntity = orgService.getById(userService.getById(userId).getOrgId());
				if(orgEntity!=null && orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_3.getValue())){
					departmentId = orgEntity.getId();
				}
				
				for (int i = 11; i < countRow; i++) {
					Row row = customerSheet.getRow(i);// 获取第i行
					String customerName = PoiUtil.getCellValue(row.getCell(0));//姓名
					String sex = PoiUtil.getCellValue(row.getCell(1));//性别
					String customerSourceName = PoiUtil.getCellValue(row.getCell(2));//来源
					String mobile = PoiUtil.getCellValue(row.getCell(3));//手机
					String qq = PoiUtil.getCellValue(row.getCell(4));//QQ
					String weixinId = PoiUtil.getCellValue(row.getCell(5));//微信
					String phone = PoiUtil.getCellValue(row.getCell(6));//座机
					String email = PoiUtil.getCellValue(row.getCell(7));//邮箱
//					String guojia = PoiUtil.getCellValue(row.getCell(8));//地区：国家
					String provinceName = PoiUtil.getCellValue(row.getCell(9));//地区：省/州
					String cityName = PoiUtil.getCellValue(row.getCell(10));//区：城市
					String areaName = PoiUtil.getCellValue(row.getCell(11));//地区：区/县
					String companyName = PoiUtil.getCellValue(row.getCell(12));//公司
					String address = PoiUtil.getCellValue(row.getCell(13));//地址
					String remark = PoiUtil.getCellValue(row.getCell(14));//备注
					String jobAge = PoiUtil.getCellValue(row.getCell(15));//工作年限
					String education = PoiUtil.getCellValue(row.getCell(16));//学历
					String customerActivityPage = PoiUtil.getCellValue(row.getCell(17));//填写表单页面
					String professional = PoiUtil.getCellValue(row.getCell(18));//专业
					String customerActivityTypePage = PoiUtil.getCellValue(row.getCell(19));//分类
//					String danban = PoiUtil.getCellValue(row.getCell(20));//单班
//					String taoban = PoiUtil.getCellValue(row.getCell(21));//套班
//					String neixun = PoiUtil.getCellValue(row.getCell(22));//内训
//					String yijiankemu = PoiUtil.getCellValue(row.getCell(23));//一建科目
//					String erjiankemu = PoiUtil.getCellValue(row.getCell(24));//二建科目
//					String zaojiakemu = PoiUtil.getCellValue(row.getCell(25));//造价科目
//					String jianlikemu = PoiUtil.getCellValue(row.getCell(26));//监理科目
//					String xiaofangkemu = PoiUtil.getCellValue(row.getCell(27));//消防科目
//					String zixungongchengshi = PoiUtil.getCellValue(row.getCell(28));//咨询工程师
//					String yibaotonghang = PoiUtil.getCellValue(row.getCell(29));//已报同行
					String remark2 = PoiUtil.getCellValue(row.getCell(30));//备注2
//					String yijiankemu2 = PoiUtil.getCellValue(row.getCell(31));//一建科目2
//					String banxingmingcheng2 = PoiUtil.getCellValue(row.getCell(32));//班型名称2
//					String youhuiquan = PoiUtil.getCellValue(row.getCell(33));//优惠券
					
					//如果手机号码为空，则此行的数据不处理
					if(StringUtils.isBlank(mobile)){
						continue;
					}
					//手机号码作为判断客户是否唯一的判断标准，所以先要判断客户是否存在
					//先看整个系统配置是否允许重复，如果允许重复，则再进行分校的判断
					if(isRepetition){
						boolean flag = existsCustomerByMobileAndBranchOrgId(mobile, branchOrgId);
						if(flag){
							//如果此客户存在，则记录导入的此客户在xxx分校中已经存在
							result.setCode(ResultCodeEnum.FILE_DATA_ERROR.getCode());
							result.setMsg(ResultCodeEnum.FILE_DATA_ERROR.getMsg());
							
							CustomerImportHistoryEntity historyEntity = new CustomerImportHistoryEntity();
							historyEntity.setUserId(user.getId());
							historyEntity.setCustomerName(customerName);
							historyEntity.setSex(SexEnum.getValue(sex));
							historyEntity.setWeixinId(weixinId);
							historyEntity.setQq(qq);
							historyEntity.setMobile(mobile);
							historyEntity.setPhone(phone);
							historyEntity.setEmail(email);
							historyEntity.setImportBatchNo(importBatchNo);
							historyEntity.setImportDate(LocalDate.now());
							historyEntity.setRemark("导入的客户已经存在于: " + branchOrgEntity.getOrgName());
							customerImportHistoryMapper.insert(historyEntity);
							
							continue;
						}
					}else{
						boolean flag = existsCustomerByMobile(mobile);
						if(flag){
							//如果整个系统中存在此客户，则记录导入的此客户在xxx分校中已经存在
							result.setCode(ResultCodeEnum.FILE_DATA_ERROR.getCode());
							result.setMsg(ResultCodeEnum.FILE_DATA_ERROR.getMsg());
							
							CustomerImportHistoryEntity historyEntity = new CustomerImportHistoryEntity();
							historyEntity.setUserId(user.getId());
							historyEntity.setCustomerName(customerName);
							historyEntity.setSex(SexEnum.getValue(sex));
							historyEntity.setWeixinId(weixinId);
							historyEntity.setQq(qq);
							historyEntity.setMobile(mobile);
							historyEntity.setPhone(phone);
							historyEntity.setEmail(email);
							historyEntity.setImportBatchNo(importBatchNo);
							historyEntity.setImportDate(LocalDate.now());
							historyEntity.setRemark("导入的客户已经存在于: " + branchOrgEntity.getOrgName());
							customerImportHistoryMapper.insert(historyEntity);
							continue;
						}
					}
					
					CustomerEntity entity = new CustomerEntity();
					entity.setBranchOrgId(branchOrgId);
					entity.setDepartmentId(departmentId);
					entity.setCustomerName(customerName);
					entity.setSex(SexEnum.getValue(sex));
					
					DictEntity dictEntity = dictService.getDictValueByTagAndRemark("customer_source_name", customerSourceName);
					if(dictEntity!=null){
//						entity.setCustomerSourceName(dictEntity.getRemark());
						entity.setCustomerSourceNameValue(dictEntity.getValue());
					}else{
//						entity.setCustomerSourceName("");
						entity.setCustomerSourceNameValue("");
					}
					
					entity.setWeixinId(weixinId);
					entity.setQq(qq);
					entity.setMobile(mobile);
					entity.setPhone(phone);
					entity.setEmail(email);
					entity.setProvinceName(provinceName);
					entity.setCityName(cityName);
					entity.setAreaName(areaName);
					entity.setCompanyName(companyName);
					entity.setAddress(address);
					entity.setRemark(remark);
					entity.setRemark2(remark2);
					entity.setJobAge(jobAge);
					entity.setEducation(education);
					entity.setCustomerActivityPage(customerActivityPage);
					entity.setProfessional(professional);
					entity.setCustomerActivityTypePage(customerActivityTypePage);
					entity.setCreateUserId(user.getId());
					entity.setCreateTime(LocalDateTime.now());//创建时间
					entity.setUpdateTime(LocalDateTime.now());//更新时间
					entity.setRecentDynamicDateTime(LocalDateTime.now());
					entity.setRecentDynamicContent("新增客户资料");
					entity.setCustomerQuality(customerQuality);
					entity.setCustomerIntentionLevel(customerIntentionLevel);
					entity.setCustomerIntentionContent(customerIntentionContent);
					entity.setPromotionUserId(promotionUserId);
					
					entity.setFollowUserId(userId);
					entity.setCustomerSourceType(CustomerSourceTypeEnum.TYPE_1.getValue());
					entity.setSeaType("");//公海类别，被用户持有时，此字段为空，为什么要这样设计呢？因为被持有，则就不属于公海
					entity.setState("");
					
					entity.setCustomerStage(CustomerStageEnum.TYPE_1.getValue());
					
					entity.setImportBatchNo(importBatchNo);//设置导入批次号，将来运维查错用
					entity.setCustomerGroupTypeId(customerGroupTypeId);
					entity.setImportType(2);
					customerMapper.insert(entity);
					
					//增加用户客户
					UserCustomerEntity userCustomer = new UserCustomerEntity();
					userCustomer.setCreateTime(LocalDateTime.now());
					userCustomer.setUserId(userId);
					userCustomer.setCustomerId(entity.getId());
					userCustomer.setMyCustomerType(MyCustomerTypeEnum.TYPE_1.getValue());
					
					userCustomerMapper.insert(userCustomer);
				}
			}
			
			workBook.close();
			is.close();
		}else{
			throw new BusinessException("请上传正确的excel文件");
		}
		return result;
	}





	
	
	

}
