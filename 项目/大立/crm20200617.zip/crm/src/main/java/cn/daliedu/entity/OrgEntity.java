package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 组织架构表，顶级节点：大立教育
 * </p>
 *
 * @author xiechao
 * @since 2019-09-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("sys_org")
public class OrgEntity extends Model<OrgEntity> {

    private static final long serialVersionUID = 1L;
    
    // 上级机构名称（ 非数据库字段）
//    @TableField(exist = false)
//    private String parentName;
    
    // 下级组织机构（ 非数据库字段）
    @TableField(exist = false)
    private List<OrgEntity> children;
    
    // 机构层级（ 非数据库字段）
    @TableField(exist = false)
    private Integer level;
    
    // value值，给前端展现用（ 非数据库字段）
    @TableField(exist = false)
    private String value;

    /**
     * 部门ID
     */
    @TableId(value = "id", type = IdType.UUID)
    @ApiModelProperty(value="部门ID")
    private String id;

    /**
     * 上级部门ID，一级机构为0，为null也行
     */
    @ApiModelProperty(value="上级部门ID，一级机构为0")
    private String parentId;

    /**
     * 部门ID全路径
     */
    @ApiModelProperty(value="部门ID全路径")
    private String parentIds;

    /**
     * 机构名称（部门名称）
     */
    @ApiModelProperty(value="机构名称（部门名称）")
    private String orgName;

    /**
     * 机构类型，0：顶级机构， 1：省份或直辖市，2：分校，3：部门， 4：代理商，5：代理商下的节点
     */
    @ApiModelProperty(value="机构类型，0：顶级机构， 1：省份或直辖市，2：分校，3：部门， 4：代理商，5：代理商下的节点")
    private String orgType;

    /**
     * 机构状态, 0:停用, 1:启用;
     */
    @ApiModelProperty(value="机构状态, 0:停用, 1:启用;")
    private String state;

    /**
     * 排序号
     */
    @ApiModelProperty(value="排序号")
    private Integer orderNum;

    /**
     * 描述
     */
    @ApiModelProperty(value="描述")
    private String remark;

    /**
     * 地区(省或自治区)ID
     */
    @ApiModelProperty(value="地区(省或自治区)ID")
    private String provinceId;

    /**
     * 地区(省)名称（冗余）
     */
    @ApiModelProperty(value="地区(省)名称（冗余）")
    private String provinceName;

    /**
     * 地区(市)ID
     */
    @ApiModelProperty(value="地区(市)ID")
    private String cityId;

    /**
     * 地区(市)名称（冗余）
     */
    @ApiModelProperty(value="地区(市)名称（冗余）")
    private String cityName;

    /**
     * 地区(区)
     */
    @ApiModelProperty(value="地区(区)")
    private String areaId;

    /**
     * 地区(区)名称（冗余）
     */
    @ApiModelProperty(value="地区(区)名称（冗余）")
    private String areaName;

    /**
     * 部门ID全路径名称
     */
    @ApiModelProperty(value="部门ID全路径名称")
    private String fullNamePath;

//    /**
//     * 删除标记，1：已删除，0：未删除
//     */
//    @ApiModelProperty(value="删除标记，1：已删除，0：未删除")
//    @TableLogic // 如果不加此标签，则删除的时候就是进行物理删除
//	@TableField(fill = FieldFill.INSERT_UPDATE)
//    private String deleted;
    
    /**
     * 账号创建时间
     */
    private LocalDateTime createTime;

   

	@Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "OrgEntity{" +
        "id=" + id +
        ", parentId=" + parentId +
        ", parentIds=" + parentIds +
        ", orgName=" + orgName +
        ", orgType=" + orgType +
        ", state=" + state +
        ", orderNum=" + orderNum +
        ", remark=" + remark +
        ", provinceId=" + provinceId +
        ", provinceName=" + provinceName +
        ", cityId=" + cityId +
        ", cityName=" + cityName +
        ", areaId=" + areaId +
        ", areaName=" + areaName +
        ", fullNamePath=" + fullNamePath +
//        ", deleted=" + deleted +
        "}";
    }
}
