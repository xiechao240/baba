package cn.daliedu.util.verifyCode;

import java.util.Random;

/**
 * 随机数工具类
 */
public class Randoms
{
    private static final Random RANDOM = new Random();

    private static final Integer ZERO = 0;

    // 定义验证码字符, 去除了 O 和 I 等容易混淆的字母
    private static final char ALPHA[] =
        {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'G', 'K', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c',
            'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'm', 'n', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '2', '3', '4', '5',
            '6', '7', '8', '9'};

    /**
     * 产生 0 - num 的随机数, 不包括 num
     *
     * @param num 数字
     * @return int 随机数字
     */
    static int num(int num)
    {
        return RANDOM.nextInt(num);
    }

    public static char alpha()
    {
        return ALPHA[num(ZERO, ALPHA.length)];
    }

    /**
     * 产生两个数之间的随机数
     *
     * @param min 小数
     * @param max 比 min 大的数
     * @return int 随机数字
     */
    private static int num(int min, int max)
    {
        return min + RANDOM.nextInt(max - min);
    }
}
