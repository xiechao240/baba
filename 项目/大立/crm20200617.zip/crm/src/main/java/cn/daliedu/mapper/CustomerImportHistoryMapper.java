package cn.daliedu.mapper;

import cn.daliedu.entity.CustomerImportHistoryEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 客户导入历史表（用于导入时记录有问题的数据，如果有需求，可以开发定时任务清理此表中的数据） Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2020-02-18
 */
public interface CustomerImportHistoryMapper extends BaseMapper<CustomerImportHistoryEntity> {

}
