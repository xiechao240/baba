package cn.daliedu.controller.api.console;


import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.UserOrgAreaEntity;
import cn.daliedu.entity.json.CustomerJson;
import cn.daliedu.entity.json.CustomerTagGroupJson;
import cn.daliedu.entity.json.GlobalJson;
import cn.daliedu.entity.json.MenuJson;
import cn.daliedu.entity.json.OrgJson;
import cn.daliedu.entity.json.UserJson;
import cn.daliedu.entity.web.CustomerContactVO;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.ContractService;
import cn.daliedu.service.CustomerService;
import cn.daliedu.service.OrgService;
import cn.daliedu.service.UserOrgAreaService;
import cn.daliedu.service.UserService;
import cn.daliedu.util.BigDecimalUtil;
import cn.daliedu.util.DateUtil;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * <p>
 * 首页管理 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
@RestController
@Api(description = "首页相关接口")
@RequestMapping(value = "${rest.path}/console/homepage") 
public class HomePageController {
	@Autowired
	OrgService orgService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	UserOrgAreaService userOrgAreaService;
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	ContractService contractService;
	
	
	@ApiOperation(value = "首页【工作记录】")
	@ApiJsonObject(name = "homePageJobRecord", value = { 
//			@ApiJsonProperty(name = UserJson.userId),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime)})
	@ApiImplicitParam(name = "params", required = true, dataType = "homePageJobRecord")
//	@RequiresPermissions("sys:report:customerCount:view")
	@PostMapping("/homePageJobRecord")
	public Result homePageJobRecord(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
//				UserEntity user = userService.getById(bean.getId());
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
//				String userId = String.valueOf(jsonObject.get("userId"));
				
				
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            paramMap.put("userId", bean.getId());
	            
	            
	            Map<Object, Object> map = new HashMap<Object, Object>();
	            //1.统计新增的客户数量
            	BigDecimal createCustomerCount = customerService.getCreateCustomerCountByUser(paramMap);
            	BigDecimal customerContactCount = customerService.getCustomerContactCountByUserId(paramMap);
            	BigDecimal createContactCount = contractService.getCreateContactCountByUserId(paramMap);
	            map.put("createCustomerCount", createCustomerCount);
	            map.put("customerContactCount", customerContactCount);
	            map.put("createContactCount", createContactCount);
	            
	            return Result.success(map);
			}
			return Result.error("无法获取工作记录，请联系管理员");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取工作记录失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "首页【业绩排名】,前端先调用用户能访问的分校范围表，加载分校范围，默认选择一个分校，将分校ID传入此接口，时间范围段也要有默认值")
	@ApiJsonObject(name = "getBranchPerformanceTop", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerJson.startDateTime),
			@ApiJsonProperty(name = CustomerJson.endDateTime)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getBranchPerformanceTop")
//	@RequiresPermissions("sys:report:customerActiveness:view")
	@PostMapping("/getBranchPerformanceTop")
	public Result getBranchPerformanceTop(@RequestBody String params) {
		try{
			Object object = SecurityUtils.getSubject().getPrincipal();
			if (object instanceof UserEntity) {
				UserEntity bean = (UserEntity) object;
	            
				System.out.println("params参数为：" + params);
				
				JSONObject jsonObject = JSON.parseObject(params);
				String startDateTime = String.valueOf(jsonObject.get("startDateTime"));
				String endDateTime = String.valueOf(jsonObject.get("endDateTime"));
				String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
				
	            Map<Object, Object> paramMap = new HashMap<Object, Object>();
	            paramMap.put("startRow", 0);
	            paramMap.put("pageSize", 1000);
	            paramMap.put("startDateTime", startDateTime);
	            paramMap.put("endDateTime", endDateTime);
	            paramMap.put("branchOrgId", branchOrgId);
	            
	            List<LinkedHashMap<Object, Object>> contractAmountList = contractService.getContractAmountCountByBranch(paramMap);
	            for(LinkedHashMap<Object, Object> map : contractAmountList){
	            	String userId = map.get("user_id").toString();
	            	paramMap.put("userId", userId);
	            	
	            	BigDecimal return_money = contractService.getReturnMoneyByUserId(paramMap);
	            	if(return_money==null){
	            		map.put("return_money", 0);
	            	}else{
	            		map.put("return_money", return_money);
	            	}
	            }
	            
	            if(contractAmountList!=null && contractAmountList.size()>0){
	            	return Result.success(contractAmountList);
	            }
	            return Result.error("暂无业绩排名数据");
	            
	            //下面的为后端组装报表对象，暂时采用前端循环取json中不同位置的数据，进行报表展现
//	            List<String> personList = new ArrayList<String>();
//				Map<String, Object> dataMap = new LinkedHashMap<String, Object>();
//				List<String> legendList = new ArrayList<String>();
//	            List yaxisList = new ArrayList();
//				
//				List<LinkedHashMap<Object, Object>> userList = userService.findUserListByOrgId(paramMap);
//	            for(LinkedHashMap<Object, Object> map : userList){
//	            	personList.add(StringUtil.nullValueConvert(map.get("user_name")));
//	            }
//	            legendList.add("已回款金额");
//	            legendList.add("合同总金额");
//	            
//	            dataMap.put("legend", legendList);
//	            dataMap.put("person", personList);
//	            dataMap.put("yaxis", yaxisList);
	            
//	            return Result.success(dataMap);
			}
			return Result.error("无法获取业绩排名，请联系管理员");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取业绩排名失败，失败原因：" + e.getMessage());
		}
	}
	
	

}
