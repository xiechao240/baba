package cn.daliedu.mapper;

import cn.daliedu.entity.CustomerSelfDefineItemConfigDetailEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 客户自定义类别配置明细表 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2020-05-20
 */
public interface CustomerSelfDefineItemConfigDetailMapper extends BaseMapper<CustomerSelfDefineItemConfigDetailEntity> {
	
	/**
	 * 根据客户标签分组类型ID，获取当前客户标签对应的最大值
	 * @param customerTagTypeId 客户标签分组类型ID
	 */
	public Integer getMaxCustomerSelfDefineItemDetailValueByItemId(String itemId);
}
