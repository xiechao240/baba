package cn.daliedu.entity;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 客户合同表
 * </p>
 *
 * @author xiechao
 * @since 2019-11-01
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_contract")
public class ContractEntity extends Model<ContractEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;

    /**
     * 用户ID（即合同的创建人）
     */
    private String createUserId;

    /**
     * 客户ID
     */
    private String customerId;

    /**
     * 合同标题
     */
    @TableId(value = "id", type = IdType.UUID)
    private String title;

    /**
     * 合同总金额
     */
    private BigDecimal amount;

    /**
     * 签约日期
     */
    private LocalDate contractDate;

    /**
     * 毕业年份
     */
    private String graduationYear;

    /**
     * 专业类型
     */
    private String professionType;

    /**
     * 公司市场优惠
     */
    private String companyMarketDiscounts;

    /**
     * 开课时间
     */
    private LocalDateTime tutionDate;

    /**
     * 合同状态，0：未完成，1：已完成
     */
    private String contractState;

    /**
     * 创建时间
     */
    private LocalDateTime createDate;

    /**
     * 更新时间
     */
    private LocalDateTime updateDate;
    
    /**
     * 备注
     */
    private String remark;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
