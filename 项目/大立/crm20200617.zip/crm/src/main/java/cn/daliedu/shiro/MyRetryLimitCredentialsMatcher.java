package cn.daliedu.shiro;

import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.credential.HashedCredentialsMatcher;
import org.springframework.context.annotation.Configuration;

import cn.daliedu.enums.LoginType;
import cn.daliedu.util.Log4jUtil;
import cn.daliedu.util.MD5Util;

/**
 * @author xiechao
 * @time 2019年3月26日 下午2:49:58
 * @version 1.0.0 
 * @description 无密码登录
 */
@Configuration
public class MyRetryLimitCredentialsMatcher extends HashedCredentialsMatcher {

    @Override
	public boolean doCredentialsMatch(AuthenticationToken authcToken, AuthenticationInfo info) {
		MyUsernamePasswordToken token = (MyUsernamePasswordToken) authcToken;
		if (token.getLoginType().equals(LoginType.NOPASSWD)) {
			return true;
		}
		// boolean matches = super.doCredentialsMatch(authcToken, info);
		// return matches;

		// 获得用户输入的密码:(可以采用加盐(salt)的方式去检验)
		String inPassword = new String(token.getPassword());
		// 获得数据库中的密码
		String dbPassword = (String) info.getCredentials();

		boolean flag = this.equals(MD5Util.encrypt(inPassword), dbPassword);
//		boolean flag = this.equals(inPassword, dbPassword);
		
		Log4jUtil.info("密码比对结果：" + flag);
		// 进行密码的比对
		return flag;
	}


}
