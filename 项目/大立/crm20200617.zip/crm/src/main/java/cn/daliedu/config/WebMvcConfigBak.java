//package cn.daliedu.config;
//
//import java.util.Arrays;
//import java.util.List;
//
//import org.springframework.boot.web.servlet.FilterRegistrationBean;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.http.converter.HttpMessageConverter;
//import org.springframework.web.servlet.LocaleResolver;
//import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
//import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
//
//import com.alibaba.fastjson.serializer.SerializerFeature;
//import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;
//
//import cn.daliedu.config.filter.CorsFilter;
//import cn.daliedu.config.i18n.MyLocaleResolver;
//
//
//
//
///**
// * @Auther: Administrator
// * @Date: 2018/8/3 09:37
// * @Description: 国际化语言配置器
// *               <p>
// *               使用 WebMvcConfigurerAdapter 可以扩展 SpringMvc 的功能, 包括拦截器, 转换器等
// *               设置 @EnableWebMvc 为完全接管 SpringMvc, 但一般不要设置完全接管 SpringMvc
// */
//@Configuration
//public class WebMvcConfig extends WebMvcConfigurerAdapter {
//	
//	
//
//
//	
////	@Override
////    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
////        FastJsonHttpMessageConverter converter = new FastJsonHttpMessageConverter();
////        converter.setFeatures(SerializerFeature.WriteNullListAsEmpty,
////                SerializerFeature.WriteMapNullValue,
////                SerializerFeature.WriteNullStringAsEmpty,//字符串null返回空字符串
////                SerializerFeature.WriteNullBooleanAsFalse,
////                SerializerFeature.PrettyFormat);
////        converters.add(converter);
////   }
//
//	
//
//	/**
//	 * 解决跨域访问
//	 */
//	// @Autowired
//	// private CORSInterceptor corsInterceptor;
//
//	
//
//	// @Override
//	// public void addCorsMappings(CorsRegistry registry) {
//	// registry.addMapping("/**")
//	// .allowedOrigins("*")
//	// .allowedMethods("POST", "GET", "PUT", "OPTIONS", "DELETE")
//	// .maxAge(3600)
//	// .allowCredentials(true);
//	// }
//
//	// @Override
//	// public void addInterceptors(InterceptorRegistry registry) {
//	// // 需要拦截的路径
//	// String[] addPathPatterns = {
//	// "/**"
//	// };
//	// //不需要拦截的路径
//	// String[] excludePathPatterns = {
//	// "/common/**",
//	// "/static/**",
//	// "/swagger-resources/**",
//	// "/v2/api-docs",
//	// "/webjars/springfox-swagger-ui/**",
//	// "/admin/login",
//	// "/register/**",
//	// "/test/**"
//	//
//	// };
//	//
//	// //addPathPatterns()添加拦截路径
//	// //excludePathPatterns() 添加不拦截的路径
//	// //添加注册登录拦截器
//	//// registry.addInterceptor(new
//	// LoginInterceptor()).addPathPatterns(addPathPatterns).excludePathPatterns(excludePathPatterns);
//	// //如果有多个拦截器可以注册多个...
//	// registry.addInterceptor(corsInterceptor);
//	// }
//}
