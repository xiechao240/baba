package cn.daliedu.service.impl;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.UserCustomerEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.UserOrgAreaEntity;
import cn.daliedu.entity.UserOrgEntity;
import cn.daliedu.entity.UserRoleEntity;
import cn.daliedu.enums.OrgTypeEnum;
import cn.daliedu.enums.UserStateEnum;
import cn.daliedu.enums.UserTypeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.mapper.CustomerMapper;
import cn.daliedu.mapper.UserCustomerMapper;
import cn.daliedu.mapper.UserMapper;
import cn.daliedu.mapper.UserOrgAreaMapper;
import cn.daliedu.mapper.UserOrgMapper;
import cn.daliedu.mapper.UserRoleMapper;
import cn.daliedu.service.OrgService;
import cn.daliedu.service.UserCustomerService;
import cn.daliedu.service.UserOrgAreaService;
import cn.daliedu.service.UserOrgService;
import cn.daliedu.service.UserService;
import cn.daliedu.shiro.redis.RedisUtil;
import cn.daliedu.util.JsonUtil;
import cn.daliedu.util.MD5Util;
import cn.daliedu.util.StringUtil;

/**
 * <p>
 * 用户管理 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, UserEntity> implements UserService {
	@Autowired
	RedisUtil redisUtil;
	
	@Autowired
	OrgService orgService;
	
	@Autowired
	UserOrgService userOrgService;
	
	@Autowired
	UserOrgAreaService userOrgAreaService;
	
	@Autowired
	UserCustomerService userCustomerService;
	
	@Resource
	UserMapper userMapper;
	
	@Resource
	UserRoleMapper userRoleMapper;
	
	@Resource
	UserOrgMapper userOrgMapper;
	
	@Resource
	UserOrgAreaMapper userOrgAreaMapper;
	
	@Resource
	CustomerMapper customerMapper;
	
	@Resource
	UserCustomerMapper userCustomerMapper;
	
	
	@Override
	public List<LinkedHashMap<Object, Object>> findAgentUserListByUserId(Map<Object, Object> map) {
		return userMapper.findAgentUserListByUserId(map);
	}


	@Override
	public Long findAgentUserListByUserIdCount(Map<Object, Object> map) {
		return userMapper.findAgentUserListByUserIdCount(map);
	}


	@Override
	public boolean receiveToNewUser(String userId, String receiveUserId) throws Exception{
		//因为可选的交接人员列表，已经做了严格的校验，此处可以再进行重复校验也可以，还是要做重复校验，如果出错，数据会乱套
		Subject subject = SecurityUtils.getSubject();
		UserEntity user = (UserEntity) subject.getPrincipal();
		
		UserEntity userEntity = this.getById(userId);
		UserEntity receiveUserEntity = this.getById(receiveUserId);
		if(userEntity!=null && receiveUserEntity!=null){
			//如果是区域管理员，需要判断两个区域管理员所管辖的区域范围是否一致，或者一个人的区域范围是否是另一个人范围的子集
			if(userEntity.getUserType().equals(UserTypeEnum.TYPE_2.getValue()) && userEntity.getUserType().equals(receiveUserEntity.getUserType())){
				List<OrgEntity> userBranchOrgList = orgService.getBranchOrgByUserId(userId);
				List<OrgEntity> receiveUserBranchOrgList = orgService.getBranchOrgByUserId(receiveUserId);
				
				List<String> userBranchOrgIdList = new ArrayList<String>();
				List<String> receiveUserBranchOrgIdList = new ArrayList<String>();
				for(OrgEntity orgEntity : userBranchOrgList){
					userBranchOrgIdList.add(orgEntity.getId());
				}
				for(OrgEntity orgEntity : receiveUserBranchOrgList){
					receiveUserBranchOrgIdList.add(orgEntity.getId());
				}
				if(receiveUserBranchOrgIdList.containsAll(userBranchOrgIdList)){
					//1.更新crm_user_customer用户客户表数据，更换持有人即可
					UserCustomerEntity entity = new UserCustomerEntity();
					entity.setUserId(receiveUserId);
					int num = userCustomerMapper.update(entity, new UpdateWrapper<UserCustomerEntity>().eq("user_id", userId));
					//2.将交接人的用户状态置为离职状态
					if(num>0){
						userEntity.setState(UserStateEnum.STATE_2.getValue());
						num = userMapper.updateById(userEntity);
						if(num>0){
							return true;
						}
					}
				}else{
					throw new BusinessException("所选择交接的区域管理员与待交接的区域管理员，业务组范围不一致，权限范围不一致，无法进行交接");
				}
			}else{
				//其他的所有类型的用户，都只需要执行如下逻辑即可
				//1.更新crm_user_customer用户客户表数据，更换持有人即可
				UserCustomerEntity entity = new UserCustomerEntity();
				entity.setUserId(receiveUserId);
				int num = userCustomerMapper.update(entity, new UpdateWrapper<UserCustomerEntity>().eq("user_id", userId));
				//2.将交接人的用户状态置为离职状态
				userEntity.setState(UserStateEnum.STATE_2.getValue());
				num = userMapper.updateById(userEntity);
				if(num>0){
					return true;
				}
			}
		}else{
			throw new BusinessException("系统数据错误，交接用户不存在，请联系系统管理员");
		}
		
		return false;
	}


	@Override
	public List<LinkedHashMap<Object, Object>> findUserListByUserType(Map<Object, Object> map) {
		return userMapper.findUserListByUserType(map);
	}


	@Override
	public Long findUserListByUserTypeCount(Map<Object, Object> map) {
		return userMapper.findUserListByUserTypeCount(map);
	}


	@Override
	public List<LinkedHashMap<Object, Object>> findUserListByAgent(Map<Object, Object> map) {
		return userMapper.findUserListByAgent(map);
	}


	@Override
	public Long findUserListByAgentCount(Map<Object, Object> map) {
		return userMapper.findUserListByAgentCount(map);
	}


	@Override
	public List<UserEntity> getAllUser() {
		return userMapper.selectList(new QueryWrapper<UserEntity>().eq("state", UserStateEnum.STATE_1.getValue()));
	}


	@Override
	public Integer getCustomerTagUpdateByCustomerTagAllCount(Map<Object, Object> map) {
		return userMapper.getCustomerTagUpdateByCustomerTagAllCount(map);
	}


	@Override
	public Integer getCustomerTagUpdateByCustomerTag(Map<Object, Object> map) {
		return userMapper.getCustomerTagUpdateByCustomerTag(map);
	}


	@Override
	public List<LinkedHashMap<Object, Object>> getCustomerTagUpdateByUser(Map<Object, Object> map) throws Exception {
		return userMapper.getCustomerTagUpdateByUser(map);
	}


	@Override
	public Integer getCallContactCustomerCount(Map<Object, Object> map) {
		return userMapper.getCallContactCustomerCount(map);
	}


	@Override
	public List<LinkedHashMap<Object, Object>> getCallContactDetailCount(Map<Object, Object> map) throws Exception {
		return userMapper.getCallContactDetailCount(map);
	}


	@Override
	public Long getAddCustomerCountTopListCount(Map<Object, Object> map) throws Exception {
		return userMapper.getAddCustomerCountTopListCount(map);
	}


	@Override
	public List<LinkedHashMap<Object, Object>> getAddCustomerCountTopList(Map<Object, Object> map) throws Exception {
		return userMapper.getAddCustomerCountTopList(map);
	}


	@Override
	public List<LinkedHashMap<Object, Object>> getCallRankingByContactList(Map<Object, Object> map) throws Exception {
		return userMapper.getCallRankingByContactList(map);
	}


	@Override
	public Long getCallRankingByContactListCount(Map<Object, Object> map) {
		return userMapper.getCallRankingByContactListCount(map);
	}


	@Override
	public boolean validateMobileExist(String mobile){
		Integer num = userMapper.selectCount(new QueryWrapper<UserEntity>().eq("mobile", mobile));
		if(num>0){
			return true;
		}
		return false;
	}
	
	
	
	@Override
	public UserEntity getUserByMobile(String mobile) throws Exception{
		List<UserEntity> list = userMapper.selectList(new QueryWrapper<UserEntity>().eq("mobile", mobile));
		if(list!=null){
			if(list.size()>1){
				throw new BusinessException("当前手机号码存在多个用户，请联系系统管理员");
			}else{
				return list.get(0);
			}
		}
		return null;
	}


	@Override
	public List<LinkedHashMap<Object, Object>> findUserListByUserState(Map<Object, Object> map) {
		return userMapper.findUserListByUserState(map);
	}

	@Override
	public Long findUserListByUserStateCount(Map<Object, Object> map) {
		return userMapper.findUserListByUserStateCount(map);
	}

	@Override
	public UserEntity findUserByUserName(String name)  {
		return userMapper.selectOne(new QueryWrapper<UserEntity>().eq("user_name", name).last("limit 1"));
	}

	@Override
	public UserEntity findUserByLoginName(String loginName)  {
		return userMapper.selectOne(new QueryWrapper<UserEntity>().eq("login_name", loginName).last("limit 1"));
	}

	@Override
	public IPage<UserEntity> findUserListByLoginNameOrUserName(Integer pageNum, Integer pageSize, String loginNameOrUserName, String state) {
		// 设置分页
		if (pageNum <= 0) {
			pageNum = 1;
		}
		IPage<UserEntity> page = new Page<UserEntity>();
		page.setCurrent(pageNum);
		page.setSize(pageSize);

		QueryWrapper<UserEntity> queryWrapper = new QueryWrapper<UserEntity>();
		// 判断客户名称是否为空
		if (loginNameOrUserName != null && !loginNameOrUserName.trim().equals("")) {
			queryWrapper.like("user_name", loginNameOrUserName).or().like("login_name", loginNameOrUserName);
		}
		if (state != null && !state.trim().equals("")) {
			queryWrapper.eq("state", state);
		}
//		queryWrapper.orderByDesc("create_time");
		return userMapper.selectPage(page, queryWrapper);
	}

	@Override
	public boolean saveUser(String params) throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		UserEntity currentUser = this.getById(((UserEntity) object).getId()); 
		
		JSONObject jsonObject = JSON.parseObject(params);
		String userName = String.valueOf(jsonObject.get("userName"));
		String sex = String.valueOf(jsonObject.get("sex"));
		String mobile = String.valueOf(jsonObject.get("mobile"));
		String password = String.valueOf(jsonObject.get("password"));
		String orgId = String.valueOf(jsonObject.get("orgId"));
//		String orgName = String.valueOf(jsonObject.get("orgName"));
//		String userType = String.valueOf(jsonObject.get("userType"));
		String roleId = String.valueOf(jsonObject.get("roleId"));
		String email = String.valueOf(jsonObject.get("email"));
		String orgIds = String.valueOf(jsonObject.get("orgIds"));//分校范围
		
		StringUtil.validateIsNull(userName, "请输入名称");
		StringUtil.validateIsNull(sex, "请输入性别");
		StringUtil.validateIsNull(mobile, "请输入手机号码");
		StringUtil.validateIsNull(password, "请输入密码");
		StringUtil.validateIsNull(orgId, "请选择部门");
//		StringUtil.validateIsNull(orgName, "请选择部门");
//		StringUtil.validateIsNull(userType, "请输入用户型");
		StringUtil.validateIsNull(roleId, "请选择角色");
//		StringUtil.validateIsNull(email, "请输入邮箱账号");
		
		
		if(validateMobileExist(mobile)){
			throw new BusinessException("该手机号码已经存在");
		}
//		List<String> roleIdList = JsonUtil.getJsonToList(roleIds, String.class);  //针对可选多角色系统使用
//		if(roleIdList.size()==0){
//			throw new BusinessException("请选择角色");
//		}
		
		String userType = roleId;//目前设计角色与用户类型一致
		OrgEntity orgEntity = orgService.getById(orgId);
		
		//1.如果选择的为顶级机构，则下面新建的用户类型只能为超级管理员，区域管理员
		if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_0.getValue())){
			if(userType.equals(UserTypeEnum.TYPE_1.getValue()) || userType.equals(UserTypeEnum.TYPE_2.getValue())){
				if(userType.equals(UserTypeEnum.TYPE_2.getValue())){
					//添加区域管理员，必需勾选业务组
					if(orgIds!=null && !orgIds.trim().equals("")){
						List<String> list = JsonUtil.getJsonToList(orgIds, String.class);
						if(list.size()==0){
							throw new BusinessException("添加区域管理员，必需选择业务组");
						}
					}else{
						throw new BusinessException("添加区域管理员，必需选择业务组");
					}
				}
			}else{
				throw new BusinessException("大立教育节点下，只允许添加用户类型为：超级管理员，区域管理员");
			}
		}
		//2.因为支持了区域管理员，区域管理员是可以跨省的，所以我们目前的业务，省份下不允许添加用户
		if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_1.getValue())){
			throw new BusinessException("省份节点下不允许添加用户，请选择正确的组织结构");
		}
		//3.分校下只能添加分校管理员，普通用户
		if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_2.getValue())){
			if(userType.equals(UserTypeEnum.TYPE_3.getValue()) || userType.equals(UserTypeEnum.TYPE_4.getValue())
					||userType.equals(UserTypeEnum.TYPE_5.getValue()) ||userType.equals(UserTypeEnum.TYPE_6.getValue())){
			}else{
				throw new BusinessException("分校节点下，只允许添加用户类型为：分校管理员，销售人员，普通用户");
			}
		}
		//4.部门节点下只能添加部门管理员，销售人员，普通用户
		if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_3.getValue())){
			if(userType.equals(UserTypeEnum.TYPE_4.getValue()) || userType.equals(UserTypeEnum.TYPE_5.getValue())
					|| userType.equals(UserTypeEnum.TYPE_6.getValue())){
				
			}else{
				throw new BusinessException("部门节点下，只允许添加用户类型为：部门管理员，销售人员，普通用户");
			}
		}
		//5.代理商及代理商的子节点下，只能添加代理商用户
		if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_4.getValue()) || orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_5.getValue())
				|| orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_6.getValue())){
			if(!userType.equals(UserTypeEnum.TYPE_7.getValue())){
				throw new BusinessException("代理商节点下，只允许添加用户类型为：代理商用户");
			}
		}
		
		
		//拼接部门名称出来，只需要处理部门与分校即可，其他节点直接使用原组织机构名称
		String orgNames = orgEntity.getOrgName();
		if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_2.getValue())){
			//如果是分校则不用处理
			orgNames = orgEntity.getOrgName();
		}
		if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_3.getValue())){
			//如果是部门，则拼接为：湖南分校-->营销部
			StringBuffer sb = new StringBuffer();
			LinkedList<String> list = new LinkedList<String>();
			//如果是部门，则先添加一个当前的部门名称
			list.push(orgEntity.getOrgName());
			
			while(true){
				//如果不等于分校，则往上查找
				OrgEntity org = orgService.getById(orgEntity.getParentId());
				if(!org.getOrgType().equals(OrgTypeEnum.ORG_TYPE_2.getValue())){
					orgEntity = org;
					list.push(orgEntity.getOrgName());
				}
				//如果找到分校了，则结束循环
				if(org.getOrgType().equals(OrgTypeEnum.ORG_TYPE_2.getValue())){
					list.push(org.getOrgName());
					break;
				}
			}
			
			//循环出栈
			int size = list.size();
			for(int i=0;i<size;i++){
				sb.append(list.pop()).append("-->");
			}
			
			orgNames = sb.toString();
			if(orgNames.substring(orgNames.length()-3, orgNames.length()).equals("-->")){
				orgNames = orgNames.substring(0, orgNames.length()-3);
			}
		}
		
		//保存用户
		UserEntity user = new UserEntity();
		user.setUserName(userName);
		user.setSex(sex);
		user.setMobile(mobile);
		user.setPassword(MD5Util.encrypt(password));
		user.setLoginName(mobile);
		user.setOrgId(orgId); //此参数很重要，目前一个用户只能从属于一个机构，如果要从属于多个，相关的方法就要调整为去用户机构表里面去找关联关系
		user.setOrgName(orgEntity.getOrgName());
		user.setOrgNames(orgNames);
		user.setUserType(userType);
		user.setEmail(email);
//		user.setOrgType(orgEntity.getOrgType());
		user.setCreateTime(LocalDateTime.now());
		user.setState(UserStateEnum.STATE_1.getValue());
		user.setCreateUserId(currentUser.getId());
		
		
		//保存用户所属组织（如果需要支持多个组织，到时候再改为封装list参数）
		UserOrgEntity userOrg = new UserOrgEntity();
		userOrg.setOrgId(orgId);
		
		//保存用户
		int num = userMapper.insert(user);
		if(num>0){
			//保存用户角色
			boolean flag = false;
//			if(roleIds!=null && !roleIds.trim().equals("")){
//				for(String roleId : roleIdList){
//					UserRoleEntity userRole = new UserRoleEntity();
//					userRole.setUserId(user.getId());
//					userRole.setRoleId(roleId);
//					userRole.setCreateTime(LocalDateTime.now());
//					
//					int num2 = userRoleMapper.insert(userRole);
//					if(num2>0){
//						flag = true;
//					}
//				}
//			}
			UserRoleEntity userRole = new UserRoleEntity();
			userRole.setUserId(user.getId());
			userRole.setRoleId(roleId);
			userRole.setCreateTime(LocalDateTime.now());
			
			int num2 = userRoleMapper.insert(userRole);
			if(num2>0){
				flag = true;
			}
			//保存用户所属组织
			if(flag){
				userOrg.setUserId(user.getId());
				int num3 = userOrgMapper.insert(userOrg);
				if(num3>0){
					//保存用户能查看的分校范围，其实就是业务组公海那里使用（否则不具有分校的查看权限，超级管理员角色除外）
					//如果是非超级管理员才需要添加用户分校查看权限，超级管理员可以查看所有分校，所以不需要添加分校范围
					if(!userType.equals(UserTypeEnum.TYPE_1.getValue())){
						//1.如果区域管理员
						if(userType.equals(UserTypeEnum.TYPE_2.getValue())){
							if(orgIds!=null && !orgIds.trim().equals("")){
								List<String> orgIdList = JsonUtil.getJsonToList(orgIds, String.class);
								for(String str: orgIdList){
									UserOrgAreaEntity bean = new UserOrgAreaEntity();
									bean.setBranchOrgId(str);
									bean.setUserId(user.getId());
									userOrgAreaMapper.insert(bean);
								}
							}
						}
						//2.如果是分校管理员
						if(userType.equals(UserTypeEnum.TYPE_3.getValue())){
							UserOrgAreaEntity bean = new UserOrgAreaEntity();
							bean.setBranchOrgId(orgId);//此时传入的组织节点一定为分校
							bean.setUserId(user.getId());
							userOrgAreaMapper.insert(bean);
						}
						//3.如果是部门管理员
						if(userType.equals(UserTypeEnum.TYPE_4.getValue())){
							OrgEntity entity = orgService.getUserBranchOrgByOrgId(orgId);
							UserOrgAreaEntity bean = new UserOrgAreaEntity();
							bean.setBranchOrgId(entity.getId());
							bean.setUserId(user.getId());
							userOrgAreaMapper.insert(bean);
						}
						//4.如果是销售人员，普通用户,因为这两种人可能挂在部门节点下面了
						if(userType.equals(UserTypeEnum.TYPE_5.getValue()) || userType.equals(UserTypeEnum.TYPE_6.getValue())){
							OrgEntity entity = orgService.getUserBranchOrgByOrgId(orgId);
							UserOrgAreaEntity bean = new UserOrgAreaEntity();
							bean.setBranchOrgId(entity.getId());
							bean.setUserId(user.getId());
							userOrgAreaMapper.insert(bean);
						}
						//5.代理商用户,添加代理商用户的区域范围
						if(userType.equals(UserTypeEnum.TYPE_7.getValue())){
							//分校管理员创建代理商，默认代理商只可以导入数据至分校管理员所在的分校
							if(currentUser.getUserType().equals(UserTypeEnum.TYPE_3.getValue())){
								UserOrgAreaEntity bean = new UserOrgAreaEntity();
								bean.setBranchOrgId(orgService.getBranchOrgByUser(currentUser).get(0).getId());
								bean.setUserId(user.getId());
								userOrgAreaMapper.insert(bean);
							}else{
								if(orgIds!=null && !orgIds.trim().equals("")){
									List<String> orgIdList = JsonUtil.getJsonToList(orgIds, String.class);
									for(String str: orgIdList){
										UserOrgAreaEntity bean = new UserOrgAreaEntity();
										bean.setBranchOrgId(str);
										bean.setUserId(user.getId());
										userOrgAreaMapper.insert(bean);
									}
								}else{
									throw new BusinessException("添加代理商用户，请选择用户的业务组");
								}
							}
							
						}
						return true;
					}
					return true;
				}
			}
		}
			
		return false;
	}



	public boolean updateUserInfo(String params) throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		UserEntity currentUser = this.getById(((UserEntity) object).getId()); 
		
		JSONObject jsonObject = JSON.parseObject(params);

		String userName = String.valueOf(jsonObject.get("userName"));
		String userId = String.valueOf(jsonObject.get("userId"));
		String sex = String.valueOf(jsonObject.get("sex"));
		String mobile = String.valueOf(jsonObject.get("mobile"));
		String password = String.valueOf(jsonObject.get("password"));
		String orgId = String.valueOf(jsonObject.get("orgId"));
//		String orgName = String.valueOf(jsonObject.get("orgName"));
//		String userType = String.valueOf(jsonObject.get("userType"));
		String roleId = String.valueOf(jsonObject.get("roleId"));
//		String email = String.valueOf(jsonObject.get("email"));
		String orgIds = String.valueOf(jsonObject.get("orgIds"));

		StringUtil.validateIsNull(userName, "请输入名称");
		StringUtil.validateIsNull(userId, "请选择用户");
		StringUtil.validateIsNull(sex, "请输入性别");
		StringUtil.validateIsNull(mobile, "请输入手机号码");
		StringUtil.validateIsNull(password, "请输入密码");
		StringUtil.validateIsNull(orgId, "请选择部门");
//		StringUtil.validateIsNull(orgName, "请选择部门");
//		StringUtil.validateIsNull(userType, "请输入用户类别")
		StringUtil.validateIsNull(roleId, "请选择角色");
//		StringUtil.validateIsNull(email, "请输入邮箱账号");
		
//		List<String> roleIdList = JsonUtil.getJsonToList(roleIds, String.class);
//		if(roleIdList.size()==0){
//			throw new BusinessException("请选择角色");
//		}
		
		//只要修改用户，则先删除redis中用户登录认证信息
		redisUtil.del("crm_cache:authenticationCache:" + userId);
		
		String userType = roleId;
		OrgEntity orgEntity = orgService.getById(orgId);
		
		//代理商用户不能直接修改为公司的内部用户
		UserEntity userBean = this.getById(userId);
		if(userBean.getUserType().equals(UserTypeEnum.TYPE_7.getValue())){
			if(!userBean.getUserType().equals(userType)){
				throw new BusinessException("不能将代理商用户修改为其他用户");
			}
			if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_5.getValue()) || orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_6.getValue())){
				
			}else{
				throw new BusinessException("请选择正确的组织架构，代理商用户只能存在于代理商的组织架构");
			}
		}
		
		//1.如果选择的为顶级机构，则下面新建的用户类型只能为超级管理员，区域管理员
		if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_0.getValue())){
			if(userType.equals(UserTypeEnum.TYPE_1.getValue()) || userType.equals(UserTypeEnum.TYPE_2.getValue())){
				if(userType.equals(UserTypeEnum.TYPE_2.getValue())){
					//添加区域管理员，必需勾选业务组
					if(orgIds!=null && !orgIds.trim().equals("")){
						List<String> list = JsonUtil.getJsonToList(orgIds, String.class);
						if(list.size()==0){
							throw new BusinessException("添加区域管理员，必需选择业务组");
						}
					}else{
						throw new BusinessException("添加区域管理员，必需选择业务组");
					}
				}
			}else{
				throw new BusinessException("大立教育节点下，只允许添加用户类型为：超级管理员，区域管理员");
			}
		}
		//2.因为支持了区域管理员，区域管理员是可以跨省的，所以我们目前的业务，省份下不允许添加用户
		if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_1.getValue())){
			throw new BusinessException("省份节点下不允许添加用户，请选择正确的组织结构");
		}
		//3.分校下只能添加分校管理员，普通用户
		if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_2.getValue())){
			if(userType.equals(UserTypeEnum.TYPE_3.getValue()) || userType.equals(UserTypeEnum.TYPE_4.getValue())
					||userType.equals(UserTypeEnum.TYPE_5.getValue()) ||userType.equals(UserTypeEnum.TYPE_6.getValue())){
			}else{
				throw new BusinessException("分校节点下，只允许添加用户类型为：分校管理员，销售人员，普通用户");
			}
		}
		//4.部门节点下只能添加部门管理员，普通用户
		if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_3.getValue())){
			if(userType.equals(UserTypeEnum.TYPE_4.getValue()) || userType.equals(UserTypeEnum.TYPE_5.getValue())
					|| userType.equals(UserTypeEnum.TYPE_6.getValue())){
				
			}else{
				throw new BusinessException("部门节点下，只允许添加用户类型为：部门管理员，销售人员，普通用户");
			}
		}
		//5.代理商及代理商的子节点下，只能添加代理商用户
		if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_4.getValue()) || orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_5.getValue())
				|| orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_6.getValue())){
			if(!userType.equals(UserTypeEnum.TYPE_7.getValue())){
				throw new BusinessException("代理商节点下，只允许添加用户类型为：代理商用户");
			}
		}
		
		
		//接接用户的组织机构名称，格式为：湖南分校-->营销部
		String orgNames = orgEntity.getOrgName();  
		if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_2.getValue())){
			//如果是分校则不用处理
			orgNames = orgEntity.getOrgName();
		}
		if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_3.getValue())){
			//如果是部门，则拼接为：湖南分校-->营销部
			StringBuffer sb = new StringBuffer();
//			Vector<String> stack = new Vector<String>();
			LinkedList<String> list = new LinkedList<String>();
			//如果是部门，则先添加一个当前的部门名称
//			sb.append(orgEntity.getName()).append("-->");
			list.push(orgEntity.getOrgName());
			
			while(true){
				//如果不等于分校，则往上查找
				OrgEntity org = orgService.getById(orgEntity.getParentId());
				if(!org.getOrgType().equals(OrgTypeEnum.ORG_TYPE_2.getValue())){
					orgEntity = org;
					list.push(orgEntity.getOrgName());
				}
				//如果找到分校了，则结束循环
				if(org.getOrgType().equals(OrgTypeEnum.ORG_TYPE_2.getValue())){
					list.push(org.getOrgName());
					break;
				}
			}
			
			//循环出栈
			int size = list.size();
			for(int i=0;i<size;i++){
				sb.append(list.pop()).append("-->");
			}
			
			orgNames = sb.toString();
			if(orgNames.substring(orgNames.length()-3, orgNames.length()).equals("-->")){
				orgNames = orgNames.substring(0, orgNames.length()-3);
			}
		}

		//保存用户
		UserEntity user = new UserEntity();
		user.setId(userId);
		user.setUserName(userName);
		user.setSex(sex);
		user.setMobile(mobile);
		user.setOrgId(orgId);
		user.setOrgName(orgEntity.getOrgName());
		user.setOrgNames(orgNames);
		user.setUserType(userType);
		user.setPassword(MD5Util.encrypt(password));


		//保存用户所属组织（如果需要支持多个组织，到时候再改为封装list参数）
		UserOrgEntity userOrg = new UserOrgEntity();
		userOrg.setOrgId(orgId);

		//将前后的“,”去掉
//		List<String> orgList = Arrays.asList(orgIds.split(",")).stream().filter(s -> !s.isEmpty()).map(s -> s.trim()).collect(Collectors.toList());
		
		
		//修改用户
		int num = this.userMapper.updateById(user);
		if (num > 0) {
			//编辑用户角色
			this.userRoleMapper.delete(new QueryWrapper<UserRoleEntity>().eq("user_id", user.getId()));
			boolean flag = false;
//			if(roleIds!=null && !roleIds.trim().equals("")){
//				for(String roleId : roleIdList){
//					UserRoleEntity userRole = new UserRoleEntity();
//					userRole.setUserId(user.getId());
//					userRole.setRoleId(roleId);
//					userRole.setCreateTime(LocalDateTime.now());
//					
//					int num2 = userRoleMapper.insert(userRole);
//					if(num2>0){
//						flag = true;
//					}
//				}
//			}
			UserRoleEntity userRole = new UserRoleEntity();
			userRole.setUserId(user.getId());
			userRole.setRoleId(roleId);
			userRole.setCreateTime(LocalDateTime.now());
			
			int num2 = userRoleMapper.insert(userRole);
			if(num2>0){
				flag = true;
			}
			if (flag) {
				//编辑用户所属组织
				userOrg.setUserId(user.getId());
				this.userOrgMapper.delete(new QueryWrapper<UserOrgEntity>().eq("user_id", user.getId()));
				num = userOrgMapper.insert(userOrg);
				if (num > 0) {
					//先删除用户的分校范围(不管是由勾上变为不勾上，还是由不勾上变为勾上，先删除已经存在的分校，哪怕最后再保存一个自己所在的分校都行)
					//如果用户有勾选，则先删除，防止前端传[]空数组过来，导致数据误删
					this.userOrgAreaMapper.delete(new QueryWrapper<UserOrgAreaEntity>().eq("user_id", user.getId()));
					//保存用户能查看的分校范围，其实就是业务组公海那里使用（否则不具有分校的查看权限，超级管理员角色除外）
					//如果是非超级管理员才需要添加用户分校查看权限，超级管理员可以查看所有分校，所以不需要添加分校范围
					if(!userType.equals(UserTypeEnum.TYPE_1.getValue())){
						//1.如果区域管理员
						if(userType.equals(UserTypeEnum.TYPE_2.getValue())){
							if(orgIds!=null && !orgIds.trim().equals("")){
								List<String> orgIdList = JsonUtil.getJsonToList(orgIds, String.class);
								for(String str: orgIdList){
									UserOrgAreaEntity bean = new UserOrgAreaEntity();
									bean.setBranchOrgId(str);
									bean.setUserId(user.getId());
									userOrgAreaMapper.insert(bean);
								}
							}
						}
						//2.如果是分校管理员
						if(userType.equals(UserTypeEnum.TYPE_3.getValue())){
							UserOrgAreaEntity bean = new UserOrgAreaEntity();
							bean.setBranchOrgId(orgId);//此时传入的组织节点一定为分校
							bean.setUserId(user.getId());
							userOrgAreaMapper.insert(bean);
						}
						//3.如果是部门管理员
						if(userType.equals(UserTypeEnum.TYPE_4.getValue())){
							OrgEntity entity = orgService.getUserBranchOrgByOrgId(orgId);
							UserOrgAreaEntity bean = new UserOrgAreaEntity();
							bean.setBranchOrgId(entity.getId());
							bean.setUserId(user.getId());
							userOrgAreaMapper.insert(bean);
						}
						//4.如果是销售人员，普通用户,因为这两种人可能挂在部门节点下面了
						if(userType.equals(UserTypeEnum.TYPE_5.getValue()) || userType.equals(UserTypeEnum.TYPE_6.getValue())){
							OrgEntity entity = orgService.getUserBranchOrgByOrgId(orgId);
							UserOrgAreaEntity bean = new UserOrgAreaEntity();
							bean.setBranchOrgId(entity.getId());
							bean.setUserId(user.getId());
							userOrgAreaMapper.insert(bean);
						}
						//5.代理商用户,添加代理商用户的区域范围
						if(userType.equals(UserTypeEnum.TYPE_7.getValue())){
							//分校管理员创建代理商，默认代理商只可以导入数据至分校管理员所在的分校
							if(currentUser.getUserType().equals(UserTypeEnum.TYPE_3.getValue())){
								UserOrgAreaEntity bean = new UserOrgAreaEntity();
								bean.setBranchOrgId(orgService.getBranchOrgByUser(currentUser).get(0).getId());
								bean.setUserId(user.getId());
								userOrgAreaMapper.insert(bean);
							}else{
								if(orgIds!=null && !orgIds.trim().equals("")){
									List<String> orgIdList = JsonUtil.getJsonToList(orgIds, String.class);
									for(String str: orgIdList){
										UserOrgAreaEntity bean = new UserOrgAreaEntity();
										bean.setBranchOrgId(str);
										bean.setUserId(user.getId());
										userOrgAreaMapper.insert(bean);
									}
								}else{
									throw new BusinessException("添加代理商用户，请选择用户的业务组");
								}
							}
							
						}
						return true;
					}
					return true;
				}
			}
		}
		return false;
	}
	

	@Override
	public List<LinkedHashMap<Object, Object>>  findUserListByOrgId(Map<Object, Object> map) {
		return userMapper.findUserListByOrgId(map);
	}
	

	@Override
	public List<UserEntity> getUserListByOrgId(String orgId) {
		return userMapper.getUserListByOrgId(orgId);
	}



	@Override
	public List<UserEntity> getUserListByBranchOrgId(Map<Object, Object> map) {
		return userMapper.getUserListByBranchOrgId(map);
	}
	
	

	@Override
	public Long getUserListByBranchOrgIdCount(Map<Object, Object> map) {
		return userMapper.getUserListByBranchOrgIdCount(map);
	}


	@Override
	public Long findUserListByOrgIdCount(Map<Object, Object> map) {
		return userMapper.findUserListByOrgIdCount(map);
	}


	@Override
	public List<LinkedHashMap<Object, Object>> findUserListByOrgIdAndChildren(Map<Object, Object> map) {
		return userMapper.findUserListByOrgIdAndChildren(map);
	}


	@Override
	public Long findUserListByOrgIdAndChildrenCount(Map<Object, Object> map) {
		return userMapper.findUserListByOrgIdAndChildrenCount(map);
	}


	@Override
	public boolean updateUserStateBatch(List<String> userIdList, String state) throws Exception {
		//如果操作员工离职，还需要将员工在，用户客户表中的数据删除，当员工离职，那么这个员工关联的客户，则都没有了
		//注意，禁用员工，只是这个账号暂时禁用而已
		if(state.equals(UserStateEnum.STATE_2.getValue())){
			//同时将离职员工手上的客户更新至业务组公海
			if(userIdList!=null && userIdList.size()>0){
        		String userIds = "";
				for(String userId : userIdList){
					userIds = userIds + "'" + userId + "'" + ",";
				}
				userIds = userIds.substring(0, userIds.length()-1);
				customerMapper.updateCustomerSeaTypeByUserIds(userIds);
				
				for(String userId : userIdList){
					userCustomerMapper.delete(new QueryWrapper<UserCustomerEntity>().eq("user_id", userId));
				}
        	}
		}
		
		for(String userId : userIdList){
			UserEntity user = new UserEntity();
			user.setId(userId);
			user.setState(state);
			
			userMapper.updateById(user);
		}
		return true;
	}

	@Override
	public List<UserEntity> getFollowUserList(Map<Object, Object> map) {
		return userMapper.getFollowUserList(map);
	}
	
	@Override
	public Long getFollowUserListCount(Map<Object, Object> map) {
		return userMapper.getFollowUserListCount(map);
	}
	


	@Override
	public boolean updateUserOrgBatch(List<String> userIds, String orgId) throws Exception {
		Object object = SecurityUtils.getSubject().getPrincipal();
		UserEntity user = this.getById(((UserEntity) object).getId()); 
		
		//查找需要移动到的组织机构
		OrgEntity orgEntity = orgService.getById(orgId);
		if(orgEntity!=null){
			//如果不是分校或者分校下的部门，则报错
			//机构类型	org_type	机构类型，0：顶级机构， 1：省份或直辖市，2：分校，3：部门， 4：代理商，5：代理商下的节点
			if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_0.getValue()) 
					|| orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_1.getValue())
					|| orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_4.getValue())
					|| orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_5.getValue())
					|| orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_6.getValue())){
				throw new BusinessException("您输入的组织机构有问题，只有分校或分校下的部门可以编辑");
			}
		}else{
			throw new BusinessException("您输入的组织机构有问题，您无权限操作");
		}
		
		//只有超级管理员跟管理员可以操作此功能
		if(user.getUserType().equals(UserTypeEnum.TYPE_2.getValue()) || user.getUserType().equals(UserTypeEnum.TYPE_2.getValue())){
			//校验移动的用户列表，如果移动的用户里面有超级管理员，则提示报错
			for(String userId : userIds){
				UserEntity entity = userMapper.selectById(userId);
				//如果移动的用户中包含超级管理员，不允许移动
				if(entity.getUserType().equals(UserTypeEnum.TYPE_1.getValue())){
					throw new BusinessException("您编辑的用户中包含超级管理员，请重新勾选");
				}
				//如果当前登录的用户为超级管理员，也不允许移动别的超级管理员
				if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue()) && user.getUserType().equals(entity.getUserType())){
					throw new BusinessException("您编辑的用户中包含超级管理员，请重新勾选");
				}
				//如果当前使用的用户为普通管理员，不允许移动别的普通管理员
				if(user.getUserType().equals(UserTypeEnum.TYPE_2.getValue()) && user.getUserType().equals(entity.getUserType())){
					throw new BusinessException("您编辑的用户中包含普通管理员，请重新勾选");
				}
			}
		}else{
			throw new BusinessException("您无权限操作此功能，请核实身份");
		}
		
		
		
		//普通管理员只可将自己所在分校下的用户，或分校下的部门下的用户进行移动，不能移动至别的分校去
		//1.获取当前用户判断是否为管理员，如果不为管理员则报错
		//2.获取当前用户所在的分校，跟需要移动的用户所在的分校进行比较，如果有一个不相等，即为移动别的分校的用户，则报错
		//3.判断移动到的分校是否相等，如果不相等，则报错
		if(user.getUserType().equals(UserTypeEnum.TYPE_2.getValue())){
			OrgEntity branchntity = orgService.getUserBranchOrgByOrgId(orgId);//获取移动的组织分校
			for(String userId : userIds){
				//找到用户原来所属的分校
				UserEntity entity = userMapper.selectById(userId);
				OrgEntity org = orgService.getById(entity.getOrgId());
				OrgEntity userbranchntity = orgService.getUserBranchOrgByOrgId(orgId);
				if(!branchntity.getId().equals(userbranchntity.getId())){
					throw new BusinessException("您只能操作本分校范围内的用户，如有需要请联系超级管理员");
				}
			}
		}
		
		
		//保存用户的分校范围
		//1.删除用户原来所属的分校
		//2.保存用户新在的分校（需要判断此机构是否为分校，如果是分校则直接保存，如果是分校下的部门，则需要先通过分校找到部门，还需要判断是否是代理商（代理商不判断了））
		for(String userId : userIds){
			//找到用户原来所属的分校
			UserEntity entity = userMapper.selectById(userId);
			OrgEntity org = orgService.getById(entity.getOrgId());
			String orgId2 = entity.getOrgId();
			if(org.getOrgType().equals(OrgTypeEnum.ORG_TYPE_3.getValue())){
				org = orgService.getUserBranchOrgByOrgId(orgId);
				orgId2 = orgEntity.getId();
			}
			//删除用户原来所属的分校范围
			userOrgAreaMapper.delete(new QueryWrapper<UserOrgAreaEntity>().eq("user_id", userId).eq("branch_org_id", orgId2));
			
			//保存新的用户所属的分校范围
			UserOrgAreaEntity userOrgEntity = new UserOrgAreaEntity();
			userOrgEntity.setUserId(userId);
			userOrgEntity.setBranchOrgId(orgId2);
			userOrgAreaMapper.insert(userOrgEntity);
		}
		
		
		//批量删除用户所属的组织
		userOrgMapper.delete(new QueryWrapper<UserOrgEntity>().in("user_id", userIds));
		
		//增加用户所属的组织
//		List<UserOrgEntity> userOrgList = new ArrayList<UserOrgEntity>(); //有事务不能再引入其他的服务层
		for(String userId : userIds){
			UserOrgEntity entity = new UserOrgEntity();
			entity.setOrgId(orgId);
			entity.setUserId(userId);
//			userOrgList.add(entity);
			userOrgMapper.insert(entity);
		}
		
		//如果是部门，找到部门所在的分校
//		if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_3.getValue())){
//			orgEntity = orgService.getBranchOrg(orgId);
//			orgId = orgEntity.getId();
//		}
		
		//接接用户的组织机构名称，格式为：湖南分校-->营销部
		String orgName = "";
		if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_2.getValue())){
			//如果是分校则不用处理
			orgName = orgEntity.getOrgName();
		}
		if(orgEntity.getOrgType().equals(OrgTypeEnum.ORG_TYPE_3.getValue())){
			//如果是部门，则拼接为：湖南分校-->营销部
			StringBuffer sb = new StringBuffer();
//			Vector<String> stack = new Vector<String>();
			LinkedList<String> list = new LinkedList<String>();
			//如果是部门，则先添加一个当前的部门名称
//			sb.append(orgEntity.getName()).append("-->");
			list.push(orgEntity.getOrgName());
			
			while(true){
				//如果不等于分校，则往上查找
				OrgEntity org = orgService.getById(orgEntity.getParentId());
				if(!org.getOrgType().equals(OrgTypeEnum.ORG_TYPE_2.getValue())){
					orgEntity = org;
					list.push(orgEntity.getOrgName());
				}
				//如果找到分校了，则结束循环
				if(org.getOrgType().equals(OrgTypeEnum.ORG_TYPE_2.getValue())){
					list.push(org.getOrgName());
					break;
				}
			}
			
			//循环出栈
			int size = list.size();
			for(int i=0;i<size;i++){
				sb.append(list.pop()).append("-->");
			}
			
			orgName = sb.toString();
			if(orgName.substring(orgName.length()-3, orgName.length()).equals("-->")){
				orgName = orgName.substring(0, orgName.length()-3);
			}
		}
		
		//更新用户的组织及组织名称
		for(String userId : userIds){
			UserEntity entity = new UserEntity();
			entity.setId(userId);
			entity.setOrgId(orgId);
			entity.setOrgName(orgName);//更新分校名称到用户表中去，看需求，如果不需要，就把上面那段代码注掉
			userMapper.updateById(entity);
		}
		return true;
		
	}


	@Override
	public LinkedHashMap<Object, Object> getUserNameAndOrgNameByUserId(String userId) {
		return userMapper.getUserNameAndOrgNameByUserId(userId);
	}


	@Override
	public List<LinkedHashMap<Object, Object>> getReceiptUserList(Map<Object, Object> map) {
		return userMapper.getReceiptUserList(map);
	}


	@Override
	public Long getReceiptUserListCount(Map<Object, Object> map) {
		return userMapper.getReceiptUserListCount(map);
	}

	
	@Override
	public List<LinkedHashMap<Object, Object>> getShareRelationUsers(String customerId) {
		return userMapper.getShareRelationUsers(customerId);
	}
	
	

}
