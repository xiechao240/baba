package cn.daliedu.entity.json;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * swagger注释属性：属性json
 * </p>
 *
 * @author xiechao
 * @since 2019-05-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ReturnMoneyPlanModel {
	
	/**
	 * 期次
	 */
	@ApiModelProperty(value = "期次")
	public  String returnMoneyNum;
	
	/**
	 * 计划回款日期
	 */
	@ApiModelProperty(value = "计划回款日期")
	public  String planReturnMoneyDate;
	
	/**
	 * 计划回款金额
	 */
	@ApiModelProperty(value = "计划回款金额")
	public  String planReturnMoney;
	
	/**
	 * 备注
	 */
	@ApiModelProperty(value = "备注")
	public  String remark;
	
	

	
}
