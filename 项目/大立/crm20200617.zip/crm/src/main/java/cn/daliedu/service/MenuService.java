package cn.daliedu.service;

import cn.daliedu.entity.MenuEntity;

import java.util.List;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 菜单管理 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
public interface MenuService extends IService<MenuEntity> {
	
	
	/**
	 * 根据角色ID获取角色对应的菜单,以树形结构返回数据
	 * @param roleId
	 * @return
	 */
	public List<MenuEntity> getTreeMenuListByRoleId(String roleId);
	
	/**
	 * 加载指定节点下的子孙菜单，以树形结构返回
	 * @param parentId 父节点菜单
	 * @return
	 */
	public List<MenuEntity> getTreeMenuListByParentId(Integer parentId);

	/**
	 * 根据角色ID获取角色对应的菜单
	 * @param roleId
	 * @return
	 */
	public List<MenuEntity> getMenuListByRoleId(String roleId);
	
	/**
	 * 根据用户ID获取用户拥有的所有角色对应的菜单,不以树形结构返回结果
	 * @param userId
	 * @return
	 */
	public List<MenuEntity> getMenuListByUserId(String userId);
	
	
	/**
	 * 根据用户ID获取用户拥有的所有角色对应的菜单
	 * @param menuType 获取菜单类型，0：获取所有菜单，包含按钮，1：获取所有菜单，不包含按钮
	 * @param userId 
	 * @return
	 */
	public List<MenuEntity> findTree(String userId, String menuType);
	
	/**
	 * 获取系统所有的菜单，并以树形结构返回
	 * @param menuType 获取菜单类型，0：获取所有菜单，包含按钮，1：获取所有菜单，不包含按钮
	 * @return
	 */
	public List<MenuEntity> findMenuTree(String menuType);
	

	/**
	 * 根据用户ID查找菜单列表
	 * @param userName
	 * @return
	 */
	public List<MenuEntity> findByUser(String userId);
}
