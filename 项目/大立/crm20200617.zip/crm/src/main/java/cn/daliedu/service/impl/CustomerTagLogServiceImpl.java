package cn.daliedu.service.impl;

import cn.daliedu.entity.CustomerTagLogEntity;
import cn.daliedu.mapper.CustomerTagLogMapper;
import cn.daliedu.service.CustomerTagLogService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户打标签记录表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-12-12
 */
@Service
public class CustomerTagLogServiceImpl extends ServiceImpl<CustomerTagLogMapper, CustomerTagLogEntity> implements CustomerTagLogService {

}
