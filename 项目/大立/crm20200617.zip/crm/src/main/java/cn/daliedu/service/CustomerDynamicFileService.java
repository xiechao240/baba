package cn.daliedu.service;

import cn.daliedu.entity.CustomerDynamicFileEntity;

import java.util.List;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 客户动态上传的文件或图片 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-29
 */
public interface CustomerDynamicFileService extends IService<CustomerDynamicFileEntity> {
	
	/**
	 * 根据客户动态ID，获取客户动态对应的图片或文件路径
	 * @param customerDynamicId
	 */
	public List<CustomerDynamicFileEntity> getCustomerDynamicFileById(String customerDynamicId);
}
