package cn.daliedu.enums;

/**
 * 合同状态枚举类
 * @author xiechao
 * @time 2019年9月20日 下午3:52:34
 * @version 1.0.0 
 * @description
 */
public enum ContractStateEnum {
	/**
	 * 未完成
	 */
	STATE_0("0", "未完成"), 
	/**
	 * 已完成
	 */
	STATE_1("1", "已完成");

	private String value;
	private String desc;

	ContractStateEnum(final String value, final String desc) {
		this.value = value;
		this.desc = desc;
	}


	public String getValue() {
		return value;
	}
	
	public String getDesc() {
		return desc;
	}
	
	 /**
     * 根据枚举值获取枚举描述
     * @param key
     * @return
     */
    public static String getDesc(String value){
    	String returnStr = "";
        for (ContractStateEnum e: ContractStateEnum.values()){
            if(e.getValue().equals(value)){
            	returnStr = e.getDesc();
            	break;
            }
        }
		return returnStr;
    }
	
}