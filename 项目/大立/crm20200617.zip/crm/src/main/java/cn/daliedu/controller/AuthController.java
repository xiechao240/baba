package cn.daliedu.controller;


import org.apache.shiro.SecurityUtils;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.daliedu.enums.ResultCodeEnum;
import cn.daliedu.util.Result;
 
/**
 * 此类为待定的类，暂时没用到
 * @author xiechao
 * @time 2019年2月22日 上午11:04:57
 * @version 1.0.0 
 * @description
 */
//@RequestMapping("/common")
//@RestController
public class AuthController {
 
    /**
     * 未授权跳转方法
     * @return
     */
    @RequestMapping("/unauth")
    public Result unauth(){
        SecurityUtils.getSubject().logout();
        return new Result(ResultCodeEnum.USER_NOT_AUTH);
    }
 
    /**
     * 被踢出后跳转方法
     * @return
     */
    @RequestMapping("/kickout")
    public Result kickout(){
        return new Result(ResultCodeEnum.NET_WORK_401_INVALID_TOKEN);
    }
 
}

