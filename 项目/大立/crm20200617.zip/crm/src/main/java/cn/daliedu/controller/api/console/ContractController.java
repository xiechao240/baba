package cn.daliedu.controller.api.console;


import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.json.ContractJson;
import cn.daliedu.entity.json.ContractModel;
import cn.daliedu.entity.json.CustomerJson;
import cn.daliedu.entity.json.GlobalJson;
import cn.daliedu.entity.json.UserJson;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.ContractReturnMoneyPlanService;
import cn.daliedu.service.ContractService;
import cn.daliedu.service.UserService;
import cn.daliedu.util.PageUtil;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * <p>
 * 客户合同表 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2019-10-31
 */
@Api(description = "客户合同与回款相关接口")
@RestController
@RequestMapping("${rest.path}/contract")
public class ContractController {
	
	@Autowired
	UserService userService;
	
	@Autowired
	ContractService contractService;
	
	@Autowired
	ContractReturnMoneyPlanService contractReturnMoneyPlanService;
	
	@ApiOperation(value = "定时任务调度，更新回款计划状态为逾期未完成")
	@PostMapping("/updateReturnMoneyStateByScheduleTask")
	public Result updateReturnMoneyStateByScheduleTask() {
		try{
			
			Integer num = contractReturnMoneyPlanService.updateReturnMoneyStateByScheduleTask();
			if(num>0){
				return Result.success("更新成功");
			}
			return Result.error("未更新到数据" + num);
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("定时任务调度，更新回款计划状态为逾期未完成，失败原因：" + e.getMessage());
		}
	}
	
	
	
	@ApiOperation(value = "获取合同列表（带分页），合同详情数据也全部返回，当点击获取合同详情时，不用再调接口")
	@ApiJsonObject(name = "getContractList", value = { 
			@ApiJsonProperty(name = CustomerJson.customerId),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getContractList")
	@PostMapping("/getContractList")
	public Result getContractList(@RequestBody String params) {
		try{
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
			String customerId = String.valueOf(jsonObject.get("customerId"));
			
			StringUtil.validateIsNull(pageNum, "请输入页码");
			StringUtil.validateIsNull(pageSize, "请输入每页记录数");
			
            
            Map<Object, Object> paramMap = new HashMap<Object, Object>();
            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
            paramMap.put("pageSize", Integer.parseInt(pageSize));
            paramMap.put("customerId", customerId);
    		

            List<LinkedHashMap<Object, Object>> list = contractService.getContractListByCustomerId(paramMap);
            if(list!=null && list.size()>0){
				Long total = contractService.getContractListByCustomerIdCount(paramMap);
				
				IPage page  = new Page();
				page.setTotal(total.longValue());
				page.setSize(Long.parseLong(pageSize));
				page.setRecords(list);
				return Result.success(page);
			}
            return Result.error("此客户暂无客户合同数据");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户合同失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "【点击回款按钮】获取客户合同回款计划，回款记录列表（带分页）,当点击获取详情时，不用再调接口")
	@ApiJsonObject(name = "getContractReturnMoneyPlanByCustomerIdList", value = { 
			@ApiJsonProperty(name = CustomerJson.customerId),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getContractReturnMoneyPlanByCustomerIdList")
	@PostMapping("/getContractReturnMoneyPlanByCustomerIdList")
	public Result getContractReturnMoneyPlanByCustomerIdList(@RequestBody String params) {
		try{
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
			String customerId = String.valueOf(jsonObject.get("customerId"));
			
			StringUtil.validateIsNull(pageNum, "请输入页码");
			StringUtil.validateIsNull(pageSize, "请输入每页记录数");
			
            
            Map<Object, Object> paramMap = new HashMap<Object, Object>();
            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
            paramMap.put("pageSize", Integer.parseInt(pageSize));
            paramMap.put("customerId", customerId);
    		

            List<LinkedHashMap<Object, Object>> list = contractReturnMoneyPlanService.getContractReturnMoneyPlanByCustomerIdList(paramMap);
            if(list!=null && list.size()>0){
				Long total = contractReturnMoneyPlanService.getContractReturnMoneyPlanByCustomerIdListCount(paramMap);
				
				IPage page  = new Page();
				page.setTotal(total.longValue());
				page.setSize(Long.parseLong(pageSize));
				page.setRecords(list);
				return Result.success(page);
			}
			
			return Result.error("此客户暂无回款计划数据");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户回款计划列表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "根据合同ID，删除合同")
	@ApiJsonObject(name = "deleteContractById", value = { 
			@ApiJsonProperty(name = CustomerJson.id)})
	@ApiImplicitParam(name = "params", required = true, dataType = "deleteContractById")
	@PostMapping("/deleteContractById")
	public Result deleteContractById(@RequestBody String params) {
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String id = String.valueOf(jsonObject.get("id"));
			
			if(contractService.removeById(id)){
				return Result.success("删除成功");
			}
			
			return Result.error("删除合同失败，请联系管理员");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("删除合同失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "新建合同")
	@ApiJsonObject(name = "saveContract", value = { 
			@ApiJsonProperty(name = CustomerJson.customerId),
			@ApiJsonProperty(name = ContractJson.title),
			@ApiJsonProperty(name = ContractJson.amount),
			@ApiJsonProperty(name = ContractJson.contractDate),
			@ApiJsonProperty(name = ContractJson.graduationYear),
//			@ApiJsonProperty(name = ContractJson.professionType),
			@ApiJsonProperty(name = ContractJson.companyMarketDiscounts),
			@ApiJsonProperty(name = ContractJson.tutionDate),
			@ApiJsonProperty(name = ContractJson.contractState),
			@ApiJsonProperty(name = ContractJson.remark)})
	@ApiImplicitParam(name = "params", required = true, dataType = "saveContract")
	@PostMapping("/saveContract")
	public Result saveContract(@RequestBody String params) {
		try{
			if(contractService.saveContract(params)){
				return Result.success("保存成功");
			}
			
			return Result.error("新建合同失败，请联系管理员");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("新建合同失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "修改合同")
	@ApiJsonObject(name = "updateContract", value = { 
			@ApiJsonProperty(name = ContractJson.contractId),
			@ApiJsonProperty(name = CustomerJson.customerId),
			@ApiJsonProperty(name = ContractJson.title),
			@ApiJsonProperty(name = ContractJson.amount),
			@ApiJsonProperty(name = ContractJson.contractDate),
			@ApiJsonProperty(name = ContractJson.graduationYear),
			@ApiJsonProperty(name = ContractJson.professionType),
			@ApiJsonProperty(name = ContractJson.companyMarketDiscounts),
			@ApiJsonProperty(name = ContractJson.tutionDate)})
	@ApiImplicitParam(name = "params", required = true, dataType = "updateContract")
	@PostMapping("/updateContract")
	public Result updateContract(@RequestBody String params) {
		try{
			if(contractService.updateContract(params)){
				return Result.success("保存成功");
			}
			
			return Result.error("修改合同失败，请联系管理员");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("修改合同失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "新增回款计划（需要根据选择的合同ID,调用合同的期次列表，如果返回的期次列表不为空，则显示相应的期次列表，并且可以增加新的期次）(前端加校验：如果合同为已完成状态，不允许再增加回款记录，回款计划)")
	@PostMapping("/saveContractReturnMoneyPlan")
	public Result saveContractReturnMoneyPlan(@RequestBody @ApiParam(required=true) ContractModel model) {
		try{
			if(contractService.saveContractReturnMoneyPlan(model)){
				return Result.success("保存成功");
			}
			
			return Result.error("新增回款计划失败，请联系管理员");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("新增回款计划失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
	
	@ApiOperation(value = "修改回款计划期次（一次只允许修改一条，如果需要将加载出来的合同所有的期次批量修改，则所有的配套接口要调整，麻烦且不易于使用）")
	@ApiJsonObject(name = "updateContractReturnMoneyPlan", value = { 
			@ApiJsonProperty(name = ContractJson.contractId),
			@ApiJsonProperty(name = ContractJson.returnMoneyNum),
			@ApiJsonProperty(name = ContractJson.planReturnMoneyDate),
			@ApiJsonProperty(name = ContractJson.planReturnMoney),
			@ApiJsonProperty(name = ContractJson.remark)})
	@ApiImplicitParam(name = "params", required = true, dataType = "updateContractReturnMoneyPlan")
	@PostMapping("/updateContractReturnMoneyPlan")
	public Result updateContractReturnMoneyPlan(@RequestBody String params) {
		try{
			if(contractService.updateContractReturnMoneyPlan(params)){
				return Result.success("保存成功");
			}
			
			return Result.error("修改回款计划期次失败，请联系管理员");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("修改回款计划期次失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "获取当前合同回款期次的最大值，给前端点击 （期次+）号使用，此方式不可取，后端只能返回一个最大值，还得前端根据当前最大值，动态加1实现，")
	@ApiJsonObject(name = "getReturnMoneyNumMax", value = { 
			@ApiJsonProperty(name = ContractJson.contractId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getReturnMoneyNumMax")
	@PostMapping("/getReturnMoneyNumMax")
	public Result getReturnMoneyNumMax(@RequestBody String params) {
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String contractId = String.valueOf(jsonObject.get("contractId"));
			
			StringUtil.validateIsNull(contractId, "请选择合同");
			
			Integer maxValue = contractReturnMoneyPlanService.getReturnMoneyNumMax(contractId);
			
			if(maxValue!=null){
				return Result.success(maxValue+1);
			}
			
			return Result.error("获取当前合同回款期次失败");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取当前合同回款期次失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "新增回款记录(前端加校验：如果合同为已完成状态，不允许再增加回款记录，回款计划)")
	@ApiJsonObject(name = "saveContractReturnMoneyRecord", value = { 
			@ApiJsonProperty(name = CustomerJson.customerId),
			@ApiJsonProperty(name = ContractJson.contractId),
			@ApiJsonProperty(name = ContractJson.returnMoneyDate),
			@ApiJsonProperty(name = ContractJson.returnMoney),
			@ApiJsonProperty(name = ContractJson.returnMoneyNum),
			@ApiJsonProperty(name = ContractJson.payType),
			@ApiJsonProperty(name = ContractJson.returnMoneyType),
			@ApiJsonProperty(name = ContractJson.receiptUserId),
			@ApiJsonProperty(name = ContractJson.remark)})
	@ApiImplicitParam(name = "params", required = true, dataType = "saveContractReturnMoneyRecord")
	@PostMapping("/saveContractReturnMoneyRecord")
	public Result saveContractReturnMoneyRecord(@RequestBody String params) {
		try{
			if(contractService.saveContractReturnMoneyRecord(params)){
				return Result.success("保存成功");
			}
			
			return Result.error("新增回款记录失败，请联系管理员");
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("新增回款记录失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "获取收款人用户列表（返回整个公司的所有在职员工,包含普通管理员，普通用户，不包含超级管理员和代理商用户及其他类型的用户），前端默认显示为当前登录的用户，当点击下拉才调此接口(带分页)",notes = "姓名参数为非必填参数")
	@ApiJsonObject(name = "getReceiptUserList", value = { 
			@ApiJsonProperty(name = UserJson.userName),
			@ApiJsonProperty(name = GlobalJson.pageNum),
			@ApiJsonProperty(name = GlobalJson.pageSize)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getReceiptUserList")
	@PostMapping("/getReceiptUserList")
	public Result getReceiptUserList(@RequestBody String params) {
		try{
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String pageNum = String.valueOf(jsonObject.get("pageNum"));
			String pageSize = String.valueOf(jsonObject.get("pageSize"));
			String userName = String.valueOf(jsonObject.get("userName"));//
			
			StringUtil.validateIsNull(pageNum, "请输入页码");
			StringUtil.validateIsNull(pageSize, "请输入每页记录数");
			
            
            Map<Object, Object> paramMap = new HashMap<Object, Object>();
            paramMap.put("startRow", PageUtil.getStartRow(pageNum, pageSize));
            paramMap.put("pageSize", Integer.parseInt(pageSize));
    		
            paramMap.put("userName", userName);
            
            List<LinkedHashMap<Object, Object>> list = userService.getReceiptUserList(paramMap);
            if(list!=null && list.size()>0){
				Long total = userService.getReceiptUserListCount(paramMap);
				
				IPage page  = new Page();
				page.setTotal(total.longValue());
				page.setSize(Long.parseLong(pageSize));
				page.setRecords(list);
				return Result.success(page);
			}
            return Result.error("当前无用户列表数据");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取收款人列表失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "获取合同的计划期次列表（新建回款计划的时候需要调用）")
	@ApiJsonObject(name = "getReturnMoneyNumList", value = { 
			@ApiJsonProperty(name = CustomerJson.customerId),
			@ApiJsonProperty(name = ContractJson.contractId)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getReturnMoneyNumList")
	@PostMapping("/getReturnMoneyNumList")
	public Result getReturnMoneyNumList(@RequestBody String params) {
		try{
			System.out.println("params参数为：" + params);
			
			JSONObject jsonObject = JSON.parseObject(params);
			String customerId = String.valueOf(jsonObject.get("customerId"));//客户ID
			String contractId = String.valueOf(jsonObject.get("contractId"));//合同ID
			
			StringUtil.validateIsNull(customerId, "请输入客户ID");
			StringUtil.validateIsNull(contractId, "请输入合同ID");
			
            
            Map<Object, Object> paramMap = new HashMap<Object, Object>();
            paramMap.put("customerId", customerId);
            paramMap.put("contractId", contractId);
            
            List<LinkedHashMap<Object, Object>> list = contractService.getReturnMoneyNumList(paramMap);
            if(list!=null && list.size()>0){
				return Result.success(list);
			}
            return Result.error("当前合同无期次数据");
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取合同期次列表失败，失败原因：" + e.getMessage());
		}
	}
}
