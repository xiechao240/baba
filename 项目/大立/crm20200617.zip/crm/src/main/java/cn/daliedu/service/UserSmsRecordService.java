package cn.daliedu.service;

import cn.daliedu.entity.UserSmsRecordEntity;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户短信发送记录表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-12-26
 */
public interface UserSmsRecordService extends IService<UserSmsRecordEntity> {
	/**
	 * 获取用户今天发送的短信数量
	 * @param userId
	 * @return
	 */
	public Integer getUserSmsCount(String userId);
}
