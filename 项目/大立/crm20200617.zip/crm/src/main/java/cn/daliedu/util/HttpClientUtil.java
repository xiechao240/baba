package cn.daliedu.util;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.FileEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.params.HttpParams;
import org.springframework.web.multipart.MultipartFile;

import cn.daliedu.config.param.SysParamConfig;
import net.sf.json.JSONObject;

public class HttpClientUtil {
	
	/**
	 * 客户录音文件或其他文件上传
	 * @param file
	 * @param customerId
	 * @return 文件服务器返回文件的全路径
	 * @throws Exception
	 */
	public static String uploadCustomerFile(MultipartFile file, String customerId) throws Exception{
		String filePath = "";
		HttpPost httpPost = new HttpPost(SysParamConfig.UPLOAD_FILE_URL);
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.setCharset(java.nio.charset.Charset.forName("UTF-8"));
		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
		//	文件传输http请求头(multipart/form-data)
		builder.addBinaryBody("file", file.getInputStream(), ContentType.MULTIPART_FORM_DATA,
				file.getOriginalFilename());// 文件流
		//	字节传输http请求头(application/json)
		ContentType contentType = ContentType.create("application/json", Charset.forName("UTF-8"));
		builder.addTextBody("path", SysParamConfig.UPLOAD_FILE_PATH  + customerId, contentType);//字节流

		HttpEntity httpEntity = builder.build();
		httpPost.setEntity(httpEntity);
		HttpResponse response = HttpClients.createDefault().execute(httpPost);
		HttpEntity responseEntity = response.getEntity();
		if (responseEntity != null) {
			// 返参
			InputStream instream = responseEntity.getContent();
			// 转换为String
			String str = IOUtils.toString(new InputStreamReader(instream));
			// 因为本实例发送的json格式需要进行解析
			JSONObject obj = JSONObject.fromObject(str);
			JSONObject data = obj.getJSONObject("data");
			filePath = data.get("fullPath").toString();
			IOUtils.closeQuietly(instream);
			// System.out.println(new String(str.getBytes("utf-8")));
		}
		return filePath;
	}

	public static String postJson(String path, String post) {
		URL url = null;
		try {
			url = new URL(path);
			HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
			httpURLConnection.setRequestMethod("POST");// 提交模式
			// conn.setConnectTimeout(10000);//连接超时 单位毫秒
			// conn.setReadTimeout(2000);//读取超时 单位毫秒
			// 发送POST请求必须设置如下两行
			httpURLConnection.setDoOutput(true);
			httpURLConnection.setDoInput(true);
			httpURLConnection.addRequestProperty("Content-Type", "application/json");
			if (post != null && post.trim().length() > 0) {
				// 获取URLConnection对象对应的输出流
				DataOutputStream printWriter = new DataOutputStream(httpURLConnection.getOutputStream());
				// 发送请求参数
				printWriter.write(post.getBytes("utf-8"));// post的参数 xx=xx&yy=yy
				// flush输出流的缓冲
				printWriter.flush();
			}

			// 开始获取数据
			BufferedInputStream bis = new BufferedInputStream(httpURLConnection.getInputStream());
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			int len;
			byte[] arr = new byte[1024];
			while ((len = bis.read(arr)) != -1) {
				bos.write(arr, 0, len);
				bos.flush();
			}
			bos.close();
			return bos.toString("utf-8");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String post(String path, String post) {
		URL url = null;
		try {
			url = new URL(path);
			HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
			httpURLConnection.setRequestMethod("POST");// 提交模式
			// conn.setConnectTimeout(10000);//连接超时 单位毫秒
			// conn.setReadTimeout(2000);//读取超时 单位毫秒
			// 发送POST请求必须设置如下两行
			httpURLConnection.setDoOutput(true);
			httpURLConnection.setDoInput(true);
			if (post != null && post.trim().length() > 0) {
				// 获取URLConnection对象对应的输出流
				DataOutputStream printWriter = new DataOutputStream(httpURLConnection.getOutputStream());
				// 发送请求参数
				printWriter.write(post.getBytes("utf-8"));// post的参数 xx=xx&yy=yy
				// flush输出流的缓冲
				printWriter.flush();
			}

			// 开始获取数据
			BufferedInputStream bis = new BufferedInputStream(httpURLConnection.getInputStream());
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			int len;
			byte[] arr = new byte[1024];
			while ((len = bis.read(arr)) != -1) {
				bos.write(arr, 0, len);
				bos.flush();
			}
			bos.close();
			return bos.toString("utf-8");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String postDownloadJson(String path, String post, String contentType) {
		URL url = null;
		try {
			url = new URL(path);
			HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
			httpURLConnection.setRequestMethod("POST");// 提交模式
			httpURLConnection.addRequestProperty("Content-Type", contentType);
			// conn.setConnectTimeout(10000);//连接超时 单位毫秒
			// conn.setReadTimeout(2000);//读取超时 单位毫秒
			// 发送POST请求必须设置如下两行
			httpURLConnection.setDoOutput(true);
			httpURLConnection.setDoInput(true);
			httpURLConnection.addRequestProperty("Content-Type", "application/json; charset=utf-8");
			// 获取URLConnection对象对应的输出流
			DataOutputStream printWriter = new DataOutputStream(httpURLConnection.getOutputStream());
			// 发送请求参数
			printWriter.write(post.getBytes("utf-8"));// post的参数 xx=xx&yy=yy
			// flush输出流的缓冲
			printWriter.flush();
			// 开始获取数据
			BufferedInputStream bis = new BufferedInputStream(httpURLConnection.getInputStream());
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			int len;
			byte[] arr = new byte[1024];
			while ((len = bis.read(arr)) != -1) {
				bos.write(arr, 0, len);
				bos.flush();
			}
			bos.close();
			return bos.toString("utf-8");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void main(String[] args) {
		try {
			// 创建HttpClient 请求
			CloseableHttpClient httpClient = HttpClients.createDefault();
			String url = "http://fservice.daliedu.cn/upload/uploadFile";
			// 创建 HttpPost
			HttpPost httpPost = new HttpPost(url);
			File file = new File("E:/CRM系统.pptx");
			System.out.println(file.exists());
			System.out.println(file.isFile());

			// 创建上传文件的表单
			MultipartEntityBuilder entityBuilder = MultipartEntityBuilder.create();
			entityBuilder.addTextBody("path", "/daliedu/crm/call");// 添加普通参数
			entityBuilder.addPart("file", new FileBody(file));// 添加上传的文件
			HttpEntity httpEntity = entityBuilder.build();
			httpPost.setEntity(httpEntity);
			// 执行post 请求
			CloseableHttpResponse response = httpClient.execute(httpPost);
			HttpEntity entity = response.getEntity();
			if (entity != null) {
				// 返参
				InputStream instream = entity.getContent();
				// 转换为String
				String str = IOUtils.toString(new InputStreamReader(instream));
				// 因为本实例发送的json格式需要进行解析
				JSONObject obj = JSONObject.fromObject(str);
				JSONObject data = obj.getJSONObject("data");
				System.out.println("全路径：" + data.get("fullPath"));;
				System.out.println(obj);
				IOUtils.closeQuietly(instream);
				// System.out.println(new String(str.getBytes("utf-8")));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
//		try {
//			String filePath = "";
//			String servletPath = "";
//			// 本地影像地址
//			filePath = "d:/img/000000000163887-2.jpg";
//			// 连接服务端地址参数直接在地址后加上
//			servletPath = "http://fservice.daliedu.cn/upload/uploadFile";
//			
//			
//
//			File file = new File(filePath);
//			FileEntity fileEntity = new FileEntity(file, "text/plain;charset=gbk");
//			HttpPost httpPost = new HttpPost(servletPath);
//			httpPost.setHeader("Content-Type", "text/xml;charset=gbk");
//			httpPost.setEntity(fileEntity); // set影像
////			httpPost.setParams(params);
//			System.out.println(httpPost);
//
//			HttpClient httpclient = new DefaultHttpClient();
//			// 发送请求
//			HttpResponse response = httpclient.execute(httpPost);
//			HttpEntity entity = response.getEntity();
//
//			if (entity != null) {
//				// 返参
//				InputStream instream = entity.getContent();
//				// 转换为String
//				String str = IOUtils.toString(new InputStreamReader(instream));
//				// 因为本实例发送的json格式需要进行解析
//				JSONObject obj = JSONObject.fromObject(str);
//				System.out.println(obj.get("imageKey"));
//				System.out.println(obj.get("flag"));
//				System.out.println(obj.get("detail"));
//				IOUtils.closeQuietly(instream);
//				// System.out.println(new String(str.getBytes("utf-8")));
//			}
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
	}
}
