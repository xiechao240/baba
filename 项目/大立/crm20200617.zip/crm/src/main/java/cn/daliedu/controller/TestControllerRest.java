package cn.daliedu.controller;

import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;

import cn.daliedu.entity.UserEntity;
import cn.daliedu.util.MD5Util;
import cn.daliedu.util.Result;

@RestController
@RequestMapping("/test")
public class TestControllerRest {
	
	/**
	 * 测试增加用户
	 * @param loginName
	 * @param pwd
	 * @param userType
	 * @param response
	 */
	@RequestMapping("/addUser")
//	public String addUser(HttpServletRequest request) {
	public Result addUser(HttpServletRequest request, ModelMap map) {
		try {
			UserEntity user = new UserEntity();
//			user.setLoginName("xiechao");
			user.setPassword(MD5Util.encrypt("aa123456"));
//			user.setAvailable(true);
//			user.setLocked(false);
//			user.setAvailable("1");
//			user.setLocked("0");
			
			boolean flag = user.insert();
			if(flag){
				return Result.success("添加成功");
			}
			return Result.error("添加用户失败");
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("添加用户失败");
		}
	}
	
	/**
	 * 测试删除用户
	 * @param loginName
	 * @param pwd
	 * @param userType
	 * @param response
	 */
	@RequestMapping("/deleteUser")
//	public String deleteUser(HttpServletRequest request) {
	public Result deleteUser(HttpServletRequest request, ModelMap map) {
		try {
			UserEntity user = new UserEntity();
			boolean flag = user.deleteById(1);
			if(flag){
				return Result.success("删除成功");
			}
			return Result.error("删除失败");
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("删除失败");
		}
	}
	
	
	/**
	 * 测试删除用户
	 * @param loginName
	 * @param pwd
	 * @param userType
	 * @param response
	 */
	@RequestMapping("/getUser")
//	public String getUser(HttpServletRequest request) {
	public Result getUser(HttpServletRequest request, ModelMap map) {
		try {
			UserEntity user = new UserEntity();
			user = user.selectOne(new QueryWrapper<UserEntity>().eq("account", "xiechao").last("limit 1"));
			
			if(user!=null){
				return Result.success(user);
			}
			return Result.error("查找用户失败");
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("查找用户失败");
		}
	}
	
}


