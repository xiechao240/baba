package cn.daliedu.config.filter;


import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
/**
 * 此类目前已经废掉，在MylocalConfig类中CORSConfigurer()一个方法就搞定了
 * CORSConfigurer()这种一个方法还是有问题，必需使用CorsFilter这种方式，因为可以自定义response的各种头，上面那种自定义不了，
 * 因为现在是签友汇，及渠道版本共用一个后台，而渠道版本使用了自定义的Cookies,所以必需要使用Filter这种方式
 * @author xiechao
 * @time 2019年3月29日 下午3:35:47
 * @version 1.0.0 
 * @description
 */
public class CorsFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }
    
    
    //如果要用，就用下面这个
	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain)
			throws IOException, ServletException {
		HttpServletResponse response = (HttpServletResponse) servletResponse;
		HttpServletRequest request = (HttpServletRequest) servletRequest;

		//千万不能设置为*，经过调试，打印出来的值为：  获取到origin的值：http://192.168.1.102   
    	//一个 http://192.168.1.102 的请求，跟你一个*去匹配，肯定是不对啊
    	//Access-Control-Allow-Origin：指定允许其他域名访问 :http://172.20.0.206'//一般用法（*，指定域，动态设置），3是因为*不允许携带认证头和cookies
		
		String origin = request.getHeader("Origin");//注意这个地方不是*了
		response.setHeader("Access-Control-Allow-Origin", origin);
		response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
		response.setHeader("Access-Control-Max-Age", "3600");
		response.setHeader("Access-Control-Allow-Headers", "Cookies, Origin, Accept, X-Requested-With, x-auth-token, client_id, uuid, Authorization, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers");
		response.setHeader("Access-Control-Allow-Credentials", "true");
		chain.doFilter(servletRequest, servletResponse);
	}
    

//    @Override
//    public void doFilter(ServletRequest request, ServletResponse response,
//                         FilterChain chain) throws IOException, ServletException {
//        HttpServletResponse httpServletResponse = (HttpServletResponse) response;
//        httpServletResponse.setHeader("Access-Control-Allow-Origin", "*");
//        httpServletResponse.setHeader("Access-Control-Allow-Credentials", "true");//是否允许发送Cookie
//        httpServletResponse.setHeader("Access-Control-Allow-Methods", "POST, GET, HEAD, OPTIONS, DELETE");
//        httpServletResponse.setHeader("Access-Control-Max-Age", "3600");
//          //对客户端自定义请求头的应答
//        httpServletResponse.setHeader("Access-Control-Allow-Headers", "Cookies, Origin, Accept, X-Requested-With, x-auth-token, client_id, uuid, Authorization, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers");
//        chain.doFilter(request, response);
//    }
    
//    public void doFilter(ServletRequest request, ServletResponse resp, FilterChain chain) throws IOException, ServletException  
//    {  
//    HttpServletResponse response = (HttpServletResponse) resp; 
      //response.setHeader("Access-Control-Allow-Origin", "*"); //解决跨域访问报错   
//    response.setHeader("Access-Control-Allow-Methods", "POST, PUT, GET, OPTIONS, DELETE");   
//    response.setHeader("Access-Control-Max-Age", "3600"); //设置过期时间   
//    response.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, client_id, uuid, Authorization");   
//    response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // 支持HTTP 1.1.   
//    response.setHeader("Pragma", "no-cache"); // 支持HTTP 1.0. response.setHeader("Expires", "0");   
//    chain.doFilter(request, resp);   
//    }


    @Override
    public void destroy() {
    }

}
