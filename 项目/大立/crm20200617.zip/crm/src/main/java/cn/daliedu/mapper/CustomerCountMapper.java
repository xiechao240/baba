package cn.daliedu.mapper;

import cn.daliedu.entity.CustomerCountEntity;

import java.util.Map;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 每天统计分校的客户总数与用户的客户总数 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-12-06
 */
public interface CustomerCountMapper extends BaseMapper<CustomerCountEntity> {
	
	/**
	 * 【客户数量统计报表】获取客户数量
	 * @param map
	 * @return
	 */
	public Integer getCustomerCountByScheduled(Map<Object, Object> map);
}
