package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 用户客户通话表
 * </p>
 *
 * @author xiechao
 * @since 2019-11-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_user_customer_call")
public class UserCustomerCallEntity extends Model<UserCustomerCallEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;

    /**
     * 用户ID
     */
    private String userId;

    /**
     * 客户ID
     */
    private String customerId;
    
    /**
     * 呼出方式（1：座机，2：手机）
     */
    private String callType;

    /**
     * 呼叫号码
     */
    private String callNumber;

    /**
     * 应答状态（0：呼出，对方未振铃，可能是空号  1：呼出，对方未接听  2：接通  3：呼入，未接来电）
     */
    private String callState;

    /**
     * 开始时间
     */
    private LocalDateTime startTime;

    /**
     * 接听时间
     */
    private LocalDateTime answerTime;

    /**
     * 结束时间
     */
    private LocalDateTime endTime;

    /**
     * 通话时长（时）
     */
    private Integer callHour;

    /**
     * 通话时长（分）
     */
    private Integer callMin;

    /**
     * 通话时长（秒）
     */
    private Integer callSec;

    /**
     * 通话时长（总秒数）
     */
    private Integer callTime;

    /**
     * 录音文件路径
     */
    private String recordingFilePath;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
