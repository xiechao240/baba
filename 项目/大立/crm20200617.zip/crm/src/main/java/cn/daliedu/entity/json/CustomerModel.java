package cn.daliedu.entity.json;

import org.springframework.web.multipart.MultipartFile;

import cn.daliedu.entity.CustomerSelfDefineItemConfigEntity;
import cn.daliedu.entity.CustomerTagEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * swagger注释属性：添加客户模型json
 * </p>
 *
 * @author xiechao
 * @since 2019-05-06
 */
@ApiModel(value="客户资料",description="客户资料所有属性")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class CustomerModel{
	
	/**
	 * 分校ID，当超级管理员，区域管理员，代理商用户，新增客户时，此属性为必填
	 */
	@ApiModelProperty(value="分校ID，当超级管理员，区域管理员，代理商用户，新增客户时，此属性为必填")
	private String branchOrgId;
	
//	/**
//	 * 客户标签集合,修改客户资料时，此属性可不填
//	 */
//	@ApiModelProperty(value="客户标签集合,修改客户资料时，此属性可不填")
//	private CustomerTagEntity[] customerTagList;
	
	/**
	 * 客户ID，新增客户时，此属性可不填，修改客户时此属性必填
	 */
	@ApiModelProperty(value="客户ID，新增客户此，此属性可不填，修改客户时此属性必填")
	private String id;
	
	/**
	 * 客户姓名
	 */
	@ApiModelProperty(value="客户姓名")
	private String customerName;
	
	/**
	 * 性别，1：男，2：女，3：未知
	 */
	@ApiModelProperty(value="性别，1：男，2：女，3：未知")
	private String sex;
	
	/**
	 * 客户来源类型（见数据字典sys_dict表customer_source_type的定义，0：非代理商，1：代理商）
	 */
	@ApiModelProperty(value="客户来源类型（见数据字典sys_dict表customer_source_type的定义，0：非代理商，1：代理商）")
	private String customerSourceType;
	
	
	/**
	 * 客户来源名称对应的值（见数据字典sys_dict表customer_source_name的定义）
	 */
	@ApiModelProperty(value="客户来源名称对应的值（见数据字典sys_dict表customer_source_name的定义）")
	private String customerSourceNameValue;
	
	/**
	 * 客户分组类型（见数据字典sys_dict表customer_group的定义，1：一般客户，2：意向客户，3：已成交客户，4：无意向客户，5：拉黑客户，6：其他）
	 */
	@ApiModelProperty(value="客户分组类型（见数据字典sys_dict表customer_group的定义，1：一般客户，2：意向客户，3：已成交客户，4：无意向客户，5：拉黑客户，6：其他）")
	private String customerGroupTypeId;
	
	/**
     * 客户质量，1：优质，2：一般
     */
	@ApiModelProperty(value="客户分组类型（见数据字典sys_dict表customer_quality的定义，1：优质，2：一般）")
    private String customerQuality;
	
	/**
     * 客户意向程度（见数据字典sys_dict表customer_intention_level的定义）
     */
	@ApiModelProperty(value="客户意向程度（见数据字典sys_dict表customer_intention_level的定义）")
    private String customerIntentionLevel;
    
    /**
     * 客户意向内容（见数据字典sys_dict表customer_intention_content的定义）
     */
	@ApiModelProperty(value="客户意向内容（见数据字典sys_dict表customer_intention_content的定义）")
    private String customerIntentionContent;
	
	/**
     * 推广人（用于记录公司内部推广部的人提供的号码，由内部别的部门人员导入系统进行跟进）
     */
	@ApiModelProperty(value="推广人（用于记录公司内部推广部的人提供的号码，由内部别的部门人员导入系统进行跟进）")
    private String promotionUserId;
	
	/**
	 * 微信号
	 */
	@ApiModelProperty(value="微信号")
	private String weixinId;
	
	
	/**
	 * qq号
	 */
	@ApiModelProperty(value="qq号")
	private String qq;
	
	/**
	 * 手机
	 */
	@ApiModelProperty(value="手机")
	private String mobile;
	
	/**
	 * 座机
	 */
	@ApiModelProperty(value="座机")
	private String phone;
	
	/**
	 * 邮箱
	 */
	@ApiModelProperty(value="邮箱")
	private String email;
	
	/**
	 * 地区(省)ID
	 */
	@ApiModelProperty(value="地区(省)ID")
	private String provinceId;
	
	/**
	 * 地区(省)名称
	 */
	@ApiModelProperty(value="地区(省)名称")
	private String provinceName;
	
	
	/**
	 * 地区(市)ID
	 */
	@ApiModelProperty(value="地区(市)ID")
	private String cityId;
	
	/**
	 * 地区(市)名称
	 */
	@ApiModelProperty(value="地区(市)名称")
	private String cityName;
	
	/**
	 * 地区(区)ID
	 */
	@ApiModelProperty(value="地区(区)ID")
	private String areaId;
	
	/**
	 * 地区(区)名称
	 */
	@ApiModelProperty(value="地区(区)名称")
	private String areaName;
	
	/**
	 * 公司名称
	 */
	@ApiModelProperty(value="公司名称")
	private String companyName;
	
	/**
	 * 地址
	 */
	@ApiModelProperty(value="地址")
	private String address;
	
	/**
	 * 备注
	 */
	@ApiModelProperty(value="备注")
	private String remark;
	
	/**
	 * 工作年限
	 */
	@ApiModelProperty(value="工作年限")
	private String jobAge;
	
	/**
	 * 学历
	 */
	@ApiModelProperty(value="学历")
	private String education;
	
	/**
	 * 专业
	 */
	@ApiModelProperty(value="专业")
	private String professional;
	
	/**
	 * 客户活动表单页面网址
	 */
	@ApiModelProperty(value="客户活动表单页面网址")
	private String customerActivityPage;
	
	/**
	 * 客户活动页面分类
	 */
	@ApiModelProperty(value="客户活动页面分类")
	private String customerActivityTypePage;
	
	//下面为自定义信息
	@ApiModelProperty(value="自定义数据集合")
	private CustomerSelfDefineItemConfigEntity[] selfDefineItemConfigList;
	
//	@ApiModelProperty(value="客户头像文件")
//	private  MultipartFile photoFile;
	
//	/**
//	 * 单班数据集合
//	 */
//	@ApiModelProperty(value="单班数据集合")
//	private CustomerSelfDefineItemEntity[] danbanList;
//	
//	/**
//	 * 套班数据集合
//	 */
//	@ApiModelProperty(value="套班数据集合")
//	private CustomerSelfDefineItemEntity[] taobanList;
//	
//	/**
//	 * 内训数据集合
//	 */
//	@ApiModelProperty(value="内训数据集合")
//	private CustomerSelfDefineItemEntity[] neixunList;
//	
//	/**
//	 * 一建科目
//	 */
//	@ApiModelProperty(value="一建科目")
//	private CustomerSelfDefineItemEntity[] yijiankemuList;
//	
//	/**
//	 * 二建科目
//	 */
//	@ApiModelProperty(value="二建科目")
//	private CustomerSelfDefineItemEntity[] erjiankemuList;
//	
//	/**
//	 * 造价科目
//	 */
//	@ApiModelProperty(value="造价科目")
//	private CustomerSelfDefineItemEntity[] zaojiakemuList;
//	
//	/**
//	 * 监理科目
//	 */
//	@ApiModelProperty(value="监理科目")
//	private CustomerSelfDefineItemEntity[] jianlikemuList;
//	
//	/**
//	 * 消防科目
//	 */
//	@ApiModelProperty(value="消防科目")
//	private CustomerSelfDefineItemEntity[] xiaofangkemuList;
//	
//	/**
//	 * 咨询工程师
//	 */
//	@ApiModelProperty(value="咨询工程师")
//	private CustomerSelfDefineItemEntity[] zixungongchengshiList;
//	
//	/**
//	 * 已报同行
//	 */
//	@ApiModelProperty(value="已报同行")
//	private CustomerSelfDefineItemEntity yibaotonghang;
	
	/**
	 * 备注2
	 */
	@ApiModelProperty(value="备注2")
	private String remark2;
	
//	/**
//	 * 一建科目2
//	 */
//	@ApiModelProperty(value="一建科目2")
//	private String yijiankemu2;
//	
//	/**
//	 * 班级名称2
//	 */
//	@ApiModelProperty(value="班级名称2")
//	private String banjimingcheng2;
	
	
	
}
