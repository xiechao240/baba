package cn.daliedu.mapper;

import cn.daliedu.entity.DictManyDetailEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 数据字典（二维数据字典明细） Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-11-07
 */
public interface DictManyDetailMapper extends BaseMapper<DictManyDetailEntity> {

}
