package cn.daliedu.service;

import cn.daliedu.entity.UserOrgEntity;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户组织表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-23
 */
public interface UserOrgService extends IService<UserOrgEntity> {

}
