package cn.daliedu.util;



import org.apache.commons.lang3.LocaleUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;

import cn.daliedu.config.param.SysParamConfig;

import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * @Auther: Administrator
 * @Date: 2018/8/3 09:47
 * @Description: 国际化获取数据
 */
public class MessageUtil {
	
	private static Logger logger = LoggerFactory.getLogger(MessageUtil.class);
	
	// 国际化配置文件路径
	private static final String I18N_MESSAGES = "/i18n/messages";

	private static ReloadableResourceBundleMessageSource messageSource;

	@SuppressWarnings("unused")
	private static MessageSource getMessageSource() {
		if (null == messageSource) {
			messageSource = new ReloadableResourceBundleMessageSource();
			messageSource.setCacheSeconds(-1);// 不失效
			messageSource.setBasenames(I18N_MESSAGES);
			messageSource.setDefaultEncoding(StandardCharsets.UTF_8.name());
		}

		return messageSource;
	}

	public static String getMessage(String code) {
		return getMessage(code, null);
	}

	public static String getMessage(String code, Object[] params) {
		// Locale locale = LocaleContextHolder.getLocale();
		Locale locale = LocaleUtils.toLocale(SysParamConfig.LANGUAGE_ZH_CN);
		String result = getMessageSource().getMessage(code, params, locale);
		return result;
	}
	
//	/**
//	 * 国际化
//	 * 注：通过@Autowired private MessageSource messageSource无法获取
//	 *   下面的写法，性能明显不够好，每次调用都去读取i18n文件，上面的改为的类的静态块方法，则比较优秀
//	 * @param result
//	 * @return
//	 */
//	public static String getMessage(String result, Object[] params) {
//	    ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
//	    messageSource.setCacheSeconds(-1);
//	    messageSource.setDefaultEncoding(StandardCharsets.UTF_8.name());
//	    messageSource.setBasenames("/i18n/messages");
//
//	    String message = "";
//	    try {
//	        Locale locale = LocaleContextHolder.getLocale();
//	        message = messageSource.getMessage(result, params, locale);
//	    } catch (Exception e) {
//	    	logger.error("parse message error! ", e);
//	    }
//	    return message;
//	}
}
