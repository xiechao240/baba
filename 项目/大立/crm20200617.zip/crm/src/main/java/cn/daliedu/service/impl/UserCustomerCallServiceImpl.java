package cn.daliedu.service.impl;

import cn.daliedu.config.param.SysParamConfig;
import cn.daliedu.entity.CustomerDynamicFileEntity;
import cn.daliedu.entity.CustomerDynamicLogEntity;
import cn.daliedu.entity.UserCustomerCallEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.enums.CallStateEnum;
import cn.daliedu.enums.DynamicTypeEnum;
import cn.daliedu.enums.ResultCodeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.mapper.CustomerDynamicFileMapper;
import cn.daliedu.mapper.CustomerDynamicLogMapper;
import cn.daliedu.mapper.UserCustomerCallMapper;
import cn.daliedu.service.UserCustomerCallService;
import cn.daliedu.util.DateUtil;
import cn.daliedu.util.FileUtil;
import cn.daliedu.util.HttpClientUtil;
import cn.daliedu.util.LocalDateTimeUtil;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import cn.daliedu.util.TimerUtil;
import io.swagger.annotations.ApiOperation;
import net.sf.json.JSONObject;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.UnauthorizedException;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * 用户客户通话表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-11-23
 */
@Service
public class UserCustomerCallServiceImpl extends ServiceImpl<UserCustomerCallMapper, UserCustomerCallEntity> implements UserCustomerCallService {
	
	@Resource
	UserCustomerCallMapper userCustomerCallMapper;
	
	@Resource
	CustomerDynamicLogMapper customerDynamicLogMapper;
	
	@Resource
	CustomerDynamicFileMapper customerDynamicFileMapper;
	

	@Override
	public List<LinkedHashMap<Object, Object>> getCallContactRecordList(Map<Object, Object> map) throws Exception {
		return userCustomerCallMapper.getCallContactRecordList(map);
	}

	@Override
	public Long getCallContactRecordListCount(Map<Object, Object> map) {
		return userCustomerCallMapper.getCallContactRecordListCount(map);
	}
	
	
	
	@Override
	public void saveCallRecordingFile(String userCustomerCallId, MultipartFile file) throws Exception {
		UserCustomerCallEntity entity = userCustomerCallMapper.selectById(userCustomerCallId);
		if(entity!=null){
			String recordingFilePath = HttpClientUtil.uploadCustomerFile(file, entity.getCustomerId());
			entity.setRecordingFilePath(recordingFilePath);
			
			userCustomerCallMapper.updateById(entity);
			
			//更新客户动态记录，用于前端播放录音文件？？？？？？？？？？？？？？
			//？？？？？ 
			
		}else{
			throw new BusinessException("通话记录ID不存在，请确保上传录音文件的正确性！");
		}
	}

	@Override
	public String saveCallRecord(String params) throws Exception {
		//1.保存通话记录
		//2.保存客户动态记录
		Object object = SecurityUtils.getSubject().getPrincipal();
		if (object instanceof UserEntity) {
			UserEntity user = (UserEntity) object;
			
			JSONObject jsonObject = JSONObject.fromObject(params);
			String customerId = String.valueOf(jsonObject.get("customerId"));
			String callType = String.valueOf(jsonObject.get("callType"));
			String startTime = String.valueOf(jsonObject.get("startTime"));
			String endTime = String.valueOf(jsonObject.get("endTime"));
			String answerTime = String.valueOf(jsonObject.get("answerTime"));
			String callNumber = String.valueOf(jsonObject.get("callNumber"));
			String callState = String.valueOf(jsonObject.get("callState"));//0： 呼出，对方未振铃，可能是空号  1： 呼出，对方未接听   2：接通   3： 呼入，未接来电
			
			StringUtil.validateIsNull(customerId, "请选择客户ID");
			StringUtil.validateIsNull(callType, "请选择呼出类型");
			StringUtil.validateIsNull(startTime, "请输入开始时间");
			StringUtil.validateIsNull(endTime, "请输入结束时间");
//			StringUtil.validateIsNull(answerTime, "请输入接听时间");
			StringUtil.validateIsNull(callNumber, "请输入呼出号码");
			StringUtil.validateIsNull(callState, "请输入应答状态");
			
			UserCustomerCallEntity entity = new UserCustomerCallEntity();
			entity.setCustomerId(customerId);
			entity.setUserId(user.getId());
			entity.setCallType(callType);
			entity.setStartTime(LocalDateTimeUtil.getLocalDateTime(startTime));
			entity.setEndTime(LocalDateTimeUtil.getLocalDateTime(endTime));
			if(answerTime!=null && !answerTime.equals("") && !answerTime.equals("null")){
				entity.setAnswerTime(LocalDateTimeUtil.getLocalDateTime(answerTime));
			}
			entity.setCallNumber(callNumber);
			entity.setCallState(callState);
			//如果是正常状态，则answerTime肯定是有值的
			Integer callTime = 0;
			if(callState.equals(CallStateEnum.TYPE_2.getValue())){
				callTime = DateUtil.getDateSecTotal(answerTime, endTime).intValue();
			}
			entity.setCallTime(callTime);//有效接听时间为：结束时间-开始接听时间
			
			
			if(userCustomerCallMapper.insert(entity)>0){
				CustomerDynamicLogEntity dynamicLogEntity = new CustomerDynamicLogEntity();
				dynamicLogEntity.setCustomerId(customerId);
				dynamicLogEntity.setDynamicType(DynamicTypeEnum.TYPE_4.getValue());
				dynamicLogEntity.setDynamicName(DynamicTypeEnum.TYPE_4.getDesc());
				
				TimerUtil tt = new TimerUtil();
				tt.setSeconds(callTime);
				dynamicLogEntity.setDynamicContent("拨打电话：" + callNumber +"    通话时长："+ tt.getMinutes() + "分" + tt.getSeconds() + "秒");
				dynamicLogEntity.setDynamicUserId(user.getId());
				dynamicLogEntity.setCreateDate(LocalDateTime.now());
				dynamicLogEntity.setDynamicTypeSub(callState);
				
				customerDynamicLogMapper.insert(dynamicLogEntity);
				
				return entity.getId();
			}
		}
		return "";
	}

	@Override
	public boolean saveCallRecordAndRecording(String userId, String customerId, String callType, String callNumber, String callState,
			String startTime, String endTime, String answerTime, MultipartFile file) throws Exception {
		//1.保存通话记录
		//2.保存客户动态记录
		StringUtil.validateIsNull(userId, "请输入用户ID");
		StringUtil.validateIsNull(customerId, "请选择客户ID");
		StringUtil.validateIsNull(callType, "请输入开始时间");
		StringUtil.validateIsNull(startTime, "请输入开始时间");
		StringUtil.validateIsNull(endTime, "请输入结束时间");
		StringUtil.validateIsNull(answerTime, "请输入接听时间");
		StringUtil.validateIsNull(callNumber, "请输入呼出号码");
		StringUtil.validateIsNull(callState, "请输入应答状态");//0： 呼出，对方未振铃，可能是空号  1： 呼出，对方未接听   2：接通   3： 呼入，未接来电
		
		//1.验证输入的用户ID是否存在，2.验证用户ID是否是登录状态，防止攻击
		//?????
		
		UserCustomerCallEntity entity = new UserCustomerCallEntity();
		entity.setCustomerId(customerId);
		entity.setUserId(userId);
		entity.setCallType(callType);
		entity.setStartTime(LocalDateTimeUtil.getLocalDateTime(startTime));
		entity.setEndTime(LocalDateTimeUtil.getLocalDateTime(endTime));
		entity.setAnswerTime(LocalDateTimeUtil.getLocalDateTime(answerTime));
		entity.setCallNumber(callNumber);
		entity.setCallState(callState);
		Integer callTime = 0;
		if(callState.equals(CallStateEnum.TYPE_2.getValue())){
			callTime = DateUtil.getDateSecTotal(answerTime, endTime).intValue();
		}
		entity.setCallTime(callTime);//有效接听时间为：结束时间-开始接听时间
		
		//上传录音文件
//		String path = request.getSession().getServletContext().getRealPath("");
//		String filePath = "";
//		String recordingFilePath = "";
//		if(SysParamConfig.UPLOAD_TYPE.equals("local")){
//			filePath = path + SysParamConfig.UPLOAD_FILE_PATH + File.separatorChar + customerId + File.separatorChar + "record";
//			recordingFilePath = filePath +  File.separatorChar + file.getOriginalFilename();
//		}else{
//			filePath = SysParamConfig.UPLOAD_FILE_PATH + File.separatorChar + customerId + File.separatorChar + "record";
//			recordingFilePath = File.separatorChar + customerId + File.separatorChar + file.getOriginalFilename();
//		}
//		//		System.out.println("创建的上传路径为：" + filePath);
//		File folder = new File(filePath);
//		if(!folder.exists()){
//			folder.mkdirs();
//		}
//		File recordFile = new File(filePath +  File.separatorChar + file.getOriginalFilename());
//		// 上传文件(如果出错，无法将出错的文件删除，其实也不需要删除，自己不使用就可以了)
//		file.transferTo(recordFile);
		
		String recordingFilePath = HttpClientUtil.uploadCustomerFile(file, customerId);
		
//		if(!StringUtils.isBlank(recordingFilePath)){
			entity.setRecordingFilePath(recordingFilePath);
			
			userCustomerCallMapper.insert(entity);
			
			CustomerDynamicLogEntity dynamicLogEntity = new CustomerDynamicLogEntity();
			dynamicLogEntity.setCustomerId(customerId);
			dynamicLogEntity.setDynamicType(DynamicTypeEnum.TYPE_4.getValue());
			dynamicLogEntity.setDynamicName(DynamicTypeEnum.TYPE_4.getDesc());
			
			TimerUtil tt = new TimerUtil();
			tt.setSeconds(callTime);
			dynamicLogEntity.setDynamicContent("拨打电话：" + callNumber +"    通话时长："+ tt.getMinutes() + "分" + tt.getSeconds() + "秒");
			dynamicLogEntity.setDynamicUserId(userId);
			dynamicLogEntity.setCreateDate(LocalDateTime.now());
			dynamicLogEntity.setDynamicTypeSub(callState);
			
			customerDynamicLogMapper.insert(dynamicLogEntity);
			
			
			CustomerDynamicFileEntity dynamicFileEntity = new CustomerDynamicFileEntity();
			dynamicFileEntity.setCustomerDynamicId(entity.getId());
			dynamicFileEntity.setFileName(file.getOriginalFilename());
			dynamicFileEntity.setFilePath(recordingFilePath);
			customerDynamicFileMapper.insert(dynamicFileEntity);
			
			return true;
	}
	
	
	
	
	
}
