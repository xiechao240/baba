package cn.daliedu.enums;

/**
 * 账号类型枚举类
 * @author xiechao
 * @time 2019年1月9日 下午5:51:51
 * @version 1.0.0
 * @description 
 */
public enum AccountTypeEnum {
	/**
	 * 签友汇账号
	 */
	ACCOUNT_TYPE_1("1", "签友汇账号"), 
	/**
	 * 微信登录账号
	 */
	ACCOUNT_TYPE_2("2", "微信登录账号"),
	/**
	 * 一签通账号
	 */
	ACCOUNT_TYPE_3("3", "一签通账号");

	private String value;
	private String desc;

	AccountTypeEnum(final String value, final String desc) {
		this.value = value;
		this.desc = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}