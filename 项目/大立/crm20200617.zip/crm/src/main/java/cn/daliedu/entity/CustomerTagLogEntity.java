package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 用户打标签记录表
 * </p>
 *
 * @author xiechao
 * @since 2019-12-12
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_customer_tag_log")
public class CustomerTagLogEntity extends Model<CustomerTagLogEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;

    /**
     * 用户ID
     */
    private String userId;

    /**
     * 客户ID
     */
    private String customerId;

    /**
     * 客户标签分组类型ID，来源于客户标签分组表
     */
    private Integer customerTagTypeId;

    /**
     * 客户标签ID，来源于客户标签分组明细表
     */
    private Integer customerTagId;

    /**
     * 客户标签值，来源于客户标签分组明细表
     */
    private String customerTagValue;

    /**
     * 创建时间
     */
    private LocalDateTime createDate;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
