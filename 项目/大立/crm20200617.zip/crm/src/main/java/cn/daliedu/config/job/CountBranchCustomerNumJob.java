package cn.daliedu.config.job;

import java.net.InetAddress;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import cn.daliedu.config.param.SysParamConfig;
import cn.daliedu.entity.CustomerCountEntity;
import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.service.ContractReturnMoneyPlanService;
import cn.daliedu.service.CustomerCountService;
import cn.daliedu.service.CustomerService;
import cn.daliedu.service.OrgService;
import cn.daliedu.service.UserService;
import cn.daliedu.util.DateUtil;

@DisallowConcurrentExecution //作业不并发
@Component
public class CountBranchCustomerNumJob implements Job{
	@Autowired
	OrgService orgService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	CustomerCountService customerCountService;
	
	@Autowired
	ContractReturnMoneyPlanService contractReturnMoneyPlanService;
	
    @Override
    public void execute(JobExecutionContext arg0) throws JobExecutionException {
        if(SysParamConfig.jobIsRun()){
        	try {
        		// 1.统计所有分校下的客户数
				List<OrgEntity> orgList = orgService.getBranchOrg();
				for (OrgEntity entity : orgList) {
					//如果已经执行完，则不再执行，防止重复执行
					boolean flag = customerCountService.existBranchCustomerCountData(entity.getId().toString(), LocalDate.now().toString());
					if(!flag){
						CustomerCountEntity bean = new CustomerCountEntity();
						bean.setBranchOrgId(entity.getId().toString());
						bean.setCreateDate(LocalDate.now());
						bean.setDataType("1");
						bean.setCustomerCount(customerService.getCustomerCountByBranchOrgId(entity.getId()));
						
						customerCountService.save(bean);
					}
				}
				// 2.统计所有分校下的用户的客户数
				List<UserEntity> userList = userService.getAllUser();
				for (UserEntity entity : userList) {
					boolean flag = customerCountService.existUserCustomerCountData(entity.getId(), LocalDate.now().toString());
					if(!flag){
						CustomerCountEntity bean = new CustomerCountEntity();
						bean.setUserId(entity.getId());
						bean.setCreateDate(LocalDate.now());
						bean.setDataType("2");
						bean.setCustomerCount(customerService.getCustomerCountByUserId(entity.getId()));
						
						customerCountService.save(bean);
					}
				}
    		} catch (Exception e) {
    			System.out.println("执行定时任务出现异常");
    			e.printStackTrace();
    		}
        }
    }

}