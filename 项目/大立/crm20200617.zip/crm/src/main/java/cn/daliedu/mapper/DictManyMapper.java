package cn.daliedu.mapper;

import cn.daliedu.entity.DictEntity;
import cn.daliedu.entity.DictManyEntity;

import java.util.LinkedHashMap;
import java.util.List;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 存储2个维度的，一对多的数据字典 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-11-07
 */
public interface DictManyMapper extends BaseMapper<DictManyEntity> {
	
	/**
	 * 获取数据库中所有的数据字典类别
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<String, String>> getDictTypeList() throws Exception;
	
	/**
	 * 根据字典类别获取所有的数据字典
	 * @param tag 标签标识符
	 * @return
	 * @throws Exception
	 */
	public List<DictEntity> getDictValueByType(String tag) throws Exception;
}
