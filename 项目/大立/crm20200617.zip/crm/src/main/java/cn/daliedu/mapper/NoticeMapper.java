package cn.daliedu.mapper;

import cn.daliedu.entity.NoticeEntity;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 公告表 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-10-28
 */
public interface NoticeMapper extends BaseMapper<NoticeEntity> {
	
	/**
	 * 根据id获取公告
	 * @param id
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getNoticeById(String id);
	
	/**
	 * 查询系统公告集合
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getNoticeList(Map<Object, Object> map);
	
	/**
	 * 查询系统公告总数
	 * @return
	 */
	public Long getNoticeListCount(Map<Object, Object> map);
}
