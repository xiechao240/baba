package cn.daliedu.entity.json;

import cn.daliedu.config.swagger.model.ApiSingleParam;

/**
 * <p>
 * swagger注释属性：客户标签分组属性json
 * </p>
 *
 * @author xiechao
 * @since 2019-05-06
 */
public class CustomerSelfDefineItemJson{
	
	
	@ApiSingleParam(value = "客户自定义类别ID", example = "a1ac6817e7684a28a066d5fe61d609ca")
	public static final String itemId = "itemId";
	
	
	@ApiSingleParam(value = "客户自定义类别名称", example = "单班")
	public static final String itemName = "itemName";
	
	@ApiSingleParam(value = "类别明细ID", example = "1")
	public static final String itemDetailId = "itemDetailId";
	
	@ApiSingleParam(value = "类别明细名称", example = "单讲班")
	public static final String itemDetailName = "itemDetailName";
	
	
	@ApiSingleParam(value = "组件类型", example = "组件类型，复选框：checkbox，下拉框：select，单选：radio，文本框的为单值且由用户输入的，不能存储在此")
	public static final String elementType = "elementType";
	
	@ApiSingleParam(value = "是否启用", example = "启用true,禁用false")
	public static final String isEnabled = "isEnabled";
	
}
