package cn.daliedu;

import java.util.Collections;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.SessionCookieConfig;
import javax.servlet.SessionTrackingMode;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.daliedu.util.Log4jUtil;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * 
 * @author xiechao
 * @time 2019年1月7日 下午5:08:23
 * @version 1.0.0 
 * @description spring boot启动类
 */
@SpringBootApplication
@MapperScan("cn.daliedu.mapper")
@EnableSwagger2 //如果不需要开启swagger，则注掉此注解
public class Application extends SpringBootServletInitializer {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
        Log4jUtil.info("\nヾ(◍°∇°◍)ﾉﾞ    spring boot启动成功      ヾ(◍°∇°◍)ﾉﾞ\n" +
                " ______                    _   ______            \n" +
                "|_   _ \\                  / |_|_   _ `.          \n" +
                "  | |_) |   .--.    .--. `| |-' | | `. \\  .--.   \n" +
                "  |  __'. / .'`\\ \\/ .'`\\ \\| |   | |  | |/ .'`\\ \\ \n" +
                " _| |__) || \\__. || \\__. || |, _| |_.' /| \\__. | \n" +
                "|_______/  '.__.'  '.__.' \\__/|______.'  '.__.'  ");
    }

    /**
     * 部署至外部的 tomcat 容器需要配置
     */
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        // 注意这里要指向原先用main方法执行的Application启动类
        return builder.sources(Application.class);
    }
    
/* 如果后台的control类，定义路径如：@RequestMapping(value = "/ws")
 * 那么前端引入static目录下的文件，就是如下的引用：
 * <script th:src="@{/js/jquery.js}"></script>
 * <!-- <script src="/crm/js/jquery.js"></script>
 * 如果没有定义路径，则就是默认的路径：
 * <script src="js/stomp.js"></script>
 * 
 * 前端如果使用了 <script th:src="@{/js/jquery.js}"></script> 这个模板标签，就会自动在后面加上jsessionId，如下：
 * http://localhost:8080/crm/js/sockjs.js;JSESSIONID=f2d903b8-8485-4fa3-b95d-f5301ee374f7   
 * 不过现在都是前后端分离，不会使用这个模板技术来做前端了，所以下面这个代码解决后面自动带上jsessionid的问题不用处理，其实引入下面这个也没有生效也解决不了
 * public void onStartup(ServletContext servletContext)throws ServletException {
        super.onStartup(servletContext);
        servletContext.setSessionTrackingModes(Collections.singleton(SessionTrackingMode.COOKIE));
        SessionCookieConfig sessionCookieConfig = servletContext.getSessionCookieConfig();
        sessionCookieConfig.setHttpOnly(true);
    }*/

}

