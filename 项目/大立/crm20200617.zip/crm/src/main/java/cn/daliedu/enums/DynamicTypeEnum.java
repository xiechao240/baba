package cn.daliedu.enums;

/**
 * 客户动态类别枚举类
 * 
 * @author xiechao
 * @time 2019年2月20日 下午2:10:21
 * @version 1.0.0
 * @description
 */
public enum DynamicTypeEnum {
	/**
	 * 客户动态类别：新增客户
	 */
	TYPE_1("1", "新增客户"), 
	/**
	 * 客户动态类别：修改客户资料
	 */
	TYPE_2("2", "修改客户资料"),
	/**
	 * 客户动态类别：添加销售计划
	 */
	TYPE_3("3", "添加销售计划"),
	/**
	 * 客户动态类别：拨打电话
	 */
	TYPE_4("4", "拨打电话"),
	/**
	 * 客户动态类别：发送短信
	 */
	TYPE_5("5", "发送短信"),
	/**
	 * 客户动态类别：新增合同
	 */
	TYPE_6("6", "新增合同"),
	/**
	 * 客户动态类别：更新客户阶段
	 */
	TYPE_7("7", "更新客户阶段"),
	/**
	 * 客户动态类别：更新客户标签
	 */
	TYPE_8("8", "更新客户标签"),
	/**
	 * 客户动态类别：转让客户
	 */
	TYPE_9("9", "转让客户"),
	/**
	 * 客户动态类别：添加跟进记录
	 */
	TYPE_10("10", "添加跟进记录"),
	/**
	 * 客户动态类别：新增回款计划
	 */
	TYPE_11("11", "新增回款计划"),
	/**
	 * 客户动态类别：新增回款记录
	 */
	TYPE_12("12", "新增回款记录"),
	/**
	 * 客户动态类别：放弃客户
	 */
	TYPE_13("13", "放弃客户"),
	/**
	 * 客户动态类别：彻底删除客户
	 */
	TYPE_14("14", "彻底删除客户");
	
	
	private String value;
	private String desc;

	DynamicTypeEnum(final String value, final String desc) {
		this.value = value;
		this.desc = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
	
	 /**
     * 根据枚举值获取枚举描述
     * @param key
     * @return
     */
    public static String getDesc(String value){
    	String returnStr = "";
        for (DynamicTypeEnum e: DynamicTypeEnum.values()){
            if(e.getValue().equals(value)){
            	returnStr = e.getDesc();
            	break;
            }
        }
		return returnStr;
    }
    
    /**
     * 根据枚举描述获取枚举值
     * @param key
     * @return
     */
    public static String getValue(String desc){
    	String returnStr = "";
        for (DynamicTypeEnum e: DynamicTypeEnum.values()){
            if(e.getDesc().equals(desc)){
            	returnStr = e.getValue();
            	break;
            }
        }
		return returnStr;
    }
    
    /**
     * 判断数值是否属于枚举类的值
     * @param key
     * @return
     */
    public static boolean isInclude(String value){
        boolean include = false;
        for (DynamicTypeEnum e: DynamicTypeEnum.values()){
            if(e.getValue().equals(value)){
                include = true;
                break;
            }
        }
        return include;
    }
}
