
package cn.daliedu.service;

import java.util.List;
import java.util.Set;

import com.baomidou.mybatisplus.extension.service.IService;

import cn.daliedu.entity.OrgEntity;
import cn.daliedu.entity.UserEntity;

/**
 * <p>
 * 机构管理 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
public interface OrgService extends IService<OrgEntity> {
	
	boolean saveOrg(OrgEntity entity);
	
	/**
	 * 获取分校下的部门（不支持部门下再创建部门，目前部门已经是系统的第4级结构了，不允许无限级）
	 * @param branchOrgId
	 * @return
	 */
	public List<OrgEntity> getDepartmentListByBranchOrgId(String branchOrgId);
	
	/**
	 * 查询机构树
	 * @param userId 
	 * @return
	 */
	public List<OrgEntity> findTreeOrgList();
	
	/**
	 * 获取所有的分校
	 * @return
	 */
	public List<OrgEntity> getBranchOrg();
	
	/**
	 * 获取所有的省份及分校(以树形结果返回)
	 * @return
	 */
	public List<OrgEntity> getBranchOrgTree();
	
	/**
	 * 获取用户拥有的分校机构
	 * @return
	 */
	public List<OrgEntity> getBranchOrgByUserId(String userId);
	
	/**
	 *  获取用户拥有的分校机构
	 * @param user
	 * @return
	 */
	public List<OrgEntity> getBranchOrgByUser(UserEntity user);
	
//	/**
//	 * 获取用户能查看的所有机构，以从业务组为单位往下搜寻（目前新增员工时，校验接口有用到此方法）
//	 * @param userId
//	 * @return
//	 */
//	public Set<OrgEntity> getOrgListByUserId(String userId);
	
	/**
	 * 删除分校机构数据
	 * @return
	 */
	public void deleteOrg(String id) throws Exception;
	
	
	/**
	 * 获取用户所在的分校(因为可能有些用户挂在分校下面的部门里面去了)
	 * @param orgId 用户的机构ID
	 * @return 
	 */
	public OrgEntity getUserBranchOrgByOrgId(String orgId) throws Exception;
	
	/**
	 * 获取用户所在的分校(因为可能有些用户挂在分校下面的部门里面去了)
	 * @param user 用户的对象
	 * @return 
	 */
	public OrgEntity getUserBranchOrgByUser(UserEntity user) throws Exception;
	
	/**
	 * 获取用户所在的分校(因为可能有些用户挂在分校下面的部门里面去了)
	 * @param userId 用户ID
	 * @return 
	 */
	public OrgEntity getUserBranchOrgByUserId(String userId) throws Exception;
	
	/**
	 * 根据客户id，查询客户所属的分校
	 * @param orgId 用户的机构ID
	 * @return 
	 */
	public OrgEntity getBranchOrgByCustomerId(String customerId) throws Exception;
	
	/**
	 * 获取指定机构的下一级机构集合
	 * @param orgId 机构ID
	 * @return
	 */
	public List<OrgEntity> getNextLevelOrgByOrgId(String orgId);
	
	
}
