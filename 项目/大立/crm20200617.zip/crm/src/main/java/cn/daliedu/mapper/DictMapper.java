package cn.daliedu.mapper;

import java.util.LinkedHashMap;
import java.util.List;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import cn.daliedu.entity.DictEntity;

/**
 * <p>
 * 数据字典表，存储系统中静态的或少量变动的格式化数据 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-09-21
 */
public interface DictMapper extends BaseMapper<DictEntity> {
	
	public List<LinkedHashMap<String, String>> getDictType();
	
	/**
	 * 根据分组tag获取最大值
	 * @param tag
	 * @throws Exception
	 */
	public Integer getValueMax(String tag);

}
