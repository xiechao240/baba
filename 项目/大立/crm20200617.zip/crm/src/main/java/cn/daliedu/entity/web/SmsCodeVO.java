package cn.daliedu.entity.web;

/**
 * 
 * @author xiechao
 * @time 2019年2月15日 上午10:08:58
 * @version 1.0.0
 * @description 短信验证码缓存VO
 */
public class SmsCodeVO {
	/* 手机号码 */
	private String phone;

	/* 验证码 */
	private String smsCode;

	/* 发送时间 */
	private Long sendTime;

	/* 过期时间 = 验证码发送时间+有效时间 */
	private Long expireTime;

	/* 验证失败次数 */
	private Integer failCounts;

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getSmsCode() {
		return smsCode;
	}

	public void setSmsCode(String smsCode) {
		this.smsCode = smsCode;
	}

	public Long getSendTime() {
		return sendTime;
	}

	public void setSendTime(Long sendTime) {
		this.sendTime = sendTime;
	}

	public Long getExpireTime() {
		return expireTime;
	}

	public void setExpireTime(Long expireTime) {
		this.expireTime = expireTime;
	}

	public Integer getFailCounts() {
		return failCounts;
	}

	public void setFailCounts(Integer failCounts) {
		this.failCounts = failCounts;
	}

}
