package cn.daliedu.service;

import cn.daliedu.entity.CustomerSelfDefineItemEntity;
import cn.daliedu.entity.CustomerTagEntity;

import java.util.List;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 客户自定义类别表，其实就是用户给客户进行自定义分类，例如：单班，套班，内训，一建科目等 服务类
 * </p>
 *
 * @author xiechao
 * @since 2020-06-03
 */
public interface CustomerSelfDefineItemService extends IService<CustomerSelfDefineItemEntity> {
	
	public boolean existsCustomerSelfDefineItemConfigUse(String itemId);


	public boolean existsCustomerSelfDefineItemConfigDetailUse(String itemDetailId);

}
