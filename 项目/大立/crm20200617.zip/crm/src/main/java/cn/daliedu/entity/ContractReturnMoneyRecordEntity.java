package cn.daliedu.entity;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 合同回款记录表
 * </p>
 *
 * @author xiechao
 * @since 2019-11-01
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_contract_return_money_record")
public class ContractReturnMoneyRecordEntity extends Model<ContractReturnMoneyRecordEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;
    
    /**
     * 用户ID（可能由不同的人产生相应的回款记录）
     */
    private String userId;

    /**
     * 回款日期
     */
    private LocalDate returnMoneyDate;

    /**
     * 回款金额
     */
    private BigDecimal returnMoney;

    /**
     * 客户ID
     */
    private String customerId;
    
    /**
     * 合同ID
     */
    private String contractId;


    /**
     * 回款期次（对应计划表中的期次）
     */
    private Integer returnMoneyNum;

    /**
     * 1：支付宝，2：微信，3：银行转账，4：现金
     */
    private String payType;

    /**
     * 1：正常回款，2：退款，3：订金，4：其他
     */
    private String returnMoneyType;

    /**
     * 收款人（用户ID）
     */
    private String receiptUserId;

    /**
     * 备注
     */
    private String remark;

    /**
     * 创建日期
     */
    private LocalDateTime createDate;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
