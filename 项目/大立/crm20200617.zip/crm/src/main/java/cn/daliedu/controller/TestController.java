package cn.daliedu.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/test")
public class TestController {
	
	/**
	 * 测试前台显示二维码
	 * @param loginName
	 * @param pwd
	 * @param userType
	 * @param response
	 */
	@RequestMapping("/websocket")
	public String websocket() {
		try {
				
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return "websocket";
	}
	
	
	
//	/**
//	 * 测试前台显示二维码
//	 * @param loginName
//	 * @param pwd
//	 * @param userType
//	 * @param response
//	 */
//	@RequestMapping("/qrcode")
////	public String qrcode(HttpServletRequest request) {
//	public String qrcode(HttpServletRequest request, ModelMap map) {
//		try {
//			
//			//下面两种都无法获取到qianyouhui_logo.jpg这个文件
////			Resource resource = new ClassPathResource("classpath:templates/static/image/qianyouhui_logo.jpg");
////			Resource resource = new ClassPathResource("static/image/qianyouhui_logo.jpg");
////			File file = ResourceUtils.getFile("classpath:templates");
////	        if(file.exists()){
////	            File[] files = file.listFiles();
////	            if(files != null){
////	                for(File childFile:files){
//////	                	if(childFile.getName())
////	                    System.out.println(childFile.getName());
////	                }
////	            }
////	        }
//			
//			String imageStr = WeiXinUitl.getWXACodeUnlimitBase64(10000001);
//			
//			map.addAttribute("imageStr", imageStr);
//			
//			
////			String path = request.getContextPath();
////	        String scheme = request.getScheme();
////	        String serverName = request.getServerName();
////	        int port = request.getServerPort();
////	        String basePath = scheme + "://" + serverName + ":" + port + path;
////	        
////	        System.out.println("获取url地址：" + request.getRequestURL());
////	        System.out.println("获取urI地址：" + request.getRequestURI());
////			System.out.println("获取url地址basePath：" + basePath);
////			
////			//***打印如下
//////			获取url地址：http://localhost:8080/crm/test/qrcode
//////			获取urI地址：/crm/test/qrcode
//////			获取url地址basePath：http://localhost:8080/crm
////	        
////	        ResourceLoader resourceLoader = new DefaultResourceLoader();
////	        Resource resource = resourceLoader.getResource("templates/static/image/qianyouhui_logo.png");
////			
////			
////			String content = "签友汇";
////			File logoFile =  resource.getFile();
////			String format = "jpg";
////			boolean needCompress = true;
////			String imageStr = QRCodeUtil.encode(content, logoFile, format, needCompress);
////			
////			map.addAttribute("imageStr", imageStr);
//		} catch (Exception e) {
//			e.printStackTrace();
//			
//		}
//		return "qrcode";
//	}
	
}


