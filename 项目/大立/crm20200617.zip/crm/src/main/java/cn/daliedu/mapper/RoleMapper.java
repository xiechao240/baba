package cn.daliedu.mapper;

import cn.daliedu.entity.RoleEntity;

import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 角色管理 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
public interface RoleMapper extends BaseMapper<RoleEntity> {
	
	/**
	 * 根据用户类型，获取用户能加载的角色列表
	 * @param userType
	 * @return
	 */
	public List<RoleEntity> getRoleListByAddUser(Map<Object, Object> map);
	
	/**
	 * 根据用户ID获取用户的所有角色集合，如果不需要分页的结果，则后面的两个参数传null即可
	 * @param map 查询参数集合
	 * @return
	 */
	public List<RoleEntity> getUserRoleList(Map<Object, Object> map);
	
	/**
	 * 根据用户ID查询用户对应的角色ID集合,如果不需要分页的结果，则后面的两个参数传null即可
	 * @param map 查询参数集合
	 * @return
	 */
	public List<Integer> getUserRoleIdsByUserId(Map<Object, Object> map);
}
