package cn.daliedu.service;

import cn.daliedu.entity.CustomerTagEntity;
import cn.daliedu.entity.json.CustomerTagJson;

import java.util.LinkedHashMap;
import java.util.List;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 客户标签表，用户为客户打上的标签，其实就是作为一个筛选条件，一个客户只能从属于一类标签中的一个值 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-08
 */
public interface CustomerTagService extends IService<CustomerTagEntity> {
	
	/**
	 * 根据客户ID获取客户标签集合
	 * @param customerId
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerTagListByCustomerId(String customerId);
	
	/**
	 * 根据客户ID删除客户已经存在的客户标签
	 * @param customerId
	 * @return
	 */
	public boolean deleteCustomerTagByCustomerId(String customerId);
	
	/**
	 * 根据客户ID修改客户的标签
	 * @param customerTagJson
	 * @return
	 */
	public boolean saveCustomerTagByCustomerId(CustomerTagJson customerTagJson) throws Exception;
	
	/**
	 * 根据客户标签分组ID，判断是否被客户已经使用
	 * @param customerTagTypeId 客户标签分组ID
	 * @return
	 */
	public boolean existsCustomerTagTypeIdUse(String customerTagTypeId);
	
	/**
	 * 根据客户标签ID，判断是否被客户已经使用
	 * @param customerTagTypeId 客户标签ID
	 * @return
	 */
	public boolean existsCustomerTagIdUse(String customerTagId);
}
