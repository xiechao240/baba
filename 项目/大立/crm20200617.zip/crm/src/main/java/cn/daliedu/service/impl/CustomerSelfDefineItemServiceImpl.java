package cn.daliedu.service.impl;

import cn.daliedu.entity.CustomerSelfDefineItemEntity;
import cn.daliedu.entity.CustomerTagEntity;
import cn.daliedu.mapper.CustomerSelfDefineItemMapper;
import cn.daliedu.service.CustomerSelfDefineItemService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

/**
 * <p>
 * 客户自定义类别表，其实就是用户给客户进行自定义分类，例如：单班，套班，内训，一建科目等 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2020-06-03
 */
@Service
public class CustomerSelfDefineItemServiceImpl extends ServiceImpl<CustomerSelfDefineItemMapper, CustomerSelfDefineItemEntity> implements CustomerSelfDefineItemService {
	
	@Resource
	CustomerSelfDefineItemMapper customerSelfDefineItemMapper;
	
	@Override
	public boolean existsCustomerSelfDefineItemConfigUse(String itemId) {
		List<CustomerSelfDefineItemEntity> list = customerSelfDefineItemMapper.selectList(new QueryWrapper<CustomerSelfDefineItemEntity>().eq("item_id", itemId));
		if(list!=null && list.size()>0){
			return true;
		}
		return false;
	}


	@Override
	public boolean existsCustomerSelfDefineItemConfigDetailUse(String itemDetailId) {
		List<CustomerSelfDefineItemEntity> list = customerSelfDefineItemMapper.selectList(new QueryWrapper<CustomerSelfDefineItemEntity>().eq("item_detail_id", itemDetailId));
		if(list!=null && list.size()>0){
			return true;
		}
		return false;
	}
}
