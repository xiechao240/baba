package cn.daliedu.service;

import cn.daliedu.entity.NoticeEntity;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 公告表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-28
 */
public interface NoticeService extends IService<NoticeEntity> {
	
	/**
	 * 获取系统公告数据集合，置顶的优先排，再根据创建日期倒排
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getNoticeList(Map<Object, Object> map);
	
	/**
	 * 获取系统公告数据
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getNoticeById(String id);
	
	
	/**
	 * 首页获取系统公告数据
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getNoticeAndNumCount(String id);
	
	/**
	 * 获取系统公告数据集合总数
	 * @param map
	 * @return
	 */
	public Long getNoticeListCount(Map<Object, Object> map);
	
	/**
	 * 新增系统公告
	 * @param title
	 * @param content
	 * @return
	 */
	public boolean saveNotice(String title, String content);
	
	/**
	 * 修改系统公告
	 * @param id
	 * @param title
	 * @param content
	 * @return
	 */
	public boolean updateNotice(String id, String title, String content);
	
	/**
	 * 删除系统公告
	 * @param id
	 * @return
	 */
	public boolean deleteNoticeById(String id);
	
	/**
	 * 删除系统公告
	 * @param idList
	 * @return
	 */
	public boolean deleteNoticeByIds(List<String> idList);
	
	/**
	 * 操作系统公告置顶
	 * @param id
	 * @return
	 */
	public boolean optionNoticeTop(String id);
	
	
}
