package cn.daliedu.mapper;

import cn.daliedu.entity.PhoneTypeEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 机型匹配目录表 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2020-06-08
 */
public interface PhoneTypeMapper extends BaseMapper<PhoneTypeEntity> {

}
