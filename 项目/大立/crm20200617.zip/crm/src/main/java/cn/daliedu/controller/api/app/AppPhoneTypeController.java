package cn.daliedu.controller.api.app;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.shiro.authz.UnauthorizedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import org.springframework.web.bind.annotation.RestController;

import cn.daliedu.entity.CustomerTagGroupEntity;
import cn.daliedu.entity.DictEntity;
import cn.daliedu.entity.PhoneTypeEntity;
import cn.daliedu.enums.ResultCodeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.PhoneTypeService;
import cn.daliedu.util.Result;

/**
 * <p>
 * 机型匹配目录表 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2020-06-08
 */
@Api(description="机型匹配目录服务接口")
@RestController
@RequestMapping(value = "${rest.path}/app/customer")
public class AppPhoneTypeController {
	
	@Autowired
	PhoneTypeService phoneTypeService;

	@ApiOperation(value = "根据机型及android版本号，获取目录")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "phoneType", dataType = "String", required = true, value = "手机型号"),
		@ApiImplicitParam(name = "androidVersion", dataType = "Integer", required = true, value = "android版本号")
	})
	@GetMapping("query-phone-directory")
	public Result queryPhoneDirectory(@RequestParam(required = true) String phoneType, @RequestParam(required = true) Integer androidVersion) {
		try {
			PhoneTypeEntity entity = phoneTypeService.queryPhoneDirectory(phoneType, androidVersion);

			return Result.success(entity);
		} catch (UnauthorizedException e) {
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("查找机型目录失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "查询所有机型及android版本号及目录")
	@GetMapping("query-all-phone-directory")
	public Result queryAllPhoneDirectory() {
		try {
			List<PhoneTypeEntity> list = phoneTypeService.list();

			return Result.success(list);
		} catch (UnauthorizedException e) {
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("查找机型失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
	
	@ApiOperation(value = "增加机型及android版本号")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "phoneType", dataType = "String", required = true, value = "手机型号"),
		@ApiImplicitParam(name = "androidVersion", dataType = "Integer", required = true, value = "android版本号"),
		@ApiImplicitParam(name = "directory", dataType = "String", required = true, value = "机型目录"),
		@ApiImplicitParam(name = "description", dataType = "String", required = false, value = "描述")
	})
	@PostMapping("save-phone-directory")
	public Result savePhoneDirectory(@RequestParam(required = true) String phoneType, @RequestParam(required = true) Integer androidVersion, 
			@RequestParam(required = true) String directory, @RequestParam String description) {
		try {
			PhoneTypeEntity entity = phoneTypeService.queryPhoneDirectory(phoneType, androidVersion);
			if(entity==null){
				PhoneTypeEntity bean = new PhoneTypeEntity();
				bean.setAndroidVersion(androidVersion);
				bean.setDescription(description);
				bean.setDirectory(directory);
				bean.setPhoneType(phoneType);
				
				phoneTypeService.save(entity);
				
				return Result.success("新增成功");
			}

			return Result.error("此机型已经存在，请勿重复添加");
		} catch (UnauthorizedException e) {
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("增加机型目录失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
}
