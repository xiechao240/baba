package cn.daliedu.entity;

import java.io.Serializable;
import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 用户表，所有登录CRM系统的员工账号都存储在此表
 * </p>
 *
 * @author xiechao
 * @since 2019-09-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("sys_user")
public class UserEntity extends Model<UserEntity> implements Principal {
	
	//集成rabitMQ时实现了Principal接口，重写了getName()方法
	@Override
	public String getName() {
		return loginName;
	}

	private static final long serialVersionUID = 1L;
    
    @TableField(exist = false)
    private String token;
    
    /**
     * 给前端返回使用
     */
    @TableField(exist = false)
    private String roleId;
    
    /**
     * 给前端返回使用，用户能查看的业务组ids
     */
    @TableField(exist = false)
    private String orgIds;
    
    @TableField(exist = false)
    List<OrgEntity> branchOrgIds;
    
    

    /**
     * 用户ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;

    /**
     * 登录账号
     */
    private String loginName;

    /**
     * 密码
     */
    @JsonIgnore
    private String password;

    /**
     * 密码盐，确保同样的密码保存入库为不一样的值
     */
    private String salt;

    /**
     * 用户数据访问权限, -1:系统所有数据; 0:用户自定义数据访问权限; 1:自己的数据; 2:仅所属部门数据; 3:所属部门及其以下所有数据; 
     */
    private String dataScope;

    /**
     * 用户类型 1：超级管理员，2：区域管理员，3：分校管理员，4：部门管理员，5：普通用户，6：代理商用户
     */
    private String userType;

    /**
     * 姓名
     */
    private String userName;

    /**
     * 手机号
     */
    private String mobile;

    /**
     * 状态，0：禁用状态，1：可用状态，2：离职状态
     */
    private String state;

    /**
     * 性别，1：男，2：女
     */
    private String sex;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 公司名称（用户无修改权限）
     */
    private String companyName;

    /**
     * 组织结构ID
     */
    private String orgId;

    /**
     * 组织结构名称
     */
    private String orgName;
    
    /**
     * 组织结构名称（保存数据格式为：分校名称-》部门名称，如果从属于分校下的部门才有部门名称）
     */
    private String orgNames;
    

    /**
     * 部门（用户无修改权限）
     */
    private String department;

    /**
     * 职位（用户无修改权限）
     */
    private String job;

    /**
     * 行业（用户无修改权限）
     */
    private String trade;

    /**
     * 地址（用户无修改权限）
     */
    private String address;

    /**
     * 网址（用户无修改权限）
     */
    private String site;

    /**
     * 微信授权
     */
    private String weixinAuthorId;

    /**
     * 邮箱授权
     */
    private String emailAuthorId;

    /**
     * 登录时间
     */
    private LocalDateTime loginTime;

    /**
     * 账号创建时间
     */
    private LocalDateTime createTime;

    /**
     * 上次登录时间
     */
    private LocalDateTime preLoginTime;

    /**
     * 本次登录时间
     */
    private LocalDateTime thisLoginTime;

    /**
     * 地区(省或自治区)ID（用户无修改权限）
     */
    private String provinceId;

    /**
     * 地区(省)名称（冗余）（用户无修改权限）
     */
    private String provinceName;

    /**
     * 地区(市)ID（用户无修改权限）
     */
    private String cityId;

    /**
     * 地区(市)名称（冗余）（用户无修改权限）
     */
    private String cityName;

    /**
     * 地区(区)（用户无修改权限）
     */
    private String areaId;

    /**
     * 地区(区)名称（冗余）（用户无修改权限）
     */
    private String areaName;
    
    /**
     * 创建人（比如谁创建的代理商）
     */
    private String createUserId;
    
    /**
     * 修改人（比如谁修改的代理商拥有的业务组等）
     */
    private String updateUserId;

//    /**
//     * 删除标记，1：已删除，0：未删除
//     */
//    @TableLogic // 如果不加此标签，则删除的时候就是进行物理删除
//	@TableField(fill = FieldFill.INSERT_UPDATE)
//    private String deleted;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
