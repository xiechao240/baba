package cn.daliedu.service;

import com.baomidou.mybatisplus.extension.service.IService;

import cn.daliedu.entity.UserOrgAreaEntity;

/**
 * <p>
 * 用户可查看的业务组公海与部门数据，用户可拥有多个分校的数据查看权限，其实就是存储用户从属于多个分校 服务类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-23
 */
public interface UserOrgAreaService extends IService<UserOrgAreaEntity> {
	
	/**
	 * 根据用户ID查询用户所属的业务组分校集合
	 * @param userId
	 * @return
	 */
	public String getUserOrgAreaIdsByUserId(String userId);
	
	
}
