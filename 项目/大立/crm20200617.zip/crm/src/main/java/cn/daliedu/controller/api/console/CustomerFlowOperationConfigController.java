package cn.daliedu.controller.api.console;


import java.util.LinkedHashMap;
import java.util.List;

import org.apache.shiro.authz.UnauthorizedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.CustomerEntity;
import cn.daliedu.entity.CustomerFlowCauseConfigEntity;
import cn.daliedu.entity.CustomerFlowOperationConfigEntity;
import cn.daliedu.entity.json.CustomerFlowOperationAndCause;
import cn.daliedu.entity.json.CustomerJson;
import cn.daliedu.enums.ResultCodeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.CustomerFlowCauseConfigService;
import cn.daliedu.service.CustomerFlowOperationConfigService;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * <p>
 * 客户流转操作配置表 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2019-10-15
 */
@Api(description = "客户流转及操作配置相关接口")
@RestController
@RequestMapping("${rest.path}/customerFlowOperationConfig")
public class CustomerFlowOperationConfigController {
	
	@Autowired
	CustomerFlowCauseConfigService customerFlowCauseConfigService;
	
	@Autowired
	CustomerFlowOperationConfigService customerFlowOperationConfigService;
	
	
	@ApiOperation(value = "增加客户流转原因")
	@ApiJsonObject(name = "saveCustomerFlowCause", value = { 
			@ApiJsonProperty(name = CustomerJson.cause)})
	@ApiImplicitParam(name = "params", required = true, dataType = "saveCustomerFlowCause")
//	@RequiresPermissions("sys:role:list")
	@PostMapping("/saveCustomerFlowCause")
	public Result saveCustomerFlowCause(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String cause = String.valueOf(jsonObject.get("cause"));
			
			StringUtil.validateIsNull(cause, "请输入客户流转原因");
			
			CustomerFlowCauseConfigEntity entity = new CustomerFlowCauseConfigEntity();
			entity.setCause(cause);
			
			boolean flag = customerFlowCauseConfigService.save(entity);
			if(flag){
				return Result.success("新增成功");
			}
			return Result.error("增加客户流转原因失败");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("增加客户流转原因失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "获取所有的客户流转原因")
	@PostMapping("/getAllCustomerFlowCause")
	public Result getAllCustomerFlowCause(){
		try{
			List<CustomerFlowCauseConfigEntity> list = customerFlowCauseConfigService.list();
			
			return Result.success(list);
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("增加客户流转原因失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "获取所有的客户流转原因操作配置")
	@PostMapping("/getAllCustomerFlowOperation")
	public Result getAllCustomerFlowOperation(){
		try{
			List<LinkedHashMap<Object, Object>> list = customerFlowOperationConfigService.getAllCustomerFlowOperation();
			if(list!=null && list.size()>0){
				return Result.success(list);
			}
			return Result.error("暂无客户流转原因操作配置");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("增加客户流转原因失败，失败原因：" + e.getMessage());
		}
	}
	
	
	@ApiOperation(value = "根据类型获取客户流转配置(如果返回内容为空，则删除客户，转让客户，放弃客户都不进行原因的显示)")
	@ApiJsonObject(name = "getCustomerFlowOperationConfigByType", value = { 
			@ApiJsonProperty(name = CustomerJson.operationType)})
	@ApiImplicitParam(name = "params", required = true, dataType = "getCustomerFlowOperationConfigByType")
//	@RequiresPermissions("sys:role:list")
	@PostMapping("/getCustomerFlowOperationConfigByType")
	public Result getCustomerFlowOperationConfigByType(@RequestBody String params){
		try{
			JSONObject jsonObject = JSON.parseObject(params);
			String operationType = String.valueOf(jsonObject.get("operationType"));
			
			StringUtil.validateIsNull(operationType, "请输入客户流转类型");
			
			List<CustomerFlowOperationConfigEntity> list = customerFlowOperationConfigService.getCustomerFlowOperationConfigByType(operationType);
			if(list!=null && list.size()>0){
				return Result.success(list);
			}
			return Result.error("暂时无客户流转配置数据");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("根据类型获取客户流转配置失败，失败原因：" + e.getMessage());
		}
	}
	
	
	
	@ApiOperation(value = "保存客户流转操作配置(前端只需要传递操作配置数组即可，因为配置数据已经包含原因)")
//	@RequiresPermissions("sys:role:list")
	@PostMapping("/saveCustomerFlowOperationConfig")
//	public Result saveCustomerFlowOperationConfig(CustomerFlowOperationConfigEntity[] arrList){
	public Result saveCustomerFlowOperationConfig(@RequestBody @ApiParam(required=true)CustomerFlowOperationAndCause model){
		try{
			if(model!=null && model.getCustomerFlowOperationConfigJson().length>0){
				boolean flag = customerFlowOperationConfigService.saveCustomerFlowOperationConfig(model.getCustomerFlowOperationConfigJson());
				if(flag){
					return Result.success("保存成功");
				}
				return Result.error("保存失败，请联系管理员");
			}
			
			return Result.error("请传入需要保存的数据");
		}catch (UnauthorizedException e){
			return Result.error(ResultCodeEnum.USER_NOT_AUTH);
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error("保存客户流转操作配置失败，失败原因：" + e.getMessage());
		}
	}
	
}
