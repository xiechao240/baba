package cn.daliedu.mapper;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import cn.daliedu.entity.CustomerEntity;

/**
 * <p>
 * 客户表 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-09-26
 */
public interface CustomerMapper extends BaseMapper<CustomerEntity> {
	
	/**
	 * 【客户查重】获取客户列表
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerListByRepetition(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【客户查重】获取客户列表
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public Long getCustomerListByRepetitionCount(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【推广管理】综合查询获取客户列表
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerListByPromotionManage(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【推广管理】综合查询获取客户列表总数
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerListByPromotionManageCount(Map<Object, Object> map);
	
	/**
	 * 查询我导入的客户列表
	 * @param map 查询组合参数集合
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerListByImport(Map<Object, Object> map);
	
	/**
	 * 查询我推广的的客户列表
	 * @param map 查询组合参数集合
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerListByGeneralize(Map<Object, Object> map);
	
	/**
	 * 查询资源库的客户列表
	 * @param map 查询组合参数集合
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerListByRepository(Map<Object, Object> map);
	
	
	/**
	 * 查询我导入的客户列表数量
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerListByImportCount(Map<Object, Object> map);
	
	/**
	 * 查询我推广的的客户列表数量
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerListByGeneralizeCount(Map<Object, Object> map);
	
	/**
	 * 查询资源库的客户列总数
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerListByRepositoryCount(Map<Object, Object> map);
	
	/**
	 * 将指定的用户手上的客户公海类别更新为"1"，即放入业务组公海，此方法不可单独使用，使用此方法前应该先删除用户客户表中的数据
	 * @param userIds 单个用户如2，多个用户拼接成 1,2,3
	 * @return
	 */
	public Integer updateCustomerSeaTypeByUserIds(@Param("userIds") String userIds);
	
//	/**
//	 * 根据分校ID，及手机号码获取分校下的客户
//	 * @param map
//	 * @return
//	 */
//	public CustomerEntity getBranchCustomerByMobile(Map<Object, Object> map);
	
	/**
	 * 获取用户联系客户的次数（首页目前有使用到）
	 * @param map
	 * @return
	 */
	public BigDecimal getCustomerContactCountByUserId(Map<Object, Object> map);
	
	/**
	 * 【客户数量统计报表】根据用户ID获取客户数量
	 * @param branchOrgId
	 * @return
	 */
	public Integer getCustomerCountByUserId(String userId);
	
	/**
	 * 【客户数量统计报表】根据分校ID获取分校客户数量
	 * @param branchOrgId
	 * @return
	 */
	public Integer getCustomerCountByBranchOrgId(String branchOrgId);
	
	
	/**
	 * 【客户数量统计报表】获取用户流失的客户数量
	 * @param map
	 * @return
	 */
	public BigDecimal getLossCustomerCountByUser(Map<Object, Object> map);
	
	
	/**
	 * 【客户数量统计报表】获取分校的用户流失的客户数量
	 * @param map
	 * @return
	 */
	public BigDecimal getLossCustomerCountByBranch(Map<Object, Object> map);
	
	/**
	 * 【客户数量统计报表】获取用户创建的客户数量
	 * @param map
	 * @return
	 */
	public BigDecimal getCreateCustomerCountByUser(Map<Object, Object> map);
	
	
	/**
	 * 【客户数量统计报表】获取分校的用户创建的客户数量
	 * @param map
	 * @return
	 */
	public BigDecimal getCreateCustomerCountByBranch(Map<Object, Object> map);
	
	/**
	 * 【客户活跃度统计报表】获取最近联系的客户数量
	 * @param contactNum
	 * @return
	 */
	public BigDecimal getLatelyContactCustomerCount(Map<Object, Object> map);
	
	/**
	 * 【客户活跃度统计报表】根据客户联系次数获取客户数量
	 * @param contactNum
	 * @return
	 */
	public BigDecimal getCustomerContactCount(Map<Object, Object> map);
	
	/**
	 * 【客户活跃度统计报表】根据分校ID获取分校客户数量
	 * @param branchOrgId
	 * @return
	 */
//	public BigDecimal getBranchCustomerCount(@Param("branchOrgId")String branchOrgId);
	public BigDecimal getBranchCustomerCount(Map<Object, Object> map);
	
	/**
	 * 【客户管理】综合查询获取客户列表
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerListByCustomerManage(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【客户管理】综合查询获取客户列表总数
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerListByCustomerManageCount(Map<Object, Object> map);
	
	
	/**
	 * 获取客户创建记录列表
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerCreateRecordList(Map<Object, Object> map) throws Exception;
	
	/**
	 * 获取客户创建记录列表总数
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerCreateRecordListCount(Map<Object, Object> map);
	
	
	/**
	 * 根据用户id查询我的客户列表
	 * @param map 查询组合参数集合
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerList(Map<Object, Object> map);
	
	/**
	 * 根据代理商导入的手机号码查询客户
	 * @param mobile
	 * @return
	 */
	public List<CustomerEntity> getCustomerListByAgentImportMobile(Map<Object, Object> map);
	
	/**
	 * 根据用户id查询业务组公海的客户列表
	 * @param map 查询组合参数集合
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerListByBusinessGroupSea(Map<Object, Object> map);
	
	/**
	 * 根据用户id查询业务组的客户列表(代理商用户查询)
	 * @param map 查询组合参数集合
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerListByAgentsSearch(Map<Object, Object> map);
	/**
	 * 根据用户id查询业务组的客户列表总数(代理商用户查询)
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerListByAgentsSearchCount(Map<Object, Object> map);
	
	/**
	 * 查询公司大公海的客户列表
	 * @param map 查询组合参数集合
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerListByCompanySea(Map<Object, Object> map);
	
	/**
	 * 根据用户id查询我的客户列表总数
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerListCount(Map<Object, Object> map);
	
	/**
	 * 根据用户id查询业务组公海的客户列表总数
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerListByBusinessGroupSeaCount(Map<Object, Object> map);
	
	/**
	 * 查询公司大公海的客户列表总数
	 * @param map 查询组合参数集合
	 */
	public Long getCustomerListByCompanySeaCount(Map<Object, Object> map);
	
	
	/**
	 * 获取当前管理员管理的机构及下属机构，员工删除的客户列表（即回收站里面显示客户列表）
	 * @param map
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> findCustomerRecycledList(Map<Object, Object> map);
	
	/**
	 * 获取当前管理员管理的机构及下属机构，员工删除的客户列表总数（即回收站里面显示客户列表）
	 * @param map
	 * @return
	 */
	public Long findCustomerRecycledListCount(Map<Object, Object> map);
}
