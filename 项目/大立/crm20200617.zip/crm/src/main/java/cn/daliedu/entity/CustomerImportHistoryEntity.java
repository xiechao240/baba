package cn.daliedu.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.time.LocalDate;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 客户导入历史表（用于导入时记录有问题的数据，如果有需求，可以开发定时任务清理此表中的数据）
 * </p>
 *
 * @author xiechao
 * @since 2020-02-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("crm_customer_import_history")
public class CustomerImportHistoryEntity extends Model<CustomerImportHistoryEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;

    /**
     * 导入的用户ID
     */
    private String userId;


    /**
     * 姓名
     */
    private String customerName;

    /**
     * 性别，1：男，2：女，3：未知
     */
    private String sex;

    /**
     * 客户来源类型id（见数据字典表定义）
     */
    private String customerSourceType;

    /**
     * 客户来源名称类型（见数据字典sys_dict表customer_source_name的定义）
     */
    private String customerSourceName;

    /**
     * 客户来源名称对应的值（见数据字典sys_dict表customer_source_name的定义）
     */
    private String customerSourceNameValue;

    /**
     * 微信号
     */
    private String weixinId;

    /**
     * QQ
     */
    private String qq;

    /**
     * 手机
     */
    private String mobile;

    /**
     * 座机电话
     */
    private String phone;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 批量导入批次号
     */
    private String importBatchNo;
    
    /**
     * 导入描述
     */
    private String remark;

    /**
     * 导入日期
     */
    private LocalDate importDate;


    @Override
    protected Serializable pkVal() {
        return this.id;
    }

}
