package cn.daliedu.mapper;

import cn.daliedu.entity.ParameterEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 系统参数表 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-12-31
 */
public interface ParameterMapper extends BaseMapper<ParameterEntity> {

}
