package cn.daliedu.entity.json;

import cn.daliedu.config.swagger.model.ApiSingleParam;

/**
 * <p>
 * swagger注释属性：属性json
 * </p>
 *
 * @author xiechao
 * @since 2019-05-06
 */
public class ParameterJson{
	
	@ApiSingleParam(value = "参数名称", example = "自定义短信发送数量")
	public static final String paramName = "paramName";
	
	
	@ApiSingleParam(value = "参数key", example = "SMS_COUNT")
	public static final String paramKey = "paramKey";
	
	@ApiSingleParam(value = "paramValue", example = "1")
	public static final String paramValue = "paramValue";
	
	@ApiSingleParam(value = "paramDesc", example = "参数描述")
	public static final String paramDesc = "paramDesc";
	
	
	
	
}
