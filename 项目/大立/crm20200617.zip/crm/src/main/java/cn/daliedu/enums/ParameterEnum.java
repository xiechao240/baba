package cn.daliedu.enums;

/**
 * 数据库系统参数配置枚举类
 * @author xiechao
 * @time 2019年1月9日 下午5:51:51
 * @version 1.0.0
 * @description 
 */
public enum ParameterEnum {
	/**
	 * 短信数量
	 */
	SMS_COUNT("SMS_COUNT", "短信数量"),
	/**
	 * 是否允许存在重复的客户
	 */
	IS_REPETITION("IS_REPETITION", "是否允许录入重复客户");

	private String value;
	private String desc;

	ParameterEnum(final String value, final String desc) {
		this.value = value;
		this.desc = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
}