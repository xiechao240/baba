package cn.daliedu.enums;

/**
 * 呼叫状态枚举类
 * @author xiechao
 * @time 2019年9月27日 下午2:44:36
 * @version 1.0.0 
 * @description
 */
public enum  CallStateEnum {
	/**
	 * 呼叫状态：呼出，对方未振铃，可能是空号
	 */
	TYPE_0("0", "呼出，对方未振铃，可能是空号"), 
	/**
	 * 呼叫状态：呼出，对方未接听
	 */
	TYPE_1("1", "呼出，对方未接听"), 
	/**
	 * 呼叫状态：接通
	 */
	TYPE_2("2", "接通"),
	/**
	 * 呼叫状态：呼入，未接来电
	 */
	TYPE_3("3", "呼入，未接来电");

	private String value;
	private String desc;

	CallStateEnum(final String value, final String desc) {
		this.value = value;
		this.desc = desc;
	}

	public String getValue() {
		return value;
	}

	public String getDesc() {
		return desc;
	}
	
	 /**
     * 根据枚举值获取枚举描述
     * @param key
     * @return
     */
    public static String getDesc(String value){
    	String returnStr = "";
        for (CallStateEnum e: CallStateEnum.values()){
            if(e.getValue().equals(value)){
            	returnStr = e.getDesc();
            	break;
            }
        }
		return returnStr;
    }
    
    /**
     * 根据枚举描述获取枚举值
     * @param key
     * @return
     */
    public static String getValue(String desc){
    	String returnStr = "";
        for (CallStateEnum e: CallStateEnum.values()){
            if(e.getDesc().equals(desc)){
            	returnStr = e.getValue();
            	break;
            }
        }
		return returnStr;
    }
    
    /**
     * 判断数值是否属于枚举类的值
     * @param key
     * @return
     */
    public static boolean isInclude(String value){
        boolean include = false;
        for (CallStateEnum e: CallStateEnum.values()){
            if(e.getValue().equals(value)){
                include = true;
                break;
            }
        }
        return include;
    }
}