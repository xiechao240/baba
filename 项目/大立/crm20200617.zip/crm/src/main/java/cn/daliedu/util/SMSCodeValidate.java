package cn.daliedu.util;

import javax.annotation.Resource;

import cn.daliedu.config.param.SmsParamConfig;
import cn.daliedu.entity.web.SmsCodeVO;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.shiro.redis.RedisUtil;




/**
 * @author xiechao
 * @time 2019年3月14日 上午9:37:39
 * @version 1.0.0 
 * @description 
 */
public class SMSCodeValidate {
	
	/**
	 * 校验验证码，并清除redis中的缓存
	 * @param mobile
	 * @param validateCode
	 * @return
	 * @throws BusinessException
	 */
	public boolean validateCode(String mobile, String validateCode) throws BusinessException{
		RedisUtil redisUtil = (RedisUtil)SpringUtil.getBean("redisUtil");
		
		Object obj = redisUtil.get(mobile);
		// 判断验证码是否已过期
		if (obj == null) {
			throw new BusinessException("该手机号，还未发送验证码");
		}
		String jsonStr = (String) obj;

		SmsCodeVO smsCodeVO = JsonUtil.getJsonToBean(jsonStr, SmsCodeVO.class);
		if (smsCodeVO == null) {
			throw new BusinessException("短信验证码已过期");
		}
		if (System.currentTimeMillis() > smsCodeVO.getExpireTime()) {
			throw new BusinessException("短信验证码已过期");
		}

		if (!smsCodeVO.getSmsCode().equals(validateCode)) {
			int failCounts = smsCodeVO.getFailCounts() + 1;
			if (SmsParamConfig.RE_CHECK_ERROR > 0 && failCounts == SmsParamConfig.RE_CHECK_ERROR) {
				redisUtil.del(mobile);
				throw new BusinessException("短信验证码错误次数过多，请重复发送短信验证码");
			}
			smsCodeVO.setFailCounts(failCounts);
			// 失败次数加1并重新设置超时时(过期时间-当前时间)
			redisUtil.set(mobile, JsonUtil.toJson(smsCodeVO),
					(smsCodeVO.getExpireTime() - System.currentTimeMillis()) / 1000);
			throw new BusinessException("短信验证码错误");
		}

		// 验证通过,清除短信验证码缓存
		redisUtil.del(mobile);
		
		return true;
	}
	
	
	/**
	 * 校验验证码，但不删除redis缓存中的验证码
	 * @param mobile
	 * @param validateCode
	 * @throws BusinessException
	 */
	public boolean validateCodeNotDelete(String mobile, String validateCode) throws BusinessException{
		RedisUtil redisUtil = (RedisUtil)SpringUtil.getBean("redisUtil");
		
		Object obj = redisUtil.get(mobile);
		// 判断验证码是否已过期
		if (obj == null) {
			throw new BusinessException("该手机号，还未发送验证码");
		}
		String jsonStr = (String) obj;

		SmsCodeVO smsCodeVO = JsonUtil.getJsonToBean(jsonStr, SmsCodeVO.class);
		if (smsCodeVO == null) {
			throw new BusinessException("短信验证码已过期");
		}
		if (System.currentTimeMillis() > smsCodeVO.getExpireTime()) {
			throw new BusinessException("短信验证码已过期");
		}

		if (!smsCodeVO.getSmsCode().equals(validateCode)) {
			int failCounts = smsCodeVO.getFailCounts() + 1;
			if (SmsParamConfig.RE_CHECK_ERROR > 0 && failCounts == SmsParamConfig.RE_CHECK_ERROR) {
				redisUtil.del(mobile);
				throw new BusinessException("短信验证码错误次数过多，请重复发送短信验证码");
			}
			smsCodeVO.setFailCounts(failCounts);
			// 失败次数加1并重新设置超时时(过期时间-当前时间)
			redisUtil.set(mobile, JsonUtil.toJson(smsCodeVO),
					(smsCodeVO.getExpireTime() - System.currentTimeMillis()) / 1000);
			throw new BusinessException("短信验证码错误");
		}

		return true;
	}
}
