package cn.daliedu.config;


import java.util.Arrays;
import java.util.List;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import cn.daliedu.config.filter.CorsFilter;
import cn.daliedu.config.i18n.MyLocaleResolver;
import cn.daliedu.config.swagger.ModelCache;
import cn.daliedu.util.ClassUtil;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;


/**
 * @author xiechao
 * @time 2019年4月23日 下午2:53:57
 * @version 1.0.0 
 * @description swagger2.9.2版本配置类，旧版本请参考bak文件夹下的类
 */
@Configuration
//@EnableSwagger2
public class Swagger2Config implements WebMvcConfigurer {
	
	@Bean
    public Docket createConsoleRestApi() {
		//使用下面的方法只能注入一个类中的所有属性，上面的方式可以注入多个类
//		ModelCache.getInstance().setParamClass(GlobalString.class);
		
		//使用下面的方法，需要每定义一个类，就要注入一个，比较麻烦
//		List<Class<?>> clsList = new ArrayList<Class<?>>();
//		clsList.add(GlobalString.class);
//		clsList.add(GlobalString2.class);
//		ModelCache.getInstance().setParamClassList(clsList);
		
		//采用自动扫描指定路径，自定义json说明属性的类文件，不用像上面那样手工添加每一个类
//		List<Class<?>> ass = ClassUtil.getAllClassByPackageName(GlobalString.class.getPackage());
		List<Class<?>> clsList = ClassUtil.getClasses("cn.daliedu.entity.json");
		ModelCache.getInstance().setParamClassList(clsList);
		

        return new Docket(DocumentationType.SWAGGER_2)
                .groupName("pc后台接口")
                .apiInfo(apiConsoleInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("cn.daliedu.controller.api.console"))//api接口包扫描路径
//                .paths(PathSelectors.regex(".*/admin/.*"))//可以根据url路径设置哪些请求加入文档，忽略哪些请求
                .paths(PathSelectors.any())
                .build();
//                .globalOperationParameters(setHeaderToken()); //将配置的header参数加上,如果不需要全局配置header参数，则注掉此行,注意.global方法要放在这个方法链的最后
    }
	
	private ApiInfo apiConsoleInfo() {
        return new ApiInfoBuilder()
                .title("pc后台接口")//设置文档的标题
//                .description("后台数据管理")//设置文档的描述->1.Overview
                .version("1.0")//设置文档的版本信息-> 1.1 Version information
                .build();
    }
	
	
	@Bean
    public Docket createAppRestApi() {
		//使用下面的方法只能注入一个类中的所有属性，上面的方式可以注入多个类
//		ModelCache.getInstance().setParamClass(GlobalString.class);
		
		//使用下面的方法，需要每定义一个类，就要注入一个，比较麻烦
//		List<Class<?>> clsList = new ArrayList<Class<?>>();
//		clsList.add(GlobalString.class);
//		clsList.add(GlobalString2.class);
//		ModelCache.getInstance().setParamClassList(clsList);
		
		//采用自动扫描指定路径，自定义json说明属性的类文件，不用像上面那样手工添加每一个类
//		List<Class<?>> ass = ClassUtil.getAllClassByPackageName(GlobalString.class.getPackage());
		List<Class<?>> clsList = ClassUtil.getClasses("cn.daliedu.entity.json");
		ModelCache.getInstance().setParamClassList(clsList);
		

        return new Docket(DocumentationType.SWAGGER_2)
                .groupName("手机app端接口")
                .apiInfo(apiAppInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("cn.daliedu.controller.api.app"))//api接口包扫描路径
//                .paths(PathSelectors.regex(".*/admin/.*"))//可以根据url路径设置哪些请求加入文档，忽略哪些请求
                .paths(PathSelectors.any())
                .build();
//                .globalOperationParameters(setHeaderToken()); //将配置的header参数加上,如果不需要全局配置header参数，则注掉此行,注意.global方法要放在这个方法链的最后
    }
	
	private ApiInfo apiAppInfo() {
        return new ApiInfoBuilder()
                .title("手机app端接口")//设置文档的标题
//                .description("后台数据管理")//设置文档的描述->1.Overview
                .version("1.0")//设置文档的版本信息-> 1.1 Version information
                .build();
    }
	
	
	
	
    

    
}