package cn.daliedu.service.impl;

import cn.daliedu.entity.CustomerImportHistoryEntity;
import cn.daliedu.mapper.CustomerImportHistoryMapper;
import cn.daliedu.service.CustomerImportHistoryService;
import cn.daliedu.util.JsonUtil;
import cn.daliedu.util.StringUtil;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

/**
 * <p>
 * 客户导入历史表（用于导入时记录有问题的数据，如果有需求，可以开发定时任务清理此表中的数据） 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2020-02-18
 */
@Service
public class CustomerImportHistoryServiceImpl extends ServiceImpl<CustomerImportHistoryMapper, CustomerImportHistoryEntity> implements CustomerImportHistoryService {
	
	@Resource
	CustomerImportHistoryMapper customerImportHistoryMapper;
	
	@Override
	public IPage<CustomerImportHistoryEntity> getCustomerImportList(Map<Object, Object> map) {
		Integer pageNum = Integer.parseInt(map.get("pageNum").toString());
		Integer pageSize = Integer.parseInt(map.get("pageSize").toString());
		String userId = StringUtil.nullValueConvert(map.get("userId"));
		String mobile = StringUtil.nullValueConvert(map.get("mobile"));
		String customerName = StringUtil.nullValueConvert(map.get("customerName"));
		String importBatchNo = StringUtil.nullValueConvert(map.get("importBatchNo"));
		
		if (pageNum <= 0) {
			pageNum = 1;
		}
		IPage<CustomerImportHistoryEntity> page = new Page<CustomerImportHistoryEntity>();
		page.setCurrent(pageNum);
		page.setSize(pageSize);
		
		QueryWrapper<CustomerImportHistoryEntity> queryWrapper = new QueryWrapper<CustomerImportHistoryEntity>();
		if(!userId.equals("") && !userId.equals("null")){
			queryWrapper.eq("user_Id", userId);
		}
		if(!mobile.equals("") && !mobile.equals("null")){
			queryWrapper.eq("mobile", mobile);
		}
		if(!customerName.equals("") && !customerName.equals("null")){
			queryWrapper.eq("customer_name", customerName);
		}
		if(!importBatchNo.equals("") && !importBatchNo.equals("null")){
			queryWrapper.eq("import_batch_no", importBatchNo);
		}

		return customerImportHistoryMapper.selectPage(page, queryWrapper);
	}

	@Override
	public boolean deleteCustomerImportResultById(String ids) {
		List<String> idList = JsonUtil.getJsonToList(ids, String.class);
		int num = customerImportHistoryMapper.deleteBatchIds(idList);
		if(num>0){
			return true;
		}
		return false;
	}
	
	
	
	
}
