package cn.daliedu.entity.json;

import cn.daliedu.entity.CustomerTagEntity;
import groovy.transform.EqualsAndHashCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 客户标签属性json
 * @author xiechao
 * @time 2019年10月9日 上午11:29:44
 * @version 1.0.0 
 * @description 
 */
@ApiModel(value="客户标签属性",description="")
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class CustomerTagJson {
	/**
	 * 客户ID集合
	 */
	@ApiModelProperty(value="客户ID集合")
	private String[] customerIds;
	/**
	 * 客户所选的标签集合
	 */
	@ApiModelProperty(value="客户所选的标签集合")
	private CustomerTagEntity[] customerTagEntity;

}
