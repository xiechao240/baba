package cn.daliedu.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import cn.daliedu.entity.AreaDataEntity;
import cn.daliedu.mapper.AreaDataMapper;
import cn.daliedu.service.AreaDataService;

/**
 * <p>
 * 区域数据表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-11-05
 */
@Service
public class AreaDataServiceImpl extends ServiceImpl<AreaDataMapper, AreaDataEntity> implements AreaDataService {

	@Resource
	AreaDataMapper areaDataMapper;
	
	@Override
	public List<AreaDataEntity> findTreeAreaList() {
		List<AreaDataEntity> tempList = new ArrayList<>();
		List<AreaDataEntity> list = areaDataMapper.selectList(new QueryWrapper<AreaDataEntity>());
		for (AreaDataEntity entity : list) {
			if (entity.getParentId() == null || entity.getParentId() == 0) {
				entity.setLevel(0);
				tempList.add(entity);
			}
		}
		findChildren(tempList, list);
		return tempList;
	}

	private void findChildren(List<AreaDataEntity> tempList, List<AreaDataEntity> list) {
		for (AreaDataEntity entity : tempList) {
			List<AreaDataEntity> children = new ArrayList<>();
			for (AreaDataEntity bean : list) {
				if (entity.getId() != null && entity.getId().equals(bean.getParentId())) {
//					bean.setParentName(entity.getCityName()); //如果不要显示上级名称，则注掉此行代码
					bean.setLevel(entity.getLevel() + 1);
					children.add(bean);
				}
			}
			//解决设置一个空的children节点的问题，如果这个节点要一直存在，则不要加上为空或大于0的判断
			if(children!=null && children.size()>0){
				entity.setChildren(children);
			}
			findChildren(children, list);
		}
	}

}
