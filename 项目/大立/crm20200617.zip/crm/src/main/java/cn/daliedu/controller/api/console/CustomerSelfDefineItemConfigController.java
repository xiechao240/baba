package cn.daliedu.controller.api.console;


import java.time.LocalDateTime;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.util.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cn.daliedu.config.swagger.model.ApiJsonObject;
import cn.daliedu.config.swagger.model.ApiJsonProperty;
import cn.daliedu.entity.CustomerSelfDefineItemConfigEntity;
import cn.daliedu.entity.CustomerTagGroupEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.entity.json.CustomerSelfDefineItemJson;
import cn.daliedu.entity.json.CustomerTagGroupJson;
import cn.daliedu.entity.json.OrgJson;
import cn.daliedu.enums.ElementTypeEnum;
import cn.daliedu.exception.BusinessException;
import cn.daliedu.service.CustomerSelfDefineItemConfigDetailService;
import cn.daliedu.service.CustomerSelfDefineItemConfigService;
import cn.daliedu.service.CustomerSelfDefineItemService;
import cn.daliedu.service.CustomerTagGroupDetailService;
import cn.daliedu.service.CustomerTagGroupService;
import cn.daliedu.service.CustomerTagService;
import cn.daliedu.util.Result;
import cn.daliedu.util.StringUtil;

/**
 * <p>
 * 客户自定义类别配置表 前端控制器
 * </p>
 *
 * @author xiechao
 * @since 2020-05-20
 */
@RestController
@Api(description = "客户自定义类别相关接口")
@RequestMapping(value = "${rest.path}/console/customerSelfDefineItemConfig") 
public class CustomerSelfDefineItemConfigController {
	
	@Autowired
	CustomerSelfDefineItemService customerSelfDefineItemService;
	
	@Autowired
	CustomerSelfDefineItemConfigService customerSelfDefineItemConfigService;
	
	@Autowired
	CustomerSelfDefineItemConfigDetailService customerSelfDefineItemConfigDetailService;
	
	
	@ApiOperation(value = "为指定分校，还原为系统客户自定义信息分组，如果分校已经存在客户自定义分组，则不还原，否则做还原操作")
	@ApiImplicitParam(paramType = "query", dataType = "String", name = "branchOrgId", value = "分校ID", required = true)
	@PostMapping("/restoreCustomerSelfDefineItemByBranchOrgId")
	public Result restoreCustomerSelfDefineItemByBranchOrgId(@RequestParam(name="branchOrgId",required=true)String branchOrgId) {
		try {
			boolean flag = customerSelfDefineItemConfigService.restoreCustomerSelfDefineItemByBranchOrgId(branchOrgId);
			if(flag){
				return Result.success("");
			}
			return Result.error("暂无数据");
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户自定义分组集合接口失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "获取客户自定义分组集合接口,如果不传分校ID，则获取的是系统初始化的自定义分组")
	@ApiImplicitParam(paramType = "query", dataType = "String", name = "branchOrgId", value = "分校ID", required = false)
	@PostMapping("/findCustomerSelfDefineItemList")
	public Result findCustomerSelfDefineItemList(@RequestParam(name="branchOrgId",defaultValue="")String branchOrgId) {
		try {
			List<CustomerSelfDefineItemConfigEntity> list = customerSelfDefineItemConfigService.findCustomerSelfDefineItemList(branchOrgId);
			if(!CollectionUtils.isEmpty(list)){
				return Result.success(list);
			}
			return Result.error("暂无数据");
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取标签分组集合接口失败，失败原因：" + e.getMessage());
		}
	}
	
	@ApiOperation(value = "获取客户自定义分组及【自定义明细】接口,如果不传分校ID，则获取的是系统初始化的自定义分组及明细数据")
	@ApiImplicitParam(paramType = "query", dataType = "String", name = "branchOrgId", value = "分校ID", required = false)
	@PostMapping("/findCustomerSelfDefineItemAndDetailList")
	public Result findCustomerSelfDefineItemAndDetailList(@RequestParam(name="branchOrgId",defaultValue="")String branchOrgId) {
		try {
			List<CustomerSelfDefineItemConfigEntity> list = customerSelfDefineItemConfigService.findCustomerSelfDefineItemAndDetailList(branchOrgId);
			if(!CollectionUtils.isEmpty(list)){
				return Result.success(list);
			}
			return Result.error("当前无客户自定义数据");
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("获取客户自定义分组及【自定义明细】失败，失败原因：" + e.getMessage());
		}
	}

	@ApiOperation(value = "新增客户自定义分组接口")
	@ApiJsonObject(name = "saveCustomerSelfDefineItem", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerSelfDefineItemJson.itemName),
			@ApiJsonProperty(name = CustomerSelfDefineItemJson.elementType)})
	@ApiImplicitParam(name = "params", required = true, dataType = "saveCustomerSelfDefineItem")
	@PostMapping("/saveCustomerSelfDefineItem")
	public Result saveCustomerSelfDefineItem(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String branchOrgId = String.valueOf(jsonObject.get("branchOrgId"));
			String itemName = String.valueOf(jsonObject.get("itemName"));
			String elementType = String.valueOf(jsonObject.get("elementType"));
			
//			StringUtil.validateIsNull(branchOrgId, "请输入分校ID");
			StringUtil.validateIsNull(itemName, "请输入客户标签分组名称");
			StringUtil.validateIsNull(elementType, "请输入组件类型");
			
			if(!ElementTypeEnum.isInclude(elementType)){
				return Result.error("请选择正确的组件类型");
			}
			
			branchOrgId = branchOrgId.trim();
			itemName = itemName.trim();
			elementType = elementType.trim();
			
			if(customerSelfDefineItemConfigService.existsCustomerSelfDefineItemName(itemName)){
				return Result.error("此客户自定义分组已经存在，请重新输入");
			}else{
				//保存客户标签分组
				CustomerSelfDefineItemConfigEntity entity = new CustomerSelfDefineItemConfigEntity();
				entity.setBranchOrgId(branchOrgId);
				entity.setItemName(itemName);
				Integer orderNum = customerSelfDefineItemConfigService.getMaxCustomerSelfDefineItemValue(branchOrgId);
				entity.setOrderNum(orderNum==null ? 0 : orderNum+1);
				entity.setElementType(elementType);
				entity.setIsEnabled(true);
				
				if(branchOrgId.equals("null") || branchOrgId.equals("")){
					entity.setIsInit(true);
				}else{
					entity.setIsInit(false);
				}
				
				
				boolean flag = customerSelfDefineItemConfigService.save(entity);
				if(flag){
					return Result.success("新增成功！");
				}
				return Result.error("新增失败");
			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("新增客户标签分组失败，失败原因：" + e.getMessage());
		}
	}

	@ApiOperation(value = "修改客户自定义分组接口")
	@ApiJsonObject(name = "updateCustomerSelfDefineItem", value = { 
			@ApiJsonProperty(name = OrgJson.branchOrgId),
			@ApiJsonProperty(name = CustomerSelfDefineItemJson.itemId),
			@ApiJsonProperty(name = CustomerSelfDefineItemJson.itemName),
			@ApiJsonProperty(name = CustomerSelfDefineItemJson.elementType),
			@ApiJsonProperty(name = OrgJson.orderNum)})
	@ApiImplicitParam(name = "params", required = true, dataType = "updateCustomerSelfDefineItem")
	@PostMapping("/updateCustomerSelfDefineItem")
	public Result updateCustomerSelfDefineItem(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String itemId = String.valueOf(jsonObject.get("itemId"));
			String itemName = String.valueOf(jsonObject.get("itemName"));
			String orderNum = String.valueOf(jsonObject.get("orderNum"));
			String elementType = String.valueOf(jsonObject.get("elementType"));
			
			StringUtil.validateIsNull(itemId, "请输入客户标签分组类型ID");
			StringUtil.validateIsNull(itemName, "请输入客户标签分组类型名称");
			StringUtil.validateIsNull(orderNum, "请输入排序号");
			StringUtil.validateIsNull(elementType, "请输入组件类型");
			
			if(!ElementTypeEnum.isInclude(elementType)){
				return Result.error("请选择正确的组件类型");
			}
			
			itemId  = itemId.trim();
			itemName = itemName.trim();
			orderNum = orderNum.trim();
			
			
			//不能存在同名的标签分组,修改的时候就不判断了吧
//			if(customerSelfDefineItemConfigService.existsCustomerSelfDefineItemName(itemName)){
//				return Result.error("此客户自定义分组已经存在，请重新输入");
//			}else{
				//修改客户标签分组
				CustomerSelfDefineItemConfigEntity entity = new CustomerSelfDefineItemConfigEntity();
				entity.setItemId(itemId);
				entity.setItemName(itemName);
				entity.setOrderNum(Integer.parseInt(orderNum));
				entity.setElementType(elementType);
				
				
				boolean flag = customerSelfDefineItemConfigService.updateById(entity);
				if(flag){
					return Result.success("修改成功！");
				}
				return Result.error("修改失败");
//			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("修改客户自定义分组失败，失败原因：" + e.getMessage());
		}
	}

	@ApiOperation(value = "删除客户自定义分组接口(如果已经被客户使用，则不允许删除),此分组只能一个一个删除，不能批量删除，因为要判断标签是否被使用")
	@ApiJsonObject(name = "deleteCustomerSelfDefineItemById", value = { 
			@ApiJsonProperty(name = CustomerSelfDefineItemJson.itemId) })
	@ApiImplicitParam(name = "params", required = true, dataType = "deleteCustomerSelfDefineItemById")
	@PostMapping("/deleteCustomerSelfDefineItemById")
	public Result deleteCustomerSelfDefineItemById(@RequestBody String params) {
		try {
			System.out.println("params参数为：" + params);
			JSONObject jsonObject = JSON.parseObject(params);
			String itemId = String.valueOf(jsonObject.get("itemId"));
			
			StringUtil.validateIsNull(itemId, "请输入客户自定义分组类型ID");
			
			itemId = itemId.trim();
			
			if(customerSelfDefineItemService.existsCustomerSelfDefineItemConfigUse(itemId)){
				return Result.error("此自定义分组已经被使用，不能删除");
			}else{
				boolean flag = customerSelfDefineItemConfigService.removeCustomerSelfDefineItem(Integer.parseInt(itemId));
				if(flag){
					return Result.success("删除成功！");
				}
				return Result.error("删除失败");
			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error("删除自定义分组失败，失败原因：" + e.getMessage());
		}
	}
	
	
}
