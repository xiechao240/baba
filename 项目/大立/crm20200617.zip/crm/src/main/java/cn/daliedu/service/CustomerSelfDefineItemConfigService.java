package cn.daliedu.service;

import cn.daliedu.entity.CustomerSelfDefineItemConfigEntity;
import cn.daliedu.entity.CustomerTagGroupEntity;

import java.util.List;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 客户自定义类别配置表 服务类
 * </p>
 *
 * @author xiechao
 * @since 2020-05-20
 */
public interface CustomerSelfDefineItemConfigService extends IService<CustomerSelfDefineItemConfigEntity> {
	
	
	/**
	 * 根据客户标签分组类型ID，获取当前客户标签对应的最大值
	 * @param customerTagTypeId 客户标签分组类型ID
	 */
	public Integer getMaxCustomerSelfDefineItemValue(String branchOrgId);
	
	/**
	 * 还原为系统自定义信息
	 * @param branchOrgId 分校ID
	 * @return
	 */
	boolean restoreCustomerSelfDefineItemByBranchOrgId(String branchOrgId);
	
	/**
	 * 根据客户ID获取客户的自定义信息及明细信息
	 * @param branchOrgId 
	 * @param customerId
	 * @return
	 */
	List<CustomerSelfDefineItemConfigEntity> getCustomerSelfDefineItemByCustomerId(String branchOrgId, String customerId);
	
	/**
	 * 获取客户自定义信息及信息明细
	 * @param branchOrgId 如果不传分校ID，则加载系统初始化的客户标签分组
	 * @return
	 */
	public List<CustomerSelfDefineItemConfigEntity> findCustomerSelfDefineItemAndDetailList(String branchOrgId);
	
	/**
	 * 获取客户自定义信息分组
	 * @param branchOrgId 如果不传分校ID，则加载系统初始化的客户标签分组
	 * @return
	 */
	public List<CustomerSelfDefineItemConfigEntity> findCustomerSelfDefineItemList(String branchOrgId);
	
	/**
	 * 判断数据库中是否已经存在自定义分组标签，简单防止同名的自定义组加入
	 * @param customerTagTypeName
	 * @return
	 */
	public boolean existsCustomerSelfDefineItemName(String itemName);
	
	/**
	 * 删除客户自定义分组，同时删除客户自定义分组明细
	 * @param customerTagTypeId
	 * @return
	 */
	public boolean removeCustomerSelfDefineItem(Integer itemId)  throws Exception;
	
	
}
