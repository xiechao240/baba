package cn.daliedu.service.impl;

import cn.daliedu.entity.CustomerFlowCauseConfigEntity;
import cn.daliedu.mapper.CustomerFlowCauseConfigMapper;
import cn.daliedu.service.CustomerFlowCauseConfigService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 客户流转原因配置表 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-10-15
 */
@Service
public class CustomerFlowCauseConfigServiceImpl extends ServiceImpl<CustomerFlowCauseConfigMapper, CustomerFlowCauseConfigEntity> implements CustomerFlowCauseConfigService {

}
