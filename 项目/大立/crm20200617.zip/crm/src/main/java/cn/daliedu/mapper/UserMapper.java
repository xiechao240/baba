package cn.daliedu.mapper;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import cn.daliedu.entity.UserEntity;

/**
 * <p>
 * 用户管理 Mapper 接口
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
public interface UserMapper extends BaseMapper<UserEntity> {
	
	public List<LinkedHashMap<Object, Object>> findAgentUserListByUserId(Map<Object, Object> map);


	public Long findAgentUserListByUserIdCount(Map<Object, Object> map);
	
	
	/**
	 * 查询指定机构下面的员工（不包含子孙机构下面的员工）
	 * @param orgId  机构ID(必传参数)
	 * @return
	 */
	public List<UserEntity> getUserListByOrgId(String orgId);
	
	/**
	 * 查询机构下面的员工(包含分校下子孙机构下面的员工)
	 * @param orgId  机构ID(必传参数)
	 * @return
	 */
	public List<UserEntity> getUserListByBranchOrgId(Map<Object, Object> map);
	
	/**
	 * 查询机构下面的员工(包含分校下子孙机构下面的员工)
	 * @param orgId  机构ID(必传参数)
	 * @return
	 */
	public Long getUserListByBranchOrgIdCount(Map<Object, Object> map);
	
	
	/**
	 * 查询机构下面的员工（不包含子孙机构下面的员工）
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> findUserListByOrgId(Map<Object, Object> map);
	
	/**
	 * 根据查询条件，查询机构下面的用户总数
	 * @param map 查询组合参数集合
	 * @return
	 */
	public Long findUserListByOrgIdCount(Map<Object, Object> map);
	
	/**
	 * 查询机构下面的员工（包含子孙机构下面的员工）
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> findUserListByOrgIdAndChildren(Map<Object, Object> map);
	
	/**
	 * 根据查询条件，查询机构下面的用户总数
	 * @param map 查询组合参数集合
	 * @return
	 */
	public Long findUserListByOrgIdAndChildrenCount(Map<Object, Object> map);
	
	
	
	
	/**
	 * 根据传入的用户类型，获取同级别的交接人员列表
	 * @param map
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> findUserListByUserType(Map<Object, Object> map);
	
	/**
	 * 根据传入的用户类型，获取同级别的交接人员列表数量
	 * @param map
	 * @return
	 */
	public Long findUserListByUserTypeCount(Map<Object, Object> map);
	
	
	/**
	 * 根据权限过滤，查询代理商节点下面的用户集合
	 * @param map
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> findUserListByAgent(Map<Object, Object> map);
	
	/**
	 * 根据权限过滤，查询代理商节点下面的用户数量
	 * @param map
	 * @return
	 */
	public Long findUserListByAgentCount(Map<Object, Object> map);
	
	/**
	 * 【客户标签变化统计】按分校统计一段时间范围内的，所有分校用户的客户标签 
	 * @param map 查询组合参数集合
	 * @return
	 */
	public Integer getCustomerTagUpdateByCustomerTagAllCount(Map<Object, Object> map);
	
	
	/**
	 * 【客户标签变化统计】获取客户标签变化的用户的标签数
	 * @param map 查询组合参数集合
	 * @return
	 */
	public Integer getCustomerTagUpdateByCustomerTag(Map<Object, Object> map);
	
	/**
	 * 【客户标签变化统计】获取客户标签变化的用户（没有打标签的用户，将不出现在结果集中）
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getCustomerTagUpdateByUser(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【电话联系统计】获取分校的电话联系的客户数
	 * @param map 查询组合参数集合
	 * @return
	 */
	public Integer getCallContactCustomerCount(Map<Object, Object> map);
	
	/**
	 * 【电话联系统计】获取分校的电话联系统计报表
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getCallContactDetailCount(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【工作效率统计】获取新增客户数量排名列表
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getAddCustomerCountTopList(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【工作效率统计】获取新增客户数量排名列表总数
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public Long getAddCustomerCountTopListCount(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【电话排名】获取电话联系统计列表
	 * @param map 查询组合参数集合
	 * @return
	 * @throws Exception
	 */
	public List<LinkedHashMap<Object, Object>> getCallRankingByContactList(Map<Object, Object> map) throws Exception;
	
	/**
	 * 【电话排名】获取电话联系统计列表总数
	 * @param map 查询组合参数集合
	 */
	public Long getCallRankingByContactListCount(Map<Object, Object> map);
	
	
	
	
	/**
	 * 根据客户ID，获取所有共享给我的客户用户列表
	 * @param customerId
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getShareRelationUsers(String customerId);
	
	/**
	 * 获取收款人用户列表（应该返回整个公司的所有员工，超级管理员除外）
	 * @param map 查询组合参数集合
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> getReceiptUserList(Map<Object, Object> map);
	
	/**
	 * 获取收款人用户列表总数（应该返回整个公司的所有员工，超级管理员除外）
	 * @param map 查询组合参数集合
	 * @return
	 */
	public Long getReceiptUserListCount(Map<Object, Object> map);
	

	
	
	/**
	 * 查询已禁用的员工或已离职的员工列表
	 * @param map 查询组合参数集合
	 * @return
	 */
	public List<LinkedHashMap<Object, Object>> findUserListByUserState(Map<Object, Object> map);
	
	/**
	 * 查询已禁用的员工或已离职的员工列表总数
	 * @param map 查询组合参数集合
	 * @return
	 */
	public Long findUserListByUserStateCount(Map<Object, Object> map);
	
	/**
	 * 获取客户的跟进人列表
	 * @param map 查询组合参数集合
	 * @return
	 */
	public List<UserEntity> getFollowUserList(Map<Object, Object> map);
	
	/**
	 * 获取客户的跟进人列表总数
	 * @param map 查询组合参数集合
	 * @return
	 */
	public Long getFollowUserListCount(Map<Object, Object> map);
	
	/*
	 * 根据用户ID获取用户名称与机构名称
	 */
	public LinkedHashMap<Object, Object> getUserNameAndOrgNameByUserId(String userId);
}
