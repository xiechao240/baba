package cn.daliedu.entity.web;

import java.io.Serializable;
import java.util.List;

public class MenuNode implements Serializable{

	private static final long serialVersionUID = 3947907013587170250L;
	
	private Integer parentId;
	private Integer id;
	private String name;
	private String href;
	private String permission;

	//子菜单
	private List<MenuNode> children;

	
	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHref() {
		return href;
	}

	public void setHref(String href) {
		this.href = href;
	}

	public String getPermission() {
		return permission;
	}

	public void setPermission(String permission) {
		this.permission = permission;
	}

	public List<MenuNode> getChildren() {
		return children;
	}

	public void setChildren(List<MenuNode> children) {
		this.children = children;
	}
	
}
