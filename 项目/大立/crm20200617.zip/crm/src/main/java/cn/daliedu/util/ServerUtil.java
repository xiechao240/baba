package cn.daliedu.util;

import java.lang.management.ManagementFactory;
import java.util.Set;

import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.management.Query;

/**
 * 服务器工具类
 * @author xiechao
 * @time 2019年12月28日 下午3:33:02
 * @version 1.0.0 
 * @description 
 */
public class ServerUtil {
	/**
	 * 返回服务器端口号
	 * @return
	 * @throws Exception
	 */
	public static String getServerReport() throws Exception{
		MBeanServer beanServer = ManagementFactory.getPlatformMBeanServer();
		Set<ObjectName> objectNames = beanServer.queryNames(new ObjectName("*:type=Connector,*"),
				Query.match(Query.attr("protocol"), Query.value("HTTP/1.1")));
		String port = objectNames.iterator().next().getKeyProperty("port");
		return port;
	}
}
