package cn.daliedu.config.param;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
/**
 * 全局系统配置常量获取类（连接对外的系统的参数定义在此类）
 * @author xiechao
 * @time 2019年1月9日 上午10:58:42
 * @version 1.0.0
 * @description 
 */

//@Configuration
public class GlobalParamConfig {
	


}