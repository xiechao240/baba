package cn.daliedu.config.job;

import java.net.InetAddress;
import java.util.Date;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import cn.daliedu.config.param.SysParamConfig;
import cn.daliedu.service.ContractReturnMoneyPlanService;
import cn.daliedu.service.CustomerCountService;
import cn.daliedu.service.CustomerService;
import cn.daliedu.service.OrgService;
import cn.daliedu.service.UserService;
import cn.daliedu.util.DateUtil;

@DisallowConcurrentExecution //作业不并发
@Component
public class UpdateContractReturnMoneyPlanJob implements Job{
	@Autowired
	OrgService orgService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	CustomerCountService customerCountService;
	
	@Autowired
	ContractReturnMoneyPlanService contractReturnMoneyPlanService;
	
    @Override
    public void execute(JobExecutionContext arg0) throws JobExecutionException {
        if(SysParamConfig.jobIsRun()){
        	try {
        		contractReturnMoneyPlanService.updateReturnMoneyStateByScheduleTask();
        		
//        		Integer num = contractReturnMoneyPlanService.updateReturnMoneyStateByScheduleTask();
//        		if(num>0){
//        			System.out.println("更新成功");
//        		}
//        		System.out.println("未更新到数据" + num);
//                System.err.println("执行静态定时任务时间: " + LocalDateTime.now());
    		} catch (Exception e) {
    			System.out.println("执行定时任务出现异常");
    			e.printStackTrace();
    		}
        }
    }

}