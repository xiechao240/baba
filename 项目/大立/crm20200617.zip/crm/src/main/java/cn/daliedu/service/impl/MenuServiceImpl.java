package cn.daliedu.service.impl;

import cn.daliedu.entity.MenuEntity;
import cn.daliedu.entity.UserEntity;
import cn.daliedu.enums.UserTypeEnum;
import cn.daliedu.mapper.MenuMapper;
import cn.daliedu.service.MenuService;
import cn.daliedu.service.UserService;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 菜单管理 服务实现类
 * </p>
 *
 * @author xiechao
 * @since 2019-09-19
 */
@Service
public class MenuServiceImpl extends ServiceImpl<MenuMapper, MenuEntity> implements MenuService {
	@Resource
	MenuMapper menuMapper;
	
	@Autowired
	UserService userService;
	
	
	
	

	@Override
	public List<MenuEntity> getTreeMenuListByParentId(Integer parentId) {
		List<MenuEntity> tempMenuList = new ArrayList<>();
		List<MenuEntity> menuList = menuMapper.getTreeMenuListByParentId(parentId);
		
		for (MenuEntity menu : menuList) {
			if (menu.getId() == parentId) {//注意这里的区别，如果这个菜单节点与传入的parentId相同，则为顶级节点，并从此节点下去遍历子孙节点
				menu.setLevel(0);
				if(!exists(tempMenuList, menu)) {
					tempMenuList.add(menu);
				}
			}
		}
		tempMenuList.sort((o1, o2) -> o1.getOrderNum().compareTo(o2.getOrderNum()));
		findChildren(tempMenuList, menuList, "0");
		return tempMenuList;
	}

	
	@Override
	public List<MenuEntity> getTreeMenuListByRoleId(String roleId) {
		List<MenuEntity> tempMenuList = new ArrayList<>();
		List<MenuEntity> menuList = getMenuListByRoleId(roleId);
		
		for (MenuEntity menu : menuList) {
			if (menu.getParentId() == null || menu.getParentId() == 0) {
				menu.setLevel(0);
				if(!exists(tempMenuList, menu)) {
					tempMenuList.add(menu);
				}
			}
		}
		tempMenuList.sort((o1, o2) -> o1.getOrderNum().compareTo(o2.getOrderNum()));
		findChildren(tempMenuList, menuList, "0");
		return tempMenuList;
	}
	
	@Override
	public List<MenuEntity> getMenuListByRoleId(String roleId) {
		 return menuMapper.getMenuListByRoleId(roleId);
	}
	
	
	@Override
	public List<MenuEntity> getMenuListByUserId(String userId) {
		 return menuMapper.getMenuListByUserId(userId);
	}
	
	
	@Override
	public List<MenuEntity> findMenuTree(String menuType) {
		List<MenuEntity> tempMenuList = new ArrayList<>();
		List<MenuEntity> menuList = menuMapper.selectList(new QueryWrapper<MenuEntity>());
		
		for (MenuEntity menu : menuList) {
			if (menu.getParentId() == null || menu.getParentId() == 0) {
				menu.setLevel(0);
				if(!exists(tempMenuList, menu)) {
					tempMenuList.add(menu);
				}
			}
		}
		tempMenuList.sort((o1, o2) -> o1.getOrderNum().compareTo(o2.getOrderNum()));
		findChildren(tempMenuList, menuList, menuType);
		return tempMenuList;
	}

	@Override
	public List<MenuEntity> findTree(String userId, String menuType) {
		Subject subject = SecurityUtils.getSubject();
		UserEntity user = (UserEntity) subject.getPrincipal();
		List<MenuEntity> menuList = null;
		if(user.getUserType().equals(UserTypeEnum.TYPE_1.getValue())){
			menuList = this.list();
		}else{
			menuList = menuMapper.getMenuListByUserId(userId);
		}
		
		
		//下面的为组装成json层级
		List<MenuEntity> tempMenuList = new ArrayList<>();
		
		for (MenuEntity menu : menuList) {
			if (menu.getParentId() == null || menu.getParentId() == 0) {
				menu.setLevel(0);
				if(!exists(tempMenuList, menu)) {
					tempMenuList.add(menu);
				}
			}
		}
		tempMenuList.sort((o1, o2) -> o1.getOrderNum().compareTo(o2.getOrderNum()));
		findChildren(tempMenuList, menuList, menuType);
		return tempMenuList;
	}
	
	
//	@Override
//	public List<MenuEntity> findTree(Integer userId, int menuType) {
//		List<MenuEntity> tempMenuList = new ArrayList<>();
//		List<MenuEntity> menuList = getMenuListByUserId(userId);
//		for (MenuEntity menu : menuList) {
//			if (menu.getParentId() == null || menu.getParentId() == 0) {
//				menu.setLevel(0);
//				if(!exists(tempMenuList, menu)) {
//					tempMenuList.add(menu);
//				}
//			}
//		}
//		tempMenuList.sort((o1, o2) -> o1.getOrderNum().compareTo(o2.getOrderNum()));
//		findChildren(tempMenuList, menuList, menuType);
//		return tempMenuList;
//	}

	@Override
	public List<MenuEntity> findByUser(String userId) {
		//待实现，超级管理员的代码写法
//		if(userName == null || "".equals(userName) || SysConstants.ADMIN.equalsIgnoreCase(userName)) {
//			return menuMapper.findAll();
//		}
//		return menuMapper.findByUserName(userName);
		return null;
	}

	private void findChildren(List<MenuEntity> tempMenuList, List<MenuEntity> menuList, String menuType) {
		for (MenuEntity entity : tempMenuList) {
			List<MenuEntity> children = new ArrayList<>();
			for (MenuEntity bean : menuList) {
//				if(menuType.equals("1") && bean.getType().equals("2")) {
//					// 如果是获取类型不需要按钮，且菜单类型是按钮的，直接过滤掉
//					continue ;
//				}
				if (entity.getId() != null && entity.getId().equals(bean.getParentId())) {
//					bean.setParentName(entity.getName());
					bean.setLevel(entity.getLevel() + 1);
					if(!exists(children, bean)) {
						children.add(bean);
					}
				}
			}
			entity.setChildren(children);
			children.sort((o1, o2) -> o1.getOrderNum().compareTo(o2.getOrderNum()));
			findChildren(children, menuList, menuType);
		}
	}

	private boolean exists(List<MenuEntity> menuList, MenuEntity entity) {
		boolean exist = false;
		for(MenuEntity menu : menuList) {
			if(menu.getId().equals(entity.getId())) {
				exist = true;
			}
		}
		return exist;
	}
}
