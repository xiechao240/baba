# pom-generator

说明：
	此工程为Mybatis Plus框架自动生成代码

运行说明：
	此项目为超级精简的项目，专门用来生成代码使用，因为在正式编写代码的项目中直接生成代码，容易导致已经编写的代码被覆盖，
	所以编写这个工程，经过编写经验来看，变动主要是数据库新增或删除字段，所以只需要运行这个项目，替换相应的
	model, mapper*.xml文件即可，其他文件可以不需要替换

运行方式：
	CodeGenerator类专门用来根据数据库表，生成相应的
		controller,
		model,
		mapper,
		service,
		serviceImpl,
		mapper*.xml

